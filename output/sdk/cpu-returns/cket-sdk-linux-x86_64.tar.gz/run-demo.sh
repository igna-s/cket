#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export CKET_SIMULATOR=sparse CKET_SEED=7
printf '%s
' 'C Ket RC3: native C statevector simulation, 37 prebuilt programs'
for block in 01 02 03 04 05 06; do
    for program in build/blocks/"$block"/*; do
        [[ -x "$program" && "$program" != *.* ]] || continue
        printf '
%s
' "$program"
        "$program"
    done
done
