#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p user
cat > user/program.c
CC=gcc-11 build/cket user/program.c -O2 -o user/program
CKET_SIMULATOR=sparse CKET_SEED=7 user/program
