# Compilador C Ket listo para Linux/WSL

Candidata experimental 1.0.0-rc.3. Requiere Linux x86-64, glibc y GCC 11.4.0 (gcc-11).
El compilador, plugin GCC, runtime C y 37 programas de los seis bloques vienen construidos.

Ejecutar sin recompilar:

```sh
sha256sum -c --status SHA256SUMS
bash run-demo.sh
```

Compilar un programa propio desde la raíz del paquete:

```sh
CC=gcc-11 ./cket mi_programa.c -O2 -o mi_programa
CKET_SIMULATOR=sparse ./mi_programa
```

Incluye las fuentes de compilador, headers y ejemplos, circuitos estáticos disponibles e
informes de recursos. Las funciones, arrays, punteros, heap y biblioteca frecuente conservan
sus contratos parciales. Direcciones, I/O y ciberseguridad siguen siendo clásicas; medir es
explícito. El backend ejecuta puertas y amplitudes complejas en un simulador C.

El simulador denso admite 24 qubits; el disperso y la representación de circuito llegan a
128 cables con presupuesto de soporte y trabajo. Una operación definida en C puede exceder
recursos o no estar implementada en el perfil cuántico. Flotantes cuánticos, ABI/punteros/vidas
generales y partes de la integración siguen pendientes. No es C11 completo, una 1.0 estable,
ejecución en QPU física ni garantía de ventaja frente a CPU.

Los 37 programas ejecutados y la suite de 1509 ejemplos verifican usos finitos y salidas;
las pruebas de coherencia, estados e inversas se conservan en las cápsulas del repositorio.
La identidad exacta de las 244 entradas está en compiler-source-sha256.json.

Los procedimientos void admiten retornos CPU anticipados y locales enteros privados, puros e inmutables desde llamadores coherentes.
Ejemplo: examples/coherent_returns.c. Se conservan los contratos de limpieza,
préstamo y copia; las salidas decididas por datos cuánticos, los bucles coherentes y la ABI general siguen pendientes.
