C Ket: demo nativa de buffers y longitudes CPU
Linux x86-64 / WSL. Simulador de estado disperso, operaciones reversibles.

Windows: ejecutar run_memory_demo.cmd desde una consola. Lanza los casos 0, 1 y 2.
El lanzador usa stdin para transferir el paquete a /tmp de WSL; no monta Windows.

Linux: extraer este archivo y ejecutar:
  CKET_SIMULATOR=sparse CKET_SEED=7 ./bin/buffer_lengths 2
También acepta 0 y 1. El programa comprueba sus resultados y devuelve 0 si coinciden.
Requisitos: Linux x86-64 con glibc compatible con Ubuntu 22.04; no requiere GCC para ejecutar.

Código: da2ffb31e568026d58b8e5d98aa31929171cfac0
Binario SHA-256: 1438154403a1cd693c0ca78bdd9eb5c1a8fd83190bcf4a04a8916b9174d55deb
Fuente: source/buffer_lengths.c. Evidencia finita: evidence-summary.json.
Las fuentes completas del compilador y su reproducción están en el repositorio.
El perfil cotidiano completo continúa en desarrollo; no hay demostración de QPU física o aceleración.
