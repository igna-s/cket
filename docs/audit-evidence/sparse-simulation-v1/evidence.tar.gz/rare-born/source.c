#include "internal.h"
#include <math.h>
#include <stdio.h>

int main(void) {
    qc_context *c = qc_create(1, UINT64_C(0x61c8864680b583eb));
    if (!c || !qc_apply(c, "{\"op\":\"qalloc\",\"id\":0,\"width\":1,\"signed\":false}", NULL) ||
        !qc_apply(c, "{\"op\":\"qprepare\",\"id\":0,\"lower\":0,\"upper\":0}", NULL) ||
        !qc_emit(c, QC_H, 0, 0, 0, 0) || !qc_emit(c, QC_PHASE, 0, 1, 1, 2e-8) ||
        !qc_emit(c, QC_H, 0, 0, 0, 0))
        return 2;
    double probability = pow(cabs(qc_amplitude(c, 1)), 2);
    int observed = qc_sim_measure(c, 0);
    printf("probability=%.17g observed=%d expected=1\n", probability, observed);
    qc_destroy(c);
    return observed != 1;
}
