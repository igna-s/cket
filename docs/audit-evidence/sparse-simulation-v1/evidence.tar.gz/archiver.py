from pathlib import Path
import hashlib
import json
import re
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/sparse-v1'
out = root / 'docs/audit-evidence/sparse-simulation-v1'
out.mkdir(parents=True, exist_ok=True)
assert not (out / 'summary.json').exists()
read = lambda p: json.loads(p.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = read(project / 'build/sources.json')
assert len(sources) == 159 and all(digest(project / n) == sha for n, sha in sources.items())
assert all(digest(root / n) == sha for n, sha in sources.items())
records = {}
for configuration in ['normal', 'sanitized']:
    directory = project / ('build/qualification-' + configuration + '-v1')
    record = read(directory / 'exit.json')
    assert record['status'] == 'passed-sparse-targeted' and record['exit_code'] == 0
    assert record['source_sha256'] == sources
    assert all(c['returncode'] == 0 and digest(directory / c['log']) == c['log_sha256'] for c in record['commands'])
    assert '88 sparse simulation checks passed' in (directory / 'validate_sparse.log').read_text()
    assert '393 passed, 0 failed' in (directory / 'native-regression.log').read_text()
    assert '1509 checks passed across 37 examples' in (directory / 'example-regression.log').read_text()
    records[configuration] = record
rare = read(project / 'build/rare-born-baseline-v1/result.json')
assert rare['status'] == 'confirmed-rare-born-cutoff-fix'
reports = {n: (project / ('build/blocks/02/' + n + '.resources.txt')).read_text() for n in ['wide_integers', 'wide_size']}
peaks = {n: int(re.search(r'Peak qubits:\s+(\d+)', text)[1]) for n, text in reports.items()}
assert peaks == {'wide_integers': 99, 'wide_size': 84}
with tarfile.open(out / 'evidence.tar.gz', 'w:gz') as archive:
    for name in sources:
        archive.add(project / name, arcname='sources/' + name)
    for configuration in records:
        directory = project / ('build/qualification-' + configuration + '-v1')
        for path in sorted(directory.iterdir()):
            if path.is_file() and path.suffix in {'.json', '.log', '.py'}:
                archive.add(path, arcname='records/' + configuration + '/' + path.name)
    for path in sorted((project / 'build/rare-born-baseline-v1').iterdir()):
        if path.is_file() and path.suffix in {'.c', '.json', '.log'}:
            archive.add(path, arcname='rare-born/' + path.name)
    for path in sorted((project / 'build/blocks/02').iterdir()):
        if path.is_file() and path.suffix in {'.qasm', '.txt'}:
            archive.add(path, arcname='block02/' + path.name)
    archive.add(__file__, arcname='archiver.py')
summary = {
    'status': 'passed-targeted-sparse-and-native-wide-examples',
    'source_files': 159, 'source_sha256': sources,
    'checks_per_configuration': {'sparse': 88, 'native': 393, 'examples': 1509},
    'closed_commands_zero': {n: len(r['commands']) for n, r in records.items()},
    'normal_build': 'fresh-full-build',
    'sanitized_build': 'fresh-engine-runtime-driver-backend-validators; byte-verified unchanged GCC plugin reused',
    'plugin_reuse': records['sanitized']['plugin_reuse'],
    'wide_examples_peak_qubits': peaks,
    'rare_born_reproduction': rare,
    'scope': '32 finite phased gate/inverse domains compared with dense amplitudes at every step; selected high wires up to127, measurement/reset channels, support bounds, small-probability regression; int32/LP64-size_t native programs at O0/O2 across eight seeds each. Native/example regression is the existing393/1509 corpus, not full C11 coverage.',
    'block02_status': 'usable-advance; integer foundation remains open',
    'broad_regression': 'pending-for-these-inputs', 'remote_ci': 'pending-for-these-inputs',
    'artifact_sha256': {'evidence.tar.gz': digest(out / 'evidence.tar.gz')},
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Archived159 sparse inputs; all targeted commands zero:', summary['closed_commands_zero'], 'bytes:', (out / 'evidence.tar.gz').stat().st_size)
