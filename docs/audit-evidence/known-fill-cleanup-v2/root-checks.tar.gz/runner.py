from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

root=Path('/tmp/quantum-audit-isolated-20261017')
out=root/'build/known-fill-root-checks-v1'
write=lambda p,r:p.write_text(json.dumps(r,indent=2)+'\n')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if '--worker' not in sys.argv:
    out.mkdir();shutil.copy2(Path(__file__),out/'runner.py')
    with (out/'worker.log').open('x') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    write(out/'job.json',{'pid':child.pid,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print('Started fresh applied-root checks:',child.pid)
    raise SystemExit(0)
r={'status':'running','commands':[],'programs':{},'scope':'Fresh normal build and20 exact contract executions in the isolated Linux root after source application. The candidate normal/SAN suites and independent states remain separate; no full root regression or Windows-native execution is claimed.'}
env=dict(os.environ,CC='gcc-11',CXX='g++-11')
def command(name,args):
    path=out/(name+'.log')
    with path.open('x') as log:
        p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    r['commands'].append({'name':name,'argv':list(map(str,args)),'returncode':p.returncode,'log':path.name,'log_sha256':digest(path)})
    write(out/'progress.json',r);assert p.returncode==0,(name,path.read_text()[-4000:])
try:
    frozen=json.loads((root/'docs/audit-evidence/known-fill-cleanup-v2/verified-sources.json').read_text())
    assert len(frozen)==146 and all(digest(root/name)==sha for name,sha in frozen.items())
    r['source_sha256']=frozen
    command('fresh-normal-build',['bash',root/'scripts/build.sh'])
    programs={
        'cleanup-interference':'#include <quantum.h>\n#include <string.h>\nint main(void){quant bool bit=superposition(0,1);int byte=7;{quant uint8_t temporary=5;if(bit)memset((void*)&temporary,byte,1);byte=99;if(temporary==7)phase(3.14159265358979323846);}inverse_fourier(bit);return measure(bit)!=1;}\n',
        'observation-order':'#include <quantum.h>\n#include <string.h>\nint main(void){quant bool bit=superposition(0,1);quant uint8_t byte=5;memset((void*)&byte,bit,1);unsigned first=measure(bit);unsigned second=measure(byte);return first!=second;}\n',
    }
    for name,text in programs.items():
        path=out/(name+'.c')
        p=subprocess.run([str(root/'.deps/format-venv/bin/clang-format'),'-style=file'],cwd=root,input=text,capture_output=True,text=True,check=True)
        path.write_text(p.stdout);r['programs'][name]={'source':path.name,'source_sha256':digest(path)}
        for level in ['-O0','-O1','-O2','-O3','-Os']:
            for builtin in ['-fbuiltin','-fno-builtin']:
                label=name+'-'+level[1:]+'-'+builtin[2:]
                command(label,[root/'build/cket',path,'--run',level,builtin,'-o',out/label])
    assert len(r['commands'])==21 and all(digest(root/name)==sha for name,sha in frozen.items())
    r.update(status='passed-fresh-applied-root-checks',exit_code=0,exact_program_executions=20)
except BaseException as error:
    traceback.print_exc();r.update(status='failed-applied-root-checks',exit_code=1,error=repr(error))
finally:
    write(out/'exit.json',r)
raise SystemExit(r['exit_code'])
