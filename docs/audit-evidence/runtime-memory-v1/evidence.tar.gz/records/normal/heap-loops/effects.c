#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
void take(quant const uint8_t *p,quant uint8_t *out,unsigned n){
    while(n--)memcpy((void*)out,(const void*)p,1);
}
int main(int argc,char **argv){
    unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;
    if(rounds>3)return 2;
    quant uint8_t *p=calloc(1,1);if(!p)return 2;
    quant bool coin=superposition(0,1);
    quant uint8_t fixed=7,sum=0;
    p[0]=coin?9:3;quant uint8_t saved=fixed^1;
    if(coin)phase(.31);ownership_checkpoint("start");
    unsigned i=0;int bad=0;
    while(i<rounds){sum+=p[0]++;memcpy((void*)&fixed,(const void*)p,1);
        if(fixed&1)phase(.07);if(sum&1)phase(.11);
        ownership_checkpoint("step");++i;
    }
    free((void*)p);if(saved==8)phase(.17);ownership_checkpoint("finish");
    measure(fixed);measure(sum);measure(coin);return bad;
}