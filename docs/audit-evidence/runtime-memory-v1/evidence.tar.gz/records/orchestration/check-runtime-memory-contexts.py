from pathlib import Path
import json
import os
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
mode = sys.argv[1]
version = sys.argv[2] if len(sys.argv) > 2 else 'v1'
project = root / ('build/runtime-memory-source-' + version)
san = root / ('build/runtime-memory-sanitized-' + version)
target = project if mode == 'normal' else san
if mode == 'development':
    project = target = root
else:
    assert json.loads((target / 'build-exit.json').read_text())['exit_code'] == 0
output = root / ('build/runtime-memory-contexts-' + mode + '-' + version)
output.mkdir()
env = dict(os.environ, CKET_SIMULATOR='sparse', CKET_SEED='7', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode == 'sanitized':
    env.update(CC=str(san / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11')
flags = ['-O2'] if mode != 'sanitized' else ['-O1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
records = []


def run(label, command, expected=0, diagnostic=None):
    r = subprocess.run(command, cwd=project, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    (output / (label + '.log')).write_text(r.stdout)
    records.append(dict(command=command, exit_code=r.returncode, expected_exit_code=expected, log=label + '.log'))
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert r.returncode == expected and (not diagnostic or diagnostic in r.stdout), r.stdout
    return r.stdout


adapter = output / 'trace.o'
run('trace-compile', ['gcc-11', '-std=c11', '-O1', *flags[1:], '-c', str(project / 'tests/heap_transfer_trace.c'), '-o', str(adapter)])
links = ['-Wl,' + str(adapter)] + ['-Wl,--wrap=' + name for name in ('qc_create_sparse', '__cket_apply', 'qc_apply', 'qc_apply_bound', '__cket_read_byte')]
header = '#include <quantum.h>\n#include <stdlib.h>\n#include <string.h>\n#include <stdio.h>\nvoid ownership_checkpoint(const char*);\nunsigned heap_transfer_read_count(void);\n'
cases = {
    'cpu_fill_once': 'unsigned calls=0;quant uint8_t a[2]={7,11};memset((void*)a,++calls,n);unsigned y=measure(a[1]),x=measure(a[0]);measure(coin);return calls!=1||x!=(n?1:7)||y!=(n>1?1:11);',
    'cpu_copy_reads': 'unsigned char data[2]={0,5};quant uint8_t a[2]={7,11};memcpy((void*)a,data,n);unsigned reads=heap_transfer_read_count(),y=measure(a[1]),x=measure(a[0]);measure(coin);return reads!=n||x!=(n?0:7)||y!=(n>1?5:11);',
    'cpu_branches': 'quant uint8_t a[2]={0,5};a[0]=coin?9:3;if(n&1)memset((void*)a,a[0]+1,n);else memcpy((void*)(a+1),(const void*)a,n?1:0);unsigned y=measure(a[1]),x=measure(a[0]),c=measure(coin),initial=c?9:3;return x!=initial+(n&1)||y!=(n==2?initial:5);',
    'loop_branch': 'quant uint8_t a[2]={0,5};a[0]=coin?9:3;for(unsigned i=0;i<3;++i)if(i&1)memset((void*)a,a[0]+1,n);unsigned y=measure(a[1]),x=measure(a[0]),c=measure(coin),initial=c?9:3;return x!=initial+(n!=0)||y!=(n>1?x:5);',
    'inactive_bounds': 'quant bool off=0;quant uint8_t a=9;size_t bad=n+3;if(off)memset((void*)&a,4,bad);unsigned x=measure(a),f=measure(off);measure(coin);return x!=9||f;',
    'coherent': 'quant uint8_t a[2]={7,11};if(coin)memset((void*)a,3,n);unsigned y=measure(a[1]),x=measure(a[0]),c=measure(coin);return x!=(c&&n?3:7)||y!=(c&&n>1?3:11);',
    'identity': 'quant uint16_t a=0;a=coin?9:3;if(coin)phase(.31);ownership_checkpoint("identity-before");memmove((void*)&a,(const void*)&a,n);ownership_checkpoint("identity-after");unsigned x=measure(a),c=measure(coin);return x!=(c?9:3);',
    'returned_measure': 'quant uint8_t a[2]={0,5},b[2]={7,11};a[0]=coin?9:3;unsigned got=measure(*(uint8_t*)memcpy((void*)b,(const void*)a,n));unsigned second=measure(b[1]),input=measure(a[0]);measure(a[1]);unsigned c=measure(coin);return got!=(n?input:7)||second!=(n>1?5:11)||input!=(c?9:3);',
    'returned_alias': 'quant uint8_t a[2]={0,5},b[2]={7,11};a[0]=coin?9:3;uint8_t *alias=memcpy((void*)b,(const void*)a,n);int bad=alias!=b;unsigned got=measure(*alias),second=measure(b[1]),input=measure(a[0]);measure(a[1]);unsigned c=measure(coin);return bad||got!=(n?input:7)||second!=(n>1?5:11)||input!=(c?9:3);',
}
executions = 0
for name, body in cases.items():
    path, binary = output / (name + '.c'), output / name
    path.write_text(header + 'int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);' + body + '}\n')
    run(name + '-compile', [str(target / 'build/cket'), str(path), *flags, *links, '-o', str(binary)])
    for n in (0, 1, 2):
        log = run(name + '-n' + str(n), [str(binary), str(n)])
        if name == 'identity':
            before, after = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
            assert before['state'] == after['state'] and before['registers'] == after['registers']
            assert not after['gates'] and after['measurements'] == after['resets'] == 0
        executions += 1
rejects = {
    'copy_bounds': ('memcpy((void*)a,data,n);', 'checked byte bounds', 4),
    'move_bounds': ('memmove((void*)(a+1),(const void*)a,n);', 'checked byte bounds', 3),
    'fill_bounds': ('memset((void*)a,a[0]+1,n);', 'checked byte bounds', 4),
    'copy_overlap': ('memcpy((void*)(a+1),(const void*)a,n);', 'overlapping quantum memcpy', 2),
}
for name, (body, diagnostic, count) in rejects.items():
    path, binary = output / (name + '.c'), output / name
    path.write_text(header + 'static void rejected(void){ownership_checkpoint("rejected");printf("reads=%u\\n",heap_transfer_read_count());}\nint main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):4;quant bool coin=superposition(0,1);quant uint8_t a[3]={0,5,7};a[0]=coin?9:3;unsigned char data[3]={1,2,3};ownership_checkpoint("before");if(atexit(rejected))exit(2);' + body + 'return 0;}\n')
    run(name + '-compile', [str(target / 'build/cket'), str(path), *flags, *links, '-o', str(binary)])
    log = run(name + '-run', [str(binary), str(count)], expected=1, diagnostic=diagnostic)
    before, after = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
    assert before['state'] == after['state'] and before['registers'] == after['registers']
    assert not after['gates'] and after['measurements'] == after['resets'] == 0 and 'reads=0' in log
binary = output / 'buffer_lengths'
run('example-compile', [str(target / 'build/cket'), 'examples/blocks/05/buffer_lengths.c', *flags, '-o', str(binary)])
for count in (0, 1, 2):
    run('example-n' + str(count), [str(binary), str(count)])
    executions += 1
if mode == 'normal':
    run('static-export', [str(target / 'build/cket'), 'examples/blocks/05/buffer_lengths.c', '--emit-qasm', '-o', str(output / 'unsupported.qasm')], expected=1, diagnostic='dynamic CPU control requires native C execution')
consumer_rejections = {
    'cpu_return_read': ('unsigned bad=*(uint8_t*)memcpy((void*)&b,(const void*)&a,n);(void)bad;', 'measure explicitly'),
    'cpu_return_call': ('printf("%s",(char*)memcpy((void*)&b,(const void*)&a,n));', 'cannot escape to a CPU call'),
    'cpu_return_store': ('struct box{void *p;};struct box box={memcpy((void*)&b,(const void*)&a,n)};(void)box;', 'CPU storage escape'),
    'return_write': ('*(uint8_t*)memcpy((void*)&b,(const void*)&a,n)=4;', 'memory-return writes require'),
}
for name, (body, diagnostic) in consumer_rejections.items():
    path = output / (name + '.c')
    path.write_text(header + 'int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):1;quant uint8_t a=3,b=7;' + body + 'measure(b);measure(a);return 0;}\n')
    run(name + '-compile', [str(target / 'build/cket'), str(path), *flags, '-o', str(output / name)], expected=1, diagnostic=diagnostic)
(output / 'summary.json').write_text(json.dumps(dict(status='passed', mode=mode, native_program_executions=executions,
    semantic_rejections=len(rejects), compile_boundary_rejections=len(consumer_rejections), preflight_state_preservation_checks=len(rejects),
    identity_state_checks=3, scope='Native observations, exact identity state/gate checks and rejected calls before writes/CPU reads; primary full-state formulas are separate.'), indent=2) + '\n')
print(mode, executions, 'native executions and', len(rejects), 'nonmutating preflight rejections passed', flush=True)
