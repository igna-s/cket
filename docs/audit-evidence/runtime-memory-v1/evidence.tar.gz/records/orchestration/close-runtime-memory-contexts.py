from pathlib import Path
import json
import os
import subprocess

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/runtime-memory-source-v3'
output = root / 'build/runtime-memory-contexts-normal-v3'
other = root / 'build/runtime-memory-contexts-sanitized-v3'
records = json.loads((output / 'commands.json').read_text())
assert len(records) == 50 and all(r['exit_code'] == r['expected_exit_code'] for r in records)
assert records[-1]['log'] == 'static-export.log'
assert 'dynamic CPU control requires native C execution' in (output / 'static-export.log').read_text()
diagnostics = {'cpu_return_read': 'measure explicitly', 'cpu_return_call': 'cannot escape to a CPU call',
               'cpu_return_store': 'CPU storage escape', 'return_write': 'memory-return writes require'}
for name, diagnostic in diagnostics.items():
    source = output / (name + '.c')
    source.write_bytes((other / (name + '.c')).read_bytes())
    command = [str(project / 'build/cket'), str(source), '-O2', '-o', str(output / name)]
    r = subprocess.run(command, cwd=project, env=dict(os.environ, CKET_SIMULATOR='sparse', CKET_SEED='7'),
                       text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    (output / (name + '-compile.log')).write_text(r.stdout)
    records.append(dict(command=command, exit_code=r.returncode, expected_exit_code=1, log=name + '-compile.log'))
    assert r.returncode == 1 and diagnostic in r.stdout, r.stdout
for name in ('copy_bounds', 'move_bounds', 'fill_bounds', 'copy_overlap'):
    log = (output / (name + '-run.log')).read_text()
    before, after = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
    assert before['state'] == after['state'] and before['registers'] == after['registers']
    assert not after['gates'] and after['measurements'] == after['resets'] == 0 and 'reads=0' in log
for n in (0, 1, 2):
    log = (output / ('identity-n' + str(n) + '.log')).read_text()
    before, after = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
    assert before['state'] == after['state'] and before['registers'] == after['registers'] and not after['gates']
(output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
(output / 'diagnostic-review.json').write_text(json.dumps(dict(status='passed',
    previous_expectation='CPU parameter bindings required', actual_diagnostic='dynamic CPU control requires native C execution',
    meaning='The prior helper stopped after the correct export rejection because it expected another valid rejection class. Native runs are preserved, not repeated; four missing compile boundary checks completed separately.'), indent=2) + '\n')
(output / 'summary.json').write_text(json.dumps(dict(status='passed', mode='normal', native_program_executions=30,
    semantic_rejections=4, compile_boundary_rejections=4, preflight_state_preservation_checks=4,
    identity_state_checks=3, scope='Native observations, exact identity checks and nonmutating rejected calls; full-state formulas are separate.'), indent=2) + '\n')
print('normal 30 native executions, 4 nonmutating preflight rejections and 4 compile boundary rejections closed', flush=True)
