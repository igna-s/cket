from collections import Counter
from pathlib import Path
import hashlib
import json
import runpy
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/runtime-memory-source-v3'
sanbuild = root / 'build/runtime-memory-sanitized-v3'
folder = root / 'docs/audit-evidence/runtime-memory-v1'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
locations = {mode: root / ('build/runtime-memory-' + mode + '-results-v3') for mode in ('normal', 'sanitized')}
contexts = {mode: root / ('build/runtime-memory-contexts-' + mode + '-v3') for mode in locations}
sources = read(project / 'source-hashes.json')
assert len(sources) == 221
assert sources == runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
assert all(sha(project / name) == digest for name, digest in sources.items())
for build in (project, sanbuild):
    assert read(build / 'build-exit.json')['exit_code'] == 0
matrices = {mode: read(path / 'matrix/summary.json') for mode, path in locations.items()}
for mode, counts in [('normal', (600, 180, 6, 8)), ('sanitized', (300, 90, 3, 4))]:
    path, matrix = locations[mode], matrices[mode]
    assert matrix['status'] == 'passed'
    assert tuple(matrix[k] for k in ('full_state_checkpoints', 'complete_gate_inverses', 'boundary_native_executions', 'compile_boundary_rejections')) == counts
    assert all(row['exit_code'] == 0 for row in read(path / 'exit.json'))
    assert all(row['exit_code'] == row.get('expected_exit_code', 0) for row in read(path / 'matrix/commands.json'))
    assert '23 runtime memory preflight contracts passed' in (path / 'preflight-engine.log').read_text()
    assert '414 memory-copy checks passed' in (path / 'memcopy.log').read_text()
    assert '940 memset checks passed' in (path / 'memset.log').read_text()
    for regression in ('fixed-loops', 'heap-loops'):
        assert read(path / regression / 'summary.json')['status'] == 'passed'
    context = read(contexts[mode] / 'summary.json')
    assert context['native_program_executions'] == 30
    assert context['semantic_rejections'] == context['compile_boundary_rejections'] == 4
    assert all(row['exit_code'] == row['expected_exit_code'] for row in read(contexts[mode] / 'commands.json'))
assert '395 passed, 0 failed' in (locations['normal'] / 'native-core.log').read_text()
assert '7 executables, 0 QASM' in (locations['normal'] / 'block05.log').read_text()
components = ['cket_plugin.so', 'json.o', 'quantum.o', 'verify.o', 'simulator.o', 'cket_runtime.o', 'cket', 'validate_runtime_memory']
for component in components[:7]:
    text = (locations['sanitized'] / ('instrumentation-' + component + '.log')).read_text()
    assert '__asan_init' in text and '__ubsan_handle' in text
folder.mkdir(parents=True, exist_ok=True)
assert not any((folder / name).exists() for name in ('summary.json', 'evidence.tar.gz', 'earlier-attempts.tar.gz', 'tool-sha256.json'))
tools = {mode: {name: sha(path / 'build' / name) for name in components} for mode, path in [('normal', project), ('sanitized', sanbuild)]}
tools['example'] = {'normal': sha(project / 'build/blocks/05/buffer_lengths'), 'sanitized': sha(contexts['sanitized'] / 'buffer_lengths')}
(folder / 'tool-sha256.json').write_text(json.dumps(tools, indent=2) + '\n')


def records(archive, location, prefix):
    for path in sorted(location.rglob('*')):
        if path.is_file() and path.suffix in ('.json', '.log', '.c'):
            archive.add(path, arcname=prefix + '/' + path.relative_to(location).as_posix())


with tarfile.open(folder / 'evidence.tar.gz', 'x:gz') as archive:
    for name in sources:
        archive.add(project / name, arcname='sources/' + name)
    archive.add(root / 'LICENSE', arcname='sources/LICENSE')
    for name, path in [('source-hashes.json', project / 'source-hashes.json'), ('inventory-fixture.json', project / 'docs/c11-library.json'), ('tool-sha256.json', folder / 'tool-sha256.json')]:
        archive.add(path, arcname='records/' + name)
    for mode in locations:
        records(archive, locations[mode], 'records/' + mode)
        records(archive, contexts[mode], 'records/contexts-' + mode)
    for name in ('build.log', 'build-exit.json', 'build-sanitized.sh'):
        archive.add(sanbuild / name, arcname='records/sanitized-build/' + name)
    for name in ('build-normal.log', 'build-exit.json'):
        archive.add(project / name, arcname='records/normal-build/' + name)
    for name in ('prepare-runtime-memory.py', 'runtime-memory-changed.txt', 'run-runtime-memory.py', 'check-runtime-memory-contexts.py', 'check-runtime-memory-contexts-before-diagnostic.py', 'close-runtime-memory-contexts.py', 'archive-runtime-memory.py'):
        archive.add(root / 'build' / name, arcname='records/orchestration/' + name)
with tarfile.open(folder / 'earlier-attempts.tar.gz', 'x:gz') as archive:
    for version in ('v1', 'v2'):
        baseline = root / ('build/runtime-memory-source-' + version)
        previous = read(baseline / 'source-hashes.json')
        for name, digest in previous.items():
            assert sha(baseline / name) == digest
            archive.add(baseline / name, arcname=baseline.name + '/sources/' + name)
        for name in ('source-hashes.json', 'build-exit.json', 'build-normal.log'):
            archive.add(baseline / name, arcname=baseline.name + '/records/' + name)
        san = root / ('build/runtime-memory-sanitized-' + version)
        for name in ('build-exit.json', 'build.log', 'build-sanitized.sh'):
            archive.add(san / name, arcname=san.name + '/' + name)
        records(archive, root / ('build/runtime-memory-normal-results-' + version), 'normal-results-' + version)
    for pattern in ('dynamic-memory-dev-v*', 'runtime-memory-dev-proof-v*', 'runtime-memory-contexts-development-*', 'runtime-memory-contexts-normal-v1', 'runtime-memory-consumer-probe-v*'):
        for path in (root / 'build').glob(pattern):
            records(archive, path, path.name)
    for path in (root / 'build').glob('dynamic-memory-dev-build-v*.log'):
        archive.add(path, arcname='development/' + path.name)
    for name in ('build-dynamic-memory-dev.py', 'check-dynamic-memory-dev.py', 'check-runtime-memory-consumer.py', 'debug-runtime-memory-ir.py'):
        archive.add(root / 'build' / name, arcname='development/' + name)
summary = dict(date='2026-10-24', status='finite-runtime-memory-qualified', source_files=221,
    source_sha256=sources, artifact_sha256={name: sha(folder / name) for name in ('evidence.tar.gz', 'earlier-attempts.tar.gz', 'tool-sha256.json')},
    normal=matrices['normal'], sanitized=matrices['sanitized'], full_state_checkpoints=900, complete_gate_inverses=270,
    boundary_native_executions=9, compile_boundary_rejections=12, preflight_engine_contracts_per_configuration=23,
    normal_native_core_checks=395, memcopy_checks_per_configuration=414, memset_checks_per_configuration=940,
    extra_native_context_executions=60, extra_semantic_rejections=8, extra_compile_boundary_rejections=8,
    preflight_state_preservation_checks=8, identity_state_checks=6,
    delivery=dict(block05_native_executables=7, static_exports=0, example_lengths=[0, 1, 2], example_binary_sha256=tools['example']),
    contexts={mode: read(path / 'summary.json') for mode, path in contexts.items()},
    regressions={mode: {name: read(path / name / 'summary.json') for name in ('fixed-loops', 'heap-loops')} for mode, path in locations.items()},
    inventory=dict(Counter(row['quantum'] for row in read(root / 'docs/c11-library.json')['interfaces'])),
    base_commit='9a7d9e3362510cb4cad564db9c6a11c8735de9b6', compiler=(project / 'build/gcc-version.txt').read_text().strip(),
    source_scope='Both builds and final campaigns use the same 221 frozen compiler/test inputs. Documentation and generated demonstration artifacts are outside this manifest and have separate hashes.',
    earlier_attempts='Frozen v1/v2 inputs and completed outcomes remain separate. v1 failed a CPU branch context; stable public owners fixed it. v2 allowed an unobserved return read to access a CPU placeholder (0 versus observed 3); v3 sequences logical reads and rejects unobserved reads/escapes. Early prototypes also exposed capture lifetime/type binding issues. A normal context helper stopped after a correct static-export rejection with a different expected message; its existing native runs were preserved and the remaining checks completed separately. Development source provenance before freezing is incomplete; repeated results do not enlarge final counts.',
    limitations=['Finite runtime CPU prefixes over checked fixed integer layouts, not complete everyday C/C11 or arbitrary quantum-state proof.',
        'Pure CPU counts, static checked addresses/object extents, at most 64 bytes; effectful counts, arbitrary addresses/CFG/ABI, heap strings and quantum floating point remain pending.',
        'The 128-wire representation, 24-wire dense simulator and bounded sparse support remain separate budgets. Retained versions consume qubits.',
        'Direct compatible reads with explicit measure and checked local aliases are supported. Conditional memory-return addresses and direct returned-expression writes still require a local checked borrow.',
        'GCC host remains uninstrumented with its existing host leak-attribution exclusion; generated instrumented programs keep leak detection.',
        'Previous paper reports keep their own historical revision. The new runtime note has a separate editorial audit; this campaign does not qualify the whole historical manuscript against the new compiler. Cybersecurity stays classical; no QPU/speedup claim.'])
(folder / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
p = root / 'docs/audit-evidence/delivery-index.json'
index = read(p)
index['active'] = 'runtime-memory-v1'
index['history'].append('runtime-memory-v1')
index['meaning'] = 'Current source identity selects finite runtime-length memory validation. The complete everyday-C profile and full new-compiler paper integration remain open.'
p.write_text(json.dumps(index, indent=2) + '\n')
(root / 'docs/paper/evidence/current-implementation.json').write_text(json.dumps(dict(date='2026-10-24', status=summary['status'], source_files=221, source_sha256=sources,
    directed_evidence='../../audit-evidence/runtime-memory-v1/summary.json', paper_audit='runtime-note-pending; historical-main-review-pending-new-compiler',
    previous_paper_review='../../audit-evidence/paper-truth-oct24-v1/summary.json', meaning='Finite runtime memory validation advances the compiler. Historical manuscript evidence and its 210-input review keep their own scope.'), indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('status', 'source_files', 'full_state_checkpoints', 'complete_gate_inverses')}), flush=True)
