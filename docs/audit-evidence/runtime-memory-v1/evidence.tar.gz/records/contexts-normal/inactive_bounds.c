#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant bool off=0;quant uint8_t a=9;size_t bad=n+3;if(off)memset((void*)&a,4,bad);unsigned x=measure(a),f=measure(off);measure(coin);return x!=9||f;}
