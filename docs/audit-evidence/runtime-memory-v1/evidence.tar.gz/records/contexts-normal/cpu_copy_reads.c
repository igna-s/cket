#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);unsigned char data[2]={0,5};quant uint8_t a[2]={7,11};memcpy((void*)a,data,n);unsigned reads=heap_transfer_read_count(),y=measure(a[1]),x=measure(a[0]);measure(coin);return reads!=n||x!=(n?0:7)||y!=(n>1?5:11);}
