#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant uint8_t a[2]={0,5};a[0]=coin?9:3;if(n&1)memset((void*)a,a[0]+1,n);else memcpy((void*)(a+1),(const void*)a,n?1:0);unsigned y=measure(a[1]),x=measure(a[0]),c=measure(coin),initial=c?9:3;return x!=initial+(n&1)||y!=(n==2?initial:5);}
