#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):1;quant uint8_t a=3,b=7;struct box{void *p;};struct box box={memcpy((void*)&b,(const void*)&a,n)};(void)box;measure(b);measure(a);return 0;}
