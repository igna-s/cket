#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
static void rejected(void){ownership_checkpoint("rejected");printf("reads=%u\n",heap_transfer_read_count());}
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):4;quant bool coin=superposition(0,1);quant uint8_t a[3]={0,5,7};a[0]=coin?9:3;unsigned char data[3]={1,2,3};ownership_checkpoint("before");if(atexit(rejected))exit(2);memcpy((void*)(a+1),(const void*)a,n);return 0;}
