#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant uint8_t a[2]={7,11};if(coin)memset((void*)a,3,n);unsigned y=measure(a[1]),x=measure(a[0]),c=measure(coin);return x!=(c&&n?3:7)||y!=(c&&n>1?3:11);}
