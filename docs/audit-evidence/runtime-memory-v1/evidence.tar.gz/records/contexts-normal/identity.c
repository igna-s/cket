#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant uint16_t a=0;a=coin?9:3;if(coin)phase(.31);ownership_checkpoint("identity-before");memmove((void*)&a,(const void*)&a,n);ownership_checkpoint("identity-after");unsigned x=measure(a),c=measure(coin);return x!=(c?9:3);}
