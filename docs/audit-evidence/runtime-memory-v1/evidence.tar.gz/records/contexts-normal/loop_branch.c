#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant uint8_t a[2]={0,5};a[0]=coin?9:3;for(unsigned i=0;i<3;++i)if(i&1)memset((void*)a,a[0]+1,n);unsigned y=measure(a[1]),x=measure(a[0]),c=measure(coin),initial=c?9:3;return x!=initial+(n!=0)||y!=(n>1?x:5);}
