#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant uint8_t a[2]={0,5},b[2]={7,11};a[0]=coin?9:3;memcpy((void*)b,(const void*)a,n);unsigned y=measure(b[0]),z=measure(b[1]),x=measure(a[0]),c=measure(coin);return y!=(n?x:7)||z!=(n>1?5:11)||x!=(c?9:3);}
