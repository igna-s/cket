#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant uint8_t a[2]={0,5};a[0]=coin?9:3;for(unsigned i=0;i<3;++i)memset((void*)a,a[0]+1,n);unsigned y=measure(a[1]),x=measure(a[0]),c=measure(coin);return x!=(c?9:3)+(n?3:0)||y!=(n>1?x:5);}
