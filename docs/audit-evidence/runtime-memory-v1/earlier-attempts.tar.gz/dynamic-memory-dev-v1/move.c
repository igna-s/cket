#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);quant uint8_t a[3]={0,5,7};a[0]=coin?9:3;memmove((void*)(a+1),(const void*)a,n);unsigned z=measure(a[2]),y=measure(a[1]),x=measure(a[0]),c=measure(coin);return x!=(c?9:3)||y!=(n?x:5)||z!=(n>1?5:7);}
