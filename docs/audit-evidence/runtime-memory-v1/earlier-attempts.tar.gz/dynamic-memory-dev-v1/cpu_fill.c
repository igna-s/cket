#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;quant bool coin=superposition(0,1);unsigned calls=0;quant uint8_t a[2]={7,11};memset((void*)a,++calls,n);unsigned y=measure(a[1]),x=measure(a[0]);measure(coin);return calls!=1||x!=(n?1:7)||y!=(n>1?1:11);}
