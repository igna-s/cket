from pathlib import Path
import json, os, runpy, subprocess, sys

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/heap-memory-source-v1'
san = root / 'build/heap-memory-sanitized-v1'
mode = sys.argv[1]
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_SEED='7',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode == 'sanitize-build':
    san.mkdir()
    prefix = (project / 'scripts/sanitize-all.sh').read_text().split('\nexport CKET_REAL_GCC="$real_cc"')[0]
    prefix = prefix.replace('cd "$(dirname "$0")/.."', 'cd "' + str(project) + '"')
    script = san / 'build-sanitized.sh'
    script.write_text(prefix + '\n')
    with (san / 'build.log').open('x') as log:
        completed = subprocess.run(['bash', str(script)], cwd=project,
            env=dict(env, CKET_SAN_ROOT=str(san)), stdout=log, stderr=subprocess.STDOUT)
    (san / 'build-exit.json').write_text(json.dumps(dict(exit_code=completed.returncode)) + '\n')
    print('Sanitized build:', completed.returncode, flush=True)
    if completed.returncode:
        print((san / 'build.log').read_text()[-4000:], flush=True)
    sys.exit(completed.returncode)
if mode == 'normal-build':
    with (project / 'build-normal.log').open('x') as log:
        completed = subprocess.run(['bash', 'scripts/build.sh'], cwd=project, env=env,
            stdout=log, stderr=subprocess.STDOUT)
    (project / 'build-exit.json').write_text(json.dumps(dict(exit_code=completed.returncode)) + '\n')
    print('Normal build:', completed.returncode, flush=True)
    if completed.returncode:
        print((project / 'build-normal.log').read_text()[-4000:], flush=True)
    sys.exit(completed.returncode)
assert mode in ('normal', 'sanitized')
target = project if mode == 'normal' else san
output = root / ('build/heap-memory-' + mode + '-results-v1')
output.mkdir()
levels = ['O0', 'O2', 'Os'] if mode == 'normal' else ['O1']
extra = [] if mode == 'normal' else ['--sanitized']
if mode == 'sanitized':
    env.update(CC=str(san / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11')
records = []
def run(label, command, selected_env=None, diagnostic=None):
    with (output / (label + '.log')).open('x') as log:
        completed = subprocess.run(command, cwd=project, env=selected_env or env,
            stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    records.append(dict(label=label, command=command, exit_code=completed.returncode, log=label + '.log'))
    (output / 'exit.json').write_text(json.dumps(records, indent=2) + '\n')
    content = (output / (label + '.log')).read_text()
    print(label, completed.returncode, content[-1600:], flush=True)
    assert (completed.returncode > 0 and diagnostic in content) if diagnostic else completed.returncode == 0
run('byte-matrix', ['python3', 'scripts/validate-heap-memory.py', '--compiler-root', str(target),
    '--output', str(output / 'matrix'), '--levels', *levels, *extra])
run('heap-engine', [str(target / 'build/validate_heap')])
run('heap-regression', ['python3', 'scripts/validate-heap.py', '--compiler-root', str(target),
    '--output', str(output / 'heap'), '--levels', levels[0] if mode == 'sanitized' else 'O2', *extra])
if mode == 'normal':
    run('native-core', [str(target / 'build/cket_tests'), str(target)])
    run('block05', ['bash', 'scripts/run-block.sh', '05'])
    run('static-export', [str(target / 'build/cket'), 'examples/blocks/05/heap_bytes.c', '-O2',
        '--emit-qasm', '-o', str(output / 'unsupported.qasm')], diagnostic='static export is unsupported')
    run('inventory', ['python3', 'scripts/inventory_c11.py'])
else:
    binary = output / 'heap_bytes'
    run('example-compile', [str(target / 'build/cket'), 'examples/blocks/05/heap_bytes.c',
        '-O1', '-o', str(binary)])
    run('example-run', [str(binary)], dict(env, CKET_SIMULATOR='sparse'))
hashes = runpy.run_path(str(project / 'scripts/archive-audit.py'))['source_hashes']()
assert hashes == json.loads((project / 'source-hashes.json').read_text())
print('PASS unchanged', len(hashes), 'frozen source inputs', flush=True)
