from pathlib import Path
from collections import Counter
import hashlib, json, runpy, subprocess, tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/heap-memory-source-v2'
build_source = root / 'build/heap-memory-source-v1'
normal = root / 'build/heap-memory-normal-results-v2'
sanitized = root / 'build/heap-memory-sanitized-results-v2'
sanbuild = root / 'build/heap-memory-sanitized-v1'
folder = root / 'docs/audit-evidence/heap-memory-v1'
folder.mkdir(parents=True, exist_ok=True)
assert not (folder / 'summary.json').exists()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = json.loads((project / 'source-hashes.json').read_text())
assert sources == runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
assert len(sources) == 206 and all(sha(project / name) == digest for name, digest in sources.items())
before = json.loads((build_source / 'source-hashes.json').read_text())
assert [name for name in sources if sources[name] != before[name]] == ['scripts/validate-heap-memory.py']
for path in (project / 'src').rglob('*'):
    if path.is_file():
        name = path.relative_to(project).as_posix()
        assert sha(path) == before[name]
n = json.loads((normal / 'matrix/summary.json').read_text())
s = json.loads((sanitized / 'matrix/summary.json').read_text())
assert n['status'] == s['status'] == 'passed'
assert (n['full_state_checkpoints'], s['full_state_checkpoints']) == (192, 64)
assert (n['complete_gate_inverses'], s['complete_gate_inverses']) == (48, 16)
for location in (normal, sanitized):
    assert all(row['exit_code'] == 0 or (row['label'] == 'static-export' and row['exit_code'] > 0)
        for row in json.loads((location / 'exit.json').read_text()))
    assert '16808 heap checks passed' in (location / 'heap-engine.log').read_text()
assert '395 passed, 0 failed' in (normal / 'native-core.log').read_text()
assert '3 executables, 0 QASM' in (normal / 'block05.log').read_text()
for path in (build_source / 'build-exit.json', sanbuild / 'build-exit.json'):
    assert json.loads(path.read_text())['exit_code'] == 0
components = ['cket_plugin.so', 'json.o', 'quantum.o', 'verify.o', 'simulator.o', 'cket_runtime.o', 'cket', 'validate_heap']
tool_hashes = {mode: {name: sha(location / 'build' / name) for name in components}
    for mode, location in [('normal', build_source), ('sanitized', sanbuild)]}
(folder / 'tool-sha256.json').write_text(json.dumps(tool_hashes, indent=2) + '\n')
with tarfile.open(folder / 'evidence.tar.gz', 'x:gz') as archive:
    for name in sources:
        archive.add(project / name, arcname='sources/' + name)
    archive.add(root / 'LICENSE', arcname='sources/LICENSE')
    for label, path in [('source-hashes.json', project / 'source-hashes.json'),
            ('inventory-fixture.json', project / 'docs/c11-library.json'),
            ('build-source-hashes.json', build_source / 'source-hashes.json'),
            ('build-reuse.json', project / 'build-reuse.json'),
            ('validator-before-fixture-correction.py', build_source / 'scripts/validate-heap-memory.py'),
            ('tool-sha256.json', folder / 'tool-sha256.json')]:
        archive.add(path, arcname='records/' + label)
    for mode, location in [('normal', normal), ('sanitized', sanitized)]:
        for path in location.rglob('*'):
            if path.is_file() and path.suffix in ('.json', '.log', '.c'):
                archive.add(path, arcname='records/' + mode + '/' + path.relative_to(location).as_posix())
    for name in ('build.log', 'build-exit.json', 'build-sanitized.sh'):
        archive.add(sanbuild / name, arcname='records/sanitized-build/' + name)
    for name in ('build-normal.log', 'build-exit.json'):
        archive.add(build_source / name, arcname='records/normal-build/' + name)
    for name in ('prepare-heap-memory.py', 'prepare-heap-memory-v2.py', 'run-heap-memory-final.py',
                 'run-heap-memory-final-v2.py', 'archive-heap-memory.py'):
        archive.add(root / 'build' / name, arcname='records/orchestration/' + name)
with tarfile.open(folder / 'earlier-attempts.tar.gz', 'x:gz') as archive:
    for pattern in ('heap-memory-prototype-v*', 'heap-memory-normal-results-v1'):
        for location in (root / 'build').glob(pattern):
            for path in location.rglob('*'):
                if path.is_file() and path.suffix in ('.json', '.log', '.c'):
                    archive.add(path, arcname=location.name + '/' + path.relative_to(location).as_posix())
    archive.add(root / 'build/heap-bytes-smoke.c', arcname='heap-bytes-smoke.c')
summary = dict(date='2026-10-24', status='finite-native-heap-memory-qualified',
    source_files=len(sources), source_sha256=sources,
    artifact_sha256={name: sha(folder / name) for name in ('evidence.tar.gz', 'earlier-attempts.tar.gz', 'tool-sha256.json')},
    normal=n, sanitized=s, full_state_checkpoints=256, complete_gate_inverses=64,
    native_program_executions=32, semantic_rejections=48,
    heap_engine_mixed_checks_per_configuration=16808, new_malformed_IR_cases=7,
    normal_native_core_checks=395,
    heap_regression={mode: json.loads((location / 'heap/summary.json').read_text())
        for mode, location in [('normal', normal), ('sanitized', sanitized)]},
    delivery=dict(block05_native_executables=3, static_exports=0, sanitized_example_executions=1),
    inventory=dict(Counter(row['quantum'] for row in json.loads((root / 'docs/c11-library.json').read_text())['interfaces'])),
    compiler=subprocess.check_output(['gcc-11', '-dumpfullversion'], text=True).strip(),
    build_provenance=dict(compiled_source_manifest='records/build-source-hashes.json',
        final_source_manifest='records/source-hashes.json', changed_after_build=['scripts/validate-heap-memory.py'],
        reason='The sole change after the clean builds corrects a negative test fixture to measure/free its inputs before exit. All compiler, engine, runtime and compile flags are unchanged. Both manifests and validator versions are archived.'),
    limitations=[
        'Finite native heap-to-heap memcpy/memmove and heap memset; no complete everyday-C, C11 or libc claim.',
        'Normal byte matrix O0/O2/Os, sanitized O1, both synthesis policies; 256 checkpoints are repeated finite profiles, not distinct arbitrary states.',
        'Heap/fixed-buffer interchange, string adapters on heaps, general ABI and CPU-loop heap update return values remain pending.',
        'Whole-byte integer layouts only; 64-byte operation cap and separate 128-wire/history budgets apply. Boolean heap byte views are rejected.',
        'Unknown retired values remain joint outputs; free does not erase them.',
        'Host GCC is uninstrumented; its instrumented plugin uses the existing wrapper with host leak attribution disabled. Generated programs retain leak detection.',
        'This campaign does not repeat every historical suite, re-audit the papers, run on a physical QPU or establish speedup.'
    ])
(folder / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
p = root / 'docs/audit-evidence/delivery-index.json'
index = json.loads(p.read_text())
index['active'] = 'heap-memory-v1'
index['history'].append('heap-memory-v1')
index['meaning'] = 'Current source identity selects finite native heap byte-memory validation. Historical artifacts retain their own inputs/results; full everyday C integration and paper audit remain open.'
p.write_text(json.dumps(index, indent=2) + '\n')
(root / 'docs/paper/evidence/current-implementation.json').write_text(json.dumps(dict(
    date='2026-10-24', status=summary['status'], source_files=len(sources), source_sha256=sources,
    directed_evidence='../../audit-evidence/heap-memory-v1/summary.json', paper_audit='pending',
    meaning='Directed native heap byte-memory validation does not regenerate or certify historical paper reports.'), indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('status', 'source_files', 'full_state_checkpoints', 'complete_gate_inverses')}), flush=True)
