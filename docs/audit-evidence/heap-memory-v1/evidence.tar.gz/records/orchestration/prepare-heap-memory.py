from pathlib import Path
import json, runpy, shutil

root = Path('/tmp/quantum-audit-isolated-20261017')
inventory = runpy.run_path(str(root / 'scripts/inventory_c11.py'))
target = root / 'docs/c11-library.json'
data = json.loads(target.read_text())
for row in data['interfaces']:
    if row['header'] == 'string.h' and row['name'] in {'memcpy', 'memmove', 'memset'}:
        status, classes, milestone, tests, contract = inventory['semantics'](
            row['header'], row['name'], row['kind'], False)
        row.update(quantum=status, restriction_classes=classes, milestone=milestone,
                   tests=tests, contract=contract)
target.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
files = '''src/cket_plugin.cpp src/engine/heap.inc src/engine/heap_memory.inc
src/engine/quantum.c src/engine/verify.c src/heap_runtime.inc src/quantum_heap.inc
src/quantum_frontend.inc src/quantum_semantics.inc scripts/validate-heap-memory.py
tests/validate_heap.c tests/heap_memory_state.inc scripts/archive-audit.py
scripts/inventory_c11.py scripts/run-block.sh examples/blocks/05/heap_bytes.c
docs/c11-heap.md docs/c11-library.json docs/estado-general-del-proyecto.es.md
docs/perfil-c-cotidiano.es.md docs/entregas-incrementales.es.md'''.split()
fmt = runpy.run_path(str(root / 'scripts/format.py'))['format_text']
for name in files:
    path = root / name
    path.write_text(fmt(path, path.read_text()))
(root / 'build/heap-memory-changed-files.txt').write_text('\n'.join(files) + '\n')
sources = runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
project = root / 'build/heap-memory-source-v1'
project.mkdir()
for name in sources:
    path = project / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, path)
(project / '.deps').symlink_to(root / '.deps', target_is_directory=True)
(project / 'cket').chmod(0o755)
(project / 'docs').mkdir()
shutil.copy2(target, project / 'docs/c11-library.json')
(project / 'source-hashes.json').write_text(json.dumps(sources, indent=2) + '\n')
print('Formatted', len(files), 'files; frozen', len(sources), 'source inputs.', flush=True)
