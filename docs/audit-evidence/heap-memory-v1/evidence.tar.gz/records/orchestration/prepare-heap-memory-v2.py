from pathlib import Path
import hashlib, json, runpy, shutil
root = Path('/tmp/quantum-audit-isolated-20261017')
previous = root / 'build/heap-memory-source-v1'
project = root / 'build/heap-memory-source-v2'
path = root / 'scripts/validate-heap-memory.py'
fmt = runpy.run_path(str(root / 'scripts/format.py'))['format_text']
path.write_text(fmt(path, path.read_text()))
sources = runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
before = json.loads((previous / 'source-hashes.json').read_text())
changed = [name for name in sources if sources[name] != before[name]]
assert changed == ['scripts/validate-heap-memory.py'], changed
project.mkdir()
for name in sources:
    path = project / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, path)
(project / 'docs').mkdir()
shutil.copy2(root / 'docs/c11-library.json', project / 'docs/c11-library.json')
(project / '.deps').symlink_to(root / '.deps', target_is_directory=True)
(project / 'build').symlink_to(previous / 'build', target_is_directory=True)
(project / 'cket').chmod(0o755)
(project / 'source-hashes.json').write_text(json.dumps(sources, indent=2) + '\n')
(project / 'build-reuse.json').write_text(json.dumps(dict(
    build_source_manifest='../heap-memory-source-v1/source-hashes.json',
    changed_files=changed,
    reason='Only a negative test fixture was corrected to destroy its input explicitly. All compiled compiler/engine/runtime sources and flags are byte-identical.'
), indent=2) + '\n')
runner = root / 'build/run-heap-memory-final.py'
text = runner.read_text().replace("root / 'build/heap-memory-source-v1'", "root / 'build/heap-memory-source-v2'")
text = text.replace("'-results-v1'", "'-results-v2'")
(root / 'build/run-heap-memory-final-v2.py').write_text(text)
print('Frozen', len(sources), 'inputs; unchanged compiler sources/build flags; corrected fixture only.', flush=True)
