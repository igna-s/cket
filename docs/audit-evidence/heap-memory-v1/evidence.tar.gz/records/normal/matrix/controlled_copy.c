#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(1,sizeof *p);if(!p)return 2;quant uint8_t *q=calloc(1,sizeof *q);if(!q)return 2;
        quant bool coin=superposition(0,1);p[0]=coin?9:3;q[0]=coin?5:5;
        if(coin)phase(.31);size_t n=1;
        ownership_checkpoint("prepared");
        quant uint8_t saved=(uint8_t)p[0]^1;
        if(coin)memcpy((void*)q,(const void*)p,n);ownership_checkpoint("written");
        free((void*)p);free((void*)q);ownership_checkpoint("freed");
        if(saved==8)phase(.17);
        ownership_checkpoint("inverse");measure(coin);return 0;}