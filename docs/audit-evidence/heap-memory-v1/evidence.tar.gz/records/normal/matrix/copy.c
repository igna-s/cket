#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(2,sizeof *p);if(!p)return 2;quant uint8_t *q=calloc(2,sizeof *q);if(!q)return 2;
        quant bool coin=superposition(0,1);p[0]=coin?9:3;p[1]=coin?7:7;q[0]=coin?11:11;q[1]=coin?13:13;
        if(coin)phase(.31);size_t n=2;
        ownership_checkpoint("prepared");
        quant uint8_t saved=(uint8_t)p[0]^1;
        memcpy((void*)q,(const void*)p,n);ownership_checkpoint("written");
        free((void*)p);free((void*)q);ownership_checkpoint("freed");
        if(saved==8)phase(.17);
        ownership_checkpoint("inverse");measure(coin);return 0;}