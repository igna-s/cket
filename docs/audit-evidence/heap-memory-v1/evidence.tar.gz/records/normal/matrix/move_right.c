#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(3,sizeof *p);if(!p)return 2;
        quant bool coin=superposition(0,1);p[0]=coin?9:3;p[1]=coin?5:5;p[2]=coin?7:7;
        if(coin)phase(.31);size_t n=2;
        ownership_checkpoint("prepared");
        quant uint8_t saved=(uint8_t)p[0]^1;
        memmove((void*)(p+1),(const void*)p,n);ownership_checkpoint("written");
        free((void*)p);ownership_checkpoint("freed");
        if(saved==8)phase(.17);
        ownership_checkpoint("inverse");measure(coin);return 0;}