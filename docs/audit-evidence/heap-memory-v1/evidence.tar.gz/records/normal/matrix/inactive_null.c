#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=NULL;quant bool b=0;if(b)memset((void*)p,8,1);measure(b);return 0;}