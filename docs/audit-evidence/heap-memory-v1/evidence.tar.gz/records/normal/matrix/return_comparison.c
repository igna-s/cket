#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(2,1),*q=calloc(2,1);if(!p||!q)return 2;p[0]=3;p[1]=9;if(memcpy((void*)q,(const void*)p,2)!=(void*)q)return 3;if(memset((void*)(q+1),7,1)!=(void*)(q+1))return 4;unsigned a=measure(q[0]),b=measure(q[1]);free((void*)p);free((void*)q);return a!=3||b!=7;}