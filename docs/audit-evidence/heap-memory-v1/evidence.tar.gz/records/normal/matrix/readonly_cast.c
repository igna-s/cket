#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(2,1);const uint8_t *v=(const uint8_t*)p;memset((void*)v,0,1);}