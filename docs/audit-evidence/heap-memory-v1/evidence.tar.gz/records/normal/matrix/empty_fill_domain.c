#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(1,1);quant uint8_t x=0;memset((void*)p,1/x,0);measure(x);free((void*)p);}