#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint16_t *p=calloc(2,2);if(!p)return 2;p[0]=1234;p[1]=5678;size_t n=4;memmove((void*)p,(const void*)p,n);unsigned a=measure(p[0]),b=measure(p[1]);free((void*)p);return a!=1234||b!=5678;}