#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(1,1);memcpy((void*)p,(const void*)p,1);}