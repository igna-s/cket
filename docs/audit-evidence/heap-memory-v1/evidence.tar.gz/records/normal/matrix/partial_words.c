#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint16_t *p=calloc(1,sizeof *p);if(!p)return 2;quant uint16_t *q=calloc(2,sizeof *q);if(!q)return 2;
        quant bool coin=superposition(0,1);p[0]=coin?4762:4796;q[0]=coin?43690:43690;q[1]=coin?48059:48059;
        if(coin)phase(.31);size_t n=2;
        ownership_checkpoint("prepared");
        quant uint8_t saved=(uint8_t)p[0]^1;
        memcpy((unsigned char*)q+1,(const void*)p,n);ownership_checkpoint("written");
        free((void*)p);free((void*)q);ownership_checkpoint("freed");
        if(saved==155)phase(.17);
        ownership_checkpoint("inverse");measure(coin);return 0;}