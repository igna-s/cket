#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
void bad(quant uint8_t *p){void *v=memset((void*)p,7,1);free(v);}int main(void){quant uint8_t *p=calloc(1,1);bad(p);}