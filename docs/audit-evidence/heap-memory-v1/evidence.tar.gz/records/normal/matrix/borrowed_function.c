#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
void copy_bytes(quant uint8_t *out,quant const uint8_t *in,size_t n){memcpy((void*)out,(const void*)in,n);}int main(void){quant uint8_t *p=calloc(3,1),*q=calloc(3,1);if(!p||!q)return 2;p[0]=3;p[1]=9;p[2]=5;copy_bytes(q+1,p+1,2);unsigned a=measure(q[0]),b=measure(q[1]),c=measure(q[2]);free((void*)p);free((void*)q);return a!=0||b!=9||c!=5;}