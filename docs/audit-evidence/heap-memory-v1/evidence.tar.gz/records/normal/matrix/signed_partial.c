#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant int16_t *p=calloc(1,2);quant uint8_t *q=calloc(2,1);if(!p||!q)return 2;p[0]=-2;memcpy((void*)q,(const void*)p,2);memset((unsigned char*)p+1,0x12,1);int x=measure(p[0]);unsigned a=measure(q[0]),b=measure(q[1]);free((void*)p);free((void*)q);return x!=0x12FE||a!=254||b!=255;}