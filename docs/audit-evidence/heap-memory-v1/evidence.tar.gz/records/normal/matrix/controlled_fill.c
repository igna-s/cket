#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint16_t *p=calloc(1,sizeof *p);if(!p)return 2;
        quant bool coin=superposition(0,1);p[0]=coin?4660:4660;
        if(coin)phase(.31);size_t n=1;
        ownership_checkpoint("prepared");
        quant uint8_t saved=(uint8_t)p[0]^1;
        if(coin)memset((unsigned char*)p+1,coin?0xAB:0xCD,n);ownership_checkpoint("written");
        free((void*)p);ownership_checkpoint("freed");
        if(saved==53)phase(.17);
        ownership_checkpoint("inverse");measure(coin);return 0;}