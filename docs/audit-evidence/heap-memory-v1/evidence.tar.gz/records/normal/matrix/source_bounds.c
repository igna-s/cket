#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(1,1),*q=calloc(2,1);size_t n=2;memcpy((void*)q,(const void*)p,n);}