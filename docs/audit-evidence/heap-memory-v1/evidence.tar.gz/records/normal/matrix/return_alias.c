#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(2,1),*q=calloc(2,1);if(!p||!q)return 2;p[0]=3;p[1]=9;void *v=memcpy((void*)q,(const void*)p,2);unsigned char *b=v;memmove(b+1,b,1);v=memset(b,7,1);unsigned x=measure(q[0]),y=measure(q[1]);int bad=v!=(void*)q;free((void*)p);free((void*)q);return bad||x!=7||y!=3;}