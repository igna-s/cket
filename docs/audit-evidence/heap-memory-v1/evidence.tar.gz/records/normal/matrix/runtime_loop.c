#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(2,1),*q=calloc(2,1);if(!p||!q)return 2;p[0]=3;p[1]=9;size_t rounds=3;for(size_t i=0;i<rounds;++i){size_t n=i%2+1;memcpy((void*)q,(const void*)p,n);memset((void*)p,(int)i+4,1);}unsigned x=measure(q[0]),y=measure(q[1]);free((void*)p);free((void*)q);return x!=5||y!=9;}