#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant bool *p=calloc(2,sizeof *p);memset((void*)p,0,1);}