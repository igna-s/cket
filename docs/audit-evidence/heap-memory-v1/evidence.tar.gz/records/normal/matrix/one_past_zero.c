#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;p[0]=7;memcpy((void*)(p+2),(const void*)(p+2),0);memmove((void*)(p+2),(const void*)p,0);memset((void*)(p+2),8,0);unsigned x=measure(p[0]);free((void*)p);return x!=7;}