#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(2,sizeof *p);p[0]=1;quant uint8_t x=p[0]++ +p[0];measure(x);free((void*)p);}