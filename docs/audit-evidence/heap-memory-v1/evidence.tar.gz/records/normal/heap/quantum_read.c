#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void) {
        size_t count=2;
        quant uint8_t *p=calloc(count,sizeof *p);
        if(!p)return 2;
        p[0]=3;p[1]=9;
        quant bool coin=superposition(0,1);
        if(coin)phase(.31);
        quant uint8_t selected=p[coin]^1;
        ownership_checkpoint("retained");
        if(selected==8)phase(.17);
        ownership_checkpoint("inverse");
        free((void*)p);
        ownership_checkpoint("freed");
        measure(coin);return 0;
    }