#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){size_t rounds=30;for(size_t i=0;i<rounds;++i){quant uint8_t *p=calloc(2,sizeof *p);if(!p)return 2;p[0]=7;p[1]=9;free((void*)p);}return 0;}