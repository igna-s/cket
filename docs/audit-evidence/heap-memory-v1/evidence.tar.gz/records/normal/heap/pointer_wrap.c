#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint16_t *p=calloc(2,sizeof *p);size_t i=(size_t)1<<63;quant uint16_t x=p[i]^1;measure(x);free((void*)p);}