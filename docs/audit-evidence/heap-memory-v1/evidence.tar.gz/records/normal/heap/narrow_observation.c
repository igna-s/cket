#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(1,sizeof *p);if(!p)return 2;p[0]=255;unsigned low=measure((uint8_t)(p[0]&3));unsigned full=measure(p[0]);free((void*)p);return low!=3||full!=255;}