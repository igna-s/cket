#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
void f(quant const uint8_t *p){((uint8_t*)p)[0]=1;} int main(void){quant uint8_t *p=calloc(2,sizeof *p);f(p);free((void*)p);}