#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(1,sizeof *p);p[0]=1;quant int y=INT_MAX;p[0]+=y;measure(y);free((void*)p);}