#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void) {
        size_t count=3;
        quant uint8_t *p=malloc(count*sizeof *p);
        if(!p)return 2;
        quant bool coin=superposition(0,1);
        p[0]=1;p[1]=coin?2:6;p[2]=9;
        if(coin)phase(.31);
        quant uint8_t selected=p[1]^1;
        p=realloc((void*)p,sizeof *p);
        ownership_checkpoint("retained");
        if(selected==3)phase(.17);
        ownership_checkpoint("inverse");
        free((void*)p);
        ownership_checkpoint("freed");
        measure(coin);return 0;
    }