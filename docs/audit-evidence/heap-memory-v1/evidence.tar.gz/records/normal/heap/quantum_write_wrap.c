#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint16_t *p=calloc(2,sizeof *p);quant uint64_t i=(uint64_t)1<<63;p[i]=7;measure(i);free((void*)p);}