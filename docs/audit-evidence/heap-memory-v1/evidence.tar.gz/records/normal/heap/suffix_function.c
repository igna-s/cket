#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
quant uint8_t pick(quant const uint8_t *p,size_t i){return p[i]^1;} int main(void){quant uint8_t *p=calloc(3,sizeof *p);if(!p)return 2;p[0]=2;p[1]=5;p[2]=9;quant uint8_t result=pick(p+1,1);unsigned x=measure(result);free((void*)p);return x!=8;}