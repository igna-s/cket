#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(2,sizeof *p);quant uint8_t i=superposition(0,1);p[i]=i++;measure(i);free((void*)p);}