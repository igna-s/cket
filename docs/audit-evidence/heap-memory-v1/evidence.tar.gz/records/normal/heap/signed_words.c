#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){size_t n=2;quant int16_t *p=malloc(n*sizeof *p);if(!p)return 2;p[0]=-7;p[1]=1234;quant int16_t selected=p[1]^1;int result=measure(selected),first=measure(p[0]),second=measure(p[1]);free((void*)p);return result!=1235||first!=-7||second!=1234;}