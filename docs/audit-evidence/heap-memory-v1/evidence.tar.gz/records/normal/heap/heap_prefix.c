#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(2,sizeof *p);p[0]=3;p[1]=9;quant bool i=superposition(0,1);quant uint8_t x=++p[i];unsigned got=measure(x),j=measure(i),a=measure(p[0]),b=measure(p[1]);free((void*)p);return got!=(j?10u:4u)||a!=(j?3u:4u)||b!=(j?10u:9u);}