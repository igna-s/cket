#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(2,sizeof *p);struct S{uint8_t *p;}s={(uint8_t*)p};free((void*)p);return s.p!=0;}