#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
void f(quant uint8_t *p,quant bool i){p[i]=7;}int main(void){quant uint8_t *p=calloc(2,sizeof *p);p[0]=3;p[1]=9;quant bool i=superposition(0,1);f(p,i);unsigned j=measure(i),a=measure(p[0]),b=measure(p[1]);free((void*)p);return a!=(j?3u:7u)||b!=(j?7u:9u);}