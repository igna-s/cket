#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
void f(quant uint8_t *p){quant uint8_t *q=realloc((void*)p,3*sizeof *p);(void)q;} int main(void){quant uint8_t *p=calloc(2,sizeof *p);f(p);free((void*)p);}