#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(2,sizeof *p);size_t i=2;quant uint8_t x=p[i]^1;measure(x);free((void*)p);}