#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void) {
        size_t count=2,index=0;
        quant uint8_t *p=calloc(count,sizeof *p);
        if(!p)return 2;
        quant bool coin=superposition(0,1);
        p[0]=7;p[1]=5;if(coin)p[0]=3;
        if(coin)phase(.31);
        quant uint8_t selected=p[index]^1;
        index=1;
        p=realloc((void*)p,3*sizeof *p);
        p[2]=9;p[0]=11;
        ownership_checkpoint("retained");
        if(selected==2)phase(.17);
        ownership_checkpoint("inverse");
        free((void*)p);
        ownership_checkpoint("freed");
        measure(coin);return index!=1;
    }