#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=NULL;p=realloc((void*)p,2*sizeof *p);if(!p)return 2;p[0]=5;unsigned x=measure(p[0]);free((void*)p);return x!=5;}