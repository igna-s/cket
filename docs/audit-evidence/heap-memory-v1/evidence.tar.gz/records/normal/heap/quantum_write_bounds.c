#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(2,sizeof *p);quant uint8_t i=superposition(0,3);p[i]=7;measure(i);free((void*)p);}