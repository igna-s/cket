#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=NULL;quant bool b=0;if(b)p[0]=1;measure(b);return 0;}