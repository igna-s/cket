#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant uint8_t *p=calloc(2,sizeof *p);
        if(!p)return 2;
        p[0]=3;p[1]=9;
        quant bool coin=superposition(0,1);
        if(coin)phase(.31);
        ownership_checkpoint("prepared");
        if(!coin)p[coin]=7;
        ownership_checkpoint("written");
        if(p[0]==7)phase(.17);
        ownership_checkpoint("inverse");
        free((void*)p);
        ownership_checkpoint("freed");
        measure(coin);return 0;
    }