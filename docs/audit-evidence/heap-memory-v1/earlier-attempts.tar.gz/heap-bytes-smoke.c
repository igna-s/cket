#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    quant uint16_t *p = calloc(2, sizeof *p);
    quant uint8_t *q = calloc(3, sizeof *q);
    if (!p || !q) return 2;
    size_t count = 3;
    p[0] = 0x1234; p[1] = 0x5678;
    memcpy(q, (unsigned char *)p + 1, count);
    unsigned a = measure(q[0]), b = measure(q[1]), c = measure(q[2]);
    memmove((unsigned char *)p + 1, p, count);
    unsigned d = measure(p[0]), e = measure(p[1]);
    memset((unsigned char *)p + 1, 0xab, 2);
    unsigned f = measure(p[0]), g = measure(p[1]);
    free((void *)p); free((void *)q);
    return a != 0x12 || b != 0x78 || c != 0x56 || d != 0x3434 ||
           e != 0x7812 || f != 0xab34 || g != 0x78ab;
}
