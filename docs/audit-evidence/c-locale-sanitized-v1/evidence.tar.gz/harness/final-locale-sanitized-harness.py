import hashlib, json, os, posixpath, shutil, subprocess, time
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
source = r / 'build/return-reference-source-v1'
target = r / 'build/return-reference-sanitized-v1'
out = r / 'build/final-locale-sanitized-v1'
out.mkdir()
current = json.loads((source/'source-hashes.json').read_text())
pools = [
    (r/'build/single-fill-sanitized-v2', json.loads((r/'build/single-fill-source-v2/source-hashes.json').read_text())),
    (r/'build/string-writes-sanitized-v1', json.loads((r/'build/string-writes-source-v1/source-hashes.json').read_text())),
]
env = dict(os.environ, CC=str(target/'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
env.pop('CKET_SIMULATOR', None)
names = ['validate_profiles','validate_numeric_locale']
records, artifacts = [], {}
started = time.monotonic()
deadline = started + 45
(out/'process.json').write_text(json.dumps(dict(pid=os.getpid(),started_unix=time.time(),
    maximum_elapsed_seconds=45,source_snapshot=str(source),scope='Priority sanitized C validators; no Python state matrices or external SDK/fuzzing in this sweep.'),indent=2)+'\n')

def publish(status, **extra):
    (out/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    if status != 'running':
        assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in current.items())
        (out/'terminal.json').write_text(json.dumps(dict(status=status,completed_commands=len(records),
            elapsed_seconds=time.monotonic()-started,frozen_inputs_unchanged=True,**extra),indent=2)+'\n')

for name in names:
    if time.monotonic() >= deadline:
        publish('time-budget-exhausted',next_validator=name);break
    dep_command = ['gcc-11','-std=c11','-Isrc/engine','-MM','tests/'+name+'.c','tests/validation.c']
    deps = subprocess.check_output(dep_command,cwd=source,text=True).replace('\\\n',' ').split()
    dependencies = sorted({posixpath.normpath(p) for p in deps if not p.endswith(':')})
    assert all(p in current for p in dependencies),dependencies
    executable = target/'build'/name
    reuse = None
    for original, old in pools:
        binary = original/'build'/name
        if binary.exists() and all(old.get(p)==current[p] for p in dependencies):
            assert hashlib.sha256((original/'build/libcket_quantum.a').read_bytes()).hexdigest()==hashlib.sha256((target/'build/libcket_quantum.a').read_bytes()).hexdigest()
            shutil.copy2(binary,executable)
            reuse = str(binary)
            break
    if reuse is None:
        command = ['gcc-11','-std=c11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',
            '-fno-pie','-no-pie','-Wall','-Wextra','-Werror','-Isrc/engine','tests/'+name+'.c',
            'tests/validation.c',str(target/'build/libcket_quantum.a'),'-lm','-o',str(executable)]
        z = subprocess.run(command,cwd=source,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (out/(name+'-build.log')).write_text(z.stdout)
        assert z.returncode==0,z.stdout
    symbols = subprocess.check_output(['nm','-u',str(executable)],text=True)
    assert '__asan_init' in symbols and '__ubsan_handle' in symbols
    artifacts[name] = dict(sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
        reused_from=reuse,dependency_sha256={p:current[p] for p in dependencies},
        dependency_command=dep_command,instrumentation=symbols)
    case_env = dict(env)
    if name in ('validate_ctype','validate_numeric_locale'):
        case_env['LSAN_OPTIONS']='suppressions='+str(source/'tests/glibc-locale.lsan')+':print_suppressions=0'
    try:
        with (out/(name+'.log')).open('w') as log:
            z = subprocess.run([str(executable)],cwd=source,env=case_env,stdout=log,
                stderr=subprocess.STDOUT,timeout=min(900,max(1,deadline-time.monotonic())))
    except subprocess.TimeoutExpired:
        publish('time-budget-exhausted',interrupted_validator=name);break
    records.append(dict(name=name,command=[str(executable)],exit_code=z.returncode,log=name+'.log'))
    publish('running')
    print(name,z.returncode,(out/(name+'.log')).read_text()[-1800:],flush=True)
    if z.returncode:
        publish('failed',failed_validator=name,exit_code=z.returncode);break
else:
    publish('passed',exit_code=0)
