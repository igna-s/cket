from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
s=(r/'build/run-sanitized-priority-sweep.py').read_text()
s=s.replace('import hashlib, json, os, shutil, subprocess, time','import hashlib, json, os, posixpath, shutil, subprocess, time')
s=s.replace("out = r / 'build/sanitized-priority-sweep-v1'","out = r / 'build/final-locale-sanitized-v1'")
start=s.index('names = [');end=s.index('\nrecords, artifacts',start)
s=s[:start]+"names = ['validate_profiles','validate_numeric_locale']"+s[end:]
s=s.replace('deadline = started + 24*60','deadline = started + 45').replace('maximum_elapsed_seconds=24*60','maximum_elapsed_seconds=45')
s=s.replace("dependencies = sorted({p for p in deps if not p.endswith(':')})","dependencies = sorted({posixpath.normpath(p) for p in deps if not p.endswith(':')})")
path=r/'build/final-locale-sanitized-harness.py'
path.write_text(s)
exec(compile(s,str(path),'exec'))
