import hashlib,json,runpy,tarfile
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
out=r/'build/final-locale-sanitized-v1'
terminal=json.loads((out/'terminal.json').read_text())
assert terminal['status']=='passed' and terminal['completed_commands']==2
commands=json.loads((out/'commands.json').read_text())
assert all(x['exit_code']==0 for x in commands)
artifacts=json.loads((out/'artifacts.json').read_text())
source=runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
assert source==json.loads((r/'build/qasm-cpu-source-v2/source-hashes.json').read_text())
for row in artifacts.values():
    assert all(source[p]==h for p,h in row['dependency_sha256'].items())
    assert '__asan_init' in row['instrumentation'] and '__ubsan_handle' in row['instrumentation']
dest=r/'docs/audit-evidence/c-locale-sanitized-v1'
dest.mkdir()
(dest/'README.es.md').write_text('''# Perfiles y locale numérico: continuación instrumentada

26 de octubre de 2026. Pasan 96 comprobaciones de perfiles inmutables y 70 de locale numérico
con ASan/UBSan. Son dos validadores pendientes de la
[campaña anterior](../c-priority-integration-v1/README.es.md); no se repiten sus diez aprobados.

La evidencia verifica las dependencias locales y la instrumentación de los binarios reutilizados.
El único cambio entre las fuentes del harness anterior y las actuales afecta al test QASM,
que no es dependencia de estos validadores. El compilador y motor permanecen iguales al SDK.
Para locale se conserva la exclusión específica de glibc, comprobada en la campaña anterior.

`evidence.tar.gz` conserva las 237 entradas actuales, comandos, hashes y logs. Quedan cinco
validadores instrumentados de aquella campaña: capturas de bytes, operandos controlados,
división, ctype y frontera de libc. Esta continuación no completa `scripts/verify.sh`,
la revisión general de papers ni el perfil cotidiano. La ciberseguridad permanece clásica.
''')
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
p=dest/'README.es.md';p.write_text(fmt(p,p.read_text()))
with tarfile.open(dest/'evidence.tar.gz','w:gz') as tar:
    for name in source:tar.add(r/name,arcname='sources/'+name)
    for p in sorted(out.iterdir()):
        if p.is_file():tar.add(p,arcname='results/'+p.name)
    for name in ('run-final-locale-sanitized.py','final-locale-sanitized-harness.py','archive-final-locale-sanitized.py'):
        tar.add(r/'build'/name,arcname='harness/'+name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=dict(status='passed-two-additional-sanitized-validators',date='2026-10-26',base_commit='9040bbb',source_files=237,source_sha256=source,production_sources_changed=False,
    sanitized_counts=dict(profiles=96,numeric_locale=70),remaining_from_prior_campaign=['byte_snapshots','controlled_operands','division','ctype','library_boundary'],
    artifact_sha256={'evidence.tar.gz':sha(dest/'evidence.tar.gz')})
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=[p.relative_to(r).as_posix() for p in sorted(dest.iterdir()) if p.is_file()]
expected=json.loads((r/'build/paper-map-git-expected.json').read_text())
expected.update({n:sha(r/n) for n in names})
(r/'build/locale-final-git-expected.json').write_text(json.dumps(expected,indent=2)+'\n')
(r/'build/locale-final-import.txt').write_text('\n'.join(names+['build/locale-final-git-expected.json'])+'\n')
print('Ready:',len(expected),'exact files; profiles 96 and numeric locale 70 instrumented checks passed')
