from pathlib import Path
import json, runpy, shutil
root=Path('/tmp/quantum-audit-isolated-20261017')
inventory=runpy.run_path(str(root/'scripts/inventory_c11.py'))
p=root/'docs/c11-library.json'; data=json.loads(p.read_text())
for row in data['interfaces']:
    if row['header']=='string.h' and row['name'] in {'memcpy','memmove'}:
        status,classes,milestone,tests,contract=inventory['semantics'](row['header'],row['name'],row['kind'],False)
        row.update(quantum=status,restriction_classes=classes,milestone=milestone,tests=tests,contract=contract)
p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
files='''src/cket_plugin.cpp src/quantum_frontend.inc src/quantum_heap.inc src/quantum_heap_transfer.inc
src/quantum_semantics.inc src/engine/binding.inc src/engine/heap_memory.inc src/engine/verify.c
scripts/validate-heap-transfer.py scripts/validate-heap-memory.py tests/heap_transfer_trace.c
tests/heap_memory_state.inc tests/validate_heap.c scripts/archive-audit.py scripts/inventory_c11.py
scripts/run-block.sh examples/blocks/05/heap_transfer.c README.md docs/c11-heap.md docs/c11-library.json
docs/estado-general-del-proyecto.es.md docs/perfil-c-cotidiano.es.md docs/entregas-incrementales.es.md'''.split()
fmt=runpy.run_path(str(root/'scripts/format.py'))['format_text']
for name in files:
    p=root/name;p.write_text(fmt(p,p.read_text()))
(root/'build/heap-transfer-changed-files.txt').write_text('\n'.join(files)+'\n')
sources=runpy.run_path(str(root/'scripts/archive-audit.py'))['source_hashes']()
target=root/'build/heap-transfer-source-v1';target.mkdir()
for name in sources:
    p=target/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,p)
(target/'.deps').symlink_to(root/'.deps',target_is_directory=True)
(target/'cket').chmod(0o755);(target/'docs').mkdir()
shutil.copy2(root/'docs/c11-library.json',target/'docs/c11-library.json')
(target/'source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
print('Formatted',len(files),'files; frozen',len(sources),'inputs.',flush=True)
