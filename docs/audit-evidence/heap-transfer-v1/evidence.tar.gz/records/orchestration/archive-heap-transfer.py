from pathlib import Path
from collections import Counter
import hashlib,json,runpy,subprocess,tarfile
root=Path('/tmp/quantum-audit-isolated-20261017');project=root/'build/heap-transfer-source-v1'
normal=root/'build/heap-transfer-normal-results-v1';sanitized=root/'build/heap-transfer-sanitized-results-v1'
sanbuild=root/'build/heap-transfer-sanitized-v1';folder=root/'docs/audit-evidence/heap-transfer-v1'
folder.mkdir(parents=True,exist_ok=True);assert not (folder/'summary.json').exists()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
sources=json.loads((project/'source-hashes.json').read_text())
assert sources==runpy.run_path(str(root/'scripts/archive-audit.py'))['source_hashes']()
assert len(sources)==210 and all(sha(project/name)==digest for name,digest in sources.items())
n=json.loads((normal/'matrix/summary.json').read_text());s=json.loads((sanitized/'matrix/summary.json').read_text())
assert n['status']==s['status']=='passed'
assert (n['full_state_checkpoints'],s['full_state_checkpoints'])==(168,56)
assert (n['complete_gate_inverses'],s['complete_gate_inverses'])==(42,14)
for location in (normal,sanitized):
    assert all(row['exit_code']==0 or (row['label']=='static-export' and row['exit_code']>0) for row in json.loads((location/'exit.json').read_text()))
    assert '16878 heap checks passed' in (location/'heap-engine.log').read_text()
assert '395 passed, 0 failed' in (normal/'native-core.log').read_text()
assert '4 executables, 0 QASM' in (normal/'block05.log').read_text()
for path in (project/'build-exit.json',sanbuild/'build-exit.json'):
    assert json.loads(path.read_text())['exit_code']==0
components=['cket_plugin.so','json.o','quantum.o','verify.o','simulator.o','cket_runtime.o','cket','validate_heap']
tool_hashes={mode:{name:sha(location/'build'/name) for name in components} for mode,location in [('normal',project),('sanitized',sanbuild)]}
(folder/'tool-sha256.json').write_text(json.dumps(tool_hashes,indent=2)+'\n')
with tarfile.open(folder/'evidence.tar.gz','x:gz') as archive:
    for name in sources:archive.add(project/name,arcname='sources/'+name)
    archive.add(root/'LICENSE',arcname='sources/LICENSE')
    for label,path in [('source-hashes.json',project/'source-hashes.json'),('inventory-fixture.json',project/'docs/c11-library.json'),('tool-sha256.json',folder/'tool-sha256.json')]:
        archive.add(path,arcname='records/'+label)
    for mode,location in [('normal',normal),('sanitized',sanitized)]:
        for path in location.rglob('*'):
            if path.is_file() and path.suffix in ('.json','.log','.c'):
                archive.add(path,arcname='records/'+mode+'/'+path.relative_to(location).as_posix())
    for name in ('build.log','build-exit.json','build-sanitized.sh'):
        archive.add(sanbuild/name,arcname='records/sanitized-build/'+name)
    for name in ('build-normal.log','build-exit.json'):
        archive.add(project/name,arcname='records/normal-build/'+name)
    for name in ('prepare-heap-transfer.py','run-heap-transfer-final.py','archive-heap-transfer.py'):
        archive.add(root/'build'/name,arcname='records/orchestration/'+name)
with tarfile.open(folder/'earlier-attempts.tar.gz','x:gz') as archive:
    for location in (root/'build').glob('heap-transfer-prototype-v*'):
        for path in location.rglob('*'):
            if path.is_file() and path.suffix in ('.json','.log','.c'):
                archive.add(path,arcname=location.name+'/'+path.relative_to(location).as_posix())
    archive.add(root/'build/heap-transfer-smoke.c',arcname='heap-transfer-smoke.c')
regressions={mode:{label:json.loads((location/label/'summary.json').read_text()) for label in ('heap-regression','byte-regression')} for mode,location in [('normal',normal),('sanitized',sanitized)]}
summary=dict(date='2026-10-24',status='finite-fixed-heap-transfer-qualified',source_files=210,source_sha256=sources,
    artifact_sha256={name:sha(folder/name) for name in ('evidence.tar.gz','earlier-attempts.tar.gz','tool-sha256.json')},
    normal=n,sanitized=s,full_state_checkpoints=224,complete_gate_inverses=56,native_program_executions=20,
    semantic_rejections=28,heap_engine_mixed_checks_per_configuration=16878,new_malformed_IR_cases=8,
    bound_heap_byte_phase_checkpoints_per_configuration=4,normal_native_core_checks=395,regressions=regressions,
    delivery=dict(block05_native_executables=4,static_exports=0,sanitized_example_executions=1),
    inventory=dict(Counter(row['quantum'] for row in json.loads((root/'docs/c11-library.json').read_text())['interfaces'])),
    compiler=subprocess.check_output(['gcc-11','-dumpfullversion'],text=True).strip(),
    source_scope='Both clean normal and ASan/UBSan builds and final checks use the exact same 210 frozen inputs. Documentation is outside this compiled/test-input manifest. Prototype records have their own outcomes without complete frozen compiler-source provenance.',
    limitations=['Finite fixed/heap and known CPU source byte transfers; no complete everyday-C, C11 or libc claim.',
        'Normal matrix O0/O2/Os, sanitized O1, both synthesis policies; checkpoints repeat finite profiles, not arbitrary independent states.',
        'Fixed views require checked static addresses; runtime CPU lengths are supported. Heap-to-fixed writes inside CPU loops require per-iteration history and remain pending.',
        'Whole-byte integer quantum layouts, at most 64 bytes per operation, with separate 128-wire/history and synthesis budgets.',
        'General returned-pointer/indirect ABI, quantum floating point and string adapters over heaps remain pending.',
        'Host GCC is uninstrumented; the existing wrapper disables host-process leak attribution for its instrumented plugin. Generated programs retain leak detection.',
        'Historical suites and papers are not fully re-audited by this campaign; no physical-QPU or speedup claim.'])
(folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
p=root/'docs/audit-evidence/delivery-index.json';index=json.loads(p.read_text());index['active']='heap-transfer-v1';index['history'].append('heap-transfer-v1')
index['meaning']='Current source identity selects finite fixed/heap transfer validation. Historical artifacts retain their own inputs/results; full everyday C integration and paper audit remain open.'
p.write_text(json.dumps(index,indent=2)+'\n')
(root/'docs/paper/evidence/current-implementation.json').write_text(json.dumps(dict(date='2026-10-24',status=summary['status'],source_files=210,source_sha256=sources,directed_evidence='../../audit-evidence/heap-transfer-v1/summary.json',paper_audit='pending',meaning='Directed fixed/heap transfer validation does not regenerate or certify historical paper reports.'),indent=2)+'\n')
print(json.dumps({key:summary[key] for key in ('status','source_files','full_state_checkpoints','complete_gate_inverses')}),flush=True)
