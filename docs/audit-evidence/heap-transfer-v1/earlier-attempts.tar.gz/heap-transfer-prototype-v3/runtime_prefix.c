#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;p[0]=3;p[1]=9;quant uint8_t out[2]={7,11};size_t n=1;memcpy((void*)out,(const void*)p,n);unsigned a=measure(out[0]),b=measure(out[1]);free((void*)p);return a!=3||b!=11;}