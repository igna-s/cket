#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(1,1);volatile unsigned char a=7;memcpy((void*)p,(const void*)&a,1);free((void*)p);}