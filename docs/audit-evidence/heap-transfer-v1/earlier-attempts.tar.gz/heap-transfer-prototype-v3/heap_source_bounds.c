#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(1,1);quant uint8_t out[2]={7,9};size_t n=2;memcpy((void*)out,(const void*)p,n);measure(out[0]);measure(out[1]);free((void*)p);}