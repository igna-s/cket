#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(1,1);if(!p)return 2;
        quant bool coin=superposition(0,1);quant uint8_t fixed[1]={0};fixed[0]=coin?9:3;p[0]=coin?5:5;
        if(coin)phase(.31);size_t n=0;ownership_checkpoint("prepared");
        memcpy((void*)fixed,(const void*)(p+1),n);quant uint8_t saved=fixed[0]^1;ownership_checkpoint("written");
        free((void*)p);ownership_checkpoint("freed");
        if(saved==8)phase(.17);ownership_checkpoint("inverse");
        measure(fixed[0]);measure(coin);return 0;}