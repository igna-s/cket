#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(2,1);quant uint8_t a=7;size_t n=2;memcpy((void*)p,(const void*)&a,n);measure(a);free((void*)p);}