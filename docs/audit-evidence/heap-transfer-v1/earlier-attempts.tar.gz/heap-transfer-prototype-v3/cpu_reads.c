#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(4,1);if(!p)return 2;unsigned char input[4]={3,5,7,9};size_t n=2;memcpy((void*)p,input,n);quant bool inactive=0;if(inactive)memcpy((void*)p,input,n);unsigned reads=heap_transfer_read_count();unsigned a=measure(p[0]),b=measure(p[1]),c=measure(p[2]);measure(inactive);free((void*)p);return reads!=2||a!=3||b!=5||c!=0;}