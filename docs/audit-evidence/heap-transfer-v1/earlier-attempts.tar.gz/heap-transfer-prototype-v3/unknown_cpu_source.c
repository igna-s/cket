#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
void f(quant uint8_t *p,const void *unknown){memcpy((void*)p,unknown,1);}int main(void){quant uint8_t *p=calloc(1,1);f(p,(void*)0);free((void*)p);}