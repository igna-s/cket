#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;
        quant bool coin=superposition(0,1);unsigned char fixed[2]={3,5};p[0]=coin?7:7;p[1]=coin?11:11;
        if(coin)phase(.31);size_t n=2;ownership_checkpoint("prepared");
        memcpy((void*)p,fixed,n);fixed[0]=99;quant uint8_t saved=p[0]^1;ownership_checkpoint("written");
        free((void*)p);ownership_checkpoint("freed");
        if(saved==2)phase(.17);ownership_checkpoint("inverse");
        measure(coin);return 0;}