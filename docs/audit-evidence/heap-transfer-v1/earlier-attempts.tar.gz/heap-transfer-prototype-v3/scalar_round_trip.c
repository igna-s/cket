#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;quant uint16_t a=0x1234,b=0;size_t n=2;memcpy((void*)p,(const void*)&a,n);memcpy((void*)&b,(const void*)p,n);unsigned x=measure(a),y=measure(b);free((void*)p);return x!=0x1234||y!=0x1234;}