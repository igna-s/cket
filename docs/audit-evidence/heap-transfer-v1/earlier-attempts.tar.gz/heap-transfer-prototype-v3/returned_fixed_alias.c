#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;p[0]=3;p[1]=9;quant uint8_t out[2]={0,0};void *alias=memcpy((void*)out,(const void*)p,2);memset(alias,7,1);unsigned a=measure(out[0]),b=measure(out[1]);free((void*)p);return a!=7||b!=9;}