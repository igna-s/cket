#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;
        quant bool coin=superposition(0,1);quant uint8_t fixed[2]={7,11};p[0]=coin?9:3;p[1]=coin?5:5;
        if(coin)phase(.31);size_t n=2;ownership_checkpoint("prepared");
        memcpy((void*)fixed,(const void*)p,n);quant uint8_t saved=fixed[0]^1;ownership_checkpoint("written");
        free((void*)p);ownership_checkpoint("freed");
        if(saved==8)phase(.17);ownership_checkpoint("inverse");
        measure(fixed[0]);measure(fixed[1]);measure(coin);return 0;}