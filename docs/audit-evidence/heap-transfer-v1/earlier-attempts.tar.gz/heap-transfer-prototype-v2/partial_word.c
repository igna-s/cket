#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(1,1);if(!p)return 2;
        quant bool coin=superposition(0,1);quant uint16_t fixed[1]={0xAAAA};p[0]=coin?9:3;
        if(coin)phase(.31);size_t n=1;ownership_checkpoint("prepared");
        memmove((unsigned char*)fixed+1,(const void*)p,n);quant uint8_t saved=(uint8_t)(fixed[0]>>8)^1;ownership_checkpoint("written");
        free((void*)p);ownership_checkpoint("freed");
        if(saved==8)phase(.17);ownership_checkpoint("inverse");
        measure(fixed[0]);measure(coin);return 0;}