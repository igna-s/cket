#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    unsigned char cpu[2] = {1, 2};
    quant uint8_t *p = calloc(2, 1);
    if (!p) return 2;
    quant uint16_t input[1] = {0x1234};
    quant uint16_t output[1] = {0xaaaa};
    size_t n = 2;
    memcpy((void*)p, cpu, n);
    unsigned a = measure(p[0]), b = measure(p[1]);
    memcpy((void*)p, (const void*)input, n);
    memmove((void*)output, (const void*)p, n);
    unsigned x = measure(output[0]);
    unsigned i = measure(input[0]);
    free((void*)p);
    return a != 1 || b != 2 || x != 0x1234 || i != 0x1234;
}
