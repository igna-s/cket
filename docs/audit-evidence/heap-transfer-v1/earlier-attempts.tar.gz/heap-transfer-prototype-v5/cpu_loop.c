#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;unsigned char input[2]={3,5};size_t rounds=3;for(size_t i=0;i<rounds;++i){input[0]=(unsigned char)(i+3);memcpy((void*)p,input,2);}unsigned reads=heap_transfer_read_count(),a=measure(p[0]),b=measure(p[1]);free((void*)p);return reads!=6||a!=5||b!=5;}