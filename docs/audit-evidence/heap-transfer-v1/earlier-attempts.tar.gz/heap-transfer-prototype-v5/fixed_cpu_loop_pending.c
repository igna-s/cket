#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
unsigned heap_transfer_read_count(void);
int main(int argc,char **argv){quant uint8_t *p=calloc(1,1);quant uint8_t out=7;for(int i=0;i<argc;++i)memcpy((void*)&out,(const void*)p,1);measure(out);free((void*)p);return argv==0;}