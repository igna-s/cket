from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import runpy
import shutil
import subprocess
import sys
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/ownership-contracts-v6'
project.mkdir()
(project / 'build').mkdir()
sources = runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
assert len(sources) == 195, len(sources)
for name in sources:
    target = project / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, target)
shutil.copy2(root / 'LICENSE', project / 'LICENSE')
(project / '.deps').mkdir()
(project / '.deps/gcc').symlink_to(root / '.deps/gcc', target_is_directory=True)
(project / 'build/sources.json').write_text(json.dumps(sources, indent=2) + '\n')
record = {'status': 'building', 'commands': []}
commands = [('build.log', ['bash', 'scripts/build.sh'])]
for name in ('decimal_conversion', 'search_write'):
    commands.append((name + '-compile.log', ['build/cket', f'examples/blocks/06/{name}.c',
                     '-O2', '-o', 'build/' + name]))
commands.append(('quantum_index-compile.log', ['build/cket', 'examples/blocks/04/quantum_index.c', '-O2', '-o', 'build/quantum_index']))
for name in ('buffer_functions', 'buffer_words'):
    commands.append((name + '-compile.log', ['build/cket', f'examples/blocks/03/{name}.c', '-O2', '-o', 'build/' + name]))
for name in ('cpu_vector_scan', 'cpu_vector_return'):
    commands.append((name + '-compile.log', ['build/cket', f'examples/blocks/03/{name}.c', '-O2', '-o', 'build/' + name]))
for log, arguments in commands:
    with (project / 'build' / log).open('x') as output:
        result = subprocess.run(arguments, cwd=project, env=dict(os.environ, CC='gcc-11', CXX='g++-11'),
                                stdout=output, stderr=subprocess.STDOUT)
    record['commands'].append({'command': arguments, 'exit_code': result.returncode, 'log': log})
    record['status'] = 'failed' if result.returncode else 'building'
    (project / 'build/exit.json').write_text(json.dumps(record, indent=2) + '\n')
    print(log, result.returncode, flush=True)
    if result.returncode:
        print((project / 'build' / log).read_text()[-4500:], flush=True)
        sys.exit(result.returncode)
record['status'] = 'built-qualification-in-progress'
(project / 'build/exit.json').write_text(json.dumps(record, indent=2) + '\n')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert all(digest(root / name) == sha == digest(project / name) for name, sha in sources.items())
