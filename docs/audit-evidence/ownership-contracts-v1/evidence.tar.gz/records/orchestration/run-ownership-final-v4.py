from pathlib import Path
import subprocess,os,json,sys
root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/ownership-contracts-v6'
mode=sys.argv[1]
if mode=='sanitize-build':
    target=root/'build/ownership-contracts-sanitized-v4'
    target.mkdir()
    prefix=(project/'scripts/sanitize-all.sh').read_text().split('\nexport CKET_REAL_GCC="$real_cc"')[0]
    prefix=prefix.replace('cd "$(dirname "$0")/.."','cd "'+str(project)+'"')
    script=target/'build-sanitized.sh'
    script.write_text(prefix+'\n')
    with (target/'build.log').open('x') as out:
        result=subprocess.run(['bash',str(script)],cwd=project,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SAN_ROOT=str(target)))
    (target/'build-exit.json').write_text(json.dumps({'exit_code':result.returncode,'command':['bash',str(script)],'normal_source_root':str(project)},indent=2)+'\n')
    print('Sanitized build',result.returncode,flush=True)
    if result.returncode: print((target/'build.log').read_text()[-5000:],flush=True)
    sys.exit(result.returncode)
output=root/'build/ownership-normal-v4'
output.mkdir()
env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SEED='7')
records=[]
commands=[('ownership-matrix',['python3','scripts/validate-ownership.py','--compiler-root',str(project),'--output',str(output/'matrix'),'--levels','O0','O1','O2','O3','Os'])]
for name in ('decimal_conversion','search_write','quantum_index','buffer_functions','buffer_words','cpu_vector_scan','cpu_vector_return'):
    commands.append((name,[str(project/'build'/name)]))
for name in ('cket_tests','validate_expressions','validate_inplace','validate_memcopy','validate_history','validate_controlled_operands'):
    commands.append((name,[str(project/'build'/name),str(project)] if name=='cket_tests' else [str(project/'build'/name)]))
for name,command in commands:
    selected_env=dict(env,CKET_SIMULATOR='sparse') if name in ('decimal_conversion','search_write','quantum_index','buffer_functions','buffer_words','cpu_vector_scan','cpu_vector_return') else env
    with (output/(name+'.log')).open('x') as out:
        result=subprocess.run(command,cwd=project,env=selected_env,stdout=out,stderr=subprocess.STDOUT)
    records.append({'label':name,'command':command,'exit_code':result.returncode,'log':name+'.log'})
    (output/'exit.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,(output/(name+'.log')).read_text()[-700:],flush=True)
    if result.returncode: sys.exit(result.returncode)