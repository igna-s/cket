from pathlib import Path
import subprocess,os,json,sys
root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/ownership-contracts-v6'
records=[]
for block in ('03','04'):
    with (project/'build'/('block'+block+'-runner.log')).open('x') as out:
        command=['bash','scripts/run-block.sh',block]
        result=subprocess.run(command,cwd=project,env=dict(os.environ,CC='gcc-11',CXX='g++-11'),stdout=out,stderr=subprocess.STDOUT)
    records.append({'command':command,'exit_code':result.returncode})
    (project/'build/runner-exit.json').write_text(json.dumps(records,indent=2)+'\n')
    print(block,result.returncode,(project/'build'/('block'+block+'-runner.log')).read_text()[-2000:],flush=True)
    if result.returncode:sys.exit(result.returncode)