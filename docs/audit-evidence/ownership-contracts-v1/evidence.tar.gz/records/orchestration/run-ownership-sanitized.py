from pathlib import Path
import subprocess,os,json,sys
root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/ownership-contracts-sanitized-v4'
source=root/'build/ownership-contracts-v6'
output=root/'build/ownership-sanitized-v1'
output.mkdir()
env=dict(os.environ, CC=str(project/'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
records=[]
commands=[('ownership-matrix',['python3',str(source/'scripts/validate-ownership.py'),'--compiler-root',str(project),'--output',str(output/'matrix'),'--levels','O1','--sanitized']),('cket_tests',[str(project/'build/cket_tests'),str(project)])]
for name,command in commands:
    with (output/(name+'.log')).open('x') as out:
        result=subprocess.run(command,cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT)
    records.append({'label':name,'command':command,'exit_code':result.returncode,'log':name+'.log'})
    (output/'exit.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,(output/(name+'.log')).read_text()[-1500:],flush=True)
    if result.returncode: sys.exit(result.returncode)