import hashlib
import io
import json
import runpy
import tarfile
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/runtime-memory-reference-source-v1'
previous = r / 'build/function-entry-source-v2'
out = r / 'build/runtime-memory-reference-results-v1'
contracts = r / 'build/runtime-memory-reference-contracts-v1'
destination = r / 'docs/audit-evidence/runtime-memory-reference-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((project / 'source-hashes.json').read_text())
old = json.loads((previous / 'source-hashes.json').read_text())
changed = [n for n in source if source[n] != old[n]]
assert len(source) == 240 and changed == ['scripts/validate-runtime-memory.py']
assert runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']() == source
assert all(sha(project / n) == h for n, h in source.items())
terminal = json.loads((out / 'terminal.json').read_text())
assert terminal['status'] == 'passed' and terminal['source_sha256'] == source
assert all(row['exit_code'] == 0 for row in json.loads((out / 'commands.json').read_text()))
normal = json.loads((r / 'build/runtime-memory-reference-normal-v1/summary.json').read_text())
san = json.loads((r / 'build/runtime-memory-reference-sanitized-v1/summary.json').read_text())
assert normal['status'] == san['status'] == 'passed'
assert (normal['full_state_checkpoints'], normal['complete_gate_inverses']) == (600, 180)
assert (san['full_state_checkpoints'], san['complete_gate_inverses']) == (300, 90)
mutation = json.loads((contracts / 'summary.json').read_text())
assert mutation['status'] == 'passed' and mutation['valid_unitary_mutations_rejected'] == 3
old_reference = runpy.run_path(str(previous / 'scripts/validate-runtime-memory.py'))
points = json.loads((contracts / 'positive-trace.json').read_text())
try:
    old_reference['check']('fill', points, 0, 1)
except AssertionError as error:
    assert str(error) == 'unmodelled retained version', error
    baseline = dict(status='reproduced',profile='fill',length=0,rounds=1,
                    failure=str(error),scope='Old reference on current checked-entry producer trace, not a rerun of the remote CI revision.')
else:
    raise AssertionError('Old reference did not reproduce the failure')
(out / 'baseline-reference.json').write_text(json.dumps(baseline, indent=2) + '\n')
artifacts = {}
entry = json.loads((r / 'build/function-entry-results-v2/terminal.json').read_text())
for mode, target in [('normal', project), ('sanitized', r / 'build/function-entry-sanitized-v2')]:
    artifacts[mode] = {}
    for name in ('cket', 'cket_backend', 'cket_plugin.so', 'cket_runtime.o', 'libcket_quantum.a', 'gcc-version.txt'):
        actual = sha(target / 'build' / name)
        base = previous if mode == 'normal' else target
        assert actual == sha(base / 'build' / name)
        if name in entry['final_artifact_sha256'][mode]:
            assert actual == entry['final_artifact_sha256'][mode][name]
        artifacts[mode][name] = actual
    if mode == 'sanitized':
        artifacts[mode]['gcc-wrapper'] = sha(target / 'build/gcc-wrapper')
assert artifacts['normal'] == terminal['reused_normal_artifacts_sha256']
sdk = json.loads((r / 'output/sdk/checked-entry/sdk-audit.json').read_text())
assert sdk['source_sha256'] == old
assert sdk['package_sha256'] == sha(r / 'output/sdk/checked-entry/cket-sdk-linux-x86_64.tar.gz')

docs = ['docs/c11-runtime-memory.md', 'docs/estado-general-del-proyecto.es.md',
        'docs/entrega-utilizable-2026-10-26.es.md', 'output/sdk/checked-entry/README.es.md',
        'docs/audit-evidence/runtime-memory-reference-v1/README.es.md']
fmt = runpy.run_path(str(r / 'scripts/format.py'))['format_text']
for name in docs:
    p = r / name
    p.write_text(fmt(p, p.read_text()))
assert not (destination / 'summary.json').exists()

def raw(tar, name, value):
    data = (json.dumps(value, indent=2) + '\n').encode()
    info = tarfile.TarInfo(name)
    info.size = len(data)
    tar.addfile(info, io.BytesIO(data))

def tree(tar, folder, prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json', '.log', '.txt', '.c', '.py'):
            tar.add(p, arcname=prefix + '/' + p.relative_to(folder).as_posix())

with tarfile.open(destination / 'evidence.tar.gz', 'w:gz') as tar:
    for name in source:
        tar.add(project / name, arcname='sources/' + name)
    raw(tar, 'source-identities.json', dict(qualified=source, previous=old))
    raw(tar, 'unchanged-producer-artifacts.json', artifacts)
    tar.add(previous / changed[0], arcname='baseline/validate-runtime-memory.py')
    tree(tar, out, 'qualification')
    tree(tar, r / 'build/runtime-memory-reference-normal-v1', 'normal')
    tree(tar, r / 'build/runtime-memory-reference-sanitized-v1', 'sanitized')
    tree(tar, contracts, 'reference-contracts')
    tree(tar, r / 'build/runtime-memory-debug-v1', 'baseline/local-reproduction')
    for name in ('readonly-ci-run-v1.json', 'readonly-ci-failed-v1.log'):
        tar.add(r / 'build' / name, arcname='baseline/remote-ci/' + name)
    for name in ('qualify-runtime-memory-reference.py', 'check-runtime-memory-reference-contracts.py', 'publish-runtime-memory-reference.py'):
        tar.add(r / 'build' / name, arcname='harness/' + name)
    for name in docs:
        tar.add(r / name, arcname='documentation/' + name)

summary = dict(status='passed-targeted-reference-correction-full-integration-pending',
    date='2026-10-27', base_commit='860e7c3', version='1.0.0-rc.3',
    source_files=240, source_sha256=source, changed_inputs=changed,
    production_sources_unchanged=True, producer_artifacts_sha256=artifacts,
    normal=normal, sanitized=san, reference_contracts=mutation, baseline=baseline,
    sdk=dict(package_sha256=sdk['package_sha256'], archive_unchanged=True,
             bundled_validator='original; corrected validator belongs to the current checkout'),
    historical_ci=dict(run_id=40426634072, head='0740cfa', conclusion='failure',
                       signature='unmodelled retained version', retrospectively_passing=False),
    scope='Finite two-label complex states and gate inverses for five C memory fixtures. No full integration, general lifetime/alias/ABI, full C11, physical QPU or speedup claim. Cybersecurity stays classical.',
    artifact_sha256={'evidence.tar.gz': sha(destination / 'evidence.tar.gz')})
(destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
names = docs + changed + ['docs/audit-evidence/runtime-memory-reference-v1/summary.json',
                         'docs/audit-evidence/runtime-memory-reference-v1/evidence.tar.gz']
expected = json.loads((r / 'build/function-entry-git-expected.json').read_text())
expected.update({name: sha(r / name) for name in names})
(r / 'build/runtime-memory-reference-git-expected.json').write_text(json.dumps(expected, indent=2) + '\n')
(r / 'build/runtime-memory-reference-import.txt').write_text('\n'.join(names + ['build/runtime-memory-reference-git-expected.json']) + '\n')
print('Published finite reference evidence:', len(expected), 'exact files; compiler binaries and SDK archive unchanged.')
