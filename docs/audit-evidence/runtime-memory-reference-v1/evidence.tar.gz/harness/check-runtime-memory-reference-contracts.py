import cmath,copy,json,runpy
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
module=runpy.run_path(str(r/'scripts/validate-runtime-memory.py'))
check=module['check'];reference=module['REFERENCE']
source=r/'build/runtime-memory-debug-v1/fillO0-n0-r1-tables0.log'
points=[];patches=[]
for line in source.read_text().splitlines():
    if line.startswith('PATCH '):patches.append(json.loads(line[6:]))
    elif line.startswith('{'):
        point=json.loads(line);point['patches']=patches;patches=[];points.append(point)
assert check('fill',points,0,1)==3
out=r/'build/runtime-memory-reference-contracts-v1';out.mkdir()
rows=[]
for kind in ('public-value','relative-phase','private-domain-zero'):
    mutant=copy.deepcopy(points)
    middle=mutant[1]
    names={x['name']:x for x in middle['registers'] if x['name']}
    coin=names['coin']['wires'][0]
    if kind=='relative-phase':
        gate=[2,0,hex(1<<coin),hex(1<<coin),.11]
        undo=[2,0,hex(1<<coin),hex(1<<coin),-.11]
        middle['state']=[[b,*((lambda z:(z.real,z.imag))(complex(a,c)*cmath.exp(.11j) if int(b,0)>>coin&1 else complex(a,c)))] for b,a,c in middle['state']]
    else:
        owner=names['a[0]'] if kind=='public-value' else next(v for n,v in names.items() if n.startswith('__cket_string_domain_'))
        wire=owner['wires'][0]
        gate=undo=[1,wire,'0x0','0x0',0]
        middle['state']=[[hex(int(b,0)^(1<<wire)),a,c] for b,a,c in middle['state']]
    middle['gates'].append(gate)
    mutant[2]['gates'].insert(0,undo)
    state={0:1+0j};gates=[]
    for point in mutant:
        state=reference['evolve'](state,point['gates'])
        reference['equal_states'](state,{int(b,0):complex(a,c) for b,a,c in point['state']})
        gates.extend(point['gates'])
    inverse=[[k,w,m,p,-a if k==2 else a] for k,w,m,p,a in reversed(gates)]
    reference['equal_states'](reference['evolve'](state,inverse),{0:1+0j})
    try:check('fill',mutant,0,1)
    except AssertionError as error:
        assert isinstance(error.args[0],tuple) and len(error.args[0])==3,error
        rows.append(dict(kind=kind,rejected=True,independent_gate_evolution='passed',complete_inverse='passed',semantic_mismatch=repr(error.args[0])))
    else:raise AssertionError('C reference accepted '+kind)
(out/'summary.json').write_text(json.dumps(dict(status='passed',positive_contexts=1,valid_unitary_mutations_rejected=3,cases=rows),indent=2)+'\n')
(out/'positive-trace.json').write_text(json.dumps(points)+'\n')
print('PASS correct trace and three valid-unitary semantic counterexamples')
