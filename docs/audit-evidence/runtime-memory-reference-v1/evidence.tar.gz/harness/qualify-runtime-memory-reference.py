import hashlib,json,os,runpy,shutil,subprocess,time
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
name='scripts/validate-runtime-memory.py'
p=r/name
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
p.write_text(fmt(p,p.read_text()))
source=runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
before=r/'build/function-entry-source-v2'
old=json.loads((before/'source-hashes.json').read_text())
assert len(source)==240 and [n for n in source if source[n]!=old[n]]==[name]
project=r/'build/runtime-memory-reference-source-v1';project.mkdir()
for n in source:
    p=project/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/n,p)
(project/'.deps').symlink_to(r/'.deps',target_is_directory=True)
(project/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
(project/'build').mkdir()
reuse={}
for n in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','gcc-version.txt'):
    shutil.copy2(before/'build'/n,project/'build'/n)
    reuse[n]=hashlib.sha256((project/'build'/n).read_bytes()).hexdigest()
out=r/'build/runtime-memory-reference-results-v1';out.mkdir()
records=[]
for mode,target,levels in [('normal',project,['O0','O2']),('sanitized',r/'build/function-entry-sanitized-v2',['O1'])]:
    result=r/('build/runtime-memory-reference-'+mode+'-v1')
    env=dict(os.environ,CC='gcc-11',CXX='g++-11')
    if mode=='sanitized':env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    command=['python3',str(project/name),'--compiler-root',str(target),'--output',str(result),'--levels']+levels+(['--sanitized'] if mode=='sanitized' else [])
    start=time.time()
    with (out/(mode+'.log')).open('w') as log:z=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    records.append(dict(name=mode,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-start,log=mode+'.log'))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(mode,z.returncode,(out/(mode+'.log')).read_text()[-1800:],flush=True)
    if z.returncode:
        (out/'terminal.json').write_text(json.dumps(dict(status='failed',failed=mode,exit_code=z.returncode))+'\n');raise SystemExit(z.returncode)
assert all(hashlib.sha256((project/n).read_bytes()).hexdigest()==h for n,h in source.items())
(out/'terminal.json').write_text(json.dumps(dict(status='passed',source_files=240,source_sha256=source,reused_normal_artifacts_sha256=reuse),indent=2)+'\n')
print('Runtime memory reference normal/sanitized campaign passed',flush=True)
