#include <quantum.h>
#include <stdlib.h>
int main(int argc,char**argv){unsigned n=argc>1?strtoul(argv[1],0,10):0;quant bool x=false;if(n)x^=true;else x^=true;return measure(x)!=1;}
