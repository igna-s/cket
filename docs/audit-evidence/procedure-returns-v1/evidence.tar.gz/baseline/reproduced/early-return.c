#include <quantum.h>
void visit(quant bool*x,unsigned n){if(!n)return;x[0]^=true;}int main(void){quant bool x=false;visit(&x,1);return measure(x)!=1;}
