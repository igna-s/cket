#include <quantum.h>
#include <stdlib.h>
void update(quant bool x,unsigned n){if(!n)return;x^=true;}int main(int argc,char**argv){unsigned n=argc>1?strtoul(argv[1],0,10):0;quant bool c=superposition(0,1),x=false;if(c)update(x,n);measure(x);measure(c);return 0;}
