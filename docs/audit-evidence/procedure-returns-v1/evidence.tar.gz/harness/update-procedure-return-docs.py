from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
buffers={}
def read(name):
    if name not in buffers:buffers[name]=(r/name).read_text()
    return buffers[name]
def change(name,old,new,count=1):
    s=read(name);assert s.count(old)==count,(name,old,s.count(old));buffers[name]=s.replace(old,new)
change('README.md','output/sdk/checked-entry','output/sdk/cpu-returns')
change('README.md','The general integration gate remains open.','The general integration gate remains open.\n\n[Structured CPU early returns](docs/c11-procedure-returns.md) now work in void quantum procedures, including CPU loops. They finish lexical cleanup and continue the caller. Run `output\\sdk\\cpu-returns\\run_return_demo.cmd` for the new example with phase interference. A separate correction removes path-local known-value claims that caused valid CPU branches to fail structural verification. General CFG and owned early results remain pending.')
# Windows command paths use backslashes, independently of Markdown URLs.
change('README.md','output\\sdk\\checked-entry','output\\sdk\\cpu-returns',2)
change('output/sdk/README.es.md','[SDK con entradas comprobadas](checked-entry/README.es.md)','[SDK con retornos CPU](cpu-returns/README.es.md)')
change('output/sdk/README.es.md','el ejemplo nuevo de interferencia','el ejemplo de retorno, limpieza e interferencia')
name='docs/entrega-utilizable-2026-10-26.es.md'
buffers[name]=read(name).replace('checked-entry','cpu-returns').replace('run_checked_demo.cmd','run_return_demo.cmd')
change(name,'El primer comando ejecuta 37 programas reconstruidos. El segundo compila un ejemplo con alias de\nlectura y comprueba interferencia: `scalar=1 vector=0,1`. El tercero compila un programa de heap.','El primer comando ejecuta 37 programas reconstruidos. El segundo compila un ejemplo con retornos CPU y limpieza, y comprueba interferencia: `limit=2 visited=2 result=0 interference=0`. El tercero compila un programa de heap.')
change(name,'240 entradas exactas','242 entradas exactas')
change(name,'Windows ejecutan el paquete y compilan el ejemplo nuevo de alias e interferencia.','Windows ejecutan el paquete y compilan los ejemplos de retornos/interferencia y del heap.\n\nLa [ampliación de retornos](c11-procedure-returns.md) implementa `return;` CPU anticipado en procedimientos `void`, incluidos bucles, sin salir del llamador ni omitir su limpieza léxica. Su [evidencia](audit-evidence/procedure-returns-v1/README.es.md) distingue 840 ejecuciones frente a C de 600 puntos de estado complejo y 300 inversas completas, normales e instrumentadas. Se conservan las restricciones sobre resultados propios, control cuántico y CFG general.')
change(name,'de datos, fase y guarda se rechazan. Solo cambia el validador Python del checkout: el compilador y\nlos binarios del SDK siguen iguales. El archivo del SDK conserva su validador y hashes originales.\nEsta corrección dirigida no equivale a una ejecución general de CI aprobada.','de datos, fase y guarda se rechazan. Aquella campaña solo cambió el validador Python; su SDK anterior conserva el archivo y hashes originales. El SDK nuevo de 242 entradas incluye la referencia corregida y la ampliación de retornos. Cada campaña conserva su propia identidad; la integración general sigue pendiente.')
name='docs/estado-general-del-proyecto.es.md'
change(name,'../output/sdk/checked-entry/README.es.md','../output/sdk/cpu-returns/README.es.md')
change(name,'`output\\sdk\\checked-entry\\run_checked_demo.cmd` para compilar el ejemplo de fase e interferencia con\nalias de lectura.','`output\\sdk\\cpu-returns\\run_return_demo.cmd` para compilar el ejemplo de retorno, limpieza e interferencia.')
change(name,'**Entradas de funciones comprobadas:**','**Retornos CPU implementados:** los procedimientos `void` admiten `return;` anticipado en bloques, condiciones y bucles CPU. Terminan su limpieza léxica y continúan el llamador. También se corrige un rechazo de ramas CPU causado por certificados de valores conocidos fuera de su camino. La [nota](c11-procedure-returns.md) y su [evidencia de 242 entradas](audit-evidence/procedure-returns-v1/README.es.md) distinguen resultados C, efectos, fases, auxiliares limpios e inversas de los flujos generales todavía pendientes.\n\n**Entradas de funciones comprobadas:**')
change(name,'mutaciones unitarias de datos, fase y guarda. No cambian el compilador ni sus binarios; el SDK\nconserva su referencia original.','mutaciones unitarias de datos, fase y guarda. Aquella corrección no cambió el compilador ni sus binarios; el SDK anterior conserva su referencia original. El SDK nuevo incluye la referencia corregida.')
name='docs/paper/README.md'
change(name,'El [mapa de afirmaciones y evidencia actual]','La [nota de retornos CPU](../c11-procedure-returns.md) y su [cápsula de 242 entradas](../audit-evidence/procedure-returns-v1/README.es.md) añaden retornos anticipados en procedimientos y corrigen certificados de ramas CPU. El SDK nuevo incluye ese frontend. Sus fórmulas C, estados, fases e inversas califican programas finitos; los manuscritos históricos mantienen sus resultados anteriores.\n\nEl [mapa de afirmaciones y evidencia actual]')
name='docs/paper/current-evidence-map-2026-10-26.es.md'
change(name,'[SDK de entradas comprobadas](../../output/sdk/checked-entry/README.es.md), con 240 entradas','[SDK de retornos CPU](../../output/sdk/cpu-returns/README.es.md), con 242 entradas')
change(name,'Los lanzadores Windows ejecutan el paquete y compilan dos archivos C independientes.','Los lanzadores Windows ejecutan el paquete y compilan ejemplos de retornos/interferencia y heap.')
name='docs/c11-function-entries.md'
change(name,'Recursion, general indirect quantum calls','[Structured CPU early returns](c11-procedure-returns.md) are supported in void procedures, including CPU loops. They finish lexical cleanup before continuing the caller; owned early results and general control flow keep their separate restrictions.\n\nRecursion, general indirect quantum calls')
name='docs/perfil-c-cotidiano.es.md'
change(name,'## Orden de trabajo','La [ampliación de retornos CPU](c11-procedure-returns.md) implementa salidas anticipadas de procedimientos `void` en bloques y bucles, con limpieza léxica y continuación del llamador. Sus estados, fases e inversas tienen evidencia propia; los resultados propios anticipados y el CFG general siguen pendientes.\n\n## Orden de trabajo')
for name,s in buffers.items():(r/name).write_text(s)
print('Current SDK and documentation links updated; historical capsules preserved.')
