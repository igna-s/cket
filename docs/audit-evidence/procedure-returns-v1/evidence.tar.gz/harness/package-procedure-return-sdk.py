import json,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
commands=json.loads((r/'build/procedure-return-results-v2/commands.json').read_text())
assert any(row['name']=='normal-example-4' and row['exit_code']==0 for row in commands)
assert json.loads((r/'build/procedure-return-normal-matrix-v2/summary.json').read_text())['status']=='passed'
s=(r/'build/package-checked-entry-sdk-complete.py').read_text()
s=s.replace('build/function-entry-source-v2','build/procedure-return-source-v2')
s=s.replace('build/checked-entry-sdk-stage-v1','build/procedure-return-sdk-stage-v1')
s=s.replace('build/checked-entry-sdk-results-v1','build/procedure-return-sdk-results-v1')
s=s.replace('output/sdk/checked-entry','output/sdk/cpu-returns')
s=s.replace('source_files=240','source_files=242').replace('240 entradas','242 entradas')
s=s.replace("date='2026-10-26'","date='2026-10-27'")
anchor="(stage/'compiler-source-sha256.json').write_text"
s=s.replace(anchor,"(stage/'README.es.md').write_text((stage/'README.es.md').read_text()+'\\nLos procedimientos void admiten retornos CPU anticipados en bloques y bucles.\\nEjemplo: examples/procedure_returns.c. Se conservan los contratos de limpieza,\\npréstamo y copia; los retornos bajo control cuántico y la ABI general siguen pendientes.\\n')\n"+anchor)
target=r/'build/package-procedure-return-sdk-complete.py';target.write_text(s)
exec(compile(s,str(target),'exec'))
destination=r/'output/sdk/cpu-returns'
project=r/'build/procedure-return-source-v2'
shutil.copy2(project/'examples/procedure_returns.c',destination/'example_returns.c')
shutil.copy2(project/'examples/blocks/05/heap_iterations.c',destination/'example_heap.c')
(destination/'run_return_demo.cmd').write_text('@echo off\ncall "%~dp0compile_and_run.cmd" "%~dp0example_returns.c"\nexit /b %errorlevel%\n')
print('SDK with structured CPU returns ready for Windows workflow checks',flush=True)
