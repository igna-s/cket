import json,os,subprocess,time
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/procedure-return-source-v2'
out=r/'build/procedure-return-runtime-memory-v1';out.mkdir()
records=[]
for mode,target,levels in [('normal',project,['O0','O2']),('sanitized',r/'build/procedure-return-sanitized-v2',['O1'])]:
    env=dict(os.environ,CC='gcc-11',CXX='g++-11')
    if mode=='sanitized':env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    command=['python3',str(project/'scripts/validate-runtime-memory.py'),'--compiler-root',str(target),'--output',str(out/mode),'--levels']+levels+(['--sanitized'] if mode=='sanitized' else [])
    start=time.time()
    with (out/(mode+'.log')).open('w') as log:z=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    records.append(dict(mode=mode,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-start))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    assert z.returncode==0,(out/(mode+'.log')).read_text()
    print(mode,(out/mode/'summary.json').read_text(),flush=True)
(out/'terminal.json').write_text(json.dumps(dict(status='passed',source_sha256=json.loads((project/'source-hashes.json').read_text())),indent=2)+'\n')
