import json,os,shutil,subprocess
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
p=r/'build/procedure-return-dev-v2';p.mkdir();(p/'build').mkdir()
for n in ('src','tests','examples','include','scripts'):(p/n).symlink_to(r/n,target_is_directory=True)
shutil.copy2(r/'cket',p/'cket')
old=r/'build/function-entry-source-v2/build'
for n in ('cket','cket_backend','cket_runtime.o','libcket_quantum.a','gcc-version.txt'):shutil.copy2(old/n,p/'build'/n)
h=Path(subprocess.check_output(['gcc-11','-print-file-name=plugin'],text=True).strip())/'include'
if not (h/'gcc-plugin.h').exists():h=r/'.deps/gcc'/h.relative_to('/')
command=['g++-11','-std=c++17','-O2','-Wall','-Wextra','-Wno-unused-parameter','-Wno-format-diag','-fPIC','-shared','-fno-rtti','-I'+str(h),'-I'+str(r/'.deps/gcc/usr/include'),'-I'+str(r/'.deps/gcc/usr/include/x86_64-linux-gnu'),'src/cket_plugin.cpp','-o',str(p/'build/cket_plugin.so')]
z=subprocess.run(command,cwd=p,text=True,capture_output=True);(p/'plugin.log').write_text(z.stdout+z.stderr)
assert z.returncode==0,(z.stdout+z.stderr)
bodies=[
 'if(n==0)return;x[0]^=true;++*visits;',
 'if(n){if(n==2)return;x[0]^=true;}else{x[0]^=true;}x[0]^=true;++*visits;',
 'for(unsigned i=0;i<n;++i,++*visits){if(i==2)return;x[0]^=true;}x[0]^=true;',
 'unsigned i=0;while(i++<n){if(i==3)return;x[0]^=true;++*visits;}x[0]^=true;',
 'unsigned i=0;do{if(i++==n)return;x[0]^=true;++*visits;}while(i<4);x[0]^=true;',
 'if(n==1){++*visits;return;}x[0]^=true;if(n==2)return;++*visits;x[0]^=true;',
 'quant bool saved=!x[0];if(saved)phase(.17);if(n==0)return;if(saved)phase(.23);',
]
rows=[]
for i,body in enumerate(bodies):
    source=p/('case-'+str(i)+'.c')
    reference=body if i<6 else 'if(n==0)return;'
    text='#include <quantum.h>\n#include <stdlib.h>\nstatic void reference(bool*x,unsigned n,unsigned*visits){'+reference+'}\nstatic void update(quant bool*x,unsigned n,unsigned*visits){'+body+'}\nint main(int argc,char**argv){unsigned n=argc>1?(unsigned)strtoul(argv[1],0,10):0;bool expected=false;unsigned a=0,b=0;reference(&expected,n,&a);quant bool x=false;update(&x,n,&b);x^=true;expected^=true;return measure(x)!=expected||a!=b;}\n'
    source.write_text(text)
    binary=p/('case-'+str(i))
    z=subprocess.run([str(p/'build/cket'),str(source),'-O0','-o',str(binary)],cwd=p,env=dict(os.environ,CC='gcc-11'),text=True,capture_output=True)
    row=dict(case=i,compile_exit=z.returncode,log=z.stdout+z.stderr)
    if z.returncode==0:
        row['runs']=[]
        for n in range(5):
            q=subprocess.run([str(binary),str(n)],cwd=p,env=dict(os.environ,CKET_SIMULATOR='sparse',CKET_SEED='7'),text=True,capture_output=True)
            row['runs'].append(dict(n=n,exit_code=q.returncode,log=q.stdout+q.stderr))
    rows.append(row);print(json.dumps(row),flush=True)
(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
