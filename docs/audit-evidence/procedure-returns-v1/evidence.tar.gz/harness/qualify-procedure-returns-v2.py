import hashlib,json,os,runpy,shutil,subprocess,time
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
changed=['src/quantum_frontend.inc','src/quantum_semantics.inc','scripts/validate-procedure-returns.py','scripts/verify.sh','scripts/sanitize-all.sh','scripts/archive-audit.py','examples/procedure_returns.c','tests/test_memory.inc']
for n in changed:
    p=r/n;p.write_text(fmt(p,p.read_text()))
source=runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
old=json.loads((r/'build/runtime-memory-reference-source-v1/source-hashes.json').read_text())
assert len(source)==242 and sorted(n for n in source if source[n]!=old.get(n))==sorted(changed)
root=r/'build/procedure-return-source-v2';root.mkdir()
for n in source:
    p=root/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/n,p)
(root/'.deps').symlink_to(r/'.deps',target_is_directory=True)
(root/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
shutil.copy2(r/'LICENSE',root/'LICENSE')
out=r/'build/procedure-return-results-v2';out.mkdir()
header=Path(subprocess.check_output(['gcc-11','-print-file-name=plugin'],text=True).strip())/'include'
if not (header/'gcc-plugin.h').exists():header=r/'.deps/gcc'/header.relative_to('/')
records=[];artifacts={}
def run(name,command,cwd,env):
    start=time.time()
    with (out/(name+'.log')).open('w') as log:z=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    records.append(dict(name=name,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-start,log=name+'.log'))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,z.returncode,(out/(name+'.log')).read_text()[-1000:],flush=True)
    if z.returncode:
        (out/'terminal.json').write_text(json.dumps(dict(status='failed',name=name,exit_code=z.returncode))+'\n');raise SystemExit(z.returncode)
for mode,previous,levels in [('normal',r/'build/function-entry-source-v2',['O0','O1','O2','O3','Os']),('sanitized',r/'build/function-entry-sanitized-v2',['O1'])]:
    target=root if mode=='normal' else r/'build/procedure-return-sanitized-v2'
    if mode=='sanitized':
        target.mkdir()
        for n in ('src','include','tests','examples'):(target/n).symlink_to(root/n,target_is_directory=True)
        shutil.copy2(root/'cket',target/'cket')
    (target/'build').mkdir()
    for n in ('cket','cket_backend','cket_runtime.o','libcket_quantum.a','gcc-version.txt','validate_bindings','validate_readonly_borrows','validate_function_entries'):
        shutil.copy2(previous/'build'/n,target/'build'/n)
    env=dict(os.environ,CC='gcc-11',CXX='g++-11')
    san=[]
    if mode=='sanitized':
        shutil.copy2(previous/'build/gcc-wrapper',target/'build/gcc-wrapper')
        env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        san=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
    run(mode+'-plugin',['g++-11','-std=c++17','-O2','-Wall','-Wextra','-Wno-unused-parameter','-Wno-format-diag','-fPIC','-shared','-fno-rtti','-I'+str(header),'-I'+str(r/'.deps/gcc/usr/include'),'-I'+str(r/'.deps/gcc/usr/include/x86_64-linux-gnu')]+san+['src/cket_plugin.cpp','-o',str(target/'build/cket_plugin.so')],root,env)
    result=r/('build/procedure-return-'+mode+'-matrix-v2')
    run(mode+'-procedure-returns',['python3',str(root/'scripts/validate-procedure-returns.py'),'--compiler-root',str(target),'--output',str(result),'--levels']+levels+(['--sanitized'] if san else []),root,env)
    for n in ('validate_readonly_borrows','validate_bindings','validate_function_entries'):
        run(mode+'-'+n,[str(target/'build'/n)],root,env)
    flags=['gcc-11','-std=c11','-O2','-Wall','-Wextra','-Werror','-Isrc/engine']+san+(['-fno-pie','-no-pie'] if san else [])
    for test in ('test_native','validate_history','validate_memset'):
        binary=target/'build'/('cket_tests' if test=='test_native' else test)
        run(mode+'-'+test+'-build',flags+['tests/'+test+'.c','tests/validation.c',str(target/'build/libcket_quantum.a'),'-lm','-o',str(binary)],root,env)
        run(mode+'-'+test,[str(binary)]+([str(target)] if test=='test_native' else []),root,env)
    example=target/'build/procedure_returns'
    run(mode+'-example-build',[str(target/'build/cket'),str(root/'examples/procedure_returns.c'),'-O2','-o',str(example)],root,env)
    for n in range(5):run(mode+'-example-'+str(n),[str(example),str(n)],root,dict(env,CKET_SIMULATOR='sparse',CKET_SEED='7'))
    artifacts[mode]={n:hashlib.sha256((target/'build'/n).read_bytes()).hexdigest() for n in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','gcc-version.txt')}
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in source.items())
(out/'terminal.json').write_text(json.dumps(dict(status='passed',source_files=242,source_sha256=source,artifacts_sha256=artifacts),indent=2)+'\n')
print('Structured CPU procedure returns and quantum regressions passed',flush=True)
