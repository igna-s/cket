import hashlib,io,json,os,re,runpy,subprocess,tarfile
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/procedure-return-source-v2'
sanitized=r/'build/procedure-return-sanitized-v2'
out=r/'build/procedure-return-results-v2'
destination=r/'docs/audit-evidence/procedure-returns-v1'
sdk=r/'output/sdk/cpu-returns'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((project/'source-hashes.json').read_text())
terminal=json.loads((out/'terminal.json').read_text())
assert terminal['status']=='passed' and terminal['source_sha256']==source and len(source)==242
assert runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()==source
assert all(sha(project/n)==h for n,h in source.items())
assert all(row['exit_code']==0 for row in json.loads((out/'commands.json').read_text()))
matrices={}
memory_root=r/'build/procedure-return-runtime-memory-v1'
assert json.loads((memory_root/'terminal.json').read_text())['source_sha256']==source
memory={mode:json.loads((memory_root/mode/'summary.json').read_text()) for mode in ('normal','sanitized')}
assert all(m['status']=='passed' for m in memory.values())
assert sum(m['full_state_checkpoints'] for m in memory.values())==900
assert sum(m['complete_gate_inverses'] for m in memory.values())==270
for mode,target,counts in [('normal',project,(700,500,250,20)),('sanitized',sanitized,(140,100,50,4))]:
    matrix=json.loads((r/('build/procedure-return-'+mode+'-matrix-v2/summary.json')).read_text())
    assert matrix['status']=='passed' and matrix['native_profiles']==14 and matrix['phase_profiles']==5
    assert tuple(matrix[n] for n in ('native_executions','full_state_checkpoints','complete_gate_inverses','compile_rejections'))==counts
    matrices[mode]=matrix
    for label,phrase in [('validate_readonly_borrows','305 readonly borrow checks passed;'),('validate_bindings','519 CPU binding checks passed;'),('validate_function_entries','90 function entry checks passed;'),('test_native','395 passed, 0 failed'),('validate_history','2332 versioned history checks passed;'),('validate_memset','940 memset checks passed;')]:
        assert phrase in (out/(mode+'-'+label+'.log')).read_text()
    for name,h in terminal['artifacts_sha256'][mode].items():assert sha(target/'build'/name)==h
    previous=r/('build/function-entry-source-v2' if mode=='normal' else 'build/function-entry-sanitized-v2')
    for name in ('cket','cket_backend','cket_runtime.o','libcket_quantum.a','gcc-version.txt'):
        assert sha(target/'build'/name)==sha(previous/'build'/name)
    assert sha(target/'build/cket_plugin.so')!=sha(previous/'build/cket_plugin.so')
before=json.loads((r/'build/runtime-memory-reference-source-v1/source-hashes.json').read_text())
production=[n for n in source if n.startswith('src/') and source[n]!=before.get(n)]
assert production==['src/quantum_frontend.inc','src/quantum_semantics.inc']
instrumentation=subprocess.check_output(['nm','-u',str(sanitized/'build/cket_plugin.so')],text=True)
assert '__asan_init' in instrumentation and '__ubsan_handle' in instrumentation
(out/'plugin-instrumentation.txt').write_text(instrumentation)
audit=json.loads((sdk/'sdk-audit.json').read_text())
assert audit['source_sha256']==source and audit['source_files']==242
assert audit['prebuilt_programs']==37 and audit['example_checks']==1509
assert audit['package_sha256']==sha(sdk/'cket-sdk-linux-x86_64.tar.gz')
assert all(row['exit_code']==0 for row in audit['commands'])
for n in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','gcc-version.txt'):
    assert sha(project/'build'/n)==audit['package_files_sha256']['build/'+n]
windows=json.loads((r/'build/procedure-return-windows-results.json').read_text())
assert len(windows)==3 and all(row['exit_code']==0 for row in windows)
assert len(re.findall(r'^build/blocks/',(r/'build/procedure-return-windows-demo.log').read_text(),re.M))==37
assert 'limit=2 visited=2 result=0 interference=0' in (r/'build/procedure-return-windows-returns.log').read_text()
assert 'rounds=3 output=12 sum=30' in (r/'build/procedure-return-windows-heap.log').read_text()
assert sha(sdk/'example_returns.c')==source['examples/procedure_returns.c']
audit['windows_launchers']=windows
audit['scope']='Prebuilt compiler and finite native programs with checked Windows workflows. Structured CPU returns retain their finite state/phase/inverse qualification; full integration, general CFG/ABI/lifetimes, complete C11 and physical QPU remain pending.'
(sdk/'sdk-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
baseline=r/'build/procedure-return-baseline-v1';baseline.mkdir()
cases=[('early-return','#include <quantum.h>\nvoid visit(quant bool*x,unsigned n){if(!n)return;x[0]^=true;}int main(void){quant bool x=false;visit(&x,1);return measure(x)!=1;}\n','early or conditional returns in quantum procedures'),
       ('branch-certificates',(r/'build/procedure-return-dev-v1/existing-branch.c').read_text(),'inactive source bits are not independently proven zero')]
records=[]
previous=r/'build/function-entry-source-v2'
for name,text,diagnostic in cases:
    path=baseline/(name+'.c');path.write_text(text)
    command=[str(previous/'build/cket'),str(path),'--emit-ir','-O0','-o',str(baseline/(name+'-old.json'))]
    result=subprocess.run(command,cwd=previous,env=dict(os.environ,CC='gcc-11'),text=True,capture_output=True)
    assert result.returncode==1 and diagnostic in result.stdout+result.stderr
    records.append(dict(name=name,command=command,exit_code=result.returncode,diagnostic=diagnostic,stdout=result.stdout,stderr=result.stderr))
command=[str(project/'build/cket'),str(baseline/'branch-certificates.c'),'--emit-ir','-O0','-o',str(baseline/'branch-certificates-new.json')]
z=subprocess.run(command,cwd=project,env=dict(os.environ,CC='gcc-11'),text=True,capture_output=True)
assert z.returncode==0,z.stdout+z.stderr
records.append(dict(name='branch-certificates-corrected',command=command,exit_code=z.returncode,stdout=z.stdout,stderr=z.stderr))
(baseline/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
docs=['README.md','output/sdk/README.es.md','output/sdk/cpu-returns/README.es.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/c11-procedure-returns.md','docs/c11-function-entries.md','docs/c11-buffer-functions.md','docs/c-coverage.md','docs/v1-plan.md','docs/perfil-c-cotidiano.es.md','docs/paper/README.md','docs/paper/current-evidence-map-2026-10-26.es.md','docs/audit-evidence/procedure-returns-v1/README.es.md']
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for n in docs:
    p=r/n;p.write_text(fmt(p,p.read_text()))
assert not (destination/'summary.json').exists()
def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.c','.py'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())
with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for n in source:tar.add(project/n,arcname='sources/'+n)
    raw(tar,'source-identities.json',dict(qualified=source,previous=before,previous_baseline_compiler=json.loads((previous/'source-hashes.json').read_text())))
    raw(tar,'producer-artifacts.json',terminal['artifacts_sha256'])
    for n in production:tar.add(previous/n,arcname='baseline/previous-producer/'+n)
    tree(tar,out,'results/final')
    for mode in matrices:tree(tar,r/('build/procedure-return-'+mode+'-matrix-v2'),mode)
    tree(tar,baseline,'baseline/reproduced')
    tree(tar,r/'build/procedure-return-coherent-call-v1','boundaries/coherent-caller')
    tree(tar,memory_root,'runtime-memory-regression')
    tree(tar,r/'build/procedure-return-results-v1','earlier/core-expectation')
    tree(tar,r/'build/procedure-return-normal-matrix-v1','earlier/four-phase-profiles')
    for version in (1,2):
        tar.add(r/('build/procedure-return-source-v'+str(version)+'/source-hashes.json'),arcname='earlier/source-v'+str(version)+'.json')
    for version in (1,2,3,4):tree(tar,r/('build/procedure-return-check-v'+str(version)),'earlier/preparation-'+str(version))
    tree(tar,r/'build/procedure-return-sdk-results-v1','sdk/results')
    for name in ('procedure-return-windows-demo.log','procedure-return-windows-returns.log','procedure-return-windows-heap.log','procedure-return-windows-results.json'):
        tar.add(r/'build'/name,arcname='sdk/windows/'+name)
    for name in ('qualify-procedure-returns.py','qualify-procedure-returns-v2.py','probe-procedure-returns.py','probe-procedure-returns-v2.py','package-procedure-return-sdk.py','package-procedure-return-sdk-complete.py','update-procedure-return-docs.py','qualify-return-runtime-memory.py','publish-procedure-returns.py'):
        tar.add(r/'build'/name,arcname='harness/'+name)
    for p in sorted(sdk.iterdir()):
        if p.is_file() and p.suffix!='.gz':tar.add(p,arcname='sdk/files/'+p.name)
    for n in docs:tar.add(r/n,arcname='documentation/'+n)
summary=dict(status='passed-structured-cpu-procedure-returns-full-integration-pending',date='2026-10-27',base_commit='b56f47c',version='1.0.0-rc.3',source_files=242,source_sha256=source,
    changed_production_inputs=production,rebuilt='GCC plugin, normal and ASan/UBSan',producer_artifacts_sha256=terminal['artifacts_sha256'],
    matrices=matrices,runtime_memory_regression=memory,regression_checks_per_configuration=dict(readonly_borrows=305,bindings=519,function_entries=90,core=395,history=2332,memset=940),
    example_cpu_limits=[0,1,2,3,4],sdk=dict(package_sha256=audit['package_sha256'],prebuilt_programs=37,normal_example_checks=1509,windows_workflows=3),
    scope='Finite native C effects, structured void exits, four-label complex states, independent gates/inverses and lexical private cleanup. General CFG, owned early results, arbitrary aliases/lifetimes/ABI, floats, full C11 and full current integration remain pending. No physical QPU or speedup claim; cybersecurity stays classical.',
    artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=set(source)|set(docs)|{p.relative_to(r).as_posix() for p in sdk.iterdir() if p.is_file()}|{'docs/audit-evidence/procedure-returns-v1/summary.json','docs/audit-evidence/procedure-returns-v1/evidence.tar.gz'}
expected=json.loads((r/'build/memory-integration-tail-git-expected.json').read_text());expected.update({n:sha(r/n) for n in names})
(r/'build/procedure-return-git-expected.json').write_text(json.dumps(expected,indent=2)+'\n')
changes={n for n in source if source[n]!=before.get(n)}
imports=(names-set(source))|changes|{'build/procedure-return-git-expected.json'}
(r/'build/procedure-return-final-import.txt').write_text('\n'.join(sorted(imports))+'\n')
print('CPU procedure returns published:',len(expected),'exact files; source identity, normal/ASan states, regressions and Windows SDK verified.')
