#include <quantum.h>
quant bool update(quant const bool x,unsigned n){quant bool t=!x;if(n)return t;t^=true;return t;}
int main(void){quant bool x=false;quant bool y=update(x,0);measure(y);measure(x);return 0;}
