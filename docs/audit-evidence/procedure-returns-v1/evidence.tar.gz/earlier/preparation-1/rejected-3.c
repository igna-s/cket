#include <quantum.h>
quant bool update(quant const bool x,unsigned n){if(n)return !x;return x^true;}
int main(void){quant bool x=false;quant bool y=update(x,0);measure(y);return 0;}
