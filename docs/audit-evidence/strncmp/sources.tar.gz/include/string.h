#ifndef CKET_STRING_H
#define CKET_STRING_H

#include_next <string.h>

#ifdef __CKET__
#pragma GCC system_header

/* Keep GCC from folding byte comparisons into host byte loads before
 * quantum storage is lowered. Classical calls still link to the real libc
 * symbol, and taking the standard function's address retains the C interface. */
extern int __cket_memcmp(const void *left, const void *right, size_t count) __asm__("memcmp");

extern int __cket_strncmp(const char *left, const char *right, size_t count) __asm__("strncmp");
#undef strncmp
#define strncmp(left, right, count) __cket_strncmp((left), (right), (count))

#undef memcmp
#define memcmp(left, right, count) __cket_memcmp((left), (right), (count))
#endif

#endif
