// Read-only object bytes on checked quantum storage. Each byte remains an
// integer expression; ordinary arithmetic synthesis supplies its unitary and
// inverse. No CPU load ever reads a quantum placeholder's representation.
struct QuantumByteRange {
    std::vector<tree> elements;
    tree element_type = NULL_TREE;
    uint64_t stride = 0, offset = 0;
    bool quantum = false;
    const char *error = nullptr;

    uint64_t size() const {
        return elements.size() * stride;
    }
};

bool standard_memory_compare(tree fn) {
    if (!fn || (DECL_SAVED_TREE(fn) && !in_system_header_at(DECL_SOURCE_LOCATION(fn))))
        return false;
    return fndecl_built_in_p(fn, BUILT_IN_MEMCMP) || fndecl_built_in_p(fn, BUILT_IN_STRNCMP) ||
           (DECL_EXTERNAL(fn) && TREE_PUBLIC(fn) && in_system_header_at(DECL_SOURCE_LOCATION(fn)) &&
            (name_of(fn) == "memcmp" || name_of(fn) == "__cket_memcmp" ||
             name_of(fn) == "strncmp" || name_of(fn) == "__cket_strncmp"));
}

bool byte_range_layout(QuantumByteRange &range) {
    tree type = range.element_type, size = TYPE_SIZE_UNIT(type);
    if (BITS_PER_UNIT != 8 || !INTEGRAL_TYPE_P(type) || !size || !tree_fits_uhwi_p(size) ||
        !tree_to_uhwi(size) || tree_to_uhwi(size) > 8 ||
        TYPE_PRECISION(type) != tree_to_uhwi(size) * BITS_PER_UNIT) {
        range.error =
            "|c>: quantum byte comparison requires integer object bytes without padding; bool, floating and aggregate layouts need further implementation";
        return false;
    }
    range.stride = tree_to_uhwi(size);
    return true;
}

bool resolve_byte_range(tree value, QuantumByteRange &range) {
    value = strip(value);
    if (!value)
        return false;
    if (TREE_CODE(value) == POINTER_PLUS_EXPR) {
        if (!resolve_byte_range(TREE_OPERAND(value, 0), range))
            return false;
        tree bytes = strip(fold(TREE_OPERAND(value, 1)));
        if (!bytes || TREE_CODE(bytes) != INTEGER_CST || TYPE_PRECISION(TREE_TYPE(bytes)) > 64) {
            range.error =
                "|c>: quantum byte comparison byte offsets currently require a constant checked address";
            return false;
        }
        int64_t delta = static_cast<int64_t>(TREE_INT_CST_LOW(bytes));
        if ((delta < 0 && (uint64_t)(-(delta + 1)) + 1 > range.offset) ||
            (delta >= 0 && (uint64_t)delta > range.size() - range.offset)) {
            range.error =
                "|c>: quantum byte comparison byte view is outside its checked storage bounds";
            return false;
        }
        range.offset = delta < 0 ? range.offset - ((uint64_t)(-(delta + 1)) + 1)
                                 : range.offset + (uint64_t)delta;
        return true;
    }
    QuantumReference reference;
    if (resolve_quantum_reference(value, reference)) {
        range.quantum = true;
        range.elements = reference.elements;
        range.element_type = reference.element_type;
        if (!byte_range_layout(range))
            return false;
        range.offset = (uint64_t)reference.offset * range.stride;
        return range.offset <= range.size();
    }
    // Immutable classical objects can be embedded as circuit constants. Mutable
    // CPU buffers need a separate once-only byte snapshot contract; never read
    // DECL_INITIAL as though a mutable object's current value were constant.
    if (TREE_CODE(value) != ADDR_EXPR)
        return false;
    tree storage = strip(TREE_OPERAND(value, 0));
    uint64_t index = 0;
    if (TREE_CODE(storage) == ARRAY_REF) {
        tree subscript = strip(fold(TREE_OPERAND(storage, 1)));
        if (!subscript || TREE_CODE(subscript) != INTEGER_CST || !tree_fits_uhwi_p(subscript))
            return false;
        index = tree_to_uhwi(subscript);
        storage = strip(TREE_OPERAND(storage, 0));
    }
    tree initial = NULL_TREE, type = TREE_TYPE(storage);
    bool array = TREE_CODE(type) == ARRAY_TYPE;
    uint64_t count = 1;
    if (TREE_CODE(storage) == STRING_CST) {
        initial = storage;
    } else if (TREE_CODE(storage) == VAR_DECL && !TREE_THIS_VOLATILE(storage) &&
               (TREE_READONLY(storage) || (array && TYPE_READONLY(TREE_TYPE(type))))) {
        initial = DECL_INITIAL(storage);
    }
    if (!initial)
        return false;
    if (array) {
        tree domain = TYPE_DOMAIN(type), maximum = domain ? TYPE_MAX_VALUE(domain) : NULL_TREE;
        if (!maximum || !tree_fits_uhwi_p(maximum) || tree_to_uhwi(maximum) >= 4096)
            return false;
        count = tree_to_uhwi(maximum) + 1;
        type = TREE_TYPE(type);
    } else if (index)
        return false;
    range.element_type = type;
    if (TYPE_VOLATILE(type) || !byte_range_layout(range) || index > count)
        return false;
    if (array && TREE_CODE(initial) != STRING_CST && TREE_CODE(initial) != CONSTRUCTOR)
        return false;
    for (uint64_t i = 0; i < count; ++i) {
        tree element = initial;
        if (array && TREE_CODE(initial) == STRING_CST) {
            if (range.stride != 1)
                return false;
            element = build_int_cstu(type,
                                     i < (uint64_t)TREE_STRING_LENGTH(initial)
                                         ? (unsigned char)TREE_STRING_POINTER(initial)[i]
                                         : 0);
        } else if (array) {
            element = constructor_element(initial, NULL_TREE, i, true);
            if (!element)
                element = build_zero_cst(type);
        }
        element = strip(fold(element));
        if (!element || TREE_CODE(element) != INTEGER_CST)
            return false;
        range.elements.push_back(fold_convert(type, element));
    }
    range.offset = index * range.stride;
    return true;
}

tree object_byte(const QuantumByteRange &range, uint64_t index, location_t location) {
    index += range.offset;
    tree element = range.elements[(size_t)(index / range.stride)];
    tree unsigned_type = unsigned_type_for(range.element_type);
    tree value = fold_convert(unsigned_type, element);
    unsigned byte = (unsigned)(index % range.stride);
    unsigned shift = 8 * (BYTES_BIG_ENDIAN ? (unsigned)range.stride - byte - 1 : byte);
    if (shift)
        value = fold_build2_loc(
            location, RSHIFT_EXPR, unsigned_type, value, build_int_cst(integer_type_node, shift));
    return fold_convert(integer_type_node, fold_convert(unsigned_char_type_node, value));
}

tree expand_memory_compare(tree call, enum tree_code relation = ERROR_MARK) {
    if (call_expr_nargs(call) != 3)
        return NULL_TREE;
    tree fn = get_callee_fndecl(call);
    bool stop_at_zero = fn && (fndecl_built_in_p(fn, BUILT_IN_STRNCMP) ||
                               name_of(fn) == "strncmp" || name_of(fn) == "__cket_strncmp");
    QuantumByteRange left, right;
    bool a = resolve_byte_range(CALL_EXPR_ARG(call, 0), left);
    bool b = resolve_byte_range(CALL_EXPR_ARG(call, 1), right);
    if (!left.quantum && !right.quantum)
        return NULL_TREE;
    auto reject = [call](const char *message) -> tree {
        error_at(at(call), "%s", message);
        return build_zero_cst(TREE_TYPE(call));
    };
    if (!a || !b)
        return reject(
            !a && left.error ? left.error
            : !b && right.error
                ? right.error
                : "|c>: quantum byte comparison requires checked quantum storage or an immutable classical integer object; mutable CPU byte snapshots and general pointers remain pending");
    tree bytes = strip(fold(CALL_EXPR_ARG(call, 2)));
    if (!bytes || TREE_CODE(bytes) != INTEGER_CST || !tree_fits_uhwi_p(bytes))
        return reject(
            "|c>: quantum byte comparison currently requires a constant byte count; bounded dynamic extents remain pending");
    uint64_t count = tree_to_uhwi(bytes);
    if (count > left.size() - left.offset || count > right.size() - right.offset)
        return reject("|c>: quantum byte comparison exceeds its checked storage bounds");
    if (count > 64)
        return reject(
            "|c>: quantum byte comparison exceeds the 64-byte expression synthesis bound");
    // C11 specifies the sign of the first differing unsigned bytes. This target
    // extension returns their exact difference, within [-255,255]. All inputs
    // are preserved; the complete computation is |a,b,0> -> |a,b,memcmp(a,b,n)>.
    bool predicate = relation != ERROR_MARK;
    tree result_type = predicate ? boolean_type_node : integer_type_node;
    tree result = build_int_cst(result_type,
                                relation == LE_EXPR || relation == GE_EXPR || relation == EQ_EXPR);
    tree equal_result = result;
    for (uint64_t i = count; i; --i) {
        tree x = object_byte(left, i - 1, at(call));
        tree y = object_byte(right, i - 1, at(call));
        if (i == count && relation != EQ_EXPR && relation != NE_EXPR) {
            result =
                fold_build2_loc(at(call), predicate ? relation : MINUS_EXPR, result_type, x, y);
            continue;
        }
        // strncmp stops at an equal NUL; unequal bytes still select their
        // own relation/difference before this suffix can contribute.
        if (stop_at_zero && i < count) {
            tree zero = fold_build2_loc(
                at(call), EQ_EXPR, boolean_type_node, x, build_zero_cst(integer_type_node));
            result = fold_build3_loc(at(call), COND_EXPR, result_type, zero, equal_result, result);
        }
        tree different = fold_build2_loc(at(call), NE_EXPR, boolean_type_node, x, y);
        if (relation == EQ_EXPR || relation == NE_EXPR) {
            tree comparison =
                relation == EQ_EXPR
                    ? fold_build1_loc(at(call), TRUTH_NOT_EXPR, boolean_type_node, different)
                    : different;
            result = fold_build2_loc(at(call),
                                     relation == EQ_EXPR ? TRUTH_ANDIF_EXPR : TRUTH_ORIF_EXPR,
                                     boolean_type_node,
                                     comparison,
                                     result);
        } else {
            tree difference =
                predicate ? fold_build2_loc(at(call),
                                            relation == LT_EXPR || relation == LE_EXPR ? LT_EXPR
                                                                                       : GT_EXPR,
                                            boolean_type_node,
                                            x,
                                            y)
                          : fold_build2_loc(at(call), MINUS_EXPR, integer_type_node, x, y);
            result =
                fold_build3_loc(at(call), COND_EXPR, result_type, different, difference, result);
        }
    }
    return predicate ? result : fold_convert(TREE_TYPE(call), result);
}

tree expand_memory_relation(tree value) {
    auto relation = TREE_CODE(value);
    if (relation != EQ_EXPR && relation != NE_EXPR && relation != LT_EXPR && relation != LE_EXPR &&
        relation != GT_EXPR && relation != GE_EXPR)
        return NULL_TREE;
    tree call = TREE_OPERAND(value, 0), zero = TREE_OPERAND(value, 1);
    if (integer_zerop(call)) {
        std::swap(call, zero);
        relation = relation == LT_EXPR   ? GT_EXPR
                   : relation == LE_EXPR ? GE_EXPR
                   : relation == GT_EXPR ? LT_EXPR
                   : relation == GE_EXPR ? LE_EXPR
                                         : relation;
    }
    // Do not strip casts here. Narrowing or unsigned conversion of memcmp's
    // result can change its sign, and therefore requires the full integer value.
    if (!zero || !integer_zerop(zero) || !call || TREE_CODE(call) != CALL_EXPR ||
        !standard_memory_compare(get_callee_fndecl(call)))
        return NULL_TREE;
    tree result = expand_memory_compare(call, relation);
    return result ? fold_convert(TREE_TYPE(value), result) : NULL_TREE;
}
