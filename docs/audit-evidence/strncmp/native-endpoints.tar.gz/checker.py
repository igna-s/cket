"""Target the six C relations without repeating the passed full-state matrix."""
from pathlib import Path
import json
import os
import signal
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/strncmp-prototype'
directory = candidate / 'build' / ('strncmp-integrated-native-endpoints' if '--integrated' in sys.argv else 'strncmp-native-endpoints')
directory.mkdir(exist_ok=False)
rows = []
for reference in (0xab00, 0xab41):
    for number, relation in enumerate(('<', '<=', '>', '>=', '==', '!=')):
        source = directory / (str(reference) + '-' + str(number) + '.c')
        source.write_text('#include <quantum.h>\n#include <string.h>\nint main(void){const uint16_t reference=' + str(reference) + ';const uint16_t words[8]={0x1200,0xab00,0x0041,0xab41,0xff41,0x0042,0xff00,0xffff};int bad=0;for(unsigned i=0;i<8;++i){uint16_t word=words[i];quant uint16_t input=word;quant bool result=strncmp((const char*)&input,(const char*)&reference,2)' + relation + '0;bad|=measure(result)!=(strncmp((const char*)&word,(const char*)&reference,2)' + relation + '0);reset(result);reset(input);}return bad;}\n')
        for builtins in ('-fbuiltin', '-fno-builtin'):
            command = [str(candidate / 'build/cket'), str(source), '--run', '-O2', builtins]
            process = subprocess.Popen(command, cwd=candidate, env=dict(os.environ, CC='gcc-11'), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
            try:
                output, error = process.communicate(timeout=120)
            except BaseException:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                raise
            assert process.returncode == 0, error + output
            assert not error.strip(), error
            rows.append({'reference': reference, 'relation': relation, 'builtins': builtins, 'values': 8})
            print(f'PASS strncmp native endpoints ref={reference} relation={relation} {builtins}', flush=True)
(directory / 'results.json').write_text(json.dumps({'status': 'passed', 'scope': '24 native programs at O2/both builtin modes, eight two-byte endpoints each, for all six relations. Wider complete-state cases were checked separately; the earlier 256-value native program for nonzero-prefix tails exceeded its 120-second command limit and remains a failed exploratory run, not a passing result.', 'checks': rows}, indent=2) + '\n')
