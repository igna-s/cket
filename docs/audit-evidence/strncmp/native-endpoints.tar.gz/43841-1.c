#include <quantum.h>
#include <string.h>
int main(void){const uint16_t reference=43841;const uint16_t words[8]={0x1200,0xab00,0x0041,0xab41,0xff41,0x0042,0xff00,0xffff};int bad=0;for(unsigned i=0;i<8;++i){uint16_t word=words[i];quant uint16_t input=word;quant bool result=strncmp((const char*)&input,(const char*)&reference,2)<=0;bad|=measure(result)!=(strncmp((const char*)&word,(const char*)&reference,2)<=0);reset(result);reset(input);}return bad;}
