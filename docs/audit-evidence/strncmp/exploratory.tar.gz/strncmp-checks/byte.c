#include <quantum.h>
#include <string.h>
int main(void){quant uint8_t input=superposition(0,255);const uint8_t reference=65;if(input==3)phase(.31);quant bool result=strncmp((const char*)&input,(const char*)&reference,1)<=0;if(result)phase(.17);measure(result);measure(input);return 0;}
