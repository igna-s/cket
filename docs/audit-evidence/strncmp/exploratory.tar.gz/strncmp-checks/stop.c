#include <quantum.h>
#include <string.h>
int main(void){quant uint16_t input=superposition(0,65535);const uint16_t reference=43776;if(input==3)phase(.31);quant bool result=strncmp((const char*)&input,(const char*)&reference,2)<=0;if(result)phase(.17);measure(result);measure(input);return 0;}
