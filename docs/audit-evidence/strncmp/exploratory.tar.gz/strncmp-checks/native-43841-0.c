#include <quantum.h>
#include <string.h>
int main(void){const uint16_t reference=43841;int bad=0;for(unsigned i=0;i<256;++i){uint16_t word=i*257u;quant uint16_t input=word;quant bool result=strncmp((const char*)&input,(const char*)&reference,2)<0;bad|=measure(result)!=(strncmp((const char*)&word,(const char*)&reference,2)<0);reset(result);reset(input);}return bad;}
