#include <quantum.h>
#include <string.h>
int main(void){quant uint8_t input=superposition(0,255);const uint8_t reference=0;if(input==3)phase(.31);quant int result=memcmp((const char*)&input,(const char*)&reference,sizeof input);if(result<0)phase(.17);measure(result);measure(input);return 0;}
