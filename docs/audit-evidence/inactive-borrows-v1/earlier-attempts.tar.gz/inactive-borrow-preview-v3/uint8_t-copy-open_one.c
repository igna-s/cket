#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
typedef uint8_t word;
int main(int argc,char **argv){
if(argc<2)return 2;size_t n=1;
quant uint8_t x=superposition(0,1);quant word y=superposition(0,1);
quant bool control=1;if(y)phase(.73);ownership_checkpoint("before");
{quant word saved=y^1;if(!control){memcpy((void*)&y,(const void*)&x,n);}if(saved)phase(.47);}
ownership_checkpoint("after");measure(y);measure(x);measure(control);return 0;}
