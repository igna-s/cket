from pathlib import Path
import sys

root=Path('/tmp/quantum-audit-isolated-20261017')
mode,version=sys.argv[1:]
name='build-coherent-store'+('-sanitized' if mode=='sanitized' else '')+'.py'
code=(root/'build'/name).read_text().replace('coherent-store','inactive-borrow')
sys.argv=[name,version]
exec(compile(code,name,'exec'))
