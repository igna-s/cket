from pathlib import Path
import sys

root=Path('/tmp/quantum-audit-isolated-20261017')
code=(root/'build/run-heap-identity-checks.py').read_text().replace('heap-identity-','inactive-borrow-')
code=code.replace("('heap-identities',['O0','O2'] if mode=='normal' else ['O1']),", "('inactive-borrows',['O0','O2'] if mode=='normal' else ['O1']),")
code=code.replace("('heap-memory',['O2' if mode=='normal' else 'O1']),", "('heap-identities',['O2' if mode=='normal' else 'O1']),")
code=code.replace("('coherent-overwrites',['O2' if mode=='normal' else 'O1'])", "('coherent-overwrites',['O0','O2'] if mode=='normal' else ['O1'])")
code=code.replace("('validate_heap_identities','validate_heap','validate_memset','validate_runtime_memory','validate_runtime_versions')", "('validate_inactive_borrows','validate_heap_identities','validate_heap','validate_controlled_operands','validate_runtime_memory','validate_runtime_versions')")
exec(compile(code,'run-inactive-borrow-checks.py','exec'))
