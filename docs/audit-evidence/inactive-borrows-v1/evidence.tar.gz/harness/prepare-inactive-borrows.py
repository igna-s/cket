import json
from pathlib import Path
import runpy
import shutil

root=Path('/tmp/quantum-audit-isolated-20261017')
format_text=runpy.run_path(str(root/'scripts/format.py'))['format_text']
for name in ('src/engine/internal.h','src/engine/quantum.c','src/engine/verify.c',
             'src/quantum_semantics.inc','tests/validate_inactive_borrows.c',
             'scripts/validate-inactive-borrows.py','scripts/build.sh','scripts/verify.sh','scripts/sanitize-all.sh'):
    path=root/name;path.write_text(format_text(path,path.read_text()))
hashes=runpy.run_path(str(root/'scripts/archive-audit.py'))['source_hashes']()
snapshot=root/'build/inactive-borrow-source-v1'
snapshot.mkdir()
for name in hashes:
    target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
(snapshot/'.deps').symlink_to(root/'.deps',target_is_directory=True)
(snapshot/'cket').chmod(0o755)
(snapshot/'docs').mkdir();shutil.copy2(root/'docs/c11-library.json',snapshot/'docs/c11-library.json')
(snapshot/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('Frozen',len(hashes),'compiler inputs',flush=True)
