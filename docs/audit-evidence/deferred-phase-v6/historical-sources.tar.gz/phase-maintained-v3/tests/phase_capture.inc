/* Inspect the actual compiled CPU bindings in a separate state context.
 * The same executable can delegate to the native runtime for domain checks.
 * Independent exported-circuit proofs remain a separate validation layer. */
#include "internal.h"
#include <math.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static qc_context *phase_test_context;
static int phase_test_capture, phase_test_preparation, phase_test_inverse;
static double phase_test_angle;

extern unsigned long long __real___cket_apply(const char *);
extern unsigned long long __real___cket_apply_values(const char *, unsigned long long, ...);
extern unsigned long long __real___cket_apply_arg(const char *, unsigned long long);
extern unsigned long long __real___cket_apply_phase(const char *, double);
extern unsigned long long __real___cket_measure(unsigned long long);

static void phase_test_fail(const char *reason) {
    fprintf(stderr, "phase state check: %s\n", reason);
    qc_destroy(phase_test_context);
    exit(1);
}

static qc_context *phase_test_engine(void) {
    if (!phase_test_context)
        phase_test_context = qc_create(1, 7);
    if (!phase_test_context)
        phase_test_fail("cannot allocate state context");
    return phase_test_context;
}

unsigned long long __wrap___cket_apply(const char *operation) {
    if (!phase_test_capture)
        return __real___cket_apply(operation);
    if (!qc_apply(phase_test_engine(), operation, NULL))
        phase_test_fail(qc_error(phase_test_context));
    return 0;
}

unsigned long long
__wrap___cket_apply_values(const char *operation, unsigned long long count, ...) {
    if (!count || count > 128)
        phase_test_fail("invalid binding count");
    uint64_t values[128];
    va_list arguments;
    va_start(arguments, count);
    for (unsigned long long i = 0; i < count; ++i)
        values[i] = va_arg(arguments, unsigned long long);
    va_end(arguments);
    /* Binding before forwarding preserves every generated CPU argument. */
    char *bound = qc_bind_operation(phase_test_engine(), operation, values, (size_t)count);
    if (!bound)
        phase_test_fail(qc_error(phase_test_context));
    unsigned long long result = 0;
    if (phase_test_capture) {
        if (!qc_apply(phase_test_context, bound, NULL))
            phase_test_fail(qc_error(phase_test_context));
    } else
        result = __real___cket_apply(bound);
    free(bound);
    return result;
}

unsigned long long __wrap___cket_apply_arg(const char *operation, unsigned long long value) {
    if (!phase_test_capture)
        return __real___cket_apply_arg(operation, value);
    if (!qc_apply_arg(phase_test_engine(), operation, value))
        phase_test_fail(qc_error(phase_test_context));
    return 0;
}

unsigned long long __wrap___cket_apply_phase(const char *operation, double angle) {
    if (!phase_test_capture)
        return __real___cket_apply_phase(operation, angle);
    if (!qc_apply_phase(phase_test_engine(), operation, angle))
        phase_test_fail(qc_error(phase_test_context));
    return 0;
}

unsigned long long __wrap___cket_measure(unsigned long long id) {
    if (!phase_test_capture) {
        qc_destroy(phase_test_context);
        phase_test_context = NULL;
        return __real___cket_measure(id);
    }
    qc_context *c = phase_test_engine();
    if (id != 0 || qc_state_size(c) != 2 || c->measure || c->reset)
        phase_test_fail("unexpected register, state dimension or implicit observation");
    unsigned phases = 0;
    for (size_t i = 0; i < c->ngates; ++i) {
        if (c->gates[i].kind != QC_PHASE)
            continue;
        double expected = phases ? -phase_test_angle : phase_test_angle;
        if (memcmp(&c->gates[i].angle, &expected, sizeof expected))
            phase_test_fail("angle differs from the ordinary C reference bits");
        ++phases;
    }
    unsigned expected_phases = phase_test_preparation ? 1u + (unsigned)phase_test_inverse : 0u;
    if (phases != expected_phases)
        phase_test_fail("wrong number of selected phase operations");
    double angle = phase_test_inverse ? 0 : phase_test_angle;
    double complex expected[2] = {0, 0};
    if (phase_test_preparation < 0) {
        expected[0] = 1 / sqrt(2.0);
        expected[1] = cexp(I * angle) / sqrt(2.0);
    } else
        expected[phase_test_preparation] = cexp(I * angle * phase_test_preparation);
    for (unsigned i = 0; i < 2; ++i)
        if (cabs(qc_amplitude(c, i) - expected[i]) > 1e-10)
            phase_test_fail("complete complex state differs from its source reference");
    qc_destroy(c);
    phase_test_context = NULL;
    return phase_test_preparation > 0;
}
