from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

root=Path('/tmp/quantum-audit-isolated-20261017')
candidate=root/'build/phase-maintained-v6'
out=candidate/'build/targeted-v1'
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
write=lambda path,value:path.write_text(json.dumps(value,indent=2)+'\n')
if '--worker' not in sys.argv:
    out.mkdir();shutil.copyfile(Path(__file__),out/'runner.py')
    with (out/'worker.log').open('x') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],cwd=candidate,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    write(out/'job.json',{'pid':child.pid,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print('Started phase v6 fresh builds and maintained checks:',child.pid)
    raise SystemExit(0)
frozen=json.loads((candidate/'build/sources.json').read_text())
record={'status':'running','source_sha256':frozen,'commands':[]}
def run(name,args,env,cwd=candidate):
    assert all(digest(candidate/path)==expected for path,expected in frozen.items())
    row={'name':name,'argv':list(map(str,args)),'log':name+'.log','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    record['commands'].append(row);write(out/'progress.json',record)
    with (out/row['log']).open('w') as log: result=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    row.update(returncode=result.returncode,log_sha256=digest(out/row['log']),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(out/'progress.json',record)
    assert result.returncode==0,(name,result.returncode)
    print(name,'closed zero',flush=True)
try:
    env=dict(os.environ,CC='gcc-11',CXX='g++-11')
    run('fresh-normal-build',['bash','scripts/build.sh'],env)
    run('normal-phase',[str(candidate/'build/validate_phase')],env)
    stage=candidate/'build/sanitized-phase-v1'
    source=(candidate/'scripts/sanitize-all.sh').read_text()
    marker='"$san_root/build/cket_tests" "$san_root"\n'
    assert source.count(marker)==1
    source=source[:source.index(marker)].replace('cd "$(dirname "$0")/.."','cd '+str(candidate))
    script=out/'fresh-sanitized.sh';script.write_text(source)
    run('fresh-sanitized-build',['bash',str(script)],dict(env,CKET_SAN_ROOT=str(stage)))
    san_env=dict(env,CC=str(stage/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    run('sanitized-phase',[str(stage/'build/validate_phase')],san_env,stage)
    record.update(status='passed-maintained-phase-targeted',exit_code=0)
except BaseException as error:
    traceback.print_exc();record.update(status='failed-maintained-phase-targeted',exit_code=1,error=repr(error))
finally:
    record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(out/'exit.json',record)
raise SystemExit(record['exit_code'])
