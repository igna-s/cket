#include "internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv) {
    if (argc != 5) return 2;
    char *text = qc_read_file(argv[1]);
    qc_context *c = qc_create(0, 7);
    if (!text || !c) return 3;
    qc_allow_tables(c, atoi(argv[4]));
    if (!qc_document(c, text, 0, 0)) { fprintf(stderr, "%s\n", qc_error(c)); return 4; }
    FILE *qasm = fopen(argv[2], "wx"), *map = fopen(argv[3], "wx");
    if (!qasm || !map || !qc_qasm(c, qasm) || fclose(qasm)) return 5;
    fprintf(map, "{\"qubits\":%u,\"measure\":%llu,\"reset\":%llu,\"registers\":[", c->physical,
        (unsigned long long)c->measure, (unsigned long long)c->reset);
    unsigned count = 0;
    for (size_t i = 0; i < c->nregisters; ++i) {
        qc_register *r = &c->registers[i];
        if (!r->alive) continue;
        fprintf(map, "%s{\"id\":%u,\"wires\":[", count++ ? "," : "", r->id);
        for (unsigned j = 0; j < r->width; ++j) fprintf(map, "%s%u", j ? "," : "", r->wires[j]);
        fputs("]}", map);
    }
    fputs("],\"phase_bits\":[", map);
    count = 0;
    for (size_t i = 0; i < c->ngates; ++i) {
        if (c->gates[i].kind != QC_PHASE) continue;
        uint64_t bits;
        memcpy(&bits, &c->gates[i].angle, sizeof bits);
        fprintf(map, "%s\"%016llx\"", count++ ? "," : "", (unsigned long long)bits);
    }
    fputs("]}\n", map);
    int failed = fclose(map);
    qc_destroy(c); free(text);
    return failed != 0;
}
