def simulate(text):
    state, measurements = {0: 1+0j}, {}
    qubits = bits = None
    gates = hadamards = 0
    terminal = False
    for line in text.splitlines():
        line = line.strip()
        if line in ('', 'OPENQASM 3.0;', 'include "stdgates.inc";'):
            continue
        match = re.fullmatch(r'(qubit|bit)\[(\d+)\] (q|results);', line)
        if match:
            if match[1] == 'qubit':
                assert qubits is None and match[3] == 'q'
                qubits = int(match[2])
                assert 0 < qubits <= 128
            else:
                assert bits is None and match[3] == 'results'
                bits = int(match[2])
            continue
        match = re.fullmatch(r'results\[(\d+)\] = measure q\[(\d+)\];', line)
        if match:
            bit, wire = int(match[1]), int(match[2])
            assert 0 <= bit < bits and 0 <= wire < qubits and bit not in measurements
            measurements[bit] = wire
            terminal = True
            continue
        assert not terminal, 'This sparse state audit only skips terminal observations.'
        match = re.fullmatch(r'(?:(ctrl|negctrl)\((\d+)\) @ )?(h|x|p|gphase)(?:\(([^)]+)\))?(?: (.*))?;', line)
        assert match, line
        modifier, controls, gate, angle, operands = match.groups()
        controls = int(controls or 0)
        wires = []
        for operand in operands.split(',') if operands else []:
            index = re.fullmatch(r'q\[(\d+)\]', operand.strip())
            assert index, operand
            wires.append(int(index[1]))
        assert len(wires) == len(set(wires)) and all(0 <= w < qubits for w in wires)
        assert len(wires) == controls + (gate != 'gphase')
        mask = sum(1 << wire for wire in wires[:controls])
        wanted = 0 if modifier == 'negctrl' else mask
        gates += 1
        if gate == 'h':
            assert controls == 0 and angle is None
            hadamards += 1
            flag, result = 1 << wires[-1], {}
            for basis, amplitude in state.items():
                low, high = basis & ~flag, basis | flag
                scaled = amplitude / math.sqrt(2)
                result[low] = result.get(low, 0) + scaled
                result[high] = result.get(high, 0) + (-scaled if basis & flag else scaled)
            state = {basis: a for basis, a in result.items() if abs(a) > 1e-14}
        elif gate == 'x':
            assert angle is None
            flag = 1 << wires[-1]
            result = {basis ^ flag if basis & mask == wanted else basis: a for basis, a in state.items()}
            assert len(result) == len(state), 'A controlled X must be a permutation.'
            state = result
        else:
            angle = float(angle)
            assert math.isfinite(angle)
            phase = cmath.exp(1j * angle)
            if gate == 'p':
                target = 1 << wires[-1]
                mask |= target
                wanted |= target
            state = {basis: a * phase if basis & mask == wanted else a for basis, a in state.items()}
        assert len(state) <= 262144, 'Sparse audit resource bound exceeded.'
    assert not measurements if bits is None else set(measurements) == set(range(bits))
    return state, measurements, qubits, gates, hadamards
