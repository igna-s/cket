#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void reference_phase(double value) {
    uint64_t bits; memcpy(&bits, &value, sizeof bits);
    printf("%016llx\n", (unsigned long long)bits);
}
#define quant
#define superposition(a,b) (b)
#define phase(x) reference_phase((x))
#define measure(x) ((unsigned)(x))
#include <stdint.h>
#include <stdlib.h>
int main(int argc,char **argv){if(argc!=6)return 2;int k=atoi(argv[1]);double a=strtod(argv[2],0);uint64_t u=strtoull(argv[3],0,10);int enabled=atoi(argv[4]),undo=atoi(argv[5]);(void)k;(void)a;(void)u;(void)enabled;quant bool b=superposition(0,1);if(b){phase((double)(uint8_t)(300/k));if(undo)phase(-((double)(uint8_t)(300/k)));}return measure(b)>1;}
