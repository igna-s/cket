"""Supplementary composition check against Grover's analytic amplitudes."""
from pathlib import Path
import argparse
import cmath
import hashlib
import json
import math
import os
import subprocess

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('configuration', choices=('normal', 'sanitized'))
args = parser.parse_args()
tool_root = root if args.configuration == 'normal' else root / 'build/sanitized'
directory = root / 'build/memcmp-oracle-results' / args.configuration
directory.mkdir(parents=True, exist_ok=False)
environment = dict(os.environ, CC='gcc-11')
if args.configuration == 'sanitized':
    environment.update(CC=str(tool_root / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
source = root / 'build/memcmp-oracle.c'
assert 'find_known(input, memcmp((const void *)&input, "A", 1) == 0, 1)' in source.read_text()
theta = math.asin(1 / 16)
estimate = math.pi / (4 * theta) - .5
iterations = max((math.floor(estimate), math.ceil(estimate)), key=lambda j: math.sin((2*j+1)*theta)**2)
marked = math.sin((2*iterations+1)*theta)
unmarked = math.cos((2*iterations+1)*theta) / math.sqrt(255)
rows = []
for level in ('-O0', '-O1', '-O2', '-O3', '-Os'):
    for builtins in ('-fbuiltin', '-fno-builtin'):
        stem = level[1:] + builtins[1:]
        ir = directory / (stem + '.json')
        command = [str(tool_root / 'build/cket'), str(source), '--emit-ir', level, builtins, '-o', str(ir)]
        subprocess.run(command, cwd=root, env=environment, check=True, capture_output=True, text=True, timeout=120)
        for tables in (True, False):
            path = directory / (stem + ('-tables' if tables else '-no-tables') + '.state.json')
            command = [str(tool_root / 'build/cket_backend'), '--state', str(ir)]
            if not tables:
                command.append('--no-tables')
            result = subprocess.run(command, cwd=root, env=environment, check=True, capture_output=True, text=True, timeout=120)
            assert not result.stderr.strip(), result.stderr
            path.write_text(result.stdout)
            state = json.loads(result.stdout)
            actual = {a['index']: complex(a['real'], a['imag']) for a in state['amplitudes']}
            assert len(actual) == len(state['amplitudes'])
            phase = actual[65] / marked
            assert abs(abs(phase) - 1) < 1e-10
            maximum = max(abs(actual.get(i, 0) - phase * (marked if i == 65 else unmarked if i < 256 else 0)) for i in range(1 << state['qubits']))
            assert maximum < 1e-10, (level, builtins, tables, maximum)
            norm = sum(abs(a)**2 for a in actual.values())
            assert abs(norm - 1) < 1e-10
            rows.append({'optimization': level, 'builtins': builtins, 'tables': tables, 'qubits': state['qubits'], 'maximum_amplitude_error': maximum, 'marked_probability': abs(actual[65])**2, 'state_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'ir_sha256': hashlib.sha256(ir.read_bytes()).hexdigest()})
report = {'status': 'passed', 'configuration': args.configuration, 'scope': 'Complete states including private-wire cleanup compared, up to one global phase, with analytic Grover amplitudes for an 8-bit single-solution memcmp predicate. Both table policies, five GCC optimization levels and both builtin settings. This does not test arbitrary promises or all oracle expressions.', 'domain': 256, 'solutions': 1, 'marked_input': 65, 'iterations': iterations, 'predicted_marked_probability': marked**2, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'checks': rows}
(directory / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(f'{len(rows)} {args.configuration} memcmp/Grover complete-state checks passed; iterations={iterations}, predicted success={marked**2:.17g}.')
