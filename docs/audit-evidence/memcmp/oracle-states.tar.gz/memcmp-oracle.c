#include <quantum.h>
#include <string.h>

int main(void) {
    quant uint8_t input = superposition(0, 255);
    quant uint8_t match = find_known(input, memcmp((const void *)&input, "A", 1) == 0, 1);
    return measure(match) != 65;
}
