#include <quantum.h>
void update(quant bool x,int n){for(unsigned i=0;i<4;++i){if(x)break;x^=true;}}
int main(int argc,char**argv){quant bool c=superposition(0,1),x=false;if(c)update(x,argc);measure(x);measure(c);return 0;}
