#include <quantum.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
static void inner(quant const bool*x,unsigned n){if(!n)return;if(x[0])phase(.17);}
static void rotate(quant const bool*x,double theta){if(!theta)return;if(x[0])phase(theta);}
static void update(quant const bool*x,unsigned n){for(unsigned i=0;i<3;++i){for(unsigned j=0;j<3;++j){if(j==n)break;if(i==n)continue;if(x[0])phase(.03*(i*3+j+1));}}if(!x[0])phase(.11);}
int main(int argc,char**argv){unsigned n=argc>1?(unsigned)strtoul(argv[1],0,10):0;quant bool x=superposition(0,1),control=superposition(0,1);if(x)phase(.37);if(control)phase(-.19);ownership_checkpoint("before");if(control)update(&x,n);if(x)phase(.41);ownership_checkpoint("after");measure(x);measure(control);return 0;}
