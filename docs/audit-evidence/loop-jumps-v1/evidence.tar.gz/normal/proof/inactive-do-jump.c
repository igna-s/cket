#include <quantum.h>
void update(quant bool x,int n){unsigned i=0;do{if(10/n)continue;++i;x^=true;}while(i<4);}
int main(int argc,char**argv){int n=argc>1?argv[1][0]-'0':0;quant bool c=false,x=false;if(c)update(x,n);return measure(x)||measure(c);}
