#include <quantum.h>
quant bool update(quant const bool x,unsigned n){quant bool t=!x;if(n)return t;t^=true;return t;}
int main(void){volatile unsigned n=0;quant bool x=false;quant bool y=update(x,n);measure(y);measure(x);return 0;}
