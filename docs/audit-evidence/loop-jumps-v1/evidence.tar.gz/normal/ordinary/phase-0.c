#include <quantum.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
static void inner(quant const bool*x,unsigned n){if(!n)return;if(x[0])phase(.17);}
static void update(quant const bool*x,unsigned n){quant bool scratch=!x[0];if(scratch)phase(.17);if(n==0)return;if(scratch)phase(.23);}
int main(int argc,char**argv){unsigned n=argc>1?(unsigned)strtoul(argv[1],0,10):0;quant bool x=superposition(0,1),spectator=superposition(0,1);if(x)phase(.37);if(spectator)phase(-.19);ownership_checkpoint("before");update(&x,n);if(x)phase(.41);ownership_checkpoint("after");measure(x);measure(spectator);return 0;}
