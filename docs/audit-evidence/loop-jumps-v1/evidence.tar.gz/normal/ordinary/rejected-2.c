#include <quantum.h>
void update(quant bool x,unsigned n){switch(n){case 0:return;default:break;}x^=true;}
int main(void){quant bool x=false;update(x,0);return 0;}
