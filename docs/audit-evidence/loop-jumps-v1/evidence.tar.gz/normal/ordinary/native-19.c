#include <quantum.h>
#include <stdlib.h>
static void cpu_inner(bool*x,unsigned n,unsigned*v){if(!n)return;x[0]^=true;++*v;}
static void inner(quant bool*x,unsigned n,unsigned*v){if(!n)return;x[0]^=true;++*v;}
static void reference(bool*x,unsigned n,unsigned*visits){for(unsigned i=0;i<4;++i){cpu_inner(x,i,visits);if(i==n)continue;if(i==2)break;x[0]^=true;}++*visits;}
static void update(quant bool*x,unsigned n,unsigned*visits){for(unsigned i=0;i<4;++i){inner(x,i,visits);if(i==n)continue;if(i==2)break;x[0]^=true;}++*visits;}
int main(int argc,char**argv){if(argc!=3)return 2;unsigned n=(unsigned)strtoul(argv[1],0,10);bool input=argv[2][0]=='1';bool expected=input;unsigned a=0,b=0;reference(&expected,n,&a);quant bool x=input;update(&x,n,&b);x^=true;expected^=true;return measure(x)!=expected||a!=b;}
