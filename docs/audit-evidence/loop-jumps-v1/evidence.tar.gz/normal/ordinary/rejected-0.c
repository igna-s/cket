#include <quantum.h>
void update(quant const bool x){if(x)return;phase(.1);}
int main(void){quant bool x=false;update(x);return 0;}
