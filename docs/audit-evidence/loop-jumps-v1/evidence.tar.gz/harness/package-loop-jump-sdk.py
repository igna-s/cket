import json,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');project=r/'build/loop-jump-source-v1'
assert json.loads((r/'build/loop-jump-normal-proof-v1/summary.json').read_text())['status']=='passed'
shutil.copy2(r/'build/private-cpu-loop-source-v3/LICENSE',project/'LICENSE')
s=(r/'build/package-private-cpu-loop-sdk-complete.py').read_text()
for old,new in [('build/private-cpu-loop-source-v3','build/loop-jump-source-v1'),('build/private-cpu-loop-sdk-stage-v2','build/loop-jump-sdk-stage-v1'),('build/private-cpu-loop-sdk-results-v2','build/loop-jump-sdk-results-v1'),('output/sdk/cpu-loops','output/sdk/loop-jumps')]:
    assert old in s,old;s=s.replace(old,new)
s=s.replace('Los procedimientos void admiten retornos CPU anticipados, locales enteros privados y bucles CPU desde llamadores coherentes.','Los procedimientos void admiten retornos CPU anticipados, locales privados y break/continue de bucles CPU desde llamadores coherentes.')
p=r/'build/package-loop-jump-sdk-complete.py';p.write_text(s);exec(compile(s,str(p),'exec'))
destination=r/'output/sdk/loop-jumps'
(destination/'example_coherent.c').write_text('''#include <quantum.h>
#include <stdio.h>
#include <stdlib.h>

static void transform(quant bool target, unsigned skip) {
    int sign = 1;
    for (unsigned i = 0; i < 4; ++i) {
        if (i == skip)
            continue;
        if (i == 2)
            break;
        sign = -sign;
        target ^= true;
        phase(sign * 3.141592653589793);
    }
}

int main(int argc, char **argv) {
    unsigned skip = argc > 1 ? (unsigned)strtoul(argv[1], NULL, 10) : 2;
    if (skip > 4)
        return 2;
    quant bool control = superposition(0, 1), target = false;
    if (control)
        transform(target, skip);
    if (skip < 3)
        if (control)
            target ^= true;
    fourier(control);
    unsigned c = measure(control), t = measure(target);
    printf("skip=%u control=%u target=%u\\n", skip, c, t);
    return t || c != (skip < 3);
}
''')
shutil.copy2(project/'examples/blocks/05/heap_iterations.c',destination/'example_heap.c')
(destination/'run_coherent_demo.cmd').write_text('@echo off\ncall "%~dp0compile_and_run.cmd" "%~dp0example_coherent.c"\nexit /b %errorlevel%\n')
print('Loop jump SDK ready for Windows workflow checks',flush=True)
