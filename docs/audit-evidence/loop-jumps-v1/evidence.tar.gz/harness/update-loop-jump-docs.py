import runpy
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
names=['README.md','output/sdk/README.es.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/c11-procedure-returns.md','docs/perfil-c-cotidiano.es.md','docs/paper/README.md','docs/paper/current-evidence-map-2026-10-26.es.md']
texts={n:(r/n).read_text() for n in names}
for n in ['README.md','output/sdk/README.es.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/paper/current-evidence-map-2026-10-26.es.md']:
    texts[n]=texts[n].replace('sdk/cpu-loops/','sdk/loop-jumps/').replace('sdk\\cpu-loops\\','sdk\\loop-jumps\\').replace('(cpu-loops/README.es.md)','(loop-jumps/README.es.md)')
def replace(n,old,new):
    assert texts[n].count(old)==1,(n,old);texts[n]=texts[n].replace(old,new)
replace('README.md','The compiler uses GCC\'s real C frontend.', '''Structured CPU break/continue now preserve loop cleanup and the for increment rules, including
calls from coherent control. The [note](docs/paper/loop_jumps_note.es.md) and
[evidence](docs/audit-evidence/loop-jumps-v1/README.es.md) distinguish finite C effects, complex
states and complete inverses from arbitrary flow/lifetime support. Quantum-dependent jumps and
continue through switch remain pending.

The compiler uses GCC's real C frontend.''')
replace('README.md','iteration, coherent break/continue, nested CPU effects and general lifetimes remain pending.','iteration, nested CPU effects and general lifetimes remain pending; the next block adds CPU jumps.')
replace('output/sdk/README.es.md','SDK con locales privados y bucles CPU coherentes','SDK con break y continue CPU desde llamadores coherentes')
replace('docs/estado-general-del-proyecto.es.md','**Locales mutables privados y bucles CPU implementados:**','''**Break y continue CPU implementados:** se transportan con permisos privados y se llega a
la limpieza del bloque antes de salir o continuar. `continue` conserva el incremento del
`for`; `break` lo omite. La [nota](paper/loop_jumps_note.es.md) y la
[evidencia](audit-evidence/loop-jumps-v1/README.es.md) registran 1900 puntos de estado y
950 inversas con llamador coherente en normal; 380 y 190 con ASan/UBSan. La comparación con
C nativo pasa 1100 ejecuciones normales y 220 instrumentadas. El SDK recomendado incluye
el ejemplo. Quedan saltos/iteración cuánticos, `continue` a través de `switch`, flujo y
vidas/alias/ABI generales e integración completa de estas fuentes.

**Bloque anterior de locales mutables y bucles CPU:**''')
texts['docs/c11-procedure-returns.md']+='''\nLos [saltos CPU estructurados de bucle](paper/loop_jumps_note.es.md) ya permiten `break` y
`continue` en ese perfil, también desde llamadores coherentes. Llegan a la limpieza y conservan
las reglas de incremento/condición de C. Se rechazan decisiones cuánticas sin medir y
`continue` a través de `switch`; los saltos y vidas generales continúan pendientes.
'''
replace('docs/c11-procedure-returns.md','saltos coherentes y las vidas generales conservan sus restricciones.','saltos generales y las vidas generales conservan sus restricciones.')
profile='docs/perfil-c-cotidiano.es.md'
start=texts[profile].index('Los [locales enteros CPU privados]')
texts[profile]=texts[profile][:start]+'''Los [locales CPU privados y bucles](paper/private_cpu_loops_note.es.md) admiten inicializadores
puros, escrituras dentro de la misma rama cuántica de declaración y condiciones de iteración CPU
puras. Se excluyen direcciones tomadas, almacenamiento estático, `volatile`, `_Atomic`, punteros
y agregados privados. Los [saltos CPU estructurados](paper/loop_jumps_note.es.md) añaden `break`
y `continue`, con la limpieza y los incrementos de C. Quedan decisiones cuánticas de salto o
iteración, `continue` a través de `switch`, efectos CPU anidados y vidas/alias/ABI generales.
Las notas y cápsulas anteriores mantienen sus propias identidades y alcances.
'''
texts['docs/paper/README.md']+='''\nLa [nota de break/continue CPU](loop_jumps_note.es.md) y su
[cápsula](../audit-evidence/loop-jumps-v1/README.es.md) amplían los bucles con permisos privados,
limpieza y reglas de incremento verificadas contra C. Incluyen matrices normales e instrumentadas
de efectos CPU, estados complejos e inversas; no recalifican los manuscritos históricos.
'''
texts['docs/paper/current-evidence-map-2026-10-26.es.md']+='''\nEl SDK recomendado incluye ahora [break/continue CPU](loop_jumps_note.es.md), con otras
244 identidades de fuente. Su [cápsula](../audit-evidence/loop-jumps-v1/README.es.md) distingue
1100 comparaciones C normales de 1900 puntos de estado con llamador coherente y sus inversas;
ambas matrices pasan también instrumentadas con sus propios recuentos. Quedan saltos cuánticos,
flujo/vidas generales e integración completa de estas fuentes.
'''
replace('docs/entrega-utilizable-2026-10-26.es.md','count=1 control=1 target=0','skip=2 control=1 target=0')
texts['docs/entrega-utilizable-2026-10-26.es.md']+='''\nEl SDK actual añade [break/continue CPU](paper/loop_jumps_note.es.md): respeta la limpieza,
el bucle más próximo y el incremento de `for`. La
[evidencia](audit-evidence/loop-jumps-v1/README.es.md) identifica sus fuentes y comprobaciones
C/estados/inversas. Los límites anteriores de saltos CPU se superan para ese perfil; permanecen
decisiones cuánticas, flujo/vidas generales y el CI completo de la ampliación.
'''
for n,s in texts.items():(r/n).write_text(fmt(r/n,s))
(r/'build/loop-jump-docs.txt').write_text('\n'.join(names)+'\n')
print('Updated',len(names),'current documents')
