import hashlib,json,os,runpy,shutil,subprocess,time
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for n in ('src/cket_plugin.cpp','src/quantum_semantics.inc','src/quantum_frontend.inc','scripts/validate-coherent-procedure-returns.py','scripts/validate-procedure-returns.py'):
    p=r/n;p.write_text(fmt(p,p.read_text()))
source=runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
root=r/'build/loop-jump-source-v1';root.mkdir()
for n in source:
    p=root/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/n,p)
(root/'.deps').symlink_to(r/'.deps',target_is_directory=True)
(root/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
out=r/'build/loop-jump-results-v1';out.mkdir()
header=Path(subprocess.check_output(['gcc-11','-print-file-name=plugin'],text=True).strip())/'include'
if not (header/'gcc-plugin.h').exists():header=r/'.deps/gcc'/header.relative_to('/')
records=[]
def run(name,command,cwd,env):
    start=time.time()
    with (out/(name+'.log')).open('w') as log:z=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
    records.append(dict(name=name,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-start))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,z.returncode,(out/(name+'.log')).read_text()[-1600:],flush=True)
    if z.returncode:raise SystemExit(z.returncode)
for mode,previous,levels in [('normal',r/'build/private-cpu-loop-source-v3',['O0','O1','O2','O3','Os']),('sanitized',r/'build/private-cpu-loop-sanitized-v3',['O1'])]:
    target=root if mode=='normal' else r/'build/loop-jump-sanitized-v1'
    if mode=='sanitized':
        target.mkdir()
        for n in ('src','include','tests','examples'):(target/n).symlink_to(root/n,target_is_directory=True)
        shutil.copy2(root/'cket',target/'cket')
    (target/'build').mkdir()
    for n in ('cket','cket_backend','cket_runtime.o','libcket_quantum.a','gcc-version.txt','validate_bindings','validate_readonly_borrows','validate_function_entries','validate_controlled_operands','cket_tests'):
        shutil.copy2(previous/'build'/n,target/'build'/n)
    env=dict(os.environ,CC='gcc-11',CXX='g++-11');san=[]
    if mode=='sanitized':
        shutil.copy2(previous/'build/gcc-wrapper',target/'build/gcc-wrapper')
        env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        san=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
    run(mode+'-plugin',['g++-11','-std=c++17','-O2','-Wall','-Wextra','-Wno-unused-parameter','-Wno-format-diag','-fPIC','-shared','-fno-rtti','-I'+str(header),'-I'+str(r/'.deps/gcc/usr/include'),'-I'+str(r/'.deps/gcc/usr/include/x86_64-linux-gnu')]+san+['src/cket_plugin.cpp','-o',str(target/'build/cket_plugin.so')],root,env)
    result=r/('build/loop-jump-'+mode+'-proof-v1')
    run(mode+'-proof',['python3',str(root/'scripts/validate-coherent-procedure-returns.py'),'--compiler-root',str(target),'--output',str(result),'--levels']+levels+(['--sanitized'] if san else []),root,env)
    ordinary=r/('build/loop-jump-'+mode+'-ordinary-v1')
    run(mode+'-ordinary',['python3',str(root/'scripts/validate-procedure-returns.py'),'--compiler-root',str(target),'--output',str(ordinary),'--levels']+levels+(['--sanitized'] if san else []),root,env)
    for n in ('validate_bindings','validate_readonly_borrows','validate_function_entries','validate_controlled_operands'):
        run(mode+'-'+n,[str(target/'build'/n)],root,env)
    run(mode+'-core',[str(target/'build/cket_tests'),str(target)],root,env)
(out/'terminal.json').write_text(json.dumps(dict(status='passed',source_sha256=source),indent=2)+'\n')
print('Private CPU loops: normal and sanitized directed qualification passed.',flush=True)
