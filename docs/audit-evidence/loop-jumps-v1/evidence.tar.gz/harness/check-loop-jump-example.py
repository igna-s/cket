import json,os,runpy,subprocess
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');out=r/'build/loop-jump-example-v1';out.mkdir()
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for n in ['output/sdk/loop-jumps/example_coherent.c','output/sdk/loop-jumps/README.es.md','docs/paper/loop_jumps_note.es.md','docs/audit-evidence/loop-jumps-v1/README.es.md']:
    p=r/n;p.write_text(fmt(p,p.read_text()))
records=[]
for mode,target in [('normal',r/'build/loop-jump-source-v1'),('sanitized',r/'build/loop-jump-sanitized-v1')]:
    env=dict(os.environ,CC='gcc-11',CKET_SEED='7',CKET_SIMULATOR='sparse')
    if mode=='sanitized':env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    binary=out/mode
    commands=[('compile',[str(target/'build/cket'),str(r/'output/sdk/loop-jumps/example_coherent.c'),'-O2','-o',str(binary)])]+[(str(n),[str(binary),str(n)]) for n in range(5)]
    for label,command in commands:
        z=subprocess.run(command,cwd=target,env=env,text=True,capture_output=True,timeout=120)
        text=z.stdout+z.stderr;(out/(mode+'-'+label+'.log')).write_text(text)
        records.append(dict(mode=mode,label=label,command=command,exit_code=z.returncode))
        (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
        print(mode,label,z.returncode,text[-1500:],flush=True);assert z.returncode==0,text
        if label!='compile':assert 'skip='+label+' control='+str(int(int(label)<3))+' target=0' in text
(out/'summary.json').write_text(json.dumps(dict(status='passed',native_executions=10,scope='Finite native break/continue, private counter, signed phase and loop interference example; distinct from complete state matrices.'),indent=2)+'\n')
