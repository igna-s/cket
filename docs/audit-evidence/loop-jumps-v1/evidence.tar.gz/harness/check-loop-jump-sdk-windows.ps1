$ErrorActionPreference = 'Stop'
$taskRoot = 'E:\Backup\GitHub\Quantum'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$rows = @()
foreach ($case in @(
    @{ name = 'demo'; command = 'output\sdk\loop-jumps\run_sdk_demo.cmd'; expected = 'build/blocks/06/search_write' },
    @{ name = 'coherent'; command = 'output\sdk\loop-jumps\run_coherent_demo.cmd'; expected = 'skip=2 control=1 target=0' },
    @{ name = 'heap'; command = 'output\sdk\loop-jumps\compile_and_run.cmd output\sdk\loop-jumps\example_heap.c'; expected = 'rounds=3 output=12 sum=30' }
)) {
    $start = New-Object System.Diagnostics.ProcessStartInfo
    $start.FileName = 'cmd.exe'
    $start.Arguments = '/d /c ' + $case.command
    $start.WorkingDirectory = $taskRoot
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $start
    $null = $process.Start()
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    $process.WaitForExit()
    $exitCode = $process.ExitCode
    $output = $stdout.Result + $stderr.Result
    [IO.File]::WriteAllText("$taskRoot/build/loop-jump-windows-$($case.name).log", $output, $utf8)
    $rows += @{ name = [string]$case.name; command = [string]$case.command; exit_code = [int]$exitCode }
    [IO.File]::WriteAllText("$taskRoot/build/loop-jump-windows-results.json", ($rows | ConvertTo-Json -Depth 5) + "`n", $utf8)
    if ($exitCode -ne 0 -or !$output.Contains($case.expected)) { throw "SDK workflow failed: $($case.name), exit $exitCode; $output" }
    Write-Output "Windows SDK $($case.name): passed"
}
