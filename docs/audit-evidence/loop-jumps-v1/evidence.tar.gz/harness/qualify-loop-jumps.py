from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
s=(r/'build/probe-private-cpu-loops-complete.py').read_text()
s=s.replace('private-cpu-loop-','loop-jump-')
for old,new in [('build/loop-jump-source-v3','build/loop-jump-source-v1'),('build/loop-jump-sanitized-v3','build/loop-jump-sanitized-v1'),('build/loop-jump-results-v3','build/loop-jump-results-v1'),('-proof-v3','-proof-v1'),('build/immutable-cpu-local-source-v3','build/private-cpu-loop-source-v3'),('build/immutable-cpu-local-sanitized-v3','build/private-cpu-loop-sanitized-v3')]:
    s=s.replace(old,new)
s=s.replace("'scripts/validate-coherent-procedure-returns.py'","'scripts/validate-coherent-procedure-returns.py','scripts/validate-procedure-returns.py'",1)
old="    for n in ('validate_bindings','validate_readonly_borrows','validate_function_entries','validate_controlled_operands'):"
new="    ordinary=r/('build/loop-jump-'+mode+'-ordinary-v1')\n    run(mode+'-ordinary',['python3',str(root/'scripts/validate-procedure-returns.py'),'--compiler-root',str(target),'--output',str(ordinary),'--levels']+levels+(['--sanitized'] if san else []),root,env)\n"+old
assert old in s;s=s.replace(old,new)
p=r/'build/qualify-loop-jumps-complete.py';p.write_text(s);exec(compile(s,str(p),'exec'))
