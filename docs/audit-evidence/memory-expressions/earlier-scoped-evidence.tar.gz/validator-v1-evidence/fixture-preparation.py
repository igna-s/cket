"""Create the maintained validator only in the isolated memset experiment."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memset-prototype'
frozen = json.loads((candidate / 'build/probe-sources-before.json').read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name

def literal_cases(path):
    tree = ast.parse(path.read_text())
    node = next(node for node in tree.body if isinstance(node, ast.Assign)
                and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'cases')
    return ast.literal_eval(node.value)

native = literal_cases(root / 'build/probe-memset-native.py')
state_tree = ast.parse((root / 'build/probe-memset-states.py').read_text())
assignments = [node for node in state_tree.body if isinstance(node, ast.Assign)
               and isinstance(node.targets[0], ast.Name)
               and node.targets[0].id in ('phase', 'cases')]
assert len(assignments) == 2
scope = {'__builtins__': {'range': range}}
exec(compile(ast.Module(body=assignments, type_ignores=[]), '<finite-source-profiles>', 'exec'), scope)
states = scope['cases']
assert len(native) == 20 and len(states) == 8

state = (root / 'build/memset-state-check.c').read_text()
control = (root / 'build/memset-control-paths.inc').read_text()
before = '''int main(int argc, char **argv) {
    if (argc != 3)
        fail("usage: memset-state-check IR PROFILE");
    unsigned profile = (unsigned)strtoul(argv[2], NULL, 10);
    char *text = qc_read_file(argv[1]);'''
after = '''static unsigned memset_state_probe(const char *ir, unsigned profile) {
    char *text = strdup(ir);
    if (profile > 7)
        fail("invalid source profile");'''
assert state.count(before) == 1
state = state.replace(before, control + '\n' + after)
assert state.count('qc_create(1, 7)') == 1
state = state.replace('qc_create(1, 7)', 'qc_create(profile == 2 ? 0 : 1, 7)')
state = state.replace('        compare(c, profile, current, 0);',
                      '        if (profile == 2)\n            memset_control_paths(c, current, 0);\n'
                      '        else\n            compare(c, profile, current, 0);')
state = state.replace('        compare(c, profile, current, 1);',
                      '        if (profile == 2) {\n'
                      '            memset_clean_decision(c, current);\n'
                      '            memset_control_paths(c, current, 1);\n'
                      '        } else\n            compare(c, profile, current, 1);')
state = state.replace('        printf("PASS memset complete state/inverse profile=%u tables=%u physical=%u\\n", profile, tables, c->physical);\n        fflush(stdout);\n', '')
assert state.count('    return 0;') == 1
state = state.replace('    return 0;', '    return 2;')
state = ('/* Fixed finite-domain reference: seven dense state profiles and one\n'
         ' * complete 512-label controlled basis-action profile, each before and\n'
         ' * after its saved inverse, under both engine synthesis policies. */\n' + state)

source = r'''#define _POSIX_C_SOURCE 200809L
#include "validation.h"
#include "memset_state.inc"

static unsigned checks;
static const char *levels[] = {"-O0", "-O1", "-O2", "-O3", "-Os"};

typedef struct {
    const char *name, *source, *diagnostic;
    int execute;
} memset_case;

static const memset_case native_cases[] = {
NATIVE_CASES
};

static const struct {
    const char *name, *body;
} state_cases[] = {
STATE_CASES
};

static char *compile_case(validation *v, const memset_case *test,
                          unsigned level, unsigned builtins) {
    char input[4096], output[4096], compiler[4096];
    validation_path(input, sizeof input, "%s/memset.c", v->temp);
    validation_path(output, sizeof output, "%s/memset.out", v->temp);
    validation_path(compiler, sizeof compiler, "%s/build/cket", v->root);
    validation_write(input, test->source);
    char *command[] = {compiler, input, test->execute ? "--run" : "--emit-ir",
                       (char *)levels[level], builtins ? "-fbuiltin" : "-fno-builtin",
                       "-o", output, NULL};
    int status = validation_run(v, command, NULL, 240);
    char *log = validation_read(v->log);
    if (test->diagnostic ? !validation_rejected(status, log, test->diagnostic) : status != 0)
        validation_fail("memset %s %s builtins=%u failed:\n%s\n%s",
                        test->name, levels[level], builtins, test->source, log);
    free(log);
    return !test->execute && !test->diagnostic ? validation_read(output) : NULL;
}

/* A rejected quantum fixture must first be valid ordinary C syntax. The
 * division-by-zero profile is deliberately undefined for one runtime input;
 * parsing it classically makes no defined-execution claim. */
static void classical_syntax(validation *v, const memset_case *test) {
    const char *mock = "#include <stdint.h>\n#include <stdbool.h>\n"
                       "#include <string.h>\n#define quant\n"
                       "#define measure(x) (x)\n#define phase(x) ((void)(x))\n"
                       "#define superposition(a,b) (a)\n";
    const char *body = strstr(test->source, "#include <quantum.h>\n");
    if (!body)
        validation_fail("missing quantum preamble in negative fixture %s", test->name);
    body += strlen("#include <quantum.h>\n");
    size_t size = strlen(mock) + strlen(body) + 1;
    char *program = malloc(size);
    if (!program)
        validation_fail("classical syntax allocation failed");
    validation_path(program, size, "%s%s", mock, body);
    char input[4096];
    validation_path(input, sizeof input, "%s/memset-classical.c", v->temp);
    validation_write(input, program);
    free(program);
    const char *environment = getenv("CC");
    char *command[] = {(char *)(environment ? environment : "gcc"), "-std=c11",
                       "-fsyntax-only", "-Wno-attributes", input, NULL};
    if (validation_run(v, command, NULL, 60) != 0) {
        char *log = validation_read(v->log);
        validation_fail("negative fixture %s is not valid ordinary C syntax:\n%s", test->name, log);
    }
}

static void native_and_rejections(validation *v) {
    unsigned positive = 0, negative = 0;
    for (unsigned i = 0; i < sizeof native_cases / sizeof *native_cases; ++i) {
        const memset_case *test = &native_cases[i];
        if (test->diagnostic)
            classical_syntax(v, test);
        for (unsigned level = 0; level < 5; ++level)
            for (unsigned builtin = 0; builtin < 2; ++builtin) {
                free(compile_case(v, test, level, builtin));
                if (test->diagnostic)
                    ++negative;
                else
                    ++positive;
            }
    }
    checks += positive + negative;
    printf("PASS %u native memset cases: classical return pointer, byte/word/array writes, partial bytes, coherent conditions, aliases and once-only CPU arguments; five GCC levels and both builtin modes\n", positive);
    printf("PASS %u memset rejection contracts: read-only storage, bounds, runtime counts, unmeasured CPU writes, reachable zero-length argument UB, returned quantum pointers and coherent CPU effects\n", negative);
    fflush(stdout);
}

static void states(validation *v) {
    unsigned dense = 0, labeled = 0;
    for (unsigned profile = 0; profile < sizeof state_cases / sizeof *state_cases; ++profile)
        for (unsigned level = 0; level < 5; ++level)
            for (unsigned builtin = 0; builtin < 2; ++builtin) {
                char program[8192];
                validation_path(program, sizeof program,
                                "#include <quantum.h>\n#include <string.h>\n"
                                "int main(void){%sreturn 0;}\n", state_cases[profile].body);
                memset_case test = {state_cases[profile].name, program, NULL, 0};
                char *ir = compile_case(v, &test, level, builtin);
                unsigned count = memset_state_probe(ir, profile);
                free(ir);
                if (profile == 2)
                    labeled += count;
                else
                    dense += count;
            }
    checks += dense + labeled;
    printf("PASS %u dense complete-state memset cases with phases, retained inputs, saved inverses and clean private wires\n", dense);
    printf("PASS %u controlled memset circuits: all 512 labeled input basis paths, amplitudes, phases and saved inverses; canonical nine-H preparation, both synthesis policies\n", labeled);
    fflush(stdout);
}

int main(int argc, char **argv) {
    if (argc != 1)
        validation_fail("usage: validate_memset");
    validation v;
    validation_init(&v, argv[0]);
    states(&v);
    native_and_rejections(&v);
    validation_cleanup(&v);
    printf("%u memset checks passed; dense states, labeled paths, native executions and rejections have distinct proof scopes.\n", checks);
    return 0;
}
'''
native_rows = []
for name, body, diagnostic in native:
    program = (body if body.startswith('#') else '#include <quantum.h>\n#include <string.h>\n'
               'int main(void){' + body + '}\n')
    native_rows.append('    {%s, %s, %s, %d},' % (
        json.dumps(name), json.dumps(program), json.dumps(diagnostic) if diagnostic else 'NULL',
        not diagnostic or name == 'zero-undefined'))
source = source.replace('NATIVE_CASES', '\n'.join(native_rows))
source = source.replace('STATE_CASES', '\n'.join('    {%s, %s},' %
                        (json.dumps(name), json.dumps(body)) for name, body in states))
spec = importlib.util.spec_from_file_location('memset_validator_formatter', candidate / 'scripts/format.py')
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)
for name, text in [('tests/memset_state.inc', state), ('tests/validate_memset.c', source)]:
    path = candidate / name
    assert not path.exists(), name
    formatted = formatter.format_text(path, text)
    assert formatter.format_text(path, formatted) == formatted, name
    with path.open('x') as handle:
        handle.write(formatted)
print('Created two formatted experimental test inputs; original 129 plugin inputs remain unchanged.')
