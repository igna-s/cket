"""Additional finite integration probes, separate from the frozen C suite."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memset-prototype'
destination = candidate / 'build/extra-native-v1'
destination.mkdir(exist_ok=False)
frozen = json.loads((candidate / 'build/memset-validator-sources-before.json').read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name

cases = [
    ('negative-truncation', 'int fill=-257;quant uint16_t x=0x1234;memset((char*)&x,fill,2);return measure(x)!=65535;'),
    ('high-truncation', 'int fill=0x1ab;quant uint16_t x=0x1234;memset((char*)&x,fill,2);return measure(x)!=0xabab;'),
    ('quantum-negative-byte', 'quant uint8_t x=superposition(0,255);quant uint8_t y=0;memset((void*)&y,(int)x-300,1);unsigned a=measure(x),b=measure(y);return b!=(uint8_t)((int)a-300);'),
    ('signed-quantum-byte', 'quant int8_t x=0;fourier(x);quant uint8_t y=0;memset((void*)&y,(int)x,1);int a=measure(x);unsigned b=measure(y);return b!=(uint8_t)a;'),
    ('parenthesized', 'quant uint8_t x=5;(memset)((void*)&x,17,1);return measure(x)!=17;'),
    ('builtin', 'quant uint8_t x=5;__builtin_memset((void*)&x,17,1);return measure(x)!=17;'),
    ('static-loop', 'quant uint8_t a[2]={17,34};quant bool b=superposition(0,1);for(int i=0;i<2;++i)memset((void*)&a[i],b,1);unsigned x=measure(a[0]),y=measure(a[1]),z=measure(b);return x!=z||y!=z;'),
    ('cpu-arm-true', 'volatile int flag=1;quant uint8_t x=5;if(flag)memset((void*)&x,17,1);else memset((void*)&x,23,1);return measure(x)!=17;'),
    ('cpu-arm-false', 'volatile int flag=0;quant uint8_t x=5;if(flag)memset((void*)&x,17,1);else memset((void*)&x,23,1);return measure(x)!=23;'),
    ('borrow', '#include <quantum.h>\n#include <string.h>\nstatic void fill(quant uint8_t *x,int n){memset((void*)x,n,1);}\nint main(void){quant uint8_t x=5;fill(&x,17);return measure(x)!=17;}\n'),
    ('borrow-array', '#include <quantum.h>\n#include <string.h>\nstatic void fill(quant uint16_t *x,quant const bool *b){memset((void*)x,*b,2);}\nint main(void){quant uint16_t a[1]={0x1234};quant bool b=superposition(0,1);fill(a,&b);unsigned x=measure(a[0]),v=measure(b);return x!=(v?257u:0u);}\n'),
    ('zero-function-value', '#include <quantum.h>\n#include <string.h>\nstatic unsigned calls;static int next(void){++calls;return 17;}\nint main(void){quant uint8_t x=5;memset((char*)&x+1,next(),0);return measure(x)!=5||calls!=1;}\n'),
    ('function-array-once', '#include <quantum.h>\n#include <string.h>\nstatic unsigned calls;static int next(void){++calls;return 17;}\nint main(void){quant uint8_t a[2]={1,2};memset((void*)a,next(),2);unsigned x=measure(a[0]),y=measure(a[1]);return x!=17||y!=17||calls!=1;}\n'),
]
rows = []
for name, body in cases:
    source = destination / (name + '.c')
    source.write_text(body if body.startswith('#') else '#include <quantum.h>\n#include <string.h>\nint main(void){' + body + '}\n')
    command = [str(candidate / 'build/cket'), str(source), '--run', '-O2', '-fbuiltin',
               '-o', str(destination / (name + '.out'))]
    result = subprocess.run(command, cwd=candidate, text=True, capture_output=True, timeout=240)
    rows.append({'name': name, 'command': command, 'returncode': result.returncode,
                 'stdout': result.stdout, 'stderr': result.stderr})
    (destination / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(f'{"PASS" if not result.returncode else "FAIL"} extra memset {name}', flush=True)
    if result.returncode:
        print(result.stderr, flush=True)
        raise SystemExit(1)
print(f'{len(rows)} additional finite native executions passed at O2/builtin; no exhaustive domain claim.')
