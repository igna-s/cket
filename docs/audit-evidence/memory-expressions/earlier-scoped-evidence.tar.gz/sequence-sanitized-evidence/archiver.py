"""Preserve the successful fresh sanitizer scope without rewriting normal evidence."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import re
import shutil

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memory-sequence-prototype'
build = candidate / 'build'
destination = build / 'sequence-sanitized-evidence'
normal = build / 'sequence-normal-evidence'
manifest = build / 'sequence-sanitized-v1-sources.json'
frozen = json.loads(manifest.read_text())
assert len(frozen) == 134
assert frozen == json.loads((normal / 'verified-sources.json').read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
historical = json.loads((normal / 'results.json').read_text())
for name, digest in historical['artifact_sha256'].items():
    assert hashlib.sha256((normal / name).read_bytes()).hexdigest() == digest, name
terminal = json.loads((build / 'sequence-sanitized-v1-exit.json').read_text())
assert terminal['exit_code'] == terminal['runner_returncode'] == 0 and terminal['error'] is None
text = (build / 'sequence-sanitized-v1.log').read_text()
markers = ['360 memory sequence checks passed;', '97 expression checks passed;',
           '414 memory-copy checks passed;', '800 memset checks passed;',
           '5 finite integration comparisons passed across the 29 C11 header families;']
for marker in markers:
    assert text.count(marker) == 1, marker
assert text.rstrip().endswith('Scoped memory-sequence sanitizer validation passed.')
assert not re.search(r'^FAIL\b|ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:|internal compiler error:|validation infrastructure failure|validation command timed out', text, re.M)
assert not destination.exists()
contract = candidate / 'docs/c11-memory-sequences.md'
original = contract.read_text()
assert original == (normal / 'contract.md').read_text()
before = '''families. The fresh scoped ASan/UBSan campaign is still running while this draft is prepared. This
experiment reuses source-identical tools from the freshly built normal `memset` candidate and builds
its modified plugin and new validator separately; it is not a repeated full fresh-build campaign.'''
after = '''families. The separate fresh scoped ASan/UBSan campaign also passed the 360 new checks, 97
expression checks, 414 memory-copy checks, 800 `memset` checks and five classical integrations.
It rebuilt its instrumented plugin, runtime, driver, backend, engine and selected validators. The
normal campaign reused source-identical tools from the freshly built normal `memset` candidate and
built its modified plugin and new validator separately. Both campaigns used the same 134 frozen
source inputs; neither is a repeated full historical `verify.sh` campaign. The
[normal record](../build/sequence-normal-evidence/results.json) and
[sanitizer record](../build/sequence-sanitized-evidence/results.json) retain their distinct scopes.'''
assert original.count(before) == 1
spec = importlib.util.spec_from_file_location('sequence_san_formatter', candidate / 'scripts/format.py')
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)
updated = formatter.format_text(contract, original.replace(before, after))
assert formatter.format_text(contract, updated) == updated
destination.mkdir()
contract.write_text(updated)
for source, name in [
    (normal / 'sources.tar.gz', 'sources.tar.gz'),
    (manifest, 'verified-sources.json'),
    (build / 'sequence-sanitized-v1-job.json', 'job.json'),
    (build / 'sequence-sanitized-v1-exit.json', 'exit.json'),
    (build / 'sequence-sanitized-v1.log', 'verify.log'),
    (contract, 'contract.md'),
    (root / 'build/launch-memory-sequence-sanitized.py', 'runner.py'),
    (root / 'build/run-memory-sequence-sanitized.sh', 'builder.sh'),
    (Path(__file__).resolve(), 'archiver.py'),
]:
    shutil.copyfile(source, destination / name)
report = {
    'status': 'passed-scoped-ASan-UBSan', 'archived_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_inputs': len(frozen), 'source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'counts': {'memory_sequence_checks': 360, 'expression_checks': 97, 'memory_copy_checks': 414,
               'memory_set_checks': 800, 'classical_integrations': 5},
    'scope': terminal['scope'],
    'normal_evidence': '../sequence-normal-evidence/results.json',
    'normal_evidence_sha256': hashlib.sha256((normal / 'results.json').read_bytes()).hexdigest(),
    'remaining': 'Isolated experiment, not main integration. Complete historical verification, pipeline wiring, general pointers/layouts/counts and complete C11 remain pending. Cybersecurity stays classical.',
    'artifact_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                        for path in destination.iterdir() if path.is_file()},
}
(destination / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print('Archived fresh scoped sanitizer success on the same 134 inputs; historical normal capsule preserved.')
