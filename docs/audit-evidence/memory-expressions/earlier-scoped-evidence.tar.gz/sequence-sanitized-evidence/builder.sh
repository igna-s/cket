#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/memory-sequence-prototype"
real_cc=gcc-11
real_cxx=g++-11
san_root="${CKET_SEQUENCE_SAN_ROOT:?missing isolated sanitizer directory}"
plugin_dir="$($real_cc -print-file-name=plugin)"
headers="$plugin_dir/include"
if [[ ! -f "$headers/gcc-plugin.h" ]]; then
    headers=".deps/gcc$plugin_dir/include"
fi
test -f "$headers/gcc-plugin.h"
extra=()
if [[ -d .deps/gcc/usr/include ]]; then
    extra+=(-I.deps/gcc/usr/include -I.deps/gcc/usr/include/x86_64-linux-gnu)
fi
flags=(-std=c11 -O1 -g -Wall -Wextra -Werror -Isrc/engine -Itests
    -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie -no-pie)
"$real_cxx" -std=c++17 -O1 -g -Wall -Wextra -Wno-unused-parameter -Wno-format-diag \
    -fPIC -shared -fno-rtti -fsanitize=address,undefined -fno-omit-frame-pointer \
    -I"$headers" "${extra[@]}" src/cket_plugin.cpp -o "$san_root/build/cket_plugin.so"
for component in json quantum verify simulator; do
    "$real_cc" "${flags[@]}" -c "src/engine/$component.c" -o "$san_root/build/$component.o"
done
ar rcs "$san_root/build/libcket_quantum.a" "$san_root/build/json.o" \
    "$san_root/build/quantum.o" "$san_root/build/verify.o" "$san_root/build/simulator.o"
"$real_cc" "${flags[@]}" -c src/cket_runtime.c -o "$san_root/build/cket_runtime.o"
"$real_cc" "${flags[@]}" src/cket.c "$san_root/build/libcket_quantum.a" -lm -o "$san_root/build/cket"
"$real_cc" "${flags[@]}" src/cket_backend.c "$san_root/build/libcket_quantum.a" -lm -o "$san_root/build/cket_backend"
for name in memory_sequences expressions memcopy memset; do
    "$real_cc" "${flags[@]}" "tests/validate_$name.c" tests/validation.c \
        "$san_root/build/libcket_quantum.a" -lm -o "$san_root/build/validate_$name"
done
"$real_cc" -dumpfullversion >"$san_root/build/gcc-version.txt"
cp cket "$san_root/cket"
cat >"$san_root/build/gcc-wrapper" <<'WRAPPER'
#!/usr/bin/env bash
set -euo pipefail
compiler="${CKET_REAL_GCC:-gcc-11}"
# Only GCC's process-wide allocations are excluded; the generated C program,
# runtime, engine and validators retain their ordinary sanitizer checks.
export LD_PRELOAD="$($compiler -print-file-name=libasan.so)"
export ASAN_OPTIONS="${ASAN_OPTIONS:-}:detect_leaks=0"
exec "$compiler" -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie -no-pie "$@"
WRAPPER
chmod +x "$san_root/build/gcc-wrapper"
export CKET_REAL_GCC="$real_cc" CC="$san_root/build/gcc-wrapper"
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
for name in memory_sequences expressions memcopy memset; do
    "$san_root/build/validate_$name"
done
CKET_DRIVER="$san_root/build/cket" bash scripts/test-c11-classical.sh
printf '%s\n' 'Scoped memory-sequence sanitizer validation passed.'
