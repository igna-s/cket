"""Launch a fresh scoped ASan/UBSan build without editing frozen inputs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import traceback

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memory-sequence-prototype'
output = candidate / 'build'
label = 'sequence-sanitized-v1'
manifest = output / (label + '-sources.json')
terminal = output / (label + '-exit.json')
metadata = output / (label + '-job.json')
log = output / (label + '.log')
san_root = output / label
runner = root / 'build/run-memory-sequence-sanitized.sh'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def check_sources():
    frozen = json.loads(manifest.read_text())
    assert len(frozen) == 134
    for name, digest in frozen.items():
        assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name

if '--worker' in sys.argv:
    status, actual, detail = 1, None, None
    try:
        check_sources()
        result = subprocess.run(['bash', str(runner)], cwd=candidate)
        actual = result.returncode
        status = actual
        check_sources()
    except BaseException as error:
        detail = repr(error)
        traceback.print_exc()
        status = 1
    with terminal.open('x') as handle:
        json.dump({'finished_utc': utc(), 'exit_code': status, 'runner_returncode': actual,
                   'error': detail, 'scope': 'Fresh scoped ASan/UBSan plugin, runtime, driver, backend, engine and validators: 360 memory-sequence checks plus expression/memory regressions and five classical C11 integrations. Not the entire historical verify.sh pipeline.'}, handle, indent=2)
        handle.write('\n')
    raise SystemExit(status)

assert not any(path.exists() for path in (manifest, terminal, metadata, log, san_root))
normal = json.loads((output / 'sequence-validation-v1-sources.json').read_text())
assert len(normal) == 134
for name, digest in normal.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
assert json.loads((output / 'sequence-exports-v1/summary.json').read_text())['status'] == 'passed'
assert json.loads((output / 'sequence-quest-v1/summary.json').read_text())['status'] == 'passed'
subprocess.run([sys.executable, 'scripts/archive-audit.py', '--freeze', str(manifest)],
               cwd=candidate, check=True)
check_sources()
assert json.loads(manifest.read_text()) == normal
san_root.mkdir()
(san_root / 'build').mkdir()
for name in ('src', 'tests', 'include', 'examples'):
    os.symlink(candidate / name, san_root / name)
environment = os.environ.copy()
environment['CKET_SEQUENCE_SAN_ROOT'] = str(san_root)
with log.open('x') as handle:
    process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker'],
                               cwd=candidate, env=environment, stdin=subprocess.DEVNULL,
                               stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
fields = (Path('/proc') / str(process.pid) / 'stat').read_text().rsplit(')', 1)[1].split()
with metadata.open('x') as handle:
    json.dump({'pid': process.pid, 'linux_start_ticks': int(fields[19]),
               'runner': str(Path(__file__).resolve()), 'started_utc': utc(),
               'build_runner': str(runner),
               'runner_sha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
               'source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest()}, handle, indent=2)
    handle.write('\n')
print(json.dumps({'state': 'started', 'pid': process.pid, 'log': str(log)}))
