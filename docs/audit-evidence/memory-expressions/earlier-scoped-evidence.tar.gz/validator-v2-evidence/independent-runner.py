"""Independently execute five new memset exports with pinned local QuEST."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memset-prototype'
base = root / 'build/byte-snapshot-prototype'
destination = candidate / 'build/quest-memset-v1'
destination.mkdir(exist_ok=False)
frozen = json.loads((candidate / 'build/memset-extended-sources-before.json').read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
assert len(frozen) == 132
quest = base / 'build/validation-deps/QuEST-d4f75f724993b4af8e43a796e3c09ce24ae11670/QuEST'
quest_library = base / 'build/validation-deps/libQuEST.a'
quest_archive = base / 'build/validation-deps/quest-3.7.0.tar.gz'
assert hashlib.sha256(quest_archive.read_bytes()).hexdigest() == '1a5939798a70b749dfa57cfaa116ece03a2d36aa59c1b712cb3dc2103ab1cded'

phase = ''.join(f'if(x&{1 << bit})phase({.001 * (1 << bit):.17g});' for bit in range(8))
cases = [
    ('memset full-byte retained history', 'quant uint8_t x=superposition(0,255);' + phase +
     'memset(&x,17,1);if(x==17)phase(.17);measure(x);'),
    ('memset full-byte self alias', 'quant uint8_t x=superposition(0,255);' + phase +
     'memset(&x,x,1);if(x==7)phase(.17);measure(x);'),
    ('memset partial word with quantum byte', 'quant uint16_t x=0x1234;quant bool b=superposition(0,1);'
     'if(b)phase(.31);memset((char*)&x+1,b,1);if(x==0x134)phase(.17);measure(x);measure(b);'),
    ('memset lazy sequenced argument', 'quant bool b=superposition(0,1),c=superposition(0,1);quant uint8_t x=5;'
     'if(b)phase(.31);if(c)phase(.19);memset(&x,c?b++:b--,1);if(x==1)phase(.17);measure(x);measure(b);measure(c);'),
    ('memset array captures aliased source once', 'quant uint8_t a[2]={superposition(0,255),34};' +
     phase.replace('x&', 'a[0]&') + 'memset(a,a[0],2);measure(a[0]);measure(a[1]);'),
]
rows = ['    {%s, %s},' % (json.dumps(name), json.dumps('#include <quantum.h>\n#include <string.h>\nint main(void){' + body + 'return 0;}\n'))
        for name, body in cases]
source = destination / 'checker.c'
source.write_text('#define main base_qasm_validator_main\n#include "' + str(candidate / 'tests/validate_qasm.c') + '"\n#undef main\n'
    'int main(int argc,char **argv){if(argc!=1)return 2;validation v;validation_init(&v,argv[0]);'
    'QuESTEnv env=createQuESTEnv();unsigned long seeds[]={913};seedQuEST(&env,seeds,1);'
    'const test_case added[]={\n' + '\n'.join(rows) + '\n};'
    'for(unsigned i=0;i<sizeof added/sizeof *added;++i)check_state(&v,env,&added[i]);'
    'destroyQuESTEnv(env);validation_cleanup(&v);'
    'puts("5 memset exported states independently validated with QuEST 3.7.0 (C); table-free export");return 0;}\n')
checker = candidate / 'build/validate_memset_qasm'
assert not checker.exists()
command = ['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-DQuEST_PREC=2',
           '-I' + str(candidate / 'src/engine'), '-I' + str(candidate / 'tests'),
           '-I' + str(quest / 'include'), str(source), str(candidate / 'tests/qasm_reference.c'),
           str(candidate / 'tests/validation.c'), str(candidate / 'build/libcket_quantum.a'),
           str(quest_library), '-lm', '-o', str(checker)]
subprocess.run(command, cwd=candidate, check=True)
with (destination / 'verify.log').open('x') as handle:
    result = subprocess.run([str(checker)], cwd=candidate, text=True, stdout=handle,
                            stderr=subprocess.STDOUT, timeout=900)
identity = {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in frozen}
assert identity == frozen
report = {'returncode': result.returncode, 'status': 'passed' if result.returncode == 0 else 'failed',
          'cases': len(cases), 'compile_command': command,
          'source_inputs': len(frozen), 'source_sha256': frozen,
          'scope': 'Five added exported states only, using reused source-identical engine/runtime/driver and pinned QuEST C library; not a fresh full regression campaign or physical QPU execution.',
          'artifacts': {name: hashlib.sha256(path.read_bytes()).hexdigest()
                        for name, path in [(str(source.relative_to(candidate)), source),
                                           (str(checker.relative_to(candidate)), checker),
                                           (str((destination / 'verify.log').relative_to(candidate)), destination / 'verify.log'),
                                           ('reused-base/libQuEST.a', quest_library)]}}
(destination / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print((destination / 'verify.log').read_text(), end='')
raise SystemExit(result.returncode)
