"""Expand the finite maintained suite using the reviewed exploratory fixtures."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memset-prototype'
path = candidate / 'tests/validate_memset.c'
original = json.loads((candidate / 'build/validator-v1-evidence/verified-sources.json').read_text())
assert hashlib.sha256(path.read_bytes()).hexdigest() == original['tests/validate_memset.c']
source = path.read_text()

def fixtures(path, name):
    node, = [node for node in ast.parse(path.read_text()).body
             if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
             and node.targets[0].id == name]
    return ast.literal_eval(node.value)

rows = []
extra = fixtures(root / 'build/probe-memset-extra.py', 'cases')
effects = fixtures(root / 'build/probe-memset-value-effects.py', 'cases')
assert len(extra) == 13 and len(effects) == 9
for row in extra + effects:
    name, body, diagnostic = row if len(row) == 3 else (*row, None)
    program = (body if body.startswith('#') else '#include <quantum.h>\n#include <string.h>\n'
               'int main(void){' + body + '}\n')
    rows.append('    {%s, %s, %s, %d},' % (json.dumps('extra-' + name), json.dumps(program),
                json.dumps(diagnostic) if diagnostic else 'NULL', not diagnostic))
before = '\n};\n\nstatic const struct {'
assert source.count(before) == 1
source = source.replace(before, '\n' + '\n'.join(rows) + before)
source = source.replace('#include "memset_state.inc"', '#include "memset_state.inc"\n#include "memset_effects.inc"')
source = source.replace('/* A rejected quantum fixture must first be valid ordinary C syntax. The\n'
                        ' * division-by-zero profile is deliberately undefined for one runtime input;\n'
                        ' * parsing it classically makes no defined-execution claim. */',
                        '/* Rejected fixtures must first have valid ordinary C syntax. Reachable\n'
                        ' * division by zero and unsequenced access deliberately have C undefined\n'
                        ' * behavior; parsing them classically makes no defined-execution claim. */')

operations = fixtures(root / 'build/probe-memset-effects-states.py', 'operations')
programs = []
for profile, operation in enumerate(operations):
    body = ('quant bool b=superposition(0,1);' +
            ('quant bool c=superposition(0,1);' if profile >= 6 else '') +
            ('quant uint8_t x[2]={17,34};' if profile == 5 else 'quant uint8_t x=5;') +
            'if(b)phase(.31);' + ('if(c)phase(.19);' if profile >= 6 else '') +
            operation + ('if(x[0]==1)phase(.17);measure(x[0]);measure(x[1]);' if profile == 5
                         else 'if(x==1)phase(.17);measure(x);') +
            'measure(b);' + ('measure(c);' if profile >= 6 else ''))
    programs.append(json.dumps('#include <quantum.h>\n#include <string.h>\nint main(void){' + body + 'return 0;}\n'))
functions = r'''
static void value_effects(validation *v) {
    static const char *programs[] = {
EFFECT_PROGRAMS
    };
    unsigned count = 0;
    for (unsigned profile = 0; profile < sizeof programs / sizeof *programs; ++profile)
        for (unsigned level = 0; level < 5; ++level)
            for (unsigned builtin = 0; builtin < 2; ++builtin) {
                memset_case test = {"sequenced-value-state", programs[profile], NULL, 0};
                char *ir = compile_case(v, &test, level, builtin);
                count += memset_effect_probe(ir, profile);
                free(ir);
            }
    checks += count;
    printf("PASS %u complete memset value-effect states: postfix/prefix, decrement, comma, zero length, arrays, coherent/lazy effects, relative phases and saved inverses; live history before inversion, private zeros after\n", count);
    fflush(stdout);
}

static void wide(validation *v) {
    unsigned count = 0;
    for (unsigned width = 16; width <= 64; width *= 2)
        for (unsigned signed_input = 0; signed_input < 2; ++signed_input)
            for (unsigned level = 0; level < 5; ++level)
                for (unsigned builtin = 0; builtin < 2; ++builtin) {
                    char program[4096];
                    validation_path(program, sizeof program,
                        "#include <quantum.h>\n#include <string.h>\nint main(void){"
                        "quant %s%u_t x=%s;quant bool b=superposition(0,1);"
                        "memset((void*)&x,b,sizeof x);measure(x);measure(b);return 0;}\n",
                        signed_input ? "int" : "uint", width, signed_input ? "-7" : "0x1234");
                    memset_case test = {"wide-layout", program, NULL, 0};
                    char *ir = compile_case(v, &test, level, builtin);
                    qc_context *c = qc_create(0, 7);
                    if (!c)
                        validation_fail("wide memset context allocation failed");
                    qc_allow_tables(c, 0);
                    if (!qc_document(c, ir, 0, 0) || c->reset || qc_qubits(c) > 128)
                        validation_fail("wide memset circuit generation failed: %s", qc_error(c));
                    free(ir);
                    qc_destroy(c);
                    ++count;
                }
    checks += count;
    printf("PASS %u wide memset no-table circuits: signed/unsigned 16/32/64-bit layouts, five GCC levels and both builtin modes; generation evidence\n", count);
    fflush(stdout);
}

'''.replace('EFFECT_PROGRAMS', ',\n'.join('        ' + program for program in programs))
assert source.count('int main(int argc, char **argv) {') == 1
source = source.replace('int main(int argc, char **argv) {', functions + 'int main(int argc, char **argv) {')
source = source.replace('    states(&v);\n    native_and_rejections(&v);',
                        '    states(&v);\n    value_effects(&v);\n    native_and_rejections(&v);\n    wide(&v);')
source = source.replace('dense states, labeled paths, native executions and rejections have distinct proof scopes.',
                        'dense states, labeled paths, native executions, rejections and wide generation have distinct proof scopes.')
spec = importlib.util.spec_from_file_location('memset_suite_formatter', candidate / 'scripts/format.py')
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)
for name, text in [('tests/validate_memset.c', source),
                   ('tests/memset_effects.inc', (candidate / 'tests/memset_effects.inc').read_text())]:
    output = candidate / name
    formatted = formatter.format_text(output, text)
    assert formatter.format_text(output, formatted) == formatted
    output.write_text(formatted)
print('Expanded maintained suite: 340 native executions, 80 rejections, 140 original dense states, 20 controlled labeled circuits, 160 sequenced-effect states and 60 wide generation cases.')
