"""Build and record one exploratory run of the isolated C memset validator."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import traceback

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memset-prototype'
output = candidate / 'build'
extended = '--extended' in sys.argv
label = 'memset-extended' if extended else 'memset-validator'
input_count = 132 if extended else 131
frozen = output / (label + '-sources-before.json')
terminal = output / (label + '-exit.json')
job = output / (label + '-job.json')
log = output / (label + '.log')

def identity(path):
    entries = json.loads(path.read_text())
    for name, digest in entries.items():
        assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
    return entries

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

if '--worker' in sys.argv:
    status = 1
    detail = None
    try:
        entries = identity(frozen)
        assert len(entries) == input_count
        result = subprocess.run([str(output / 'validate_memset')], cwd=candidate)
        status = result.returncode
        identity(frozen)
    except BaseException as error:
        detail = repr(error)
        traceback.print_exc()
        status = 1
    with terminal.open('x') as handle:
        json.dump({'finished_utc': utc(), 'returncode': status, 'error': detail,
                   'scope': 'New maintained validator against the exploratory memset plugin, with source-identical reused base driver/engine/runtime; not a complete fresh-build verification.'}, handle, indent=2)
        handle.write('\n')
    raise SystemExit(status)

assert not any(path.exists() for path in (frozen, terminal, job, log))
if extended:
    previous = json.loads((output / 'value-effects-sources-before.json').read_text())
    for name, digest in previous.items():
        if name != 'tests/validate_memset.c':
            assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
else:
    identity(output / 'probe-sources-before.json')
tooling = json.loads((output / 'probe-tooling.json').read_text())
for name, digest in tooling['artifact_sha256'].items():
    assert hashlib.sha256((output / name).read_bytes()).hexdigest() == digest, name
subprocess.run(['python3', 'scripts/archive-audit.py', '--freeze', str(frozen)],
               cwd=candidate, check=True)
assert len(identity(frozen)) == input_count
command = ['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
           '-Isrc/engine', '-Itests', 'tests/validate_memset.c', 'tests/validation.c',
           'build/libcket_quantum.a', '-lm', '-o', 'build/validate_memset']
subprocess.run(command, cwd=candidate, check=True)
environment = os.environ.copy()
environment['CC'] = 'gcc-11'
with log.open('x') as handle:
    process = subprocess.Popen(['python3', str(Path(__file__).resolve()), '--worker'] +
                               (['--extended'] if extended else []),
                               cwd=candidate, env=environment,
                               stdin=subprocess.DEVNULL, stdout=handle,
                               stderr=subprocess.STDOUT, start_new_session=True)
fields = (Path('/proc') / str(process.pid) / 'stat').read_text().rsplit(')', 1)[1].split()
with job.open('x') as handle:
    json.dump({'pid': process.pid, 'linux_start_ticks': int(fields[19]),
               'runner': str(Path(__file__).resolve()), 'started_utc': utc(),
               'source_manifest_sha256': hashlib.sha256(frozen.read_bytes()).hexdigest(),
               'compile_command': command,
               'validator_sha256': hashlib.sha256((output / 'validate_memset').read_bytes()).hexdigest(),
               'plugin_sha256': hashlib.sha256((output / 'cket_plugin.so').read_bytes()).hexdigest(),
               'target_checks': ({'dense_state_and_inverse': 140,
                                 'controlled_512_label_paths_and_inverse': 20,
                                 'sequenced_effect_states_and_inverse': 160,
                                 'native_execution': 340, 'rejection': 80,
                                 'wide_generation': 60} if extended else
                                 {'dense_state_and_inverse': 140,
                                  'controlled_512_label_paths_and_inverse': 20,
                                  'native_execution': 130, 'rejection': 70}),
               'proof_scope': 'Exploratory reused tooling, separately built plugin and newly built validator. Current inputs are frozen; compiler implementation is unchanged since the recorded plugin build.'}, handle, indent=2)
    handle.write('\n')
print(json.dumps({'state': 'started', 'pid': process.pid, 'log': str(log)}))
