#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/memset-prototype"
python3 scripts/archive-audit.py --freeze build/value-effects-sources-before.json
plugin_dir="$(gcc-11 -print-file-name=plugin)"
headers="$plugin_dir/include"
if [[ ! -f "$headers/gcc-plugin.h" ]]; then
    headers=".deps/gcc$plugin_dir/include"
fi
test -f "$headers/gcc-plugin.h"
extra=()
if [[ -d .deps/gcc/usr/include ]]; then
    extra+=(-I.deps/gcc/usr/include -I.deps/gcc/usr/include/x86_64-linux-gnu)
fi
nice -n 15 g++-11 -std=c++17 -O2 -Wall -Wextra -Wno-unused-parameter -Wno-format-diag \
    -fPIC -shared -fno-rtti -I"$headers" "${extra[@]}" \
    src/cket_plugin.cpp -o build/cket_plugin.so
printf '%s\n' 'Built experimental memset value effects; driver/engine/runtime sources are unchanged.'
