/* Export the actual aliasing value-effect prefix and saved definition inverses.
 * This tool generates circuits; independent sparse references execute them. */
#include "internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void fail(const char *message) {
    fprintf(stderr, "memset alias-effect export: %s\n", message);
    exit(1);
}

static void snapshot(FILE *out, qc_context *c) {
    fprintf(out, "{\"qubits\":%u,\"registers\":[", c->physical);
    unsigned count = 0;
    for (size_t i = 0; i < c->nregisters; ++i) {
        qc_register *r = &c->registers[i];
        if (!r->alive)
            continue;
        fprintf(out, "%s{\"id\":%u,\"history\":%s,\"wires\":[", count++ ? "," : "", r->id, r->history ? "true" : "false");
        for (unsigned bit = 0; bit < r->width; ++bit)
            fprintf(out, "%s%u", bit ? "," : "", r->wires[bit]);
        fprintf(out, "]}");
    }
    fprintf(out, "],\"measure\":%llu,\"reset\":%llu}", (unsigned long long)c->measure, (unsigned long long)c->reset);
}

static void export(qc_context *c, const char *path) {
    FILE *out = fopen(path, "wx");
    if (!out || !qc_qasm(c, out) || fclose(out))
        fail("QASM creation failed");
}

int main(int argc, char **argv) {
    if (argc != 5)
        fail("usage: alias-effects IR PREFIX-QASM INVERSE-QASM MAP-JSON");
    char *text = qc_read_file(argv[1]);
    cj_doc d = {0};
    qc_context *c = qc_create(0, 7);
    if (!text || !c || !cj_parse(&d, text) || !qc_verify_document(c, &d))
        fail(c ? qc_error(c) : "allocation");
    qc_allow_tables(c, 0);
    int list = cj_get(&d, 0, "instructions");
    unsigned current = UINT32_MAX, nwrite = 0, nadd = 0;
    char *writes[32];
    unsigned additions[8];
    for (int token = list + 1; token < d.tokens[list].next; token = d.tokens[token].next) {
        int op = cj_get(&d, token, "op");
        uint64_t value;
        if (cj_equal(&d, op, "qmeasure")) {
            if (!cj_u64(&d, cj_get(&d, token, "id"), &value) || value > UINT32_MAX)
                fail("invalid current destination ID");
            current = (unsigned)value;
            break;
        }
        if (cj_equal(&d, op, "qxor_inplace")) {
            if (nwrite == sizeof writes / sizeof *writes)
                fail("write recording budget exceeded");
            writes[nwrite++] = cj_copy(&d, token);
        }
        if (cj_equal(&d, op, "qadd_inplace")) {
            uint64_t id, amount;
            int controls = cj_get(&d, token, "controls");
            if (nadd == sizeof additions / sizeof *additions ||
                !cj_u64(&d, cj_get(&d, token, "id"), &id) || id != 0 ||
                !cj_u64(&d, cj_get(&d, token, "value"), &amount) || amount != 1 ||
                (controls >= 0 && d.tokens[controls].children))
                fail("unexpected argument addition outside the declared alias fixtures");
            additions[nadd++] = (unsigned)id;
        }
        if (!qc_apply_token(c, &d, token, 0, 0, &value))
            fail(qc_error(c));
    }
    qc_register *old = qc_lookup(c, 0), *result = qc_lookup(c, current);
    if (!old || !old->alive || !old->history || old->width != 8 ||
        !result || !result->definition || current == 0 || c->measure || c->reset)
        fail("missing original history/current definition or implicit channel");
    FILE *out = fopen(argv[4], "wx");
    if (!out)
        fail("mapping creation failed");
    fprintf(out, "{\"current_id\":%u,\"argument_adds\":%u,\"before\":", current, nadd);
    snapshot(out, c);
    export(c, argv[2]);
    while (nwrite) {
        char *operation = writes[--nwrite];
        if (!qc_apply(c, operation, NULL))
            fail(qc_error(c));
        free(operation);
    }
    for (size_t i = c->nregisters; i; --i) {
        qc_register *r = &c->registers[i - 1];
        if (!r->alive || !r->definition)
            continue;
        size_t capacity = strlen(r->definition) + 128;
        char *operation = malloc(capacity);
        unsigned id = r->id;
        if (!operation)
            fail("inverse allocation failed");
        snprintf(operation, capacity, "{\"op\":\"quncompute\",\"id\":%u,\"expr\":%s}", id, r->definition);
        if (!qc_apply(c, operation, NULL))
            fail(qc_error(c));
        snprintf(operation, capacity, "{\"op\":\"qrelease\",\"id\":%u}", id);
        if (!qc_apply(c, operation, NULL))
            fail(qc_error(c));
        free(operation);
    }
    // Prefix unsigned increment can update the input reversibly in place.
    // Its consumers must be inverted before restoring that original input.
    while (nadd) {
        char operation[128];
        snprintf(operation, sizeof operation,
                 "{\"op\":\"qadd_inplace\",\"id\":%u,\"value\":-1}", additions[--nadd]);
        if (!qc_apply(c, operation, NULL))
            fail(qc_error(c));
    }
    fprintf(out, ",\"after\":");
    snapshot(out, c);
    fprintf(out, "}\n");
    if (fclose(out) || c->measure || c->reset)
        fail("mapping flush failed or channel appeared");
    export(c, argv[3]);
    printf("Exported aliasing value effect and saved inverses: %u physical wires\n", c->physical);
    qc_destroy(c);
    cj_free(&d);
    free(text);
    return 0;
}
