"""Full-byte sparse state and labeled-path checks for self-modifying fills."""
from pathlib import Path
import ast
import cmath
import hashlib
import json
import math
import re
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memset-prototype'
label = sys.argv[1] if len(sys.argv) > 1 else 'alias-effects-v1'
start = int(sys.argv[2]) if len(sys.argv) > 2 else 0
assert label and all(character.isalnum() or character == '-' for character in label)
destination = candidate / 'build' / label
destination.mkdir(exist_ok=False)
frozen = json.loads((candidate / 'build/memset-full-sources-before.json').read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
assert 'Built |c> native C driver' in (candidate / 'build/memset-full-verify.log').read_text()
exporter = destination / 'export-prefix'
subprocess.run(['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                '-I' + str(candidate / 'src/engine'), str(root / 'build/export-memset-alias-effects.c'),
                str(candidate / 'build/libcket_quantum.a'), '-lm', '-o', str(exporter)], check=True)

def pure_function(path, name):
    source = path.read_text()
    node, = [node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == name]
    return ast.get_source_segment(source, node)

simulator = pure_function(root / 'build/check-byte-comparison-raw.py', 'simulate')
before = 'assert set(measurements) == set(range(bits))'
assert simulator.count(before) == 1
simulator = simulator.replace(before, 'assert not measurements if bits is None else set(measurements) == set(range(bits))')
paths = pure_function(root / 'build/check-memset-sparse.py', 'labeled_paths')
paths = paths.replace('512', '256').replace('prepared < 9', 'prepared < 8').replace('prepared == 9', 'prepared == 8')
namespace = {'re': re, 'math': math, 'cmath': cmath}
exec(compile(simulator, '<independent sparse H/X/phase reference>', 'exec'), namespace)
exec(compile(paths, '<independent 256-label suffix reference>', 'exec'), namespace)
phase = ''.join(f'if(x&{1 << bit})phase({.001 * (1 << bit):.17g});' for bit in range(8))
cases = [
    ('postfix-self', 'quant uint8_t x=superposition(0,255);' + phase +
     'memset(&x,x++,1);if(x==7)phase(.17);measure(x);'),
    ('prefix-self', 'quant uint8_t x=superposition(0,255);' + phase +
     'memset(&x,++x,1);if(x==7)phase(.17);measure(x);'),
    ('comma-self', 'quant uint8_t x=superposition(0,255);' + phase +
     'memset(&x,(x=7,x),1);if(x==7)phase(.17);measure(x);'),
    ('postfix-array', 'quant uint8_t a[2]={superposition(0,255),34};' + phase.replace('x&', 'a[0]&') +
     'memset(a,a[0]++,2);if(a[0]==7)phase(.17);measure(a[0]);measure(a[1]);'),
]
rows = []
for profile, (name, body) in enumerate(cases):
    if profile < start:
        continue
    source = destination / (name + '.c')
    source.write_text('#include <quantum.h>\n#include <string.h>\nint main(void){' + body + 'return 0;}\n')
    ir = destination / (name + '.json')
    compute, inverse = destination / (name + '.qasm'), destination / (name + '-inverse.qasm')
    mapping_path = destination / (name + '-mapping.json')
    for command in [
        [str(candidate / 'build/cket'), str(source), '--emit-ir', '-O2', '-fbuiltin', '-o', str(ir)],
        [str(exporter), str(ir), str(compute), str(inverse), str(mapping_path)],
    ]:
        result = subprocess.run(command, cwd=candidate, text=True, capture_output=True, timeout=240)
        if result.returncode:
            (destination / 'failure.json').write_text(json.dumps({'profile': name, 'command': command,
                'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
            raise SystemExit(result.stderr)
    mapping = json.loads(mapping_path.read_text())
    current = mapping['current_id']
    in_place = mapping['argument_adds']
    assert in_place in (0, 1) and (not in_place or profile == 1)
    for cleaned, path, stage in [(False, compute, 'before'), (True, inverse, 'after')]:
        state_info = mapping[stage]
        assert state_info['measure'] == state_info['reset'] == 0
        registers = {entry['id']: entry for entry in state_info['registers']}
        assert registers[0]['wires'] == list(range(8))
        namespace['wires'] = {'qubits': state_info['qubits']}
        text = path.read_text()
        actual, observations, qubits, gates, hadamards = namespace['simulate'](text)
        labeled, amplitudes, _ = namespace['labeled_paths'](text)
        assert not observations and qubits == state_info['qubits'] and hadamards == 8
        assert len(actual) == 256 and len(labeled) == 256
        extras = set(registers) - {0, current} - ({1} if profile == 3 else set())
        assert len(extras) == (1 if profile in (1, 2) and not cleaned and not in_place else 0), (name, stage, extras)
        if cleaned:
            assert set(registers) == ({0, 1} if profile == 3 else {0})
        else:
            assert registers[0]['history']
        maximum = 0
        expected = {}
        for x in range(256):
            value = ((x + 1) & 255) if profile == 1 else 7 if profile == 2 else x
            values = {0: value if profile == 1 and in_place and not cleaned else x}
            if not cleaned:
                values[current] = value
                values.update({identifier: value for identifier in extras})
            if profile == 3:
                values[1] = 34 if cleaned else x
            basis = 0
            for identifier, value_bits in values.items():
                slots = registers[identifier]['wires']
                assert len(slots) == 8
                basis |= sum(((value_bits >> bit) & 1) << wire for bit, wire in enumerate(slots))
            angle = .001 * x + (.17 if value == 7 else 0)
            amplitude = cmath.exp(1j * angle) / 16
            assert basis not in expected
            expected[basis] = amplitude
            assert labeled[x] == basis, (name, stage, x, 'labeled input/result/private mapping')
            maximum = max(maximum, abs(actual.get(basis, 0) - amplitude), abs(amplitudes[x] - amplitude))
        assert set(actual) == set(expected) and maximum < 1e-10
        norm = sum(abs(amplitude) ** 2 for amplitude in actual.values())
        assert abs(norm - 1) < 1e-10
        rows.append({'profile': name, 'stage': stage, 'physical_wires': qubits,
                     'amplitudes': 256, 'labeled_paths': 256, 'gates': gates,
                     'maximum_amplitude_error': maximum, 'norm': norm,
                     'qasm_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        (destination / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(f'PASS {name} {stage}: {qubits} wires, all 256 labeled paths and amplitudes, error={maximum:.3g}', flush=True)
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
(destination / 'summary.json').write_text(json.dumps({'status': 'passed',
    'scope': 'Full byte domain for four self-modifying value arguments at O2/builtin/no-tables, before and after saved definition inverses. Independent sparse QASM amplitudes plus complete labeled paths after verified eight-H preparation; not an unrestricted dense/channel or hardware claim.',
    'source_inputs': len(frozen), 'checks': rows}, indent=2) + '\n')
