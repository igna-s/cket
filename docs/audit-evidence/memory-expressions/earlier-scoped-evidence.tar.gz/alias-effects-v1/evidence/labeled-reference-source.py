"""Verify the full controlled byte domain beyond the dense simulator budget."""
from pathlib import Path
import ast
import cmath
import hashlib
import json
import math
import re
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memset-prototype'
label = sys.argv[1] if len(sys.argv) > 1 else 'sparse-controlled-v1'
assert label and all(character.isalnum() or character == '-' for character in label)
destination = candidate / 'build' / label
destination.mkdir(exist_ok=False)
exporter = destination / 'export-prefix'
subprocess.run(['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                '-I' + str(candidate / 'src/engine'), str(root / 'build/export-memset-prefix.c'),
                str(candidate / 'build/libcket_quantum.a'), '-lm', '-o', str(exporter)], check=True)
ir = candidate / 'build/state-probes-v1/controlled-history.json'
compute = destination / 'compute.qasm'
inverse = destination / 'inverse.qasm'
mapping = destination / 'mapping.json'
subprocess.run([str(exporter), str(ir), str(compute), str(inverse), str(mapping)], check=True)
wires = json.loads(mapping.read_text())
assert wires['old'] == list(range(8)) and wires['flag'] == [8]
assert len(wires['current']) == 8
assert len(wires['decision']) == 1
assert len(set(wires['old'] + wires['flag'] + wires['current'] + wires['decision'])) == 18
assert wires['measure'] == wires['reset'] == 0

# Load only the previously reviewed pure simulator function, without executing
# that older campaign's top-level directory creation or compiler commands.
reference = root / 'build/check-byte-comparison-raw.py'
source = reference.read_text()
function, = [node for node in ast.parse(source).body
             if isinstance(node, ast.FunctionDef) and node.name == 'simulate']
function_source = ast.get_source_segment(source, function)
postcondition = 'assert set(measurements) == set(range(bits))'
assert function_source.count(postcondition) == 1
function_source = function_source.replace(postcondition,
    'assert (not measurements) if bits is None else set(measurements) == set(range(bits))')
namespace = {'re': re, 'math': math, 'cmath': cmath}
exec(compile(function_source, '<pure sparse reference, optional terminal observations>', 'exec'), namespace)
simulate = namespace['simulate']


def encode(value, slots):
    return sum(((value >> bit) & 1) << wire for bit, wire in enumerate(slots))


def expected(x, b, cleaned):
    value = 17 if b else x
    basis = encode(x, wires['old']) | encode(b, wires['flag'])
    if not cleaned:
        basis |= encode(value, wires['current'])
        basis |= encode(b, wires['decision'])
    angle = .001 * x + .19 * b + (.17 if value == 7 else 0)
    return basis, cmath.exp(1j * angle) / math.sqrt(512)


def labeled_paths(text):
    states = list(range(512))
    amplitudes = [complex(1 / math.sqrt(512))] * 512
    prepared = 0
    suffix = False
    gates = 0
    for line in text.splitlines():
        line = line.strip()
        if line in ('', 'OPENQASM 3.0;', 'include "stdgates.inc";'):
            continue
        declaration = re.fullmatch(r'qubit\[(\d+)\] q;', line)
        if declaration:
            assert int(declaration[1]) == wires['qubits']
            continue
        match = re.fullmatch(r'(?:(ctrl|negctrl)\((\d+)\) @ )?(h|x|p|gphase)(?:\(([^)]+)\))?(?: (.*))?;', line)
        assert match, ('unexpected gate or channel', line)
        modifier, count, kind, angle, operands = match.groups()
        count = int(count or 0)
        slots = []
        for operand in operands.split(',') if operands else []:
            parsed = re.fullmatch(r'q\[(\d+)\]', operand.strip())
            assert parsed, operand
            slots.append(int(parsed[1]))
        assert len(slots) == len(set(slots)) and len(slots) == count + (kind != 'gphase')
        assert all(0 <= slot < wires['qubits'] for slot in slots)
        if kind == 'h':
            assert not suffix and prepared < 9 and count == 0 and angle is None and slots == [prepared]
            prepared += 1
            continue
        assert prepared == 9
        suffix = True
        gates += 1
        mask = sum(1 << slot for slot in slots[:count])
        pattern = 0 if modifier == 'negctrl' else mask
        if kind == 'x':
            assert angle is None
            target = 1 << slots[-1]
            states = [value ^ target if value & mask == pattern else value for value in states]
        else:
            angle = float(angle)
            assert math.isfinite(angle)
            if kind == 'p':
                mask |= 1 << slots[-1]
                pattern |= 1 << slots[-1]
            phase = cmath.exp(1j * angle)
            amplitudes = [amplitude * phase if value & mask == pattern else amplitude
                          for value, amplitude in zip(states, amplitudes)]
    assert prepared == 9 and len(set(states)) == 512
    return states, amplitudes, gates


rows = []
for cleaned, path in ((False, compute), (True, inverse)):
    text = path.read_text()
    state, observations, qubits, gates, hadamards = simulate(text)
    assert observations == {} and qubits == wires['qubits'] and hadamards == 9
    assert len(state) == 512
    paths, amplitudes, suffix_gates = labeled_paths(text)
    maximum = 0
    for b in range(2):
        for x in range(256):
            basis, amplitude = expected(x, b, cleaned)
            maximum = max(maximum, abs(state.get(basis, 0) - amplitude))
            index = x | (b << 8)
            assert paths[index] == basis, (cleaned, x, b, 'input/result/private-wire mismatch')
            maximum = max(maximum, abs(amplitudes[index] - amplitude))
    assert maximum < 1e-10 and abs(sum(abs(a) ** 2 for a in state.values()) - 1) < 1e-10
    rows.append({'stage': 'after-saved-inverse' if cleaned else 'computed',
                 'states': 512, 'labeled_basis_paths': 512, 'qubits': qubits,
                 'logical_gates': gates, 'suffix_gates': suffix_gates,
                 'maximum_amplitude_error': maximum,
                 'qasm_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    print(f'PASS controlled full-byte {rows[-1]["stage"]}: {qubits} wires, 512 complete amplitudes and labeled paths; error={maximum:.3g}', flush=True)
report = {'status': 'passed',
          'scope': 'Actual compiled unitary prefix and its saved inverse, before terminal observations. All 256 old byte values and both controls; no tables, O2/builtin source. The retained control decision is checked as a live dependency before inversion, then uncomputed and released after the result inverse. Sparse complex amplitudes and independently labeled basis paths preserve inputs, phases and zero unused private wires. This does not claim dense simulation or arbitrary channels at this width.',
          'input_ir_sha256': hashlib.sha256(ir.read_bytes()).hexdigest(),
          'reference_sha256': hashlib.sha256(reference.read_bytes()).hexdigest(),
          'reference_adaptation': 'Only the pure simulator function is loaded; it additionally accepts measurement-free unitary exports. Historical source file remains unchanged.',
          'checks': rows}
(destination / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
