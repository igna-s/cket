"""Independent sparse simulation of full int results beyond the dense limit."""
from pathlib import Path
import cmath
import hashlib
import json
import math
import os
import re
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/strncmp-prototype'
directory = candidate / 'build/full-raw-comparison-verified'
directory.mkdir(exist_ok=False)
assert sys.byteorder == 'little', 'This audit declares the GCC/glibc little-endian target.'

def simulate(text):
    state, measurements = {0: 1+0j}, {}
    qubits = bits = None
    gates = hadamards = 0
    terminal = False
    for line in text.splitlines():
        line = line.strip()
        if line in ('', 'OPENQASM 3.0;', 'include "stdgates.inc";'):
            continue
        match = re.fullmatch(r'(qubit|bit)\[(\d+)\] (q|results);', line)
        if match:
            if match[1] == 'qubit':
                assert qubits is None and match[3] == 'q'
                qubits = int(match[2])
                assert 0 < qubits <= 128
            else:
                assert bits is None and match[3] == 'results'
                bits = int(match[2])
            continue
        match = re.fullmatch(r'results\[(\d+)\] = measure q\[(\d+)\];', line)
        if match:
            bit, wire = int(match[1]), int(match[2])
            assert 0 <= bit < bits and 0 <= wire < qubits and bit not in measurements
            measurements[bit] = wire
            terminal = True
            continue
        assert not terminal, 'This sparse state audit only skips terminal observations.'
        match = re.fullmatch(r'(?:(ctrl|negctrl)\((\d+)\) @ )?(h|x|p|gphase)(?:\(([^)]+)\))?(?: (.*))?;', line)
        assert match, line
        modifier, controls, gate, angle, operands = match.groups()
        controls = int(controls or 0)
        wires = []
        for operand in operands.split(',') if operands else []:
            index = re.fullmatch(r'q\[(\d+)\]', operand.strip())
            assert index, operand
            wires.append(int(index[1]))
        assert len(wires) == len(set(wires)) and all(0 <= w < qubits for w in wires)
        assert len(wires) == controls + (gate != 'gphase')
        mask = sum(1 << wire for wire in wires[:controls])
        wanted = 0 if modifier == 'negctrl' else mask
        gates += 1
        if gate == 'h':
            assert controls == 0 and angle is None
            hadamards += 1
            flag, result = 1 << wires[-1], {}
            for basis, amplitude in state.items():
                low, high = basis & ~flag, basis | flag
                scaled = amplitude / math.sqrt(2)
                result[low] = result.get(low, 0) + scaled
                result[high] = result.get(high, 0) + (-scaled if basis & flag else scaled)
            state = {basis: a for basis, a in result.items() if abs(a) > 1e-14}
        elif gate == 'x':
            assert angle is None
            flag = 1 << wires[-1]
            result = {basis ^ flag if basis & mask == wanted else basis: a for basis, a in state.items()}
            assert len(result) == len(state), 'A controlled X must be a permutation.'
            state = result
        else:
            angle = float(angle)
            assert math.isfinite(angle)
            phase = cmath.exp(1j * angle)
            if gate == 'p':
                target = 1 << wires[-1]
                mask |= target
                wanted |= target
            state = {basis: a * phase if basis & mask == wanted else a for basis, a in state.items()}
        assert len(state) <= 262144, 'Sparse audit resource bound exceeded.'
    assert set(measurements) == set(range(bits))
    return state, measurements, qubits, gates, hadamards

rows = []
cases = [(8, value) for value in (0, 1, 65, 127, 128, 254, 255)]
cases += [(16, value) for value in (0xab00, 0xab41)]
for function in ('memcmp', 'strncmp'):
    for width, reference in cases:
        stem = function + '-' + str(width) + '-' + str(reference)
        source = directory / (stem + '.c')
        source.write_text('#include <quantum.h>\n#include <string.h>\nint main(void){quant uint' + str(width) + '_t input=superposition(0,' + str((1 << width)-1) + ');const uint' + str(width) + '_t reference=' + str(reference) + ';if(input==3)phase(.31);quant int result=' + function + '((const char*)&input,(const char*)&reference,sizeof input);if(result<0)phase(.17);measure(result);measure(input);return 0;}\n')
        exported = {}
        for configuration in ('normal', 'sanitized'):
            tools = candidate if configuration == 'normal' else candidate / 'build/sanitized'
            environment = dict(os.environ, CC='gcc-11', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
            if configuration == 'sanitized':
                environment.update(CC=str(tools / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11')
            ir = directory / (stem + '-' + configuration + '.json')
            subprocess.run([str(tools / 'build/cket'), str(source), '--emit-ir', '-O2', '-fbuiltin', '-o', str(ir)], cwd=candidate, env=environment, check=True, capture_output=True, timeout=120)
            result = subprocess.run([str(tools / 'build/cket_backend'), '--emit-qasm', str(ir), '--no-tables'], cwd=candidate, env=environment, check=True, capture_output=True, text=True, timeout=120)
            assert not result.stderr.strip(), result.stderr
            exported[configuration] = result.stdout
            (directory / (stem + '-' + configuration + '.qasm')).write_text(result.stdout)
        cache = {}
        for configuration, qasm in exported.items():
            digest = hashlib.sha256(qasm.encode()).hexdigest()
            reused = digest in cache
            if not reused:
                cache[digest] = simulate(qasm)
            actual, mapping, qubits, gates, hadamards = cache[digest]
            assert len(mapping) == 32 + width and hadamards == width
            assert len(actual) == 1 << width
            expected = {}
            for x in range(1 << width):
                difference = 0
                for a, b in zip(x.to_bytes(width//8, 'little'), reference.to_bytes(width//8, 'little')):
                    difference = a - b
                    if difference or (function == 'strncmp' and a == 0):
                        break
                result_bits = difference & 0xffffffff
                index = sum(((result_bits >> bit) & 1) << mapping[bit] for bit in range(32))
                index |= sum(((x >> bit) & 1) << mapping[bit+32] for bit in range(width))
                assert index not in expected
                expected[index] = cmath.exp(1j * ((.31 if x == 3 else 0) + (.17 if difference < 0 else 0))) / math.sqrt(1 << width)
            maximum = max(abs(actual.get(index, 0) - amplitude) for index, amplitude in expected.items())
            assert maximum < 1e-10, (function, width, reference, configuration, maximum)
            assert not (set(actual) - set(expected)), 'Input, result or private-wire leakage.'
            norm = sum(abs(a)**2 for a in actual.values())
            assert abs(norm - 1) < 1e-10
            row = {'function': function, 'configuration': configuration, 'input_bits': width, 'reference': reference, 'result_bits': 32, 'states': len(actual), 'qubits': qubits, 'logical_gates': gates, 'maximum_amplitude_error': maximum, 'norm': norm, 'qasm_sha256': digest, 'simulation_reused_for_identical_qasm': reused, 'normal_sanitized_qasm_identical': exported['normal'] == exported['sanitized']}
            rows.append(row)
            print(f'PASS full raw {function} {configuration}: {width}-bit input, ref={reference}, {qubits} qubits, {len(actual)} phased states, error={maximum:.3g}', flush=True)
        (directory / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
(directory / 'summary.json').write_text(json.dumps({'status': 'passed', 'scope': '36 normal/sanitized export checks of the full signed 32-bit result: all 256 byte inputs at seven constants and all 65536 word inputs at two constants for each function. Each distinct QASM circuit is independently sparsely simulated; identical exports reuse the same simulation. Input phases, negative-result phases and all private-wire zeros are checked. GCC sanitizer flags can preserve subtraction where the ordinary frontend folds addition of a negative constant, so circuit identity is not required. No-table export; O2 and builtin mode only. Sparse simulation covers this logical H/X/phase export subset with terminal observations, not arbitrary dense or channel circuits.', 'distinct_circuits_simulated': len({row['qasm_sha256'] for row in rows}), 'simulation_runs': sum(not row['simulation_reused_for_identical_qasm'] for row in rows), 'checks': rows}, indent=2) + '\n')
