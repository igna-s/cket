"""Extend discarded library-call sequencing in a separate checked source fork."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil

root = Path(__file__).resolve().parent.parent
base = root / 'build/memset-prototype'
manifest = base / 'build/memset-full-sources-before.json'
frozen = json.loads(manifest.read_text())
assert len(frozen) == 132
for name, digest in frozen.items():
    assert hashlib.sha256((base / name).read_bytes()).hexdigest() == digest, name
assert '800 memset checks passed;' in (base / 'build/memset-full-verify.log').read_text()
candidate = root / 'build/memory-sequence-prototype'
candidate.mkdir(exist_ok=False)
for name in (*frozen, 'LICENSE', 'docs/c11-memset.md', 'docs/c11-library.json'):
    target = candidate / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(base / name, target)
    os.chmod(target, 0o755 if name == 'cket' or name.endswith('.sh') else 0o644)
(candidate / '.deps').mkdir()
for name in ('gcc', 'format-venv', 'format-tools'):
    os.symlink(root / '.deps' / name, candidate / '.deps' / name)
(candidate / 'build').mkdir()

path = candidate / 'src/quantum_semantics.inc'
source = path.read_text()
before = 'std::string expression(tree value, std::set<unsigned> &deps) {\n'
helpers = '''// This predicate is used only for an explicitly discarded comma operand.
// A real return-pointer consumer still needs the checked quantum pointer ABI.
bool discarded_memory_sequence(tree value) {
    value = strip(value);
    if (!value)
        return false;
    if (quantum_memory_sets.count(value) || quantum_memory_copies.count(value))
        return true;
    return TREE_CODE(value) == COMPOUND_EXPR &&
           discarded_memory_sequence(TREE_OPERAND(value, 0)) &&
           discarded_memory_sequence(TREE_OPERAND(value, 1));
}

tree lower_discarded_memory_sequence(tree value) {
    value = strip(value);
    if (TREE_CODE(value) != COMPOUND_EXPR)
        return lower_node(value);
    tree list = alloc_stmt_list();
    append(&list, lower_discarded_memory_sequence(TREE_OPERAND(value, 0)));
    append(&list, lower_discarded_memory_sequence(TREE_OPERAND(value, 1)));
    return list;
}

'''
assert source.count(before) == 1
source = source.replace(before, helpers + before)
before = '''    if (code == SAVE_EXPR) {
        auto cached = expression_saves.find(value);'''
after = '''    if (code == COMPOUND_EXPR && discarded_memory_sequence(TREE_OPERAND(value, 0))) {
        if (expression_frames.empty() || lazy_effect_depth) {
            error_at(at(value), "|c>: discarded memory calls require a scheduled ordered consumer");
            return "{}";
        }
        std::set<unsigned> previous_parameters;
        previous_parameters.swap(active_cpu_parameters);
        append(expression_frames.back()->prefix,
               lower_discarded_memory_sequence(TREE_OPERAND(value, 0)));
        active_cpu_parameters.insert(previous_parameters.begin(), previous_parameters.end());
        return expression(TREE_OPERAND(value, 1), deps);
    }
    if (code == SAVE_EXPR) {
        auto cached = expression_saves.find(value);'''
assert source.count(before) == 1
source = source.replace(before, after)
spec = importlib.util.spec_from_file_location('sequence_formatter', candidate / 'scripts/format.py')
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)
formatted = formatter.format_text(path, source)
assert formatter.format_text(path, formatted) == formatted
path.write_text(formatted)
artifacts = ['cket', 'cket_backend', 'libcket_quantum.a', 'cket_runtime.o', 'gcc-version.txt',
             'validate_memset', 'validate_expressions', 'validate_memcopy', 'cket_tests']
for name in artifacts:
    source_path, target = base / 'build' / name, candidate / 'build' / name
    assert source_path.is_file()
    shutil.copyfile(source_path, target)
    if not name.endswith(('.a', '.o', '.txt')):
        os.chmod(target, 0o755)
(candidate / 'build/experimental-base.json').write_text(json.dumps({
    'source_sha256': frozen, 'scope': 'Separate experiment based on the frozen 132-input memset candidate. Its full campaign remains pending. Only quantum_semantics.inc is changed; source-identical fresh normal base binaries are reused except for the newly built plugin.',
    'artifact_sha256': {name: hashlib.sha256((candidate / 'build' / name).read_bytes()).hexdigest() for name in artifacts},
}, indent=2) + '\n')
print('Created discarded-memory-sequence experiment; both frozen campaigns and main compiler unchanged.')
