"""Read the local primary C11 draft around function-call sequencing."""
from pathlib import Path
import pymupdf

root = Path(__file__).resolve().parent.parent
document = pymupdf.open(root / 'build/re-audit-n1570.pdf')
for index, page in enumerate(document):
    text = ' '.join(page.get_text().split())
    needle = 'Every evaluation in the calling function'
    if needle in text:
        start = text.index(needle)
        print('N1570 PDF page', index + 1)
        print(text[start:start + 830])
