"""Record the new C sequence validator and relevant normal regressions."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import traceback

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memory-sequence-prototype'
output = candidate / 'build'
label = sys.argv[1] if len(sys.argv) > 1 else 'sequence-validation-v1'
assert label and all(character.isalnum() or character == '-' for character in label)
manifest = output / (label + '-sources.json')
terminal = output / (label + '-exit.json')
metadata = output / (label + '-job.json')
log = output / (label + '.log')
binary = output / ('validate_memory_sequences-' + label)

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def check_sources():
    frozen = json.loads(manifest.read_text())
    assert len(frozen) == 134
    for name, digest in frozen.items():
        assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name

if '--worker' in sys.argv:
    status, detail, completed = 1, None, []
    try:
        check_sources()
        commands = [[str(binary)], [str(output / 'validate_expressions')],
                    [str(output / 'validate_memcopy')], [str(output / 'validate_memset')],
                    [str(output / 'cket_tests'), str(candidate)],
                    ['bash', 'scripts/test-c11-classical.sh']]
        for command in commands:
            print('Running:', ' '.join(command), flush=True)
            result = subprocess.run(command, cwd=candidate)
            completed.append({'command': command, 'returncode': result.returncode})
            if result.returncode:
                break
        status = completed[-1]['returncode']
        check_sources()
    except BaseException as error:
        detail = repr(error)
        traceback.print_exc()
        status = 1
    with terminal.open('x') as handle:
        json.dump({'finished_utc': utc(), 'exit_code': status, 'error': detail,
                   'commands': completed,
                   'scope': 'New 360-check C sequence validator plus relevant normal regression suites using a newly built plugin and source-identical reused fresh normal base tools/validators. Not a fresh full-build or sanitizer campaign.'}, handle, indent=2)
        handle.write('\n')
    raise SystemExit(status)

assert not any(path.exists() for path in (manifest, terminal, metadata, log, binary))
base = json.loads((output / 'experimental-base.json').read_text())
for name, digest in base['artifact_sha256'].items():
    assert hashlib.sha256((output / name).read_bytes()).hexdigest() == digest, name
before = json.loads((output / 'sequence-sources-before.json').read_text())
for name, digest in before.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
spec = importlib.util.spec_from_file_location('sequence_check_formatter', candidate / 'scripts/format.py')
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)
for name in ('tests/validate_memory_sequences.c', 'tests/memory_sequence_state.inc'):
    path = candidate / name
    assert formatter.format_text(path, path.read_text()) == path.read_text(), name
subprocess.run([sys.executable, 'scripts/archive-audit.py', '--freeze', str(manifest)], cwd=candidate, check=True)
check_sources()
command = ['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
           '-Isrc/engine', '-Itests', 'tests/validate_memory_sequences.c', 'tests/validation.c',
           'build/libcket_quantum.a', '-lm', '-o', str(binary)]
subprocess.run(command, cwd=candidate, check=True)
environment = os.environ.copy()
environment['CC'] = 'gcc-11'
with log.open('x') as handle:
    process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), label, '--worker'],
                               cwd=candidate, env=environment, stdin=subprocess.DEVNULL,
                               stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
fields = (Path('/proc') / str(process.pid) / 'stat').read_text().rsplit(')', 1)[1].split()
with metadata.open('x') as handle:
    json.dump({'pid': process.pid, 'linux_start_ticks': int(fields[19]),
               'runner': str(Path(__file__).resolve()), 'started_utc': utc(),
               'source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
               'compile_command': command,
               'validator_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
               'plugin_sha256': hashlib.sha256((output / 'cket_plugin.so').read_bytes()).hexdigest()}, handle, indent=2)
    handle.write('\n')
print(json.dumps({'state': 'started', 'pid': process.pid, 'log': str(log)}))
