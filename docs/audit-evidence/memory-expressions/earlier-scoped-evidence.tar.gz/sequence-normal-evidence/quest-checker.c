/* Execute exported prefixes with QuEST, independently of the project's motor. */
#define _XOPEN_SOURCE 700
#include "qasm_reference.h"
#include "validation.h"
#include "json.h"
#include <complex.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static size_t expected_basis(const cj_doc *d, unsigned profile, int inverse, unsigned b) {
    uint8_t x = 5, y = profile == 1 ? 7 : 0;
    switch (profile) {
    case 0: y = (memset(&x, (int)b, 1), x + 1); break;
    case 1: memset(&x, (memset(&y, (int)b, 1), y + 1), 1); break;
    case 2: y = b ? (memset(&x, 17, 1), x) : x; break;
    case 3: y = b && (memset(&x, 17, 1), x == 17); break;
    case 4: y = b || (memset(&x, 17, 1), x == 17); break;
    default: validation_fail("invalid QuEST sequence profile");
    }
    int list = cj_get(d, 0, "registers");
    size_t basis = 0;
    unsigned seen = 0, auxiliary = 0;
    for (int token = list + 1; token < d->tokens[list].next; token = d->tokens[token].next) {
        uint64_t id;
        if (!cj_u64(d, cj_get(d, token, "id"), &id))
            validation_fail("invalid QuEST sequence mapping ID");
        unsigned value;
        if (id == 0) { value = b; seen |= 1; }
        else if (id == 1) { value = inverse ? 5 : x; seen |= 2; }
        else if (id == 2) { value = inverse ? 7 : y; seen |= 4; }
        else {
            if (inverse || profile < 2 || ++auxiliary > 1)
                validation_fail("unexpected QuEST sequence auxiliary");
            value = b;
        }
        int wires = cj_get(d, token, "wires");
        unsigned bit = 0;
        for (int w = wires + 1; w < d->tokens[wires].next; w = d->tokens[w].next) {
            uint64_t index;
            if (!cj_u64(d, w, &index) || index >= 24 || bit >= 8)
                validation_fail("invalid QuEST sequence wire mapping");
            basis |= (size_t)((value >> bit++) & 1) << index;
        }
        if (bit != (id == 0 || id >= 3 || (id == 2 && profile >= 3) ? 1u : 8u))
            validation_fail("invalid QuEST sequence register width");
    }
    if (seen != (inverse && profile != 1 ? 3u : 7u))
        validation_fail("incomplete QuEST sequence mapping");
    return basis;
}

int main(int argc, char **argv) {
    if (argc != 5)
        validation_fail("usage: check-sequence-quest QASM MAP PROFILE INVERSE");
    char *qasm = validation_read(argv[1]), *mapping = validation_read(argv[2]);
    unsigned profile = (unsigned)strtoul(argv[3], NULL, 10);
    int inverse = atoi(argv[4]);
    reference_circuit circuit;
    cj_doc d = {0};
    if (!reference_parse(&circuit, qasm) || !cj_parse(&d, mapping) || circuit.bits)
        validation_fail("invalid QuEST sequence circuit or mapping");
    QuESTEnv env = createQuESTEnv();
    Qureg q = createQureg((int)circuit.qubits, env);
    initZeroState(q);
    (void)reference_execute(&circuit, q, 0);
    size_t expected[2] = {expected_basis(&d, profile, inverse, 0), expected_basis(&d, profile, inverse, 1)};
    if (expected[0] == expected[1])
        validation_fail("QuEST sequence lost a distinct input");
    for (size_t basis = 0; basis < (size_t)1 << circuit.qubits; ++basis) {
        double complex wanted = 0;
        for (unsigned b = 0; b < 2; ++b)
            if (basis == expected[b])
                wanted = cexp(I * (.31 * b + (b || profile == 4 ? .17 : 0))) / sqrt(2);
        Complex a = getAmp(q, (long long)basis);
        if (!isfinite(a.real) || !isfinite(a.imag) || cabs(a.real + I * a.imag - wanted) > 1e-10)
            validation_fail("independent QuEST sequence amplitude mismatch at %zu", basis);
    }
    printf("PASS QuEST memory sequence p=%u inverse=%d: %u wires, complete amplitudes and private zeros\n", profile, inverse, circuit.qubits);
    destroyQureg(q, env);
    destroyQuESTEnv(env);
    reference_destroy(&circuit);
    cj_free(&d);
    free(mapping);
    free(qasm);
    return 0;
}
