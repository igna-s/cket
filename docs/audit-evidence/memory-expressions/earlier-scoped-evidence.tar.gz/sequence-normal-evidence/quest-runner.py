"""Check every new prefix fitting the existing independent dense budget."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memory-sequence-prototype'
base = root / 'build/byte-snapshot-prototype/build/validation-deps'
probe = candidate / 'build/sequence-exports-v1'
summary = json.loads((probe / 'summary.json').read_text())
assert summary['status'] == 'passed' and len(summary['checks']) == 20
destination = candidate / 'build/sequence-quest-v1'
destination.mkdir(exist_ok=False)
manifest = candidate / 'build/sequence-validation-v1-sources.json'
frozen = json.loads(manifest.read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
assert hashlib.sha256((base / 'quest-3.7.0.tar.gz').read_bytes()).hexdigest() == '1a5939798a70b749dfa57cfaa116ece03a2d36aa59c1b712cb3dc2103ab1cded'
quest = base / 'QuEST-d4f75f724993b4af8e43a796e3c09ce24ae11670/QuEST'
checker = destination / 'checker'
command = ['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-DQuEST_PREC=2',
           '-I' + str(candidate / 'src/engine'), '-I' + str(candidate / 'tests'), '-I' + str(quest / 'include'),
           str(root / 'build/check-sequence-quest.c'), str(candidate / 'tests/qasm_reference.c'),
           str(candidate / 'tests/validation.c'), str(candidate / 'build/libcket_quantum.a'),
           str(base / 'libQuEST.a'), '-lm', '-o', str(checker)]
subprocess.run(command, cwd=candidate, check=True)
rows, outside = [], []
with (destination / 'verify.log').open('x') as log:
    for row in summary['checks']:
        if row['physical_wires'] > 24:
            outside.append(row)
            continue
        stem = f"export-p{row['profile']}-t{row['tables']}-{row['stage']}"
        qasm, mapping = probe / (stem + '.qasm'), probe / (stem + '.json')
        assert hashlib.sha256(qasm.read_bytes()).hexdigest() == row['qasm_sha256']
        command = [str(checker), str(qasm), str(mapping), str(row['profile']), str(int(row['stage'] == 'after'))]
        result = subprocess.run(command, cwd=candidate, text=True, capture_output=True, timeout=180)
        log.write(result.stdout + result.stderr)
        log.flush()
        rows.append({'command': command, 'returncode': result.returncode, **row})
        (destination / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(result.stdout, end='', flush=True)
        if result.returncode:
            raise SystemExit(result.stderr)
assert len(rows) == 14 and len(outside) == 6
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
(destination / 'summary.json').write_text(json.dumps({'status': 'passed', 'source_inputs': len(frozen),
    'source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'checks': rows,
    'outside_dense_budget': outside,
    'scope': '14 actual prefix/inverse exports executed with pinned QuEST 3.7.0 and compared against independent finite C models including all amplitudes. Six 25/26-wire exports exceed the unchanged 24-wire independent dense budget; all twenty were checked separately by sparse amplitudes and labeled paths. Normal only, O2/builtin, both synthesis policies; not full regression or QPU evidence.'}, indent=2) + '\n')
