"""Independent sparse and labeled OpenQASM references for sequence prefixes."""
from pathlib import Path
import ast
import cmath
import hashlib
import json
import math
import re
import subprocess

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memory-sequence-prototype'
destination = candidate / 'build/sequence-exports-v1'
destination.mkdir(exist_ok=False)
manifest = candidate / 'build/sequence-validation-v1-sources.json'
frozen = json.loads(manifest.read_text())
assert len(frozen) == 134
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
node, = [node for node in ast.parse((root / 'build/prepare-memory-sequence-validator.py').read_text()).body
          if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
          and node.targets[0].id == 'state_cases']
cases = ast.literal_eval(node.value)
header = (candidate / 'tests/memory_sequence_state.inc').read_text()
for inverse in (0, 1):
    before = f'        sequence_compare(c, profile, {inverse});'
    assert header.count(before) == 1
    header = header.replace(before, before + f'\n        export_stage(c, profile, {inverse}, tables);')
(destination / 'instrumented-state.inc').write_text(header)
source = destination / 'exporter.c'
source.write_text(r'''#define _POSIX_C_SOURCE 200809L
#include "internal.h"
#include "validation.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static const char *prefix;
static void export_stage(qc_context *, unsigned, int, unsigned);
#include "instrumented-state.inc"
static void export_stage(qc_context *c, unsigned profile, int inverse, unsigned tables) {
    char path[4096];
    validation_path(path, sizeof path, "%s-p%u-t%u-%s.qasm", prefix, profile, tables, inverse?"after":"before");
    FILE *out = fopen(path, "wx");
    if (!out || !qc_qasm(c, out) || fclose(out))
        validation_fail("sequence QASM export failed");
    validation_path(path, sizeof path, "%s-p%u-t%u-%s.json", prefix, profile, tables, inverse?"after":"before");
    out = fopen(path, "wx");
    if (!out)
        validation_fail("sequence mapping export failed");
    fprintf(out, "{\"qubits\":%u,\"registers\":[", c->physical);
    unsigned count = 0;
    for (size_t i = 0; i < c->nregisters; ++i) {
        const qc_register *r = &c->registers[i];
        if (!r->alive)
            continue;
        fprintf(out, "%s{\"id\":%u,\"wires\":[", count++?",":"", r->id);
        for (unsigned b = 0; b < r->width; ++b)
            fprintf(out, "%s%u", b?",":"", r->wires[b]);
        fprintf(out, "]}");
    }
    fprintf(out, "]}\n");
    if (fclose(out))
        validation_fail("sequence mapping flush failed");
}
int main(int argc, char **argv) {
    if (argc != 4)
        return 2;
    prefix = argv[3];
    char *ir = validation_read(argv[1]);
    unsigned maximum = 0;
    (void)sequence_state_probe(ir, (unsigned)strtoul(argv[2], NULL, 10), &maximum);
    free(ir);
    return 0;
}
''')
exporter = destination / 'exporter'
subprocess.run(['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                '-I' + str(candidate / 'src/engine'), '-I' + str(candidate / 'tests'),
                str(source), str(candidate / 'tests/validation.c'),
                str(candidate / 'build/libcket_quantum.a'), '-lm', '-o', str(exporter)], check=True)

def pure_function(path, name):
    text = path.read_text()
    node, = [node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef) and node.name == name]
    return ast.get_source_segment(text, node)

simulator = pure_function(root / 'build/check-byte-comparison-raw.py', 'simulate')
assert simulator.count('assert set(measurements) == set(range(bits))') == 1
simulator = simulator.replace('assert set(measurements) == set(range(bits))',
    'assert not measurements if bits is None else set(measurements) == set(range(bits))')
paths = pure_function(root / 'build/check-memset-sparse.py', 'labeled_paths')
paths = paths.replace('512', '2').replace('prepared < 9', 'prepared < 1').replace('prepared == 9', 'prepared == 1')
namespace = {'re': re, 'math': math, 'cmath': cmath}
exec(compile(simulator, '<pure independent sparse reference>', 'exec'), namespace)
exec(compile(paths, '<pure independent two-label reference>', 'exec'), namespace)
rows = []
for profile, body in enumerate(cases):
    program = destination / f'profile-{profile}.c'
    program.write_text('#include <quantum.h>\n#include <string.h>\nint main(void){' + body + 'return 0;}\n')
    ir = destination / f'profile-{profile}.json'
    prefix = destination / 'export'
    subprocess.run([str(candidate / 'build/cket'), str(program), '--emit-ir', '-O2', '-fbuiltin', '-o', str(ir)],
                   cwd=candidate, check=True, capture_output=True, timeout=120)
    subprocess.run([str(exporter), str(ir), str(profile), str(prefix)],
                   cwd=candidate, check=True, capture_output=True, timeout=120)
    for tables in (0, 1):
        for cleaned, stage in ((False, 'before'), (True, 'after')):
            mapping = json.loads((destination / f'export-p{profile}-t{tables}-{stage}.json').read_text())
            path = destination / f'export-p{profile}-t{tables}-{stage}.qasm'
            qasm = path.read_text()
            namespace['wires'] = {'qubits': mapping['qubits']}
            actual, observations, qubits, gates, hadamards = namespace['simulate'](qasm)
            labeled, amplitudes, _ = namespace['labeled_paths'](qasm)
            assert observations == {} and qubits == mapping['qubits'] and hadamards == 1
            registers = {entry['id']: entry['wires'] for entry in mapping['registers']}
            assert registers[0] == [0] and len(registers[1]) == 8
            assert set(registers) >= ({0, 1, 2} if not cleaned or profile == 1 else {0, 1})
            extras = set(registers) - {0, 1, 2}
            assert len(extras) <= 1 and (not extras or profile >= 2 and not cleaned)
            expected = {}
            maximum = 0
            for b in (0, 1):
                x = b if profile == 0 else b + 1 if profile == 1 else (17 if b else 5) if profile in (2, 3) else (5 if b else 17)
                y = b + 1 if profile == 0 else b if profile in (1, 3) else x if profile == 2 else 1
                values = {0: b, 1: 5 if cleaned else x}
                if not cleaned:
                    values[2] = y
                elif profile == 1:
                    values[2] = 7
                values.update({identifier: b for identifier in extras})
                assert set(values) == set(registers)
                basis = 0
                for identifier, value in values.items():
                    basis |= sum(((value >> bit) & 1) << wire for bit, wire in enumerate(registers[identifier]))
                amplitude = cmath.exp(1j * (.31 * b + (.17 if b or profile == 4 else 0))) / math.sqrt(2)
                assert basis not in expected and labeled[b] == basis
                expected[basis] = amplitude
                maximum = max(maximum, abs(actual.get(basis, 0) - amplitude), abs(amplitudes[b] - amplitude))
            assert set(actual) == set(expected) and maximum < 1e-10
            assert abs(sum(abs(value) ** 2 for value in actual.values()) - 1) < 1e-10
            rows.append({'profile': profile, 'tables': tables, 'stage': stage, 'physical_wires': qubits,
                         'labeled_paths': 2, 'maximum_amplitude_error': maximum, 'gates': gates,
                         'qasm_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
            print(f'PASS independent sequence export p={profile} tables={tables} {stage}: {qubits} wires, error={maximum:.3g}', flush=True)
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
(destination / 'summary.json').write_text(json.dumps({'status': 'passed', 'source_inputs': len(frozen),
    'source_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'checks': rows,
    'scope': '20 table-policy/prefix/inverse OpenQASM exports at O2/builtin. Independent sparse amplitudes and both labeled basis paths after verified one-H preparation, including all private-wire zeros after inversion. Not arbitrary dense/channel simulation or QPU evidence.'}, indent=2) + '\n')
