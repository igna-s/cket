"""Finite compositions of the checked C library adapters and value effects."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
candidate = root / 'build' / (sys.argv[1] if len(sys.argv) > 1 else 'memset-prototype')
label = sys.argv[2] if len(sys.argv) > 2 else 'library-compositions-v2'
assert candidate.parent == root / 'build'
assert label and all(character.isalnum() or character == '-' for character in label)
destination = candidate / 'build' / label
destination.mkdir(exist_ok=False)
manifest = candidate / 'build/memset-full-sources-before.json'
if not manifest.exists():
    manifest = candidate / 'build/sequence-sources-before.json'
frozen = json.loads(manifest.read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name

cases = [
    ('fill-then-memcmp', 'quant bool b=superposition(0,1);quant uint8_t a[2]={17,34};memset(a,b,2);quant bool r=memcmp(a,"\\x01\\x01",2)==0;unsigned z=measure(r),x=measure(a[0]),y=measure(a[1]),v=measure(b);return x!=v||y!=v||z!=v;', None),
    ('fill-then-strncmp', 'quant bool b=superposition(0,1);quant uint8_t a[2]={17,34};memset(a,b,1);const char ref[2]={0,99};quant bool r=strncmp((char*)a,ref,2)<=0;unsigned z=measure(r),x=measure(a[0]),y=measure(a[1]),v=measure(b);return x!=v||y!=34||z!=!v;', None),
    ('fill-then-copy', 'quant bool b=superposition(0,1);quant uint8_t x=17,y=0;memset(&x,b,1);memcpy(&y,&x,1);unsigned a=measure(x),d=measure(y),v=measure(b);return a!=v||d!=v;', None),
    ('copy-then-fill', 'quant bool b=superposition(0,1);quant uint8_t source=b+1,destination=37;memcpy(&destination,&source,1);memset(&destination,17,1);unsigned x=measure(destination);measure(b);return x!=17;', None),
    ('live-comparison-before-fill', 'quant bool b=superposition(0,1);quant uint8_t x=b+1;quant bool r=memcmp(&x,"\\x01",1)<=0;memset(&x,17,1);unsigned a=measure(x),z=measure(r),v=measure(b);return a!=17||z!=!v;', None),
    ('cpu-reference-before-fill', 'unsigned char ref=17;quant bool b=superposition(0,1);quant uint8_t x=b+16;quant bool r=memcmp(&x,&ref,1)<=0;ref=99;memset(&x,17,1);unsigned a=measure(x),z=measure(r);measure(b);return a!=17||z!=1||ref!=99;', None),
    ('memcmp-fill-value', 'quant bool b=superposition(0,1);quant uint8_t source=b,x=5;const unsigned char ref=1;memset(&x,memcmp(&source,&ref,1),1);unsigned a=measure(x),v=measure(b);return a!=(v?0u:255u);', None),
    ('self-comparison-fill', 'quant bool b=superposition(0,1);quant uint8_t x=b+1;memset(&x,strncmp((char*)&x,"\\x01",1),1);unsigned a=measure(x),v=measure(b);return a!=v;', None),
    ('ctype-fill-value', 'quant bool b=superposition(0,1);quant uint8_t x=5;memset(&x,islower(b?97:65),1);unsigned a=measure(x),v=measure(b);return a!=(unsigned char)islower(v?97:65);', None),
    ('conversion-fill-value', 'quant bool b=superposition(0,1);quant uint8_t x=5;memset(&x,tolower((int)b+65),1);unsigned a=measure(x),v=measure(b);return a!=(unsigned)tolower((int)v+65);', None),
    ('division-fill-value', 'quant bool b=superposition(0,1);quant uint8_t x=5;memset(&x,div((int)b+5,2).rem,1);unsigned a=measure(x),v=measure(b);return a!=(unsigned)div((int)v+5,2).rem;', None),
    ('absolute-fill-value', 'quant bool b=superposition(0,1);quant uint8_t x=5;memset(&x,abs((int)b-1),1);unsigned a=measure(x),v=measure(b);return a!=(unsigned)abs((int)v-1);', None),
    ('cpu-effect-then-comparison', 'unsigned n=17;quant uint8_t x=5;memset(&x,++n,1);const unsigned char ref=18;quant bool r=memcmp(&x,&ref,1)==0;n=99;unsigned z=measure(r),a=measure(x);return a!=18||z!=1||n!=99;', None),
    ('comma-value', 'quant bool b=superposition(0,1);quant uint8_t x=0;quant uint8_t y=(memset(&x,b,1),x+1);unsigned z=measure(y),a=measure(x),v=measure(b);return a!=v||z!=v+1;', None),
    ('nested-value', 'quant uint8_t x=5,y=7;memset(&x,(memset(&y,17,1),y+1),1);unsigned a=measure(x),z=measure(y);return a!=18||z!=17;', None),
    ('coherent-comma-value', 'quant bool b=superposition(0,1);quant uint8_t x=5;quant uint8_t y=b?(memset(&x,17,1),x):x;if(y==17)phase(.17);unsigned z=measure(y),a=measure(x),v=measure(b);return a!=(v?17u:5u)||z!=a;', None),
    ('unsequenced-comma', 'quant bool b=superposition(0,1);quant uint8_t x=0,y=7;memset(&x,(memset(&y,17,1),b++ + b),1);measure(x);measure(y);return measure(b);', 'unsequenced quantum modification and access'),
    ('call-body-indeterminate-order', 'quant bool b=superposition(0,1);quant uint8_t x=5;quant uint8_t y=(memset(&x,b,1),x)+x;unsigned z=measure(y),a=measure(x),v=measure(b);return a!=v||(z!=2*v&&z!=v+5);', None),
    ('copy-comma-value', 'quant bool b=superposition(0,1);quant uint8_t x=b+1,y=0;quant bool r=(memcpy(&y,&x,1),y==2);unsigned z=measure(r),a=measure(y),v=measure(b);return z!=v||a!=v+1;', None),
    ('move-comma-value', 'quant bool b=superposition(0,1);quant uint8_t a[2]={b+1,34};quant bool r=(memmove(a+1,a,1),a[1]==2);unsigned z=measure(r),x=measure(a[0]),y=measure(a[1]),v=measure(b);return z!=v||x!=v+1||y!=x;', None),
]
rows = []
for name, body, diagnostic in cases:
    source = destination / (name + '.c')
    source.write_text('#include <quantum.h>\n#include <string.h>\n#include <ctype.h>\n#include <stdlib.h>\nint main(void){' + body + '}\n')
    command = [str(candidate / 'build/cket'), str(source), '--emit-ir' if diagnostic else '--run',
               '-O2', '-fbuiltin', '-o', str(destination / (name + '.out'))]
    result = subprocess.run(command, cwd=candidate, text=True, capture_output=True, timeout=240)
    messages = '\n'.join(line.split('|c>:', 1)[1] for line in result.stderr.splitlines() if '|c>:' in line)
    passed = (result.returncode == 1 and diagnostic in messages if diagnostic else result.returncode == 0)
    if re.search(r'AddressSanitizer:DEADLYSIGNAL|ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:|internal compiler error:', result.stderr):
        passed = False
    rows.append({'name': name, 'command': command, 'returncode': result.returncode, 'passed': passed,
                 'stdout': result.stdout, 'stderr': result.stderr})
    (destination / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(f'{"PASS" if passed else "INCOMPLETE"} memory composition {name}', flush=True)
    if not passed:
        print(messages or result.stderr[-1200:], flush=True)
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
(destination / 'summary.json').write_text(json.dumps({'status': 'passed' if all(row['passed'] for row in rows) else 'incomplete',
    'passed': sum(row['passed'] for row in rows), 'total': len(rows),
    'scope': 'Finite O2/builtin native executions and one expected unsequenced-access rejection; failed or resource-exhausted cases remain explicitly incomplete.'}, indent=2) + '\n')
raise SystemExit(0 if all(row['passed'] for row in rows) else 1)
