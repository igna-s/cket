"""Create the maintained finite validator for discarded library-call sequences."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json

root = Path(__file__).resolve().parent.parent
candidate = root / 'build/memory-sequence-prototype'
frozen = json.loads((candidate / 'build/sequence-sources-before.json').read_text())
for name, digest in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == digest, name
tree = ast.parse((root / 'build/probe-memory-compositions.py').read_text())
node, = [node for node in tree.body if isinstance(node, ast.Assign)
          and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'cases']
cases = ast.literal_eval(node.value)
assert len(cases) == 20
cases += [
    ('logical-and', 'quant bool b=superposition(0,1);quant uint8_t x=5;quant bool r=b&&(memset(&x,17,1),x==17);unsigned z=measure(r),a=measure(x),v=measure(b);return z!=v||a!=(v?17u:5u);', None),
    ('logical-or', 'quant bool b=superposition(0,1);quant uint8_t x=5;quant bool r=b||(memset(&x,17,1),x==17);unsigned z=measure(r),a=measure(x),v=measure(b);return z!=1||a!=(v?5u:17u);', None),
    ('previous-cpu-binding', 'unsigned n=17;quant bool b=superposition(0,1);quant uint8_t x=5;quant uint8_t y=n+(memset(&x,b,1),x);n=99;unsigned z=measure(y),a=measure(x),v=measure(b);return z!=17+v||a!=v||n!=99;', None),
    ('zero-cpu-comma', 'unsigned n=17;quant uint8_t x=5;quant uint8_t y=(memset((char*)&x+1,++n,0),x+1);unsigned z=measure(y),a=measure(x);return z!=6||a!=5||n!=18;', None),
    ('call-chain', 'quant bool b=superposition(0,1);quant uint8_t x=5,y=0;quant bool r=(memset(&x,b,1),memcpy(&y,&x,1),y==1);unsigned z=measure(r),a=measure(x),d=measure(y),v=measure(b);return z!=v||a!=v||d!=v;', None),
    ('coherent-cpu-effect', 'unsigned n=17;quant bool b=superposition(0,1);quant uint8_t x=5;quant uint8_t y=b?(memset(&x,++n,1),x):x;measure(y);measure(x);measure(b);return n;', 'CPU effects in quantum expressions'),
]

state_cases = [
    'quant bool b=superposition(0,1);quant uint8_t x=5;if(b)phase(.31);quant uint8_t y=(memset(&x,b,1),x+1);if(y==2)phase(.17);measure(y);measure(x);measure(b);',
    'quant bool b=superposition(0,1);quant uint8_t x=5,y=7;if(b)phase(.31);memset(&x,(memset(&y,b,1),y+1),1);if(x==2)phase(.17);measure(x);measure(y);measure(b);',
    'quant bool b=superposition(0,1);quant uint8_t x=5;if(b)phase(.31);quant uint8_t y=b?(memset(&x,17,1),x):x;if(y==17)phase(.17);measure(y);measure(x);measure(b);',
    'quant bool b=superposition(0,1);quant uint8_t x=5;if(b)phase(.31);quant bool y=b&&(memset(&x,17,1),x==17);if(y)phase(.17);measure(y);measure(x);measure(b);',
    'quant bool b=superposition(0,1);quant uint8_t x=5;if(b)phase(.31);quant bool y=b||(memset(&x,17,1),x==17);if(y)phase(.17);measure(y);measure(x);measure(b);',
]
def program(body):
    return '#include <quantum.h>\n#include <string.h>\n#include <ctype.h>\n#include <stdlib.h>\nint main(void){' + body + '}\n'

rows = ['    {%s, %s, %s},' % (json.dumps(name), json.dumps(program(body)),
         json.dumps(diagnostic) if diagnostic else 'NULL') for name, body, diagnostic in cases]
source = r'''#define _POSIX_C_SOURCE 200809L
#include "internal.h"
#include "validation.h"
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "memory_sequence_state.inc"

static unsigned checks;
static const char *levels[] = {"-O0", "-O1", "-O2", "-O3", "-Os"};
typedef struct {
    const char *name, *program, *diagnostic;
} sequence_case;
static const sequence_case native_cases[] = {
NATIVE_CASES
};

static char *compile_case(validation *v, const sequence_case *test,
                          unsigned level, unsigned builtin, int execute) {
    char source[4096], output[4096], compiler[4096];
    validation_path(source, sizeof source, "%s/sequence.c", v->temp);
    validation_path(output, sizeof output, "%s/sequence.out", v->temp);
    validation_path(compiler, sizeof compiler, "%s/build/cket", v->root);
    validation_write(source, test->program);
    char *command[] = {compiler, source, execute ? "--run" : "--emit-ir",
        (char *)levels[level], builtin ? "-fbuiltin" : "-fno-builtin", "-o", output, NULL};
    int status = validation_run(v, command, NULL, 240);
    char *log = validation_read(v->log);
    if (test->diagnostic ? !validation_rejected(status, log, test->diagnostic) : status != 0)
        validation_fail("memory sequence %s %s builtins=%u failed:\n%s\n%s",
                        test->name, levels[level], builtin, test->program, log);
    free(log);
    return !execute && !test->diagnostic ? validation_read(output) : NULL;
}

static void syntax(validation *v, const sequence_case *test) {
    const char *preamble = "#include <stdint.h>\n#include <stdbool.h>\n#define quant\n"
        "#define measure(x) (x)\n#define phase(x) ((void)(x))\n#define superposition(a,b) (a)\n";
    const char *body = strstr(test->program, "#include <quantum.h>\n");
    if (!body)
        validation_fail("missing memory sequence fixture preamble");
    body += strlen("#include <quantum.h>\n");
    size_t size = strlen(preamble) + strlen(body) + 1;
    char *program = malloc(size);
    if (!program)
        validation_fail("memory sequence fixture allocation failed");
    validation_path(program, size, "%s%s", preamble, body);
    char source[4096];
    validation_path(source, sizeof source, "%s/classical.c", v->temp);
    validation_write(source, program);
    free(program);
    const char *cc = getenv("CC");
    char *command[] = {(char *)(cc ? cc : "gcc"), "-std=c11", "-fsyntax-only", source, NULL};
    if (validation_run(v, command, NULL, 60)) {
        char *log = validation_read(v->log);
        validation_fail("memory sequence rejection fixture is not valid ordinary C syntax:\n%s", log);
    }
}

static void native(validation *v) {
    unsigned positive = 0, negative = 0;
    for (unsigned i = 0; i < sizeof native_cases / sizeof *native_cases; ++i) {
        const sequence_case *test = &native_cases[i];
        if (test->diagnostic)
            syntax(v, test);
        for (unsigned level = 0; level < 5; ++level)
            for (unsigned builtin = 0; builtin < 2; ++builtin) {
                free(compile_case(v, test, level, builtin, !test->diagnostic));
                if (test->diagnostic)
                    ++negative;
                else
                    ++positive;
            }
    }
    checks += positive + negative;
    printf("PASS %u native memory compositions: comparisons, copies, ctype/division/abs values, comma chains, CPU snapshots and coherent short circuit; five GCC levels, both builtin modes\n", positive);
    printf("PASS %u memory sequence rejection contracts: unsequenced value-argument access and coherent CPU effects; ordinary C syntax checked, not a definedness claim\n", negative);
    fflush(stdout);
}

static void states(validation *v) {
    static const char *programs[] = {
STATE_CASES
    };
    unsigned count = 0, maximum = 0;
    for (unsigned profile = 0; profile < sizeof programs / sizeof *programs; ++profile)
        for (unsigned level = 0; level < 5; ++level)
            for (unsigned builtin = 0; builtin < 2; ++builtin) {
                sequence_case test = {"complete-action", programs[profile], NULL};
                char *ir = compile_case(v, &test, level, builtin, 0);
                count += sequence_state_probe(ir, profile, &maximum);
                free(ir);
            }
    checks += count;
    printf("PASS %u complete memory sequence basis-action circuits: both input labels, relative phases, saved result/write inverses and private zeros; verified one-H preparation, both synthesis policies, maximum %u physical wires\n", count, maximum);
    fflush(stdout);
}

int main(int argc, char **argv) {
    if (argc != 1)
        validation_fail("usage: validate_memory_sequences");
    validation v;
    validation_init(&v, argv[0]);
    states(&v);
    native(&v);
    validation_cleanup(&v);
    printf("%u memory sequence checks passed; complete labeled action, native integration and expected rejections have distinct proof scopes.\n", checks);
    return 0;
}
'''
source = source.replace('NATIVE_CASES', '\n'.join(rows))
source = source.replace('STATE_CASES', ',\n'.join('        ' + json.dumps(program(body + 'return 0;')) for body in state_cases))
path = candidate / 'tests/validate_memory_sequences.c'
assert not path.exists()
spec = importlib.util.spec_from_file_location('sequence_validator_formatter', candidate / 'scripts/format.py')
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)
for name, text in [('tests/validate_memory_sequences.c', source),
                   ('tests/memory_sequence_state.inc', (candidate / 'tests/memory_sequence_state.inc').read_text())]:
    output = candidate / name
    formatted = formatter.format_text(output, text)
    assert formatter.format_text(output, formatted) == formatted
    output.write_text(formatted)
print('Created finite memory-sequence validator: 240 native, 20 rejection and 100 complete labeled-action/inverse cases.')
