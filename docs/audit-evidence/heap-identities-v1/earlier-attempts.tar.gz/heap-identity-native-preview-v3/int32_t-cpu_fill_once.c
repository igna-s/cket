#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
typedef int32_t word;
int main(int argc,char **argv){
unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):8;if(rounds>64)return 2;
quant word *p=calloc(1,sizeof *p);if(!p)return 2;
quant bool y=superposition(0,1),flag=superposition(0,1);p[0]=(word)0;
if(y)phase(.73);if(flag)phase(.31);ownership_checkpoint("before");
unsigned calls=0;
for(unsigned i=0;i<rounds;++i){memset((void*)p,(++calls,0),1);}
ownership_checkpoint("after");free((void*)p);measure(y);measure(flag);
return calls!=rounds;
}
