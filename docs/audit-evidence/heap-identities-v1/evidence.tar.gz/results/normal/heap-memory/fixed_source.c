#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char *);
int main(void){quant uint8_t *p=calloc(2,1);if(!p)return 2;quant uint8_t v=7;memcpy((void*)p,&v,1);unsigned a=measure(p[0]),b=measure(v);free((void*)p);return a!=7||b!=7;}