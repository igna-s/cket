import json
import os
from pathlib import Path
import subprocess

root=Path('/tmp/quantum-audit-isolated-20261017')
compiler=root/'build/coherent-store-source-v4'
output=root/'build/coherent-scope-probe-v4'
output.mkdir()
path=output/'inactive-scoped-borrow.c'
path.write_text('''#include <quantum.h>
void ownership_checkpoint(const char*);
int main(void){
quant bool x=superposition(0,1),y=superposition(0,1),control=0;
if(y)phase(.73);ownership_checkpoint("before");
{quant bool saved=y^1;if(control)y=x^0;if(saved)phase(.47);}
ownership_checkpoint("after");
measure(y);measure(x);measure(control);return 0;}
''')
trace=root/'build/quantum-nature-probe-v4/trace.o'
binary=output/'inactive-scoped-borrow'
env=dict(os.environ,CC='gcc-11',CKET_SIMULATOR='sparse',CKET_SEED='7')
records=[]
def run(label,command):
    result=subprocess.run(command,cwd=compiler,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    (output/(label+'.log')).write_text(result.stdout)
    records.append(dict(command=command,exit_code=result.returncode,log=label+'.log'))
    (output/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode==0,result.stdout
    return result.stdout
run('compile',[str(compiler/'build/cket'),str(path),'-O2','-Wl,'+str(trace),
               '-Wl,--wrap=qc_create_sparse','-Wl,--wrap=__cket_apply','-o',str(binary)])
log=run('execute',[str(binary)])
points=[json.loads(line) for line in log.splitlines() if line.startswith('{')]
purities=[]
for point in points:
    register=next(r for r in point['registers'] if r['name']=='y' and not r['history'])
    wire=register['wires'][0]
    blocks={}
    for basis,real,imag in point['state']:
        basis=int(basis,0)
        blocks.setdefault(basis&~(1<<wire),{})[(basis>>wire)&1]=complex(real,imag)
    rho={}
    for block in blocks.values():
        for a,left in block.items():
            for b,right in block.items():
                rho[a,b]=rho.get((a,b),0j)+left*right.conjugate()
    purities.append(sum(abs(value)**2 for value in rho.values()))
report=dict(status='observed',source_purities=purities,measurements=points[-1]['measurements'],
            resets=points[-1]['resets'],meaning='An inactive branch must not prevent the scoped borrow inverse from restoring a pure owner after phase kickback.')
(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
