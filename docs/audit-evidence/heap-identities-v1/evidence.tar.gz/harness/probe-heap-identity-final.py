import json
import os
from pathlib import Path
import subprocess

root=Path('/tmp/quantum-audit-isolated-20261017')
compiler=root/'build/heap-identity-source-v1'
env=dict(os.environ,COHERENCE_COMPILER_ROOT=str(compiler),COHERENCE_VERSION='heap-identity-final-v1')
for script in ('probe-heap-identities.py','probe-inactive-coherence.py'):
    subprocess.run(['python3',str(root/'build'/script)],cwd=root,env=env,check=True)
folder=root/'build/heap-identity-scope-final-v1'
code=(root/'build/probe-coherent-scope.py').read_text()
code=code.replace("root/'build/coherent-store-source-v4'","root/'build/heap-identity-source-v1'")
code=code.replace("root/'build/coherent-scope-probe-v4'","root/'build/heap-identity-scope-final-v1'")
trace=root/'build/heap-identity-source-v1/build/identity-final-trace.o'
subprocess.run(['gcc-11','-std=c11','-O1','-c',str(root/'tests/ownership_trace.c'),'-o',str(trace)],check=True)
code=code.replace("root/'build/quantum-nature-probe-v4/trace.o'",repr(str(trace)))
exec(compile(code,'probe-coherent-scope.py','exec'))
scope=json.loads((folder/'summary.json').read_text())
identity=json.loads((root/'build/heap-identity-probe-heap-identity-final-v1/summary.json').read_text())
joint=json.loads((root/'build/inactive-coherence-probe-heap-identity-final-v1/summary.json').read_text())
assert all(abs(p-1)<1e-9 for case in identity for p in case['joint_purities'])
assert abs(scope['source_purities'][1]-.5)<1e-9
assert sum(case['inactive_density_max_error']>.49 for case in joint)==1
print('Two heap identity counterexamples corrected; scoped borrow and coherent nonidentity heap copy remain open.',flush=True)
