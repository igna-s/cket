import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

root=Path('/tmp/quantum-audit-isolated-20261017')
mode,version=sys.argv[1:]
project=root/('build/heap-identity-source-'+version)
target=project if mode=='normal' else root/('build/heap-identity-sanitized-'+version)
assert json.loads((target/'build-exit.json').read_text())['exit_code']==0
output=root/('build/heap-identity-'+mode+'-results-'+version)
output.mkdir()
env=dict(os.environ,CC='gcc-11',CKET_SEED='7',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode=='sanitized':
    env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11')
records=[]
def run(label,command):
    with (output/(label+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
    records.append(dict(command=command,exit_code=result.returncode,log=label+'.log'))
    (output/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,result.returncode,(output/(label+'.log')).read_text()[-2000:],flush=True)
    assert result.returncode==0
extra=['--sanitized'] if mode=='sanitized' else []
for name,levels in [('heap-identities',['O0','O2'] if mode=='normal' else ['O1']),
                    ('heap-memory',['O2' if mode=='normal' else 'O1']),
                    ('coherent-overwrites',['O2' if mode=='normal' else 'O1'])]:
    run(name,['python3','scripts/validate-'+name+'.py','--compiler-root',str(target),
              '--output',str(output/name),'--levels',*levels,*extra])
for name in ('validate_heap_identities','validate_heap','validate_memset','validate_runtime_memory','validate_runtime_versions'):
    run(name,[str(target/'build'/name)])
run('core',[str(target/'build/cket_tests'),str(target)])
if mode=='normal':
    run('block05',['bash','scripts/run-block.sh','05'])
hashes=runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()
assert hashes==json.loads((project/'source-hashes.json').read_text())
(output/'summary.json').write_text(json.dumps(dict(status='passed',mode=mode,source_files=len(hashes),commands=len(records)),indent=2)+'\n')
print('PASS unchanged',len(hashes),'frozen inputs',flush=True)
