import json
import math
import os
from pathlib import Path
import subprocess

root=Path('/tmp/quantum-audit-isolated-20261017')
compiler=Path(os.environ.get('COHERENCE_COMPILER_ROOT',str(root/'build/runtime-memory-source-v3')))
out=root/('build/inactive-coherence-probe-'+os.environ.get('COHERENCE_VERSION','v1'))
out.mkdir()
env=dict(os.environ,CC='gcc-11',CKET_SIMULATOR='sparse',CKET_SEED='7')
def run(label,argv):
    r=subprocess.run(argv,cwd=compiler,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
    (out/(label+'.log')).write_text(r.stdout)
    assert r.returncode==0,r.stdout
    return r.stdout
trace=root/'build/quantum-nature-probe-v4/trace.o'
links=['-Wl,'+str(trace),'-Wl,--wrap=qc_create_sparse','-Wl,--wrap=__cket_apply']
def density(point,selection,control_value=None):
    names={r['name']:r for r in point['registers'] if r['name'] and not r['history']}
    selected=[w for name in selection for w in names[name]['wires']]
    if control_value is not None:
        wire=names['control']['wires'][0]
    mask=sum(1<<w for w in selected)
    blocks={}
    norm=0
    for b,real,imag in point['state']:
        b=int(b,0);a=complex(real,imag)
        if control_value is not None and (b>>wire)&1!=control_value:
            continue
        norm+=abs(a)**2
        local=sum(((b>>w)&1)<<i for i,w in enumerate(selected))
        blocks.setdefault(b&~mask,{})[local]=a
    rho={}
    for block in blocks.values():
        for a,left in block.items():
            for b,right in block.items():
                rho[a,b]=rho.get((a,b),0j)+left*right.conjugate()/norm
    return rho
records=[]
for effect in ('memcpy','assignment','heap'):
    for control in ('0','superposition(0,1)'):
        label=effect+('-off' if control=='0' else '-coherent')
        allocation='quant uint8_t *p=calloc(1,1);if(!p)return 2;' if effect=='heap' else ''
        initial='memcpy((void*)p,(const void*)&y,1);' if effect=='heap' else ''
        operation={'memcpy':'memcpy((void*)&y,(const void*)&x,n);','assignment':'y=x^0;',
                   'heap':'memcpy((void*)p,(const void*)&x,n);'}[effect]
        path=out/(label+'.c');binary=out/label
        path.write_text('#include <quantum.h>\n#include <stdlib.h>\n#include <string.h>\nvoid ownership_checkpoint(const char*);\n'
                        'int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):1;'+allocation+
                        'quant uint8_t x=superposition(0,1),y=superposition(0,1);quant bool control='+control+';'
                        'if(x)phase(.31);if(y)phase(.73);'+initial+'ownership_checkpoint("before");if(control){'+operation+
                        '}ownership_checkpoint("after");'+('free((void*)p);' if effect=='heap' else '')+
                        'measure(y);measure(x);measure(control);return 0;}\n')
        run(label+'-compile',[str(compiler/'build/cket'),str(path),'-O2',*links,'-o',str(binary)])
        log=run(label+'-run',[str(binary),'1'])
        points=[json.loads(line) for line in log.splitlines() if line.startswith('{')]
        if effect=='heap':
            for point in points:
                identity=point['heaps'][0]['ids'][0]
                next(r for r in point['registers'] if r['id']==identity)['name']='target'
            target='target'
        else:
            target='y'
        selection=['y',target] if effect=='heap' else [target]
        before,after=[density(p,selection,0) for p in points]
        error=max(abs(before.get(k,0j)-after.get(k,0j)) for k in before.keys()|after.keys())
        purity=[sum(abs(v)**2 for v in rho.values()) for rho in (before,after)]
        record=dict(case=label,inactive_density_max_error=error,purities=purity,
                    before_measurements=points[0]['measurements'],after_measurements=points[1]['measurements'],
                    resets=points[1]['resets'])
        records.append(record)
        print(json.dumps(record),flush=True)
(out/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
