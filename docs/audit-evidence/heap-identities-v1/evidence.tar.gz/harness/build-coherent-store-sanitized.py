import json
import os
from pathlib import Path
import subprocess
import sys

root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/('build/coherent-store-source-'+sys.argv[1])
destination=root/('build/coherent-store-sanitized-'+sys.argv[1])
destination.mkdir()
prefix=(project/'scripts/sanitize-all.sh').read_text().split('\nexport CKET_REAL_GCC="$real_cc"')[0]
line=next(line for line in prefix.splitlines() if line.startswith('cd '))
prefix=prefix.replace(line,'cd '+str(project))
script=destination/'build-sanitized.sh'
script.write_text(prefix+'\n')
env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SAN_ROOT=str(destination))
command=['bash',str(script)]
with (destination/'build.log').open('x') as log:
    result=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
(destination/'build-exit.json').write_text(json.dumps(dict(command=command,exit_code=result.returncode))+'\n')
print('sanitized build exit',result.returncode,flush=True)
if result.returncode:
    print((destination/'build.log').read_text()[-5000:],flush=True)
raise SystemExit(result.returncode)
