import json
import os
from pathlib import Path
import subprocess
import sys
root=Path('/tmp/quantum-audit-isolated-20261017/build/coherent-store-source-'+sys.argv[1])
command=['bash','scripts/build.sh']
with (root/'build-normal.log').open('x') as log:
    result=subprocess.run(command,cwd=root,env=dict(os.environ,CC='gcc-11',CXX='g++-11'),stdout=log,stderr=subprocess.STDOUT)
(root/'build-exit.json').write_text(json.dumps(dict(command=command,exit_code=result.returncode))+'\n')
print('build exit',result.returncode,flush=True)
if result.returncode:
    print((root/'build-normal.log').read_text()[-6000:],flush=True)
raise SystemExit(result.returncode)
