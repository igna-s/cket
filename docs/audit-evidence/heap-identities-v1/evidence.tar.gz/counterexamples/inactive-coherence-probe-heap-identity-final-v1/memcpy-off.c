#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):1;quant uint8_t x=superposition(0,1),y=superposition(0,1);quant bool control=0;if(x)phase(.31);if(y)phase(.73);ownership_checkpoint("before");if(control){memcpy((void*)&y,(const void*)&x,n);}ownership_checkpoint("after");measure(y);measure(x);measure(control);return 0;}
