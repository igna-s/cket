#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(1,1);if(!p)return 2;
quant uint8_t y=superposition(0,1);if(y)phase(.73);
memcpy((void*)p,(const void*)&y,1);ownership_checkpoint("before");
memset((void*)p,p[0],1);ownership_checkpoint("after");free((void*)p);measure(y);return 0;}
