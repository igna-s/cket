#include <quantum.h>
void update(quant bool x,const int*p,int n){if(n&&*p)return;x^=true;}
int main(int argc,char**argv){const int*p=0;int n=argc>1?argv[1][0]-'0':0;quant bool c=superposition(0,1),x=false;if(c)update(x,p,n);unsigned a=measure(x),b=measure(c);return a!=b;}
