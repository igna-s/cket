#include <quantum.h>
void update(quant bool x,int n){if(n)return;x^=true;}
int main(int argc,char**argv){int data[1]={1};unsigned index=(unsigned)argc;quant bool c=false,x=false;if(c)update(x,data[index]);return measure(x)||measure(c);}
