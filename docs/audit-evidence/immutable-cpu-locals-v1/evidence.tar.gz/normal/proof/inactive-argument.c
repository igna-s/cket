#include <quantum.h>
void update(quant bool x,int n){x^=n;if(n)return;x^=true;}
int main(int argc,char**argv){int k=argc>1?argv[1][0]-'0':0;quant bool c=false,x=false;if(c)update(x,10/k);return measure(x)||measure(c);}
