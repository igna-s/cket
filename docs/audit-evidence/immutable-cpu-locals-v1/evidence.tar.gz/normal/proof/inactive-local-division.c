#include <quantum.h>
void update(quant bool x,int n){int local=10/n;if(local)return;x^=true;}
int main(int argc,char**argv){int n=argc>1?argv[1][0]-'0':0;quant bool c=false,x=false;if(c)update(x,n);return measure(x)||measure(c);}
