#include <quantum.h>
static int visits;void update(quant bool x,int n){if(n)return;++visits;x^=true;}
int main(int argc,char**argv){int n=argc;quant bool c=superposition(0,1),x=false;if(c)update(x,n);measure(x);measure(c);return 0;}
