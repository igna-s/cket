#include <quantum.h>
void update(quant bool x,const int*p){if(*p)return;x^=true;}
int main(int argc,char**argv){const int*p=0;quant bool c=false,x=false;if(c)update(x,p);return measure(x)||measure(c);}
