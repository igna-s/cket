#include <quantum.h>
void update(quant bool x,int n){if(n)return;x^=true;}
int main(int argc,char**argv){int n=0;quant bool c=superposition(0,1),x=false;if(c)update(x,n++);measure(x);measure(c);return 0;}
