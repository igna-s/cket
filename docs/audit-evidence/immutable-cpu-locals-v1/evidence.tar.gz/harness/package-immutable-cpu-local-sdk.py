import json,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/immutable-cpu-local-source-v3'
assert json.loads((r/'build/immutable-cpu-local-normal-proof-v3/summary.json').read_text())['status']=='passed'
shutil.copy2(r/'build/coherent-return-source-v1/LICENSE',project/'LICENSE')
s=(r/'build/package-coherent-return-sdk-complete.py').read_text()
for old,new in [('build/coherent-return-source-v1','build/immutable-cpu-local-source-v3'),('build/coherent-return-sdk-stage-v1','build/immutable-cpu-local-sdk-stage-v1'),('build/coherent-return-sdk-results-v1','build/immutable-cpu-local-sdk-results-v1'),('output/sdk/coherent-returns','output/sdk/immutable-locals')]:
    assert old in s;s=s.replace(old,new)
s=s.replace('Los procedimientos void admiten retornos CPU anticipados y llamadas coherentes con predicados CPU puros.','Los procedimientos void admiten retornos CPU anticipados y locales enteros privados, puros e inmutables desde llamadores coherentes.')
target=r/'build/package-immutable-cpu-local-sdk-complete.py';target.write_text(s)
exec(compile(s,str(target),'exec'))
destination=r/'output/sdk/immutable-locals'
(destination/'example_coherent.c').write_text('''#include <quantum.h>
#include <stdio.h>
#include <stdlib.h>

static void transform(quant bool target, unsigned count) {
    unsigned limit = count + 1;
    bool done = count == 2;
    if (done)
        return;
    if (limit & 1)
        target ^= true;
    if (!target)
        phase(3.141592653589793);
}

int main(int argc, char **argv) {
    unsigned count = argc > 1 ? (unsigned)strtoul(argv[1], NULL, 10) : 3;
    quant bool control = superposition(0, 1), target = false;
    if (control)
        transform(target, count);
    if (count != 2 && !((count + 1) & 1)) {
        /* The phase is selected on target=0 and becomes relative to control. */
    } else if (count != 2) {
        if (control)
            target ^= true;
    }
    fourier(control);
    unsigned c = measure(control), t = measure(target);
    printf("count=%u control=%u target=%u\\n", count, c, t);
    return t || c != (count != 2 && !((count + 1) & 1));
}
''')
shutil.copy2(project/'examples/blocks/05/heap_iterations.c',destination/'example_heap.c')
(destination/'run_coherent_demo.cmd').write_text('@echo off\ncall "%~dp0compile_and_run.cmd" "%~dp0example_coherent.c"\nexit /b %errorlevel%\n')
print('Immutable CPU local SDK ready for Windows workflow checks',flush=True)
