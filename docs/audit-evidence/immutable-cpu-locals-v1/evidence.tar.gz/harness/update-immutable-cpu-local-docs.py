from pathlib import Path
import runpy
r=Path('/tmp/quantum-audit-isolated-20261017')
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
names=['README.md','output/sdk/README.es.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/c11-procedure-returns.md','docs/perfil-c-cotidiano.es.md','docs/paper/README.md','docs/paper/current-evidence-map-2026-10-26.es.md']
texts={n:(r/n).read_text() for n in names}
for n in ['README.md','output/sdk/README.es.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/paper/current-evidence-map-2026-10-26.es.md']:
    texts[n]=texts[n].replace('sdk/coherent-returns/','sdk/immutable-locals/').replace('sdk\\coherent-returns\\','sdk\\immutable-locals\\').replace('(coherent-returns/README.es.md)','(immutable-locals/README.es.md)')
def replace(n,old,new):
    assert texts[n].count(old)==1,(n,old);texts[n]=texts[n].replace(old,new)
replace('README.md','The compiler uses GCC\'s real C frontend.', '''Private, initialized CPU integer locals now compose with those calls when they are never
written again and their addresses do not escape. The
[note](docs/paper/private_cpu_locals_note.es.md) and
[evidence](docs/audit-evidence/immutable-cpu-locals-v1/README.es.md) identify the new compiler,
normal/sanitized state and inverse checks, and checked Windows SDK workflows. Mutable locals,
coherent loops and general lifetimes remain pending.

The compiler uses GCC's real C frontend.''')
replace('output/sdk/README.es.md','SDK con retornos y llamadas coherentes','SDK con locales CPU privados y llamadas coherentes')
replace('docs/estado-general-del-proyecto.es.md','**Integración completa aprobada para `ac8f5bc`:**','''**Locales CPU privados implementados:** se admiten `bool` y enteros automáticos inicializados
con expresiones CPU puras, sin escrituras posteriores ni dirección tomada, dentro de llamadas
coherentes. La [nota](paper/private_cpu_locals_note.es.md) y la
[evidencia](audit-evidence/immutable-cpu-locals-v1/README.es.md) registran 800 puntos de estado
y 400 inversas en normal; 160 y 80 con ASan/UBSan. El SDK recomendado incluye este plugin y
el nuevo ejemplo. Siguen pendientes locales mutables, bucles coherentes y vidas generales.

**Integración completa aprobada para `ac8f5bc`:**''')
replace('docs/estado-general-del-proyecto.es.md','El compilador de 244 entradas tiene su propia campaña dirigida aprobada; su','El compilador de llamadas coherentes `cba9759`, anterior al bloque de locales privados, tiene su campaña dirigida aprobada; su')
replace('docs/estado-general-del-proyecto.es.md','Solo se habilitan la bandera y ramas privadas del compilador;\nsiguen rechazados los efectos CPU observables y las salidas decididas por datos cuánticos sin medir.','Siguen rechazados los efectos CPU observables y las salidas decididas por datos cuánticos sin medir.')
replace('docs/c11-procedure-returns.md','cuántico. Solo la bandera privada del compilador recibe permiso para crear almacenamiento y cambiar\nsu valor.','cuántico. La bandera privada del compilador puede cambiar su valor al retornar. También se\nadmiten locales enteros CPU privados, inicializados una vez y sin escrituras posteriores ni\ndirección tomada; su [nota técnica](paper/private_cpu_locals_note.es.md) detalla el análisis.')
texts['docs/perfil-c-cotidiano.es.md']+='''\nLos [locales enteros CPU privados](paper/private_cpu_locals_note.es.md) ya pueden inicializarse
con expresiones puras dentro de una llamada coherente. Se excluyen escrituras posteriores,
direcciones tomadas, almacenamiento estático, `volatile`, `_Atomic`, punteros y agregados. El
SDK actualizado ejecuta el ejemplo; los locales mutables y los bucles coherentes siguen abiertos.
'''
texts['docs/paper/README.md']+='''\nLa [nota de locales CPU privados](private_cpu_locals_note.es.md) y su
[cápsula](../audit-evidence/immutable-cpu-locals-v1/README.es.md) califican locales enteros
puros, inmutables y sin alias desde llamadores coherentes. Las 244 entradas tienen hashes
distintos de las 244 de la ampliación anterior; la cantidad de archivos no es una identidad.
La [integración completa de 242 entradas](../audit-evidence/full-ci-cpu-returns-v1/README.es.md)
terminó aprobada. Los pendientes de CI de los párrafos históricos conservan su contexto;
la integración completa de los cambios posteriores sigue pendiente.
'''
texts['docs/paper/current-evidence-map-2026-10-26.es.md']+='''\nLa [ampliación de locales CPU privados](private_cpu_locals_note.es.md) también tiene 244
entradas, con hashes distintos de `cba9759`. Su
[campaña dirigida](../audit-evidence/immutable-cpu-locals-v1/README.es.md) y su SDK comprueban
esa ampliación; el CI enlazado de `cba9759` corresponde a su predecesor. Ni la cantidad de
archivos ni el CI de una revisión sustituyen la identidad de fuentes de la otra.
'''
replace('docs/entrega-utilizable-2026-10-26.es.md','count=1 control=1 target=0','count=3 control=1 target=0')
texts['docs/entrega-utilizable-2026-10-26.es.md']+='''\nEl SDK recomendado añade locales enteros CPU privados, puros e inmutables. Su
[nota](paper/private_cpu_locals_note.es.md) y
[evidencia](audit-evidence/immutable-cpu-locals-v1/README.es.md) identifican las fuentes y
los límites. Su integración completa queda pendiente; el CI de `cba9759` enlazado arriba
corresponde al compilador anterior de llamadas coherentes.
'''
for n,s in texts.items():(r/n).write_text(fmt(r/n,s))
(r/'build/immutable-cpu-local-docs.txt').write_text('\n'.join(names)+'\n')
print('Updated',len(names),'current documents')
