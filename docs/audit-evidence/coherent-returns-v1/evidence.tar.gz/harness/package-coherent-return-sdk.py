import json,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
commands=json.loads((r/'build/coherent-return-results-v1/commands.json').read_text())
assert any(row['name']=='normal-example-3' and row['exit_code']==0 for row in commands)
assert json.loads((r/'build/coherent-return-normal-coherent-v1/summary.json').read_text())['status']=='passed'
s=(r/'build/package-procedure-return-sdk-complete.py').read_text()
s=s.replace('build/procedure-return-source-v2','build/coherent-return-source-v1')
s=s.replace('build/procedure-return-sdk-stage-v1','build/coherent-return-sdk-stage-v1')
s=s.replace('build/procedure-return-sdk-results-v1','build/coherent-return-sdk-results-v1')
s=s.replace('output/sdk/cpu-returns','output/sdk/coherent-returns')
s=s.replace('source_files=242','source_files=244').replace('242 entradas','244 entradas')
s=s.replace('examples/procedure_returns.c','examples/coherent_returns.c')
s=s.replace('Los procedimientos void admiten retornos CPU anticipados en bloques y bucles.','Los procedimientos void admiten retornos CPU anticipados y llamadas coherentes con predicados CPU puros.')
s=s.replace('los retornos bajo control cuántico y la ABI general siguen pendientes.','las salidas decididas por datos cuánticos, los bucles coherentes y la ABI general siguen pendientes.')
target=r/'build/package-coherent-return-sdk-complete.py';target.write_text(s)
exec(compile(s,str(target),'exec'))
destination=r/'output/sdk/coherent-returns'
project=r/'build/coherent-return-source-v1'
shutil.copy2(project/'examples/coherent_returns.c',destination/'example_coherent.c')
shutil.copy2(project/'examples/blocks/05/heap_iterations.c',destination/'example_heap.c')
(destination/'run_coherent_demo.cmd').write_text('@echo off\ncall "%~dp0compile_and_run.cmd" "%~dp0example_coherent.c"\nexit /b %errorlevel%\n')
print('Coherent caller return SDK ready for Windows workflow checks',flush=True)
