import cmath,json,os,runpy,shutil,subprocess
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
p=r/'build/coherent-return-dev-v1';p.mkdir();(p/'build').mkdir()
for n in ('src','tests','examples','include','scripts'):(p/n).symlink_to(r/n,target_is_directory=True)
shutil.copy2(r/'cket',p/'cket')
old=r/'build/procedure-return-source-v2/build'
for n in ('cket','cket_backend','cket_runtime.o','libcket_quantum.a','gcc-version.txt'):shutil.copy2(old/n,p/'build'/n)
h=Path(subprocess.check_output(['gcc-11','-print-file-name=plugin'],text=True).strip())/'include'
if not (h/'gcc-plugin.h').exists():h=r/'.deps/gcc'/h.relative_to('/')
cmd=['g++-11','-std=c++17','-O2','-Wall','-Wextra','-Wno-unused-parameter','-Wno-format-diag','-fPIC','-shared','-fno-rtti','-I'+str(h),'-I'+str(r/'.deps/gcc/usr/include'),'-I'+str(r/'.deps/gcc/usr/include/x86_64-linux-gnu'),'src/cket_plugin.cpp','-o',str(p/'build/cket_plugin.so')]
z=subprocess.run(cmd,cwd=p,text=True,capture_output=True);(p/'plugin.log').write_text(z.stdout+z.stderr)
assert z.returncode==0,z.stdout+z.stderr
env=dict(os.environ,CC='gcc-11',CKET_SIMULATOR='sparse',CKET_SEED='7')
records=[]
def run(name,cmd):
    z=subprocess.run(cmd,cwd=p,env=env,text=True,capture_output=True,timeout=60)
    (p/(name+'.log')).write_text(z.stdout+z.stderr)
    records.append(dict(name=name,command=cmd,exit_code=z.returncode,stdout=z.stdout,stderr=z.stderr))
    (p/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,z.returncode,(z.stdout+z.stderr)[-1500:],flush=True)
    return z
adapter=p/'trace.o'
assert run('trace',['gcc-11','-std=c11','-O1','-c',str(r/'tests/heap_transfer_trace.c'),'-o',str(adapter)]).returncode==0
links=['-Wl,'+str(adapter)]+['-Wl,--wrap='+n for n in ('qc_create_sparse','__cket_apply','qc_apply','qc_apply_bound','__cket_read_byte')]
source=p/'phase.c'
source.write_text('#include <quantum.h>\n#include <stdlib.h>\nvoid ownership_checkpoint(const char*);void update(quant bool x,unsigned n){if(!n)return;x^=true;if(x)phase(.17);if(n==2)return;x^=true;phase(.23);}\nint main(int argc,char**argv){unsigned n=argc>1?strtoul(argv[1],0,10):0;quant bool c=superposition(0,1),x=superposition(0,1);if(c)phase(.19);if(x)phase(-.23);ownership_checkpoint("before");if(c)update(x,n);ownership_checkpoint("after");measure(c);measure(x);return 0;}\n')
z=run('phase-build',[str(p/'build/cket'),str(source),'-O0',*links,'-o',str(p/'phase')]);assert z.returncode==0
ref=runpy.run_path(str(r/'scripts/validate-ownership.py'))
for n in range(5):
    z=run('phase-'+str(n),[str(p/'phase'),str(n)]);assert z.returncode==0
    points=[json.loads(s) for s in z.stdout.splitlines() if s.startswith('{')]
    assert [x['tag'] for x in points]==['before','after']
    state={0:1+0j};gates=[]
    for point in points:
        assert point['measurements']==point['resets']==0
        names={x['name']:x for x in point['registers'] if x['name']}
        cw,xw=names['c']['wires'][0],names['x']['wires'][0]
        expected={}
        for control in (0,1):
            for initial in (0,1):
                output=initial;angle=.19*control-.23*initial
                if point['tag']=='after' and control and n:
                    angle+=.17*(1-initial)+(.23 if n!=2 else 0)
                    output^=n==2
                expected[(control<<cw)|(output<<xw)]=.5*cmath.exp(1j*angle)
        actual={int(b,0):complex(a,c) for b,a,c in point['state']}
        state=ref['evolve'](state,point['gates']);ref['equal_states'](actual,state);ref['equal_states'](actual,expected)
        gates.extend(point['gates'])
    inverse=[[k,w,m,pat,-a if k==2 else a] for k,w,m,pat,a in reversed(gates)]
    ref['equal_states'](ref['evolve'](state,inverse),{0:1+0j})
cases=[
('inactive-arithmetic','void update(quant bool x,int n){if(n)return;x^=true;}','int k=argc>1?argv[1][0]-\'0\':0;quant bool c=false,x=false;if(c)update(x,10/k);return measure(x)||measure(c);'),
('inactive-load','void update(quant bool x,const int*p){if(*p)return;x^=true;}','const int*p=0;quant bool c=false,x=false;if(c)update(x,p);return measure(x)||measure(c);'),
('argument-effect','void update(quant bool x,int n){if(n)return;x^=true;}','int n=0;quant bool c=superposition(0,1),x=false;if(c)update(x,n++);measure(x);measure(c);return 0;')]
for name,definition,body in cases:
    q=p/(name+'.c');q.write_text('#include <quantum.h>\n'+definition+'\nint main(int argc,char**argv){'+body+'}\n')
    z=run(name+'-build',[str(p/'build/cket'),str(q),'-O0','-o',str(p/name)])
    if name=='argument-effect':assert z.returncode==1 and 'must be pure' in z.stdout+z.stderr
    else:
        assert z.returncode==0
        assert run(name,[str(p/name)]).returncode==0
(p/'terminal.json').write_text(json.dumps(dict(status='passed',full_state_checkpoints=10,complete_inverses=5))+'\n')
