from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
buffers={}
def read(name):
    if name not in buffers:buffers[name]=(r/name).read_text()
    return buffers[name]
def change(name,old,new,count=1):
    s=read(name);assert s.count(old)==count,(name,old,s.count(old));buffers[name]=s.replace(old,new)
for name in ('README.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md'):
    buffers[name]=read(name).replace('output/sdk/cpu-returns','output/sdk/coherent-returns').replace('output\\sdk\\cpu-returns','output\\sdk\\coherent-returns').replace('run_return_demo.cmd','run_coherent_demo.cmd')
change('README.md','General CFG and owned early results remain pending.','General CFG and owned early results remain pending.\n\nPure CPU exit predicates now compose with a coherent caller. The [technical note](docs/paper/coherent_returns_note.es.md) explains controlled global phase, private CPU flags, and inactive operands. The [244-input evidence](docs/audit-evidence/coherent-returns-v1/README.es.md) records complete states, independent gate inverses and directed normal/sanitized regressions.')
change('output/sdk/README.es.md','[SDK con retornos CPU](cpu-returns/README.es.md)','[SDK con retornos y llamadas coherentes](coherent-returns/README.es.md)')
name='docs/entrega-utilizable-2026-10-26.es.md'
change(name,'`limit=2 visited=2 result=0 interference=0`','`count=1 control=1 target=0`')
change(name,'242 entradas exactas','244 entradas exactas')
change(name,'La [ampliación de retornos]','La [ampliación anterior de retornos]')
change(name,'La [corrección de entradas de función]','La [composición coherente](paper/coherent_returns_note.es.md) permite llamar esos procedimientos desde un control cuántico cuando sus predicados CPU son puros. La [cápsula de 244 entradas](audit-evidence/coherent-returns-v1/README.es.md) añade 600 puntos de estado y 300 inversas entre normal y ASan/UBSan, con casos de X, fases, llamadas anidadas y ángulos clásicos. Mantiene separados sus alcances de las pruebas anteriores.\n\nLa [corrección de entradas de función]')
change(name,'El SDK nuevo de 242 entradas incluye la referencia\ncorregida y la ampliación de retornos.','El SDK de 242 entradas conserva la referencia corregida y los retornos CPU; el nuevo de 244 añade el llamador coherente.')
name='docs/estado-general-del-proyecto.es.md'
change(name,'**Retornos CPU implementados:**','**Retornos desde un llamador coherente:** los predicados CPU puros de salida ya seleccionan puertas bajo el control cuántico del llamador. Solo se habilitan la bandera y ramas privadas del compilador; siguen rechazados los efectos CPU observables y las salidas decididas por datos cuánticos sin medir. La [nota técnica](paper/coherent_returns_note.es.md) y su [evidencia de 244 entradas](audit-evidence/coherent-returns-v1/README.es.md) registran estados, fases e inversas normales e instrumentados. El SDK nuevo incluye el ejemplo de interferencia.\n\n**Retornos CPU implementados:**')
name='docs/paper/README.md'
change(name,'El [mapa de afirmaciones y evidencia actual]','La [nota de llamadas coherentes y retornos CPU](coherent_returns_note.es.md) añade la selección por predicados CPU puros desde un llamador cuántico. Explica cuándo una fase global del procedimiento se vuelve relativa y mantiene los límites de control, efectos y vidas. Su [cápsula de 244 entradas](../audit-evidence/coherent-returns-v1/README.es.md) registra estados, inversas y regresiones; no modifica los manuscritos históricos.\n\nEl [mapa de afirmaciones y evidencia actual]')
name='docs/paper/current-evidence-map-2026-10-26.es.md'
change(name,'[SDK de retornos CPU](../../output/sdk/cpu-returns/README.es.md), con 242 entradas','[SDK de llamadas coherentes](../../output/sdk/coherent-returns/README.es.md), con 244 entradas')
name='docs/c11-function-entries.md'
change(name,'owned early results and general\ncontrol flow keep their separate restrictions.','owned early results and general control flow keep their separate restrictions. Pure CPU exit predicates also compose with a coherent caller; [the technical note](paper/coherent_returns_note.es.md) records the new phase and inverse scope.')
name='docs/c11-controlled-operands.md'
change(name,'## División en una actualización inactiva','Los [retornos CPU desde llamadores coherentes](paper/coherent_returns_note.es.md) protegen también argumentos y predicados CPU puros mediante esa consulta simbólica. La protección cubre la evaluación previa del argumento, no solo su consumidor final. No habilita efectos CPU visibles ni lecturas implícitas de datos cuánticos.\n\n## División en una actualización inactiva')
name='docs/perfil-c-cotidiano.es.md'
change(name,'## Orden de trabajo','La [composición con un llamador coherente](paper/coherent_returns_note.es.md) ya admite esos retornos cuando los predicados CPU son puros. No habilita salidas decididas por datos cuánticos, efectos CPU observables, bucles coherentes ni vidas generales.\n\n## Orden de trabajo')
for name,s in buffers.items():(r/name).write_text(s)
print('Current documentation points to coherent caller SDK; historical packages preserved.')
