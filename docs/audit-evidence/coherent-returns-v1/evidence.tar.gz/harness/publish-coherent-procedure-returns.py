import hashlib,io,json,os,re,runpy,subprocess,tarfile
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/coherent-return-source-v1';sanitized=r/'build/coherent-return-sanitized-v1'
out=r/'build/coherent-return-results-v1'
sdk=r/'output/sdk/coherent-returns'
destination=r/'docs/audit-evidence/coherent-returns-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((project/'source-hashes.json').read_text())
before=json.loads((r/'build/procedure-return-source-v2/source-hashes.json').read_text())
terminal=json.loads((out/'terminal.json').read_text())
assert terminal['status']=='passed' and terminal['source_sha256']==source and len(source)==244
assert runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()==source
assert all(sha(project/n)==h for n,h in source.items())
assert all(row['exit_code']==0 for row in json.loads((out/'commands.json').read_text()))
matrices={};artifacts=terminal['artifacts_sha256']
for mode,target,counts in [('normal',project,(500,250,25,20)),('sanitized',sanitized,(100,50,5,4))]:
    coherent=json.loads((r/('build/coherent-return-'+mode+'-coherent-v1/summary.json')).read_text())
    ordinary=json.loads((r/('build/coherent-return-'+mode+'-ordinary-v1/summary.json')).read_text())
    assert coherent['status']==ordinary['status']=='passed'
    assert tuple(coherent[n] for n in ('full_state_checkpoints','complete_gate_inverses','native_boundary_executions','compile_rejections'))==counts
    assert (ordinary['native_executions'],ordinary['full_state_checkpoints'],ordinary['complete_gate_inverses'])==((700,500,250) if mode=='normal' else (140,100,50))
    matrices[mode]=dict(coherent=coherent,ordinary=ordinary)
    for label,phrase in [('validate_bindings','519 CPU binding checks passed;'),('validate_readonly_borrows','305 readonly borrow checks passed;'),('validate_function_entries','90 function entry checks passed;'),('core','395 passed, 0 failed'),('controlled','1270 controlled operand checks passed;')]:
        assert phrase in (out/(mode+'-'+label+'.log')).read_text()
    previous=r/('build/procedure-return-source-v2' if mode=='normal' else 'build/procedure-return-sanitized-v2')
    for n,h in artifacts[mode].items():
        assert sha(target/'build'/n)==h
        if n!='cket_plugin.so':assert h==sha(previous/'build'/n)
    for n,h in terminal['reused_artifacts_sha256'][mode].items():assert sha(target/'build'/n)==h
    assert sha(target/'build/cket_plugin.so')!=sha(previous/'build/cket_plugin.so')
production=[n for n in source if n.startswith('src/') and source[n]!=before.get(n)]
assert production==['src/cket_plugin.cpp','src/quantum_frontend.inc','src/quantum_semantics.inc']
for n in before:
    if n.startswith(('tests/','include/','src/engine/')):assert source[n]==before[n]
symbols=subprocess.check_output(['nm','-u',str(sanitized/'build/cket_plugin.so')],text=True)
assert '__asan_init' in symbols and '__ubsan_handle' in symbols
(out/'plugin-instrumentation.txt').write_text(symbols)
audit=json.loads((sdk/'sdk-audit.json').read_text())
assert audit['source_sha256']==source and audit['source_files']==244
assert audit['prebuilt_programs']==37 and audit['example_checks']==1509
assert audit['package_sha256']==sha(sdk/'cket-sdk-linux-x86_64.tar.gz')
assert all(row['exit_code']==0 for row in audit['commands'])
for n,h in artifacts['normal'].items():assert audit['package_files_sha256']['build/'+n]==h
windows=json.loads((r/'build/coherent-return-windows-results.json').read_text())
assert len(windows)==3 and all(row['exit_code']==0 for row in windows)
assert len(re.findall(r'^build/blocks/',(r/'build/coherent-return-windows-demo.log').read_text(),re.M))==37
assert 'count=1 control=1 target=0' in (r/'build/coherent-return-windows-coherent.log').read_text()
assert 'rounds=3 output=12 sum=30' in (r/'build/coherent-return-windows-heap.log').read_text()
assert sha(sdk/'example_coherent.c')==source['examples/coherent_returns.c']
audit['windows_launchers']=windows
audit['scope']='Prebuilt compiler and finite native programs with checked Windows workflows. Pure CPU exits compose with coherent callers in the documented state/phase/inverse families. General CFG, coherent loops, quantum-controlled exits, arbitrary lifetimes/ABI, full C11 and physical QPU remain pending.'
(sdk/'sdk-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
baseline=r/'build/coherent-return-baseline-v1';baseline.mkdir()
path=baseline/'call.c';path.write_text((r/'build/procedure-return-coherent-call-v1/call.c').read_text())
rows=[]
for label,target in [('previous',r/'build/procedure-return-source-v2'),('corrected',project)]:
    command=[str(target/'build/cket'),str(path),'--emit-ir','-O0','-o',str(baseline/(label+'.json'))]
    z=subprocess.run(command,cwd=target,env=dict(os.environ,CC='gcc-11'),text=True,capture_output=True)
    assert z.returncode==(1 if label=='previous' else 0),z.stdout+z.stderr
    if label=='previous':assert 'classical storage cannot be created coherently' in z.stdout+z.stderr
    rows.append(dict(label=label,command=command,exit_code=z.returncode,stdout=z.stdout,stderr=z.stderr))
(baseline/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
docs=['README.md','output/sdk/README.es.md','output/sdk/coherent-returns/README.es.md','docs/c11-procedure-returns.md','docs/c11-function-entries.md','docs/c11-controlled-operands.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/perfil-c-cotidiano.es.md','docs/paper/README.md','docs/paper/current-evidence-map-2026-10-26.es.md','docs/paper/coherent_returns_note.es.md','docs/audit-evidence/coherent-returns-v1/README.es.md']
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for n in docs:
    p=r/n;p.write_text(fmt(p,p.read_text()))
assert not (destination/'summary.json').exists()
def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.c','.py'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())
with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for n in source:tar.add(project/n,arcname='sources/'+n)
    raw(tar,'source-identities.json',dict(qualified=source,previous=before))
    raw(tar,'producer-artifacts.json',artifacts)
    raw(tar,'reused-artifacts.json',terminal['reused_artifacts_sha256'])
    tree(tar,out,'results/final')
    for mode in matrices:
        for label in ('coherent','ordinary'):tree(tar,r/('build/coherent-return-'+mode+'-'+label+'-v1'),mode+'/'+label)
    tree(tar,baseline,'baseline')
    tree(tar,r/'build/coherent-return-capture-comparison-v1','boundaries/existing-effect-rejection')
    tree(tar,r/'build/coherent-return-sdk-results-v1','sdk/results')
    for version in (1,2):tree(tar,r/('build/coherent-return-check-v'+str(version)),'earlier/check-'+str(version))
    for n in ('coherent-return-windows-results.json','coherent-return-windows-demo.log','coherent-return-windows-coherent.log','coherent-return-windows-heap.log'):
        tar.add(r/'build'/n,arcname='sdk/windows/'+n)
    for n in ('qualify-coherent-procedure-returns.py','probe-coherent-procedure-returns.py','probe-coherent-procedure-returns-v2.py','package-coherent-return-sdk.py','package-coherent-return-sdk-complete.py','update-coherent-return-docs.py','publish-coherent-procedure-returns.py'):
        tar.add(r/'build'/n,arcname='harness/'+n)
    for p in sorted(sdk.iterdir()):
        if p.is_file() and p.suffix!='.gz':tar.add(p,arcname='sdk/files/'+p.name)
    for n in docs:tar.add(r/n,arcname='documentation/'+n)
summary=dict(status='passed-pure-cpu-exits-with-coherent-callers-full-integration-pending',date='2026-10-27',base_commit='ac8f5bc',version='1.0.0-rc.3',source_files=244,source_sha256=source,changed_production_inputs=production,
    producer_artifacts_sha256=artifacts,rebuilt='GCC plugin, normal and ASan/UBSan',
    matrices=matrices,regressions_per_configuration=dict(bindings=519,readonly_borrows=305,function_entries=90,core=395,controlled_operands=1270),
    baseline=rows,sdk=dict(package_sha256=audit['package_sha256'],prebuilt_programs=37,normal_example_checks=1509,windows_workflows=3),
    scope='Finite four-label states, C formulas, controlled global/relative phases, X, nested calls and independent gates/inverses. Pure CPU guards and argument capture only; coherent loops, quantum-controlled exits, user locals/lifetimes, arbitrary aliases/ABI, quantum floats, complete C11 and full current CI/paper review remain pending. No physical QPU or speedup claim; cybersecurity stays classical.',
    artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=set(source)|set(docs)|{p.relative_to(r).as_posix() for p in sdk.iterdir() if p.is_file()}|{'docs/audit-evidence/coherent-returns-v1/summary.json','docs/audit-evidence/coherent-returns-v1/evidence.tar.gz'}
expected=json.loads((r/'build/procedure-return-git-expected.json').read_text());expected.update({n:sha(r/n) for n in names})
(r/'build/coherent-return-git-expected.json').write_text(json.dumps(expected,indent=2)+'\n')
changes={n for n in source if source[n]!=before.get(n)}
imports=(names-set(source))|changes|{'build/coherent-return-git-expected.json'}
(r/'build/coherent-return-final-import.txt').write_text('\n'.join(sorted(imports))+'\n')
(r/'build/coherent-return-format-import.txt').write_text('\n'.join(sorted(n for n in imports if not n.endswith('.gz') and not n.startswith('build/') and (not n.startswith('docs/audit-evidence/') or n.endswith('.md'))))+'\n')
print('Coherent caller returns ready:',len(expected),'exact files; source identity, normal/ASan states, regressions and Windows SDK verified.')
