#include <quantum.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
static void inner(quant const bool*x,unsigned n){if(!n)return;if(x[0])phase(.17);}
static void update(quant bool*x,unsigned n){if(!n)return;x[0]^=true;if(x[0])phase(.17);if(n==2)return;x[0]^=true;phase(.23);}
int main(int argc,char**argv){unsigned n=argc>1?(unsigned)strtoul(argv[1],0,10):0;quant bool x=superposition(0,1),control=superposition(0,1);if(x)phase(.37);if(control)phase(-.19);ownership_checkpoint("before");if(control)update(&x,n);if(x)phase(.41);ownership_checkpoint("after");measure(x);measure(control);return 0;}
