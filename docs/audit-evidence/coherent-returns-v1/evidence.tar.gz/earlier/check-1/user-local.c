#include <quantum.h>
void update(quant bool x,int n){int local=1;if(n)return;x^=local;}
int main(int argc,char**argv){int n=argc;quant bool c=superposition(0,1),x=false;if(c)update(x,n);measure(x);measure(c);return 0;}
