#include <quantum.h>
void update(quant bool x,int n){if(x)phase(n);}
int main(void){int n=1;quant bool x=superposition(0,1);update(x,n++);measure(x);return n!=2;}
