import json,os,runpy,subprocess,sys
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');mode=sys.argv[1]
project=r/'build/lazy-pending-source-v1'
target=project if mode=='normal' else r/'build/lazy-pending-sanitized-v1'
out=r/('build/lazy-pending-'+mode+'-results-v1');out.mkdir()
env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SEED='7')
env.pop('CKET_SIMULATOR',None)
if mode=='sanitized':
 env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
records=[]
def run(name,command,environment=env):
 z=subprocess.run(command,cwd=project,env=environment,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=1200)
 (out/(name+'.log')).write_text(z.stdout);records.append(dict(command=command,exit_code=z.returncode,log=name+'.log'))
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,z.returncode,z.stdout[-2600:],flush=True)
 assert z.returncode==0,z.stdout[-5000:]
 assert not any(x in z.stdout for x in ('ERROR: AddressSanitizer','runtime error:','internal compiler error:'))
extra=['--sanitized'] if mode=='sanitized' else []
flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie'] if mode=='sanitized' else []
demo=out/'lazy_values.c'
demo.write_text('''#include <quantum.h>
#include <stdio.h>
int main(void) {
    quant bool condition = false, value = false;
    quant bool previous = condition ? value++ : value--;
    unsigned old = measure(previous), next = measure(value), flag = measure(condition);
    printf("previous=%u value=%u condition=%u\\n", old, next, flag);
    return old != 0 || next != 1 || flag != 0;
}
''')
binary=out/'lazy_values'
run('demo-build',[str(target/'build/cket'),str(demo),'-O2' if mode=='normal' else '-O1',*flags,'-o',str(binary)])
run('demo',[str(binary)])
run('history',[str(target/'build/validate_history'),*(['--coherent-reference'] if mode=='sanitized' else [])])
run('expressions',[str(target/'build/validate_expressions')])
run('core',[str(target/'build/cket_tests'),str(target)])
run('string-writes',['python3','scripts/validate-string-writes.py','--compiler-root',str(target),
 '--output',str(out/'string-writes'),'--levels','O2' if mode=='normal' else 'O1',*extra])
if mode=='normal':run('block06',['bash','scripts/run-block.sh','06'])
h=runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()
assert h==json.loads((project/'source-hashes.json').read_text())
(out/'summary.json').write_text(json.dumps(dict(status='passed',mode=mode,source_files=len(h),commands=len(records),
 history_scope='full-2332' if mode=='normal' else 'focused-355'),indent=2)+'\n')
print('PASS unchanged frozen inputs',len(h),flush=True)
