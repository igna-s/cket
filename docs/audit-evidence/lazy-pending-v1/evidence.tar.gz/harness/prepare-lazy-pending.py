import json,runpy,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
names=['src/quantum_semantics.inc','tests/test_coherent_history.inc','tests/test_cpu_history.inc','tests/test_lazy_values.inc','tests/validate_history.c']
f=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for n in names:
 p=r/n;p.write_text(f(p,p.read_text()))
h=runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
base=r/'build/string-writes-examples-source-v2';old=json.loads((base/'source-hashes.json').read_text())
assert len(h)==237 and sorted(n for n in h if h[n]!=old[n])==sorted(names)
p=r/'build/lazy-pending-source-v1';p.mkdir()
for n in h:
 q=p/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/n,q)
(p/'.deps').symlink_to(r/'.deps',target_is_directory=True);(p/'cket').chmod(0o755)
(p/'source-hashes.json').write_text(json.dumps(h,indent=2)+'\n')
print('Frozen 237 inputs; one compiler file and four validator files changed',flush=True)
