import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');mode=sys.argv[1]
source=r/'build/lazy-pending-source-v1'
base=r/('build/string-writes-examples-source-v2' if mode=='normal' else 'build/string-writes-sanitized-v1')
target=source if mode=='normal' else r/'build/lazy-pending-sanitized-v1'
if mode=='sanitized':
 target.mkdir()
 for n in ('include','src','tests','examples','.deps'):(target/n).symlink_to(source/n,target_is_directory=True)
 shutil.copy2(source/'cket',target/'cket')
(target/'build').mkdir()
reused={}
for n in ('cket','cket_backend','libcket_quantum.a','cket_runtime.o','gcc-version.txt',*(['gcc-wrapper'] if mode=='sanitized' else [])):
 shutil.copy2(base/'build'/n,target/'build'/n)
 reused[n]=hashlib.sha256((target/'build'/n).read_bytes()).hexdigest()
plugin=Path(subprocess.check_output(['gcc-11','-print-file-name=plugin'],text=True).strip())/'include'
if not (plugin/'gcc-plugin.h').is_file():plugin=r/'.deps/gcc'/str(plugin).lstrip('/')
flags=['-O2'] if mode=='normal' else ['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
records=[]
def run(label,command):
 z=subprocess.run(command,cwd=source,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=600)
 (target/(label+'.log')).write_text(z.stdout);records.append(dict(command=command,exit_code=z.returncode,log=label+'.log'))
 (target/'build-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,z.returncode,z.stdout[-4000:],flush=True);assert z.returncode==0,z.stdout[-5000:]
run('plugin-build',['g++-11','-std=c++17',*flags,'-Wall','-Wextra','-Wno-unused-parameter','-Wno-format-diag',
 '-fPIC','-shared','-fno-rtti','-I'+str(plugin),'-I'+str(r/'.deps/gcc/usr/include'),'-I'+str(r/'.deps/gcc/usr/include/x86_64-linux-gnu'),
 str(source/'src/cket_plugin.cpp'),'-o',str(target/'build/cket_plugin.so')])
linkflags=[] if mode=='normal' else ['-fno-pie','-no-pie']
for n,files in [('validate_history',['tests/validate_history.c','tests/validation.c']),
 ('validate_expressions',['tests/validate_expressions.c','tests/validation.c']),('cket_tests',['tests/test_native.c','tests/validation.c'])]:
 run(n+'-build',['gcc-11','-std=c11',*flags,*linkflags,'-Wall','-Wextra','-Werror','-I'+str(source/'src/engine'),
  *[str(source/f) for f in files],str(target/'build/libcket_quantum.a'),'-lm','-o',str(target/'build'/n)])
(target/'build-exit.json').write_text(json.dumps(dict(exit_code=0,mode=mode,reused_artifact_sha256=reused,
 reuse_scope='Engine, runtime and drivers have no source changes relative to 6400aed; new plugin and validators built from the frozen 237-input snapshot.'))+'\n')
