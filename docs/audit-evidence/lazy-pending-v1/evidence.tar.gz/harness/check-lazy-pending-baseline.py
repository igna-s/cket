import json, os, subprocess
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
out = r / 'build/lazy-pending-baseline-v1'
out.mkdir()
source = r / 'build/lazy-pending-normal-results-v1/lazy_values.c'
command = [str(r / 'build/string-writes-examples-source-v2/build/cket'), str(source),
           '-O2', '-o', str(out / 'lazy_values')]
result = subprocess.run(command, env=dict(os.environ, CC='gcc-11'), text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
(out / 'compile.log').write_text(result.stdout)
signature = 'inactive source bits are not independently proven zero'
assert result.returncode == 1 and signature in result.stdout, result.stdout
(out / 'result.json').write_text(json.dumps(dict(command=command, exit_code=result.returncode,
    expected_diagnostic=signature, source=source.read_text(),
    scope='The published 6400aed compiler rejects the same defined-C demo accepted by the correction.'), indent=2) + '\n')
print('Confirmed exact baseline diagnostic:', signature)
