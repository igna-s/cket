import hashlib,json,os,re,runpy,shutil,subprocess,tarfile
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');project=r/'build/lazy-pending-source-v1'
san=r/'build/lazy-pending-sanitized-v1';out=r/'output/demo'
stage=r/'build/lazy-pending-demo-package-v1';stage.mkdir();(stage/'bin').mkdir()
source=stage/'lazy_values.c'
source.write_text('''#include <quantum.h>
#include <stdio.h>

int main(void) {
    quant bool condition = superposition(0, 1), value = superposition(0, 1);
    if (condition) phase(.19);
    if (value) phase(.31);
    quant bool previous = condition ? value++ : value--;
    if (previous) phase(.37);
    unsigned old = measure(previous), next = measure(value), flag = measure(condition);
    unsigned expected = flag ? 1u : !old;
    printf("previous=%u value=%u condition=%u expected=%u\\n", old, next, flag, expected);
    return next != expected;
}
''')
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text'];source.write_text(fmt(source,source.read_text()))
records=[]
for mode,target in [('normal',project),('sanitized',san)]:
 env=dict(os.environ,CC='gcc-11',CKET_SEED='7',CKET_SIMULATOR='sparse')
 flags=[]
 if mode=='sanitized':
  env.update(CC=str(san/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
  flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
 binary=stage/'bin/lazy_values' if mode=='normal' else r/'build/lazy-pending-sanitized-results-v1/demo-coherent'
 command=[str(target/'build/cket'),str(source),'-O2' if mode=='normal' else '-O1',*flags,'-o',str(binary)]
 z=subprocess.run(command,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 records.append(dict(mode=mode,command=command,exit_code=z.returncode,stdout=z.stdout))
 assert z.returncode==0,z.stdout
 for seed in (1,7,13,29):
  z=subprocess.run([str(binary)],env=dict(env,CKET_SEED=str(seed)),text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  m=re.fullmatch(r'previous=([01]) value=([01]) condition=([01]) expected=([01])\n',z.stdout)
  assert z.returncode==0 and m and m[2]==m[4],z.stdout
  records.append(dict(mode=mode,seed=seed,command=[str(binary)],exit_code=z.returncode,stdout=z.stdout))
shutil.copy2(r/'build/lazy-pending-normal-results-v1/lazy_values',stage/'bin/lazy_values_basis')
shutil.copy2(r/'build/lazy-pending-normal-results-v1/lazy_values.c',stage/'lazy_values_basis.c')
shutil.copy2(r/'LICENSE',stage/'LICENSE')
hashes={p.relative_to(stage).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'SHA256SUMS').write_text(''.join(h+'  '+n+'\n' for n,h in hashes.items()))
z=subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=stage,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
assert z.returncode==0,z.stdout
archive=out/'cket-lazy-demo-linux-x86_64.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(stage.rglob('*')):
  if p.is_file():tar.add(p,arcname=p.relative_to(stage).as_posix())
shutil.copy2(source,out/'lazy_values.c')
destination='/tmp/cket-lazy-demo-'+hashes['bin/lazy_values'][:12]
(out/'run_lazy_demo.cmd').write_bytes(f'''@echo off
setlocal
wsl -d Ubuntu2204 --exec mkdir -p "{destination}"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "{destination}" --exec tar -xzf - < "%~dp0cket-lazy-demo-linux-x86_64.tar.gz"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "{destination}" --exec sha256sum -c SHA256SUMS
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "{destination}" --exec env CKET_SIMULATOR=sparse CKET_SEED=7 ./bin/lazy_values_basis
if errorlevel 1 exit /b 1
for %%S in (1 7 13 29) do (
  wsl -d Ubuntu2204 --cd "{destination}" --exec env CKET_SIMULATOR=sparse CKET_SEED=%%S ./bin/lazy_values
  if errorlevel 1 exit /b 1
)
exit /b 0
'''.encode())
(out/'demo-lazy-audit.json').write_text(json.dumps(dict(status='passed-native-value-demo',date='2026-10-26',
 compiler_snapshot='lazy-pending-source-v1',compiler_input_files=237,package_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
 file_sha256=hashes,commands=records,basis_example_logs={mode:(r/('build/lazy-pending-'+mode+'-results-v1/demo.log')).read_text() for mode in ('normal','sanitized')},
 scope='One corrected known-basis case plus four coherent seed executions per configuration. These measured values do not establish coherence; the independent phased history-channel/state/inverse references are separate. No physical QPU or complete C-profile claim.'),indent=2)+'\n')
(out/'README-lazy.es.md').write_text('''# Demo de valores anteriores y efectos seleccionados

Desde la raíz del repositorio en Windows:

```cmd
output\\demo\\run_lazy_demo.cmd
```

Usa WSL `Ubuntu2204`, extrae por entrada estándar y comprueba SHA256. No recompila ni monta
unidades Windows. El paquete está construido para Linux x86-64/glibc compatible con Ubuntu 22.04
y GCC 11.4.0. En Linux, extraer `cket-lazy-demo-linux-x86_64.tar.gz` y ejecutar:

```sh
sha256sum -c SHA256SUMS
CKET_SIMULATOR=sparse CKET_SEED=7 ./bin/lazy_values_basis
CKET_SIMULATOR=sparse CKET_SEED=7 ./bin/lazy_values
```

Primero ejecuta el caso antes rechazado, con salida `previous=0 value=1 condition=0`. Después
ejecuta cuatro semillas de un programa con dos entradas en superposición, fases y un resultado
postfix seleccionado. El valor observado debe ser `condition ? 1 : !previous`. La
[fuente](lazy_values.c) y `demo-lazy-audit.json` conservan el programa y las ejecuciones normales
e instrumentadas. El paquete incluye fuentes, ejecutables, licencia y hashes.

Los resultados medidos se comprueban contra C. La coherencia, los canales de historial y las
inversas tienen [evidencia independiente](../../docs/audit-evidence/lazy-pending-v1/README.es.md)
separada. La [nota técnica](../../docs/paper/lazy_values_note.es.md) explica los fallos corregidos
y sus límites. La candidata sigue siendo RC3; la integración de todo el perfil cotidiano y la
1.0 estable continúan pendientes. La ciberseguridad permanece clásica.
''')
print('Packaged native basis/coherent demonstrations:',hashlib.sha256(archive.read_bytes()).hexdigest(),flush=True)
