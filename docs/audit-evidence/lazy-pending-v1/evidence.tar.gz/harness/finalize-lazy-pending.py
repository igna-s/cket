import hashlib, io, json, runpy, subprocess, tarfile
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/lazy-pending-source-v1'
san = r / 'build/lazy-pending-sanitized-v1'
base = r / 'build/string-writes-examples-source-v2'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((project / 'source-hashes.json').read_text())
original = json.loads((base / 'source-hashes.json').read_text())
expected_changes = ['src/quantum_semantics.inc', 'tests/test_coherent_history.inc',
                    'tests/test_cpu_history.inc', 'tests/test_lazy_values.inc', 'tests/validate_history.c']
assert len(source) == len(original) == 237
assert sorted(n for n in source if source[n] != original[n]) == expected_changes
assert runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']() == source
assert all(sha(project / n) == h for n, h in source.items())

campaigns, tools = {}, {}
for mode, target, previous, count in [
    ('normal', project, base, 7),
    ('sanitized', san, r / 'build/string-writes-sanitized-v1', 6),
]:
    out = r / f'build/lazy-pending-{mode}-results-v1'
    result = json.loads((out / 'summary.json').read_text())
    records = json.loads((out / 'commands.json').read_text())
    assert result['status'] == 'passed' and result['source_files'] == 237
    assert len(records) == count and all(x['exit_code'] == 0 for x in records)
    expected_history = ('2332 versioned history checks passed' if mode == 'normal'
                        else '355 focused history-reference checks passed')
    for name, signature in [('history', expected_history), ('expressions', '3509 expression checks passed'),
                            ('core', '395 passed, 0 failed'), ('demo', 'previous=0 value=1 condition=0')]:
        text = (out / (name + '.log')).read_text()
        assert signature in text, (mode, name)
        assert not any(x in text for x in ['ERROR: AddressSanitizer', 'runtime error:', 'internal compiler error:'])
    matrix = json.loads((out / 'string-writes/summary.json').read_text())
    assert matrix['status'] == 'passed'
    assert matrix['public_density_comparisons'] == matrix['joint_gate_state_comparisons'] == 592
    assert matrix['complete_gate_inverses'] == 296 and matrix['runtime_domain_preflights'] == 8
    assert len(matrix['exclusions']) == 14
    campaigns[mode] = dict(terminal=result, string_writes=matrix,
                          history_checks=2332 if mode == 'normal' else 355,
                          expressions=3509, native_core=395)
    build = json.loads((target / 'build-exit.json').read_text())
    assert build['exit_code'] == 0
    assert all(x['exit_code'] == 0 for x in json.loads((target / 'build-commands.json').read_text()))
    assert all(sha(target / 'build' / n) == sha(previous / 'build' / n) == h
               for n, h in build['reused_artifact_sha256'].items())
    tools[mode] = {n: sha(target / 'build' / n) for n in
                   ('cket', 'cket_backend', 'cket_plugin.so', 'libcket_quantum.a', 'cket_runtime.o',
                    'validate_history', 'validate_expressions', 'cket_tests')}
assert 'Block 06 ready: 10 executables, 10 QASM circuits' in (
    r / 'build/lazy-pending-normal-results-v1/block06.log').read_text()

instrumentation = {}
for name in ('cket_plugin.so', 'libcket_quantum.a', 'cket_runtime.o', 'cket', 'cket_backend',
             'validate_history', 'validate_expressions', 'cket_tests'):
    text = subprocess.check_output(['nm', '-u', str(san / 'build' / name)], text=True)
    assert '__asan_init' in text and '__ubsan_handle' in text, name
    instrumentation[name] = text

baseline = r / 'build/lazy-pending-baseline-v1'
before = json.loads((baseline / 'result.json').read_text())
assert before['exit_code'] == 1 and before['expected_diagnostic'] in (baseline / 'compile.log').read_text()
demo = json.loads((r / 'output/demo/demo-lazy-audit.json').read_text())
assert demo['package_sha256'] == sha(r / 'output/demo/cket-lazy-demo-linux-x86_64.tar.gz')
assert len(demo['commands']) == 10 and all(x['exit_code'] == 0 for x in demo['commands'])
assert demo['windows_launcher']['exit_code'] == 0
assert demo['windows_launcher']['stdout'].count('expected=1') == 4

destination = r / 'docs/audit-evidence/lazy-pending-v1'
assert (destination / 'README.es.md').is_file()
assert not (destination / 'summary.json').exists()

def tree(tar, folder, prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json', '.c', '.log', '.py', '.sh', '.txt'):
            tar.add(p, arcname=prefix + '/' + p.relative_to(folder).as_posix())

def raw(tar, name, value):
    data = (json.dumps(value, indent=2) + '\n').encode()
    entry = tarfile.TarInfo(name)
    entry.size = len(data)
    tar.addfile(entry, io.BytesIO(data))

with tarfile.open(destination / 'evidence.tar.gz', 'w:gz') as tar:
    for name in source:
        tar.add(project / name, arcname='sources/' + name)
    raw(tar, 'source-identities.json', dict(source_sha256=source, base_source_sha256=original,
                                         changed_inputs=expected_changes))
    raw(tar, 'instrumentation.json', instrumentation)
    raw(tar, 'tool-sha256.json', tools)
    for mode, target in [('normal', project), ('sanitized', san)]:
        tree(tar, r / f'build/lazy-pending-{mode}-results-v1', 'results/' + mode)
        for name in ('build-exit.json', 'build-commands.json', 'plugin-build.log',
                     'validate_history-build.log', 'validate_expressions-build.log', 'cket_tests-build.log'):
            tar.add(target / name, arcname='build/' + mode + '/' + name)
    tree(tar, baseline, 'baseline-published-6400aed')
    for name in ('prepare-lazy-pending.py', 'build-lazy-pending.py', 'run-lazy-pending-checks.py',
                 'package-lazy-demo.py', 'check-lazy-pending-baseline.py', 'finalize-lazy-pending.py'):
        tar.add(r / 'build' / name, arcname='harness/' + name)
    for name in ('demo-lazy-audit.json', 'lazy_values.c', 'README-lazy.es.md', 'run_lazy_demo.cmd'):
        tar.add(r / 'output/demo' / name, arcname='demo/' + name)
    tar.add(r / 'build/lazy-pending-launcher.log', arcname='demo/windows-launcher.log')

with tarfile.open(destination / 'earlier-attempts.tar.gz', 'w:gz') as tar:
    for p in sorted((r / 'build').iterdir()):
        if p.is_dir() and (p.name.startswith(('history-reference-dev-', 'lazy-pending-dev-',
                                              'lazy-state-reference-dev-', 'lazy-pending-followup-dev-'))
                           or p.name == 'lazy-zero-support-debug-v1'):
            tree(tar, p, p.name)

summary = dict(
    status='finite-pending-value-correction-with-open-general-integration', date='2026-10-26',
    base_commit='6400aed', version='1.0.0-rc.3', compiler_input_files=237,
    source_sha256=source, changed_inputs=expected_changes, campaigns=campaigns, tool_sha256=tools,
    focused_history_scope=dict(checks=355, complete_state_contexts=320,
        independent_semantic_channel_and_gate_contexts=280, independent_complete_inverses=280,
        unchanged_strict_direct_state_contexts=40,
        limitation='Basis-label histories for these finite Boolean programs; not arbitrary superposed histories.'),
    string_regression=dict(public_densities=1184, independent_joint_states=1184,
                           complete_inverses=592, runtime_preflights=16, explicit_resource_exclusions=14),
    block06=dict(native_executables=10, qasm_exports=10, fresh_independent_sdk_qualification=False),
    baseline_rejection=before, demo_package_sha256=demo['package_sha256'],
    scope='Normal full history; focused, not full history under ASan/UBSan. No new general CI, QPU, full C11, arbitrary lifetime/alias/ABI, all repeated writes, quantum floating point or general papers qualification. Cybersecurity remains classical.',
    earlier_attempts='Includes failed stale-reference assumptions and intermediate compiler fixes; only terminal frozen campaigns count as passing evidence.',
    artifact_sha256={n: sha(destination / n) for n in ('evidence.tar.gz', 'earlier-attempts.tar.gz')})
(destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(status=summary['status'], source_files=237, artifacts=summary['artifact_sha256'])))
