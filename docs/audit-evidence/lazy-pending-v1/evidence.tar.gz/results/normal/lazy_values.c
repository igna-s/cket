#include <quantum.h>
#include <stdio.h>
int main(void) {
    quant bool condition = false, value = false;
    quant bool previous = condition ? value++ : value--;
    unsigned old = measure(previous), next = measure(value), flag = measure(condition);
    printf("previous=%u value=%u condition=%u\n", old, next, flag);
    return old != 0 || next != 1 || flag != 0;
}
