#include <quantum.h>
#include <stdint.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(int argc,char **argv){quant uint16_t y=0;quant bool active=0;char src[2]={argc>1?argv[1][0]:0,1};ownership_checkpoint("before");if(active){strcat((char*)&y,src);}ownership_checkpoint("after");measure(y);measure(active);return 0;}
