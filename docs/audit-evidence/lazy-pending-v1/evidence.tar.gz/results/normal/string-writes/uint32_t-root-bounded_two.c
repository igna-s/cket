#include <quantum.h>
#include <stdint.h>
#include <string.h>
void ownership_checkpoint(const char*);
typedef uint32_t word;
int main(int argc,char **argv){
int enabled=argc>1&&argv[1][0]=='1';
quant bool a=superposition(0,1),x=superposition(0,1);
quant bool c=superposition(0,1),d=superposition(0,1);
quant uint8_t src[2]={x^0,0};quant word y=superposition(0,1);y^=(word)(a?256:0);
if(a)phase(.11);if(y&1)phase(.23);if(x)phase(.41);if(c)phase(.17);if(d)phase(.29);
ownership_checkpoint("before");if(enabled){if(c){strncpy((char*)&y,(const char*)src,2);}}ownership_checkpoint("after");
measure(y);
measure(src[0]);measure(src[1]);measure(a);measure(x);measure(c);measure(d);return 0;}
