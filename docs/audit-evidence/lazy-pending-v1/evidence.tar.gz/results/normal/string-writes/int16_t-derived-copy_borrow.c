#include <quantum.h>
#include <stdint.h>
#include <string.h>
void ownership_checkpoint(const char*);
typedef int16_t word;
int main(int argc,char **argv){
int enabled=argc>1&&argv[1][0]=='1';
quant bool a=superposition(0,1),x=superposition(0,1);
quant bool c=superposition(0,1),d=superposition(0,1);
quant uint8_t src[2]={x^0,0};quant bool b=superposition(0,1);quant word y=(word)~(((word)a<<8)|b);
if(a)phase(.11);if(y&1)phase(.23);if(x)phase(.41);if(c)phase(.17);if(d)phase(.29);
ownership_checkpoint("before");{quant word saved=y^1;if(enabled){if(c){strcpy((char*)&y,(const char*)src);}}if(saved&1)phase(.47);if(saved&256)phase(.13);}ownership_checkpoint("after");
measure(y);measure(b);
measure(src[0]);measure(src[1]);measure(a);measure(x);measure(c);measure(d);return 0;}
