#include <quantum.h>
int main(void){quant bool c=true;quant bool y=c||(c=true);c=!c;return measure(y)!=1||measure(c)!=0;}
