#include <quantum.h>
int main(void){quant bool c=false;quant bool y=c&&(c=false);c=!c;return measure(y)!=0||measure(c)!=1;}
