#include <quantum.h>
int main(void){quant bool c=0,x=0;quant bool y=c?x++:x--;unsigned a=measure(y),b=measure(x),d=measure(c);return a!=0||b!=1||d!=0;}
