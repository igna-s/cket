#include <quantum.h>
int main(void){quant bool c=1,x=0;quant bool y=c?(x=false):(x=true);unsigned a=measure(y),b=measure(x),d=measure(c);return a!=0||b!=0||d!=1;}
