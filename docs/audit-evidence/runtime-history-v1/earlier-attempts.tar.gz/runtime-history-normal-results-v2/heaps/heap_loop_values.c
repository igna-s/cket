#include <quantum.h>
#include <stdlib.h>
#include <limits.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(1,sizeof *p);if(!p)return 2;quant uint8_t sum=0;size_t count=2;for(size_t i=0;i<count;++i)sum+=p[0]++;unsigned result=measure(sum),last=measure(p[0]);free((void*)p);return result!=1||last!=2;}