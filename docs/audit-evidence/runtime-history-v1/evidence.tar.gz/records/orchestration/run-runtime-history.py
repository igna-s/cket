from pathlib import Path
import json
import os
import runpy
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
version = sys.argv[2] if len(sys.argv) > 2 else 'v1'
project = root / ('build/runtime-history-source-' + version)
san = root / ('build/runtime-history-sanitized-' + version)
mode = sys.argv[1]
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_SEED='7',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode in ('normal-build', 'sanitize-build'):
    if mode == 'normal-build':
        output = project
        command = ['bash', 'scripts/build.sh']
        name = 'build-normal.log'
    else:
        san.mkdir()
        output = san
        prefix = (project / 'scripts/sanitize-all.sh').read_text().split('\nexport CKET_REAL_GCC="$real_cc"')[0]
        prefix = prefix.replace('cd "$(dirname "$0")/.."', 'cd "' + str(project) + '"')
        script = san / 'build-sanitized.sh'
        script.write_text(prefix + '\n')
        command = ['bash', str(script)]
        env['CKET_SAN_ROOT'] = str(san)
        name = 'build.log'
    with (output / name).open('x') as log:
        result = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT)
    (output / 'build-exit.json').write_text(json.dumps(dict(command=command, exit_code=result.returncode)) + '\n')
    print(mode, result.returncode, flush=True)
    if result.returncode:
        print((output / name).read_text()[-5000:], flush=True)
    sys.exit(result.returncode)

assert mode in ('normal', 'sanitized')
target = project if mode == 'normal' else san
output_tag = sys.argv[3] if len(sys.argv) > 3 else version
output = root / ('build/runtime-history-' + mode + '-results-' + output_tag)
output.mkdir()
if mode == 'sanitized':
    env.update(CC=str(san / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11')
records = []

def run(label, command, selected_env=None):
    with (output / (label + '.log')).open('x') as log:
        result = subprocess.run(command, cwd=project, env=selected_env or env,
                                stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    records.append(dict(label=label, command=command, exit_code=result.returncode, log=label + '.log'))
    (output / 'exit.json').write_text(json.dumps(records, indent=2) + '\n')
    text = (output / (label + '.log')).read_text()
    print(label, result.returncode, text[-2500:], flush=True)
    assert result.returncode == 0

extra = ['--sanitized'] if mode == 'sanitized' else []
run('iterations', ['python3', 'scripts/validate-runtime-versions.py', '--compiler-root', str(target),
                   '--output', str(output / 'matrix'), '--levels',
                   *(['O0', 'O2'] if mode == 'normal' else ['O1']), *extra])
run('runtime-engine', [str(target / 'build/validate_runtime_versions')])
run('transfer-regression', ['python3', 'scripts/validate-heap-transfer.py', '--compiler-root', str(target),
                            '--output', str(output / 'transfers'), '--levels', 'O2' if mode == 'normal' else 'O1', *extra])
run('heap-regression', ['python3', 'scripts/validate-heap.py', '--compiler-root', str(target),
                        '--output', str(output / 'heaps'), '--levels', 'O2' if mode == 'normal' else 'O1', *extra])
if mode == 'normal':
    run('native-core', [str(target / 'build/cket_tests'), str(target)])
    run('history', [str(target / 'build/validate_history')])
    run('block05', ['bash', 'scripts/run-block.sh', '05'])
else:
    for component in ('cket_plugin.so', 'json.o', 'quantum.o', 'verify.o', 'simulator.o', 'cket_runtime.o', 'cket'):
        run('instrumentation-' + component, ['nm', '-u', str(target / 'build' / component)])
        text = (output / ('instrumentation-' + component + '.log')).read_text()
        assert '__asan_init' in text and '__ubsan_handle' in text
hashes = runpy.run_path(str(project / 'scripts/archive-audit.py'))['source_hashes']()
assert hashes == json.loads((project / 'source-hashes.json').read_text())
print('PASS unchanged', len(hashes), 'frozen inputs', flush=True)
