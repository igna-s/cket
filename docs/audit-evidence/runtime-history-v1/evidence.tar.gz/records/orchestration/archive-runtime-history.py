"""Archive a closed, source-identical runtime-history delivery."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/runtime-history-source-v4'
sanbuild = root / 'build/runtime-history-sanitized-v4'
folder = root / 'docs/audit-evidence/runtime-history-v1'
locations = {mode: root / ('build/runtime-history-' + mode + '-results-v4')
             for mode in ('normal', 'sanitized')}
contexts = {mode: root / ('build/runtime-contexts-' + mode + '-v4') for mode in locations}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())
sources = read(project / 'source-hashes.json')
assert len(sources) == 214
assert sources == runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
assert all(sha(project / name) == digest for name, digest in sources.items())
for build in (project, sanbuild):
    assert read(build / 'build-exit.json')['exit_code'] == 0
matrices = {mode: read(path / 'matrix/summary.json') for mode, path in locations.items()}
for mode, counts in [('normal', (200, 60)), ('sanitized', (100, 30))]:
    path = locations[mode]
    matrix = matrices[mode]
    assert matrix['status'] == 'passed'
    assert (matrix['full_state_checkpoints'], matrix['complete_gate_inverses']) == counts
    assert matrix['profiles'] == ['scalar', 'transfer', 'effects', 'branches', 'function']
    assert all(row['exit_code'] == 0 for row in read(path / 'exit.json'))
    assert '15 runtime history contracts passed' in (path / 'runtime-engine.log').read_text()
    for regression in ('transfers', 'heaps'):
        assert read(path / regression / 'summary.json')['status'] == 'passed'
    assert read(contexts[mode] / 'summary.json')['native_program_executions'] == 16
    assert all(row['exit_code'] == row['expected_exit_code']
               for row in read(contexts[mode] / 'commands.json'))
assert '395 passed, 0 failed' in (locations['normal'] / 'native-core.log').read_text()
assert '2332 versioned history checks passed' in (locations['normal'] / 'history.log').read_text()
assert '5 executables, 0 QASM' in (locations['normal'] / 'block05.log').read_text()
components = ['cket_plugin.so', 'json.o', 'quantum.o', 'verify.o', 'simulator.o',
              'cket_runtime.o', 'cket', 'validate_runtime_versions']
for component in components[:-1]:
    symbols = (locations['sanitized'] / ('instrumentation-' + component + '.log')).read_text()
    assert '__asan_init' in symbols and '__ubsan_handle' in symbols
folder.mkdir(parents=True)
tool_hashes = {mode: {name: sha(path / 'build' / name) for name in components}
               for mode, path in [('normal', project), ('sanitized', sanbuild)]}
(folder / 'tool-sha256.json').write_text(json.dumps(tool_hashes, indent=2) + '\n')


def add_records(archive, location, prefix):
    for path in sorted(location.rglob('*')):
        if path.is_file() and path.suffix in ('.json', '.log', '.c'):
            archive.add(path, arcname=prefix + '/' + path.relative_to(location).as_posix())


with tarfile.open(folder / 'evidence.tar.gz', 'x:gz') as archive:
    for name in sources:
        archive.add(project / name, arcname='sources/' + name)
    archive.add(root / 'LICENSE', arcname='sources/LICENSE')
    for name, path in [('source-hashes.json', project / 'source-hashes.json'),
                       ('inventory-fixture.json', project / 'docs/c11-library.json'),
                       ('tool-sha256.json', folder / 'tool-sha256.json')]:
        archive.add(path, arcname='records/' + name)
    for mode in locations:
        add_records(archive, locations[mode], 'records/' + mode)
        add_records(archive, contexts[mode], 'records/contexts-' + mode)
    for name in ('build.log', 'build-exit.json', 'build-sanitized.sh'):
        archive.add(sanbuild / name, arcname='records/sanitized-build/' + name)
    for name in ('build-normal.log', 'build-exit.json'):
        archive.add(project / name, arcname='records/normal-build/' + name)
    for name in ('prepare-runtime-history.py', 'runtime-history-changed.txt',
                 'run-runtime-history.py', 'check-runtime-contexts.py',
                 'archive-runtime-history.py'):
        archive.add(root / 'build' / name, arcname='records/orchestration/' + name)

with tarfile.open(folder / 'earlier-attempts.tar.gz', 'x:gz') as archive:
    for version in ('v1', 'v2', 'v3'):
        previous = root / ('build/runtime-history-source-' + version)
        previous_sources = read(previous / 'source-hashes.json')
        for name, digest in previous_sources.items():
            assert sha(previous / name) == digest
            archive.add(previous / name, arcname=previous.name + '/sources/' + name)
        for name in ('source-hashes.json', 'build-exit.json', 'build-normal.log'):
            archive.add(previous / name, arcname=previous.name + '/records/' + name)
        san = root / ('build/runtime-history-sanitized-' + version)
        for name in ('build.log', 'build-exit.json', 'build-sanitized.sh'):
            archive.add(san / name, arcname=san.name + '/' + name)
        for pattern in ('runtime-history-*-results-' + version + '*',
                        'runtime-contexts-*-' + version):
            for previous_results in (root / 'build').glob(pattern):
                add_records(archive, previous_results, previous_results.name)
    for name in ('runtime-history-dev-matrix-v1', 'runtime-history-dev'):
        add_records(archive, root / 'build' / name, name)

regressions = {mode: {label: read(location / label / 'summary.json')
                     for label in ('transfers', 'heaps')}
               for mode, location in locations.items()}
summary = dict(
    date='2026-10-24', status='finite-runtime-history-qualified', source_files=214,
    source_sha256=sources,
    artifact_sha256={name: sha(folder / name) for name in
                    ('evidence.tar.gz', 'earlier-attempts.tar.gz', 'tool-sha256.json')},
    normal=matrices['normal'], sanitized=matrices['sanitized'],
    full_state_checkpoints=300, complete_gate_inverses=90,
    runtime_engine_contracts_per_configuration=15,
    extra_native_context_executions=32,
    contexts={mode: read(path / 'summary.json') for mode, path in contexts.items()},
    normal_native_core_checks=395, normal_versioned_history_checks=2332,
    regressions=regressions,
    delivery=dict(block05_native_executables=5, static_exports=0,
                  example_iteration_counts=[0, 1, 3, 4]),
    inventory=dict(Counter(row['quantum'] for row in
                           read(root / 'docs/c11-library.json')['interfaces'])),
    compiler=subprocess.check_output(['gcc-11', '-dumpfullversion'], text=True).strip(),
    windows_base_commit='3fd5e90aee155c795b39c63424b9933405c492c3',
    isolated_git_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    source_scope='Normal and ASan/UBSan builds and final checks use the same 214 frozen inputs. Source hashes identify the compiled changes; Git base revisions are provenance, not the final source identity. Documentation is outside this manifest.',
    earlier_attempts='Frozen v1/v2/v3 source manifests and outcomes are separate. v1 exhausted the wire budget before accumulator optimization; v2 had an obsolete negative expectation and a prematurely started sanitized campaign (no program ran); v3 additional function context exposed an internal GCC error. v4 corrects these. Pre-freeze development records have incomplete source provenance and are not qualification evidence.',
    limitations=[
        'Finite everyday integer, heap-effect and heap-to-fixed runtime loops; everyday C, C11 and libc remain incomplete.',
        'Five profiles at iteration counts 0/1/3, normal O0/O2 and sanitized O1, both synthesis policies; these are finite correlated states, not arbitrary input proofs.',
        'CPU conditions choose the executed path. General quantum loop conditions, quantum declarations inside controlled/runtime blocks, early returns and arbitrary CFG ownership remain pending.',
        'Retained versions consume the 128-wire budget; native dense simulation separately supports 24 wires, with bounded sparse mode. No implicit measurement/reset erases history.',
        'General indexed overwrites, fixed-to-fixed memory loops, heap strings, returned-pointer/indirect ABI and quantum floating point remain pending.',
        'The host GCC is uninstrumented; its wrapper excludes host-process leak attribution for the instrumented plugin. Generated sanitized programs retain leak detection.',
        'Historical paper captures and the prior 210-input paper review remain unchanged. New compiler inputs require separate paper integration; no QPU execution or speedup claim.'])
(folder / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
p = root / 'docs/audit-evidence/delivery-index.json'
index = read(p)
index['active'] = 'runtime-history-v1'
index['history'].append('runtime-history-v1')
index['meaning'] = 'Current source identity selects finite native runtime-history validation. Prior deliveries and paper captures retain their own inputs; everyday C integration and qualification of new compiler changes in the papers remain open.'
p.write_text(json.dumps(index, indent=2) + '\n')
(root / 'docs/paper/evidence/current-implementation.json').write_text(json.dumps(dict(
    date='2026-10-24', status=summary['status'], source_files=214, source_sha256=sources,
    directed_evidence='../../audit-evidence/runtime-history-v1/summary.json',
    paper_audit='pending-for-new-compiler',
    previous_paper_review='../../audit-evidence/paper-truth-oct24-v1/summary.json',
    meaning='Runtime-history validation advances the compiler. The published paper review checks its own 210-input predecessor; historical paper reports remain unchanged.'), indent=2) + '\n')
print(json.dumps({key: summary[key] for key in
                  ('status', 'source_files', 'full_state_checkpoints', 'complete_gate_inverses')}), flush=True)
