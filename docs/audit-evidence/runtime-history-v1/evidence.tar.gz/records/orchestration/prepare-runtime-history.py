from pathlib import Path
import json
import runpy
import shutil
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
format_text = runpy.run_path(str(root / 'scripts/format.py'))['format_text']
files = (root / 'build/runtime-history-changed.txt').read_text().splitlines()
for name in files:
    path = root / name
    path.write_text(format_text(path, path.read_text()))
sources = runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
project = root / ('build/runtime-history-source-' + (sys.argv[1] if len(sys.argv) > 1 else 'v1'))
project.mkdir()
for name in sources:
    path = project / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, path)
(project / '.deps').symlink_to(root / '.deps', target_is_directory=True)
(project / 'cket').chmod(0o755)
(project / 'docs').mkdir()
shutil.copy2(root / 'docs/c11-library.json', project / 'docs/c11-library.json')
(project / 'source-hashes.json').write_text(json.dumps(sources, indent=2) + '\n')
print('Formatted', len(files), 'files; frozen', len(sources), 'inputs.', flush=True)
