from pathlib import Path
import json
import os
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
version = sys.argv[2] if len(sys.argv) > 2 else 'v3'
project = root / ('build/runtime-history-source-' + version)
san = root / ('build/runtime-history-sanitized-' + version)
mode = sys.argv[1]
target = project if mode == 'normal' else san
output = root / ('build/runtime-contexts-' + mode + '-' + version)
output.mkdir()
env = dict(os.environ, CKET_SIMULATOR='sparse', CKET_SEED='7',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode == 'sanitized':
    env.update(CC=str(san / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11')
flags = ['-O2'] if mode == 'normal' else ['-O1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
cases = {
    'do_while': ('', 'unsigned i=0;do{out=p[0]++;++i;}while(i<rounds);',
                 'unsigned count=rounds?rounds:1;return result!=initial+count-1||last!=initial+count;'),
    'nested': ('', 'for(unsigned i=0;i<2;++i)for(unsigned j=0;j<rounds;++j)out=p[0]++;',
               'unsigned count=2*rounds;return result!=(count?initial+count-1:7)||last!=initial+count;'),
    'conditional': ('', 'for(unsigned i=0;i<rounds;++i){if(i&1)out=p[0]++;else out=++p[0];}',
                    'unsigned expected=rounds?initial+rounds-((rounds-1)&1):7;return result!=expected||last!=initial+rounds;'),
    'function': ('void take(quant const uint8_t *p,quant uint8_t *out,unsigned n){while(n--)memcpy((void*)out,(const void*)p,1);}',
                 'unsigned passed=rounds;take(p,&out,rounds++);bad|=rounds!=passed+1;rounds=passed;',
                 'return result!=(rounds?initial:7)||last!=initial||bad;'),
}
records = []

def run(label, command, expected=0, diagnostic=None):
    r = subprocess.run(command, cwd=project, env=env, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    (output / (label + '.log')).write_text(r.stdout)
    records.append(dict(command=command, exit_code=r.returncode, log=label + '.log',
                        expected_exit_code=expected))
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert r.returncode == expected and (not diagnostic or diagnostic in r.stdout), r.stdout

executions = 0
for name, (helper, body, check) in cases.items():
    source = output / (name + '.c')
    source.write_text('''#include <quantum.h>
#include <stdlib.h>
#include <string.h>
''' + helper + '''
int main(int argc,char **argv){
unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;
int bad=0;(void)bad;
quant uint8_t *p=calloc(1,1);if(!p)return 2;
quant bool coin=superposition(0,1);p[0]=coin?9:3;
quant uint8_t out=7;
''' + body + '''
unsigned result=measure(out),last=measure(p[0]),input=measure(coin);
free((void*)p);unsigned initial=input?9:3;
''' + check + '}\n')
    binary = output / name
    run(name + '-compile', [str(target / 'build/cket'), str(source), *flags, '-o', str(binary)])
    for rounds in (0, 1, 3):
        run(name + '-n' + str(rounds), [str(binary), str(rounds)])
        executions += 1
binary = output / 'heap_iterations'
run('example-compile', [str(target / 'build/cket'), 'examples/blocks/05/heap_iterations.c',
                        *flags, '-o', str(binary)])
for rounds in (0, 1, 3, 4):
    run('example-n' + str(rounds), [str(binary), str(rounds)])
    executions += 1
if mode == 'normal':
    run('static-export', [str(target / 'build/cket'), 'examples/blocks/05/heap_iterations.c',
                          '--emit-qasm', '-o', str(output / 'unsupported.qasm')],
        expected=1, diagnostic='static export is unsupported')
(output / 'summary.json').write_text(json.dumps(dict(status='passed', mode=mode,
    native_program_executions=executions, contexts=list(cases),
    scope='Finite native observations only; full complex-state evidence is in the separate iteration matrix.'), indent=2) + '\n')
print(mode, executions, 'native iteration-context executions passed', flush=True)
