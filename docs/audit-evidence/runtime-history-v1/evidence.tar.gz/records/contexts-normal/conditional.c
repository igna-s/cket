#include <quantum.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char **argv){
unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;
int bad=0;(void)bad;
quant uint8_t *p=calloc(1,1);if(!p)return 2;
quant bool coin=superposition(0,1);p[0]=coin?9:3;
quant uint8_t out=7;
for(unsigned i=0;i<rounds;++i){if(i&1)out=p[0]++;else out=++p[0];}
unsigned result=measure(out),last=measure(p[0]),input=measure(coin);
free((void*)p);unsigned initial=input?9:3;
unsigned expected=rounds?initial+rounds-((rounds-1)&1):7;return result!=expected||last!=initial+rounds;}
