#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void take(quant const uint8_t *p,quant uint8_t *out,unsigned n){while(n--)memcpy((void*)out,(const void*)p,1);}
int main(int argc,char **argv){
unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;
int bad=0;(void)bad;
quant uint8_t *p=calloc(1,1);if(!p)return 2;
quant bool coin=superposition(0,1);p[0]=coin?9:3;
quant uint8_t out=7;
unsigned passed=rounds;take(p,&out,rounds++);bad|=rounds!=passed+1;rounds=passed;
unsigned result=measure(out),last=measure(p[0]),input=measure(coin);
free((void*)p);unsigned initial=input?9:3;
return result!=(rounds?initial:7)||last!=initial||bad;}
