#include <quantum.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char **argv){
unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;
int bad=0;(void)bad;
quant uint8_t *p=calloc(1,1);if(!p)return 2;
quant bool coin=superposition(0,1);p[0]=coin?9:3;
quant uint8_t out=7;
unsigned i=0;do{out=p[0]++;++i;}while(i<rounds);
unsigned result=measure(out),last=measure(p[0]),input=measure(coin);
free((void*)p);unsigned initial=input?9:3;
unsigned count=rounds?rounds:1;return result!=initial+count-1||last!=initial+count;}
