#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#define phase(x) ((void)(x))
#include <string.h>
#include <stdlib.h>
int main(int argc,char **argv){int k=argc>1?argv[1][0]-'0':0;quant bool b=0;quant uint8_t x=5;if(b){if(x + 10/k > 1) phase(.17);}unsigned a=measure(x),v=measure(b);return a!=5||v;}
