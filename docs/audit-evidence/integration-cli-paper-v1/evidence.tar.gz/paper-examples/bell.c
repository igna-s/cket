#include <quantum.h>
#include <stdio.h>
int main(void) {
quant bool a = 0, b = 0;
fourier(a);
if (a) b ^= 1;
unsigned first = measure(a), second = measure(b);
printf("%u%u\n", first, second);
return 0;
}
