import hashlib, io, json, runpy, tarfile
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
base = r / 'build/integrated-be96caf-source-v1'
project = r / 'build/integrated-cli-source-v2'
out = r / 'docs/audit-evidence/integration-cli-paper-v1'
out.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((project / 'source-hashes.json').read_text())
before = json.loads((base / 'source-hashes.json').read_text())
assert len(source) == len(before) == 237
assert [n for n in source if source[n] != before[n]] == ['tests/test_examples.c']
assert runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']() == source
baseline = r / 'build/integrated-be96caf-results-v1'
assert json.loads((baseline / 'terminal.json').read_text())['exit_code'] == 1
assert 'example driver failed: CLI information' in (baseline / 'verify.log').read_text()
native = project / 'build/verify-native.log'
assert '395 passed, 0 failed (native C tests, no external quantum SDK)' in native.read_text()
assert '1509 checks passed across 37 examples, five optimization levels and CLI/input contracts' in native.read_text()
reuse = json.loads((r / 'build/integrated-cli-results-v2/build-reuse.json').read_text())
assert reuse['rebuilt_exit_code'] == 0
assert all(sha(base / 'build' / n) == sha(project / 'build' / n) == h
           for n, h in reuse['reused_artifact_sha256'].items())
paper = r / 'build/current-paper-examples-v1'
proof = json.loads((paper / 'summary.json').read_text())
assert proof['compiler_source_sha256'] == source
assert proof['status'] == 'passed-current-native-values-and-finite-states'
assert proof['unique_c_examples'] == proof['native_executions'] == 3
assert proof['complete_state_comparisons'] == 6
assert all(x['exit_code'] == 0 for x in json.loads((paper / 'commands.json').read_text()))
docs = ['docs/paper/README.md', 'docs/c11-heap.md', 'docs/c11-buffer-functions.md', 'docs/v1-plan.md',
        'docs/audit-evidence/integration-cli-paper-v1/README.es.md']
fmt = runpy.run_path(str(r / 'scripts/format.py'))['format_text']
for name in docs:
    p = r / name
    p.write_text(fmt(p, p.read_text()))

def raw(tar, name, value):
    data = (json.dumps(value, indent=2) + '\n').encode()
    entry = tarfile.TarInfo(name)
    entry.size = len(data)
    tar.addfile(entry, io.BytesIO(data))

assert not (out / 'summary.json').exists()
with tarfile.open(out / 'evidence.tar.gz', 'w:gz') as tar:
    for name in source:
        tar.add(project / name, arcname='sources/' + name)
    tar.add(base / 'tests/test_examples.c', arcname='baseline/test_examples.c')
    tar.add(base / 'build/verify-build.log', arcname='baseline/complete-build.log')
    tar.add(baseline / 'verify.log', arcname='baseline/failed-verification.log')
    tar.add(baseline / 'terminal.json', arcname='baseline/terminal.json')
    tar.add(base / 'build/validation-Dz07xt/stdout', arcname='baseline/actual-version.txt')
    tar.add(native, arcname='corrected/complete-native-phase.log')
    for name in ('build-reuse.json', 'test-examples-build.log', 'verify-after-build.sh'):
        tar.add(r / 'build/integrated-cli-results-v2' / name, arcname='corrected/' + name)
    for p in sorted(paper.iterdir()):
        if p.is_file() and p.suffix in ('.c', '.json', '.log'):
            tar.add(p, arcname='paper-examples/' + p.name)
    for name in proof['manuscript_sha256']:
        tar.add(r / name, arcname='manuscripts/' + Path(name).name)
    for name in ('run-integrated-be96caf-v1.py', 'run-integrated-cli-v2.py',
                 'audit-current-paper-examples-v1.py', 'finalize-integration-cli-paper.py'):
        tar.add(r / 'build' / name, arcname='harness/' + name)
    raw(tar, 'source-identities.json', dict(current=source, baseline=before))
summary = dict(status='passed-native-phase-and-current-paper-examples-only', date='2026-10-26',
    base_commit='be96caf', compiler_input_files=237, source_sha256=source,
    changed_compiler_inputs=['tests/test_examples.c'], production_source_changes=False,
    normal_native_core=395, normal_example_checks=1509, examples=37, optimization_levels=5,
    paper_examples=dict(unique_c_blocks=3, native_executions=3, complete_formula_states=6,
                        manuscript_sha256=proof['manuscript_sha256'], results=proof['results']),
    build_reuse=reuse, full_normal_and_sanitized_integration_qualified=False,
    scope='Completed normal native phase and exact current manuscript examples. No broad CI, new SDK, historical benchmark/PDF rebuild, general scientific review, everyday-C completeness or QPU claim. Cybersecurity remains classical.',
    artifact_sha256={'evidence.tar.gz': sha(out / 'evidence.tar.gz')})
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
names = sorted(set(source) | set(docs) | {'docs/audit-evidence/integration-cli-paper-v1/summary.json',
                                       'docs/audit-evidence/integration-cli-paper-v1/evidence.tar.gz'})
(r / 'build/integration-cli-paper-git-expected.json').write_text(json.dumps({n: sha(r / n) for n in names}, indent=2) + '\n')
imports = sorted(set(docs) | {'tests/test_examples.c', 'docs/audit-evidence/integration-cli-paper-v1/summary.json',
    'docs/audit-evidence/integration-cli-paper-v1/evidence.tar.gz', 'build/integration-cli-paper-git-expected.json'})
(r / 'build/integration-cli-paper-import.txt').write_text('\n'.join(imports) + '\n')
print('Archived completed native phase and paper examples;', len(names), 'publication files')
