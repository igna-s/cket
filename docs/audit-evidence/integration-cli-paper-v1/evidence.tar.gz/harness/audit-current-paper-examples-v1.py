import cmath, hashlib, json, math, os, re, subprocess
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/integrated-cli-source-v2'
out = r / 'build/current-paper-examples-v1'
out.mkdir()
manuscripts = {language: r / ('docs/paper/c_ket_paper' + ('_en' if language == 'en' else '') + '.md')
               for language in ('es', 'en')}
blocks = {language: re.findall(r'```c\n(.*?)```', p.read_text(), re.S)
          for language, p in manuscripts.items()}
assert len(blocks['es']) == len(blocks['en']) == 3 and blocks['es'] == blocks['en']
environment = dict(os.environ, CC='gcc-11', CKET_SEED='7')
environment.pop('CKET_SIMULATOR', None)
records = []

def run(name, command):
    result = subprocess.run(command, cwd=project, env=environment, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    (out / (name + '.log')).write_text(result.stdout)
    records.append(dict(command=command, exit_code=result.returncode, log=name + '.log'))
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, result.stdout
    return result.stdout

results = []
for index, name in enumerate(('hello', 'bell', 'find')):
    text = blocks['es'][index]
    if name != 'hello':
        if name == 'bell':
            text += 'printf("%u%u\\n", first, second);\n'
        text = '#include <quantum.h>\n#include <stdio.h>\nint main(void) {\n' + text + 'return 0;\n}\n'
    source = out / (name + '.c')
    source.write_text(text)
    native = run(name + '-native', [str(project / 'build/cket'), str(source), '-O2', '--run',
                                  '--seed', '7', '-o', str(out / name)])
    assert native.strip() in ({'12'} if name == 'hello' else {'00', '11'} if name == 'bell' else {'3'})
    ir = out / (name + '.json')
    run(name + '-ir', [str(project / 'build/cket'), str(source), '-O2', '--emit-ir', '-o', str(ir)])
    if name == 'hello':
        expected = {12: 1 + 0j}
    elif name == 'bell':
        expected = {0: 1 / math.sqrt(2), 3: 1 / math.sqrt(2)}
    else:
        theta = math.asin(1 / 4)
        expected = {k: math.sin(7 * theta) if k == 3 else math.cos(7 * theta) / math.sqrt(15)
                    for k in range(16)}
    for tables in (0, 1):
        state = json.loads(run(name + '-state-' + str(tables), [str(project / 'build/cket_backend'),
            '--state', str(ir), *([] if tables else ['--no-tables'])]))
        actual = {int(row['index']): complex(row['real'], row['imag']) for row in state['amplitudes']}
        assert abs(sum(abs(a) ** 2 for a in actual.values()) - 1) < 1e-10
        pivot = max(expected, key=lambda k: abs(expected[k]))
        phase = actual.get(pivot, 0j) / expected[pivot]
        assert abs(abs(phase) - 1) < 1e-10
        error = max(abs(actual.get(k, 0j) - phase * expected.get(k, 0j)) for k in actual.keys() | expected.keys())
        assert error < 1e-10, (name, tables, error)
        results.append(dict(example=name, tables=tables, maximum_complete_state_error=error,
                            formula='C result 12' if name == 'hello' else 'Bell amplitudes' if name == 'bell'
                            else 'sin(7 asin(1/4)) and cos(7 asin(1/4))/sqrt(15)',
                            explicit_measurements_ignored_for_unitary_comparison=True))
assert len(records) == 12 and len(results) == 6
summary = dict(status='passed-current-native-values-and-finite-states', date='2026-10-26',
    compiler_snapshot=str(project), compiler_source_sha256=json.loads((project / 'source-hashes.json').read_text()),
    manuscript_sha256={p.relative_to(r).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in manuscripts.values()},
    unique_c_examples=3, equal_code_blocks_in_both_languages=True, native_executions=3,
    complete_state_comparisons=6, results=results,
    scope='Exact three C blocks from both unchanged manuscripts; O2 native values with seed 7 and complete formula states under both synthesis policies. Does not rerun historical evaluation, inspect PDF layout, establish general correctness or qualify a physical QPU.')
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('PASS current exact manuscript examples: 3 native executions, 6 complete formula states; historical artifacts preserved')
