import hashlib, json, os, runpy, shutil, subprocess, time
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/integrated-be96caf-source-v1'
out = r / 'build/integrated-be96caf-results-v1'
project.mkdir()
out.mkdir()
source = runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']()
assert source == json.loads((r / 'build/lazy-pending-source-v1/source-hashes.json').read_text())
assert len(source) == 237
for name in source:
    p = project / name
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(r / name, p)
shutil.copy2(r / 'LICENSE', project / 'LICENSE')
(project / '.deps').symlink_to(r / '.deps', target_is_directory=True)
(project / 'cket').chmod(0o755)
(project / 'source-hashes.json').write_text(json.dumps(source, indent=2) + '\n')
archives = list((r / 'build').glob('*/build/validation-deps/quest-3.7.0.tar.gz'))
if (r / 'build/validation-deps/quest-3.7.0.tar.gz').exists():
    archives.insert(0, r / 'build/validation-deps/quest-3.7.0.tar.gz')
if archives:
    p = archives[0]
    assert hashlib.sha256(p.read_bytes()).hexdigest() == '1a5939798a70b749dfa57cfaa116ece03a2d36aa59c1b712cb3dc2103ab1cded'
    destination = project / 'build/validation-deps'
    destination.mkdir(parents=True)
    shutil.copy2(p, destination / p.name)
environment = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_FUZZ_SEED='20261012', CKET_FUZZ_CASES='24')
environment.pop('CKET_SIMULATOR', None)
environment.pop('CKET_SAN_ROOT', None)
command = ['bash', 'scripts/verify.sh']
started = time.time()
with (out / 'verify.log').open('w') as log:
    child = subprocess.Popen(command, cwd=project, env=environment, stdout=log, stderr=subprocess.STDOUT)
    (out / 'process.json').write_text(json.dumps(dict(pid=child.pid, command=command, cwd=str(project),
        commit='be96caf', source_files=237, started_unix=started), indent=2) + '\n')
    print('Started full integration', child.pid, project, flush=True)
    code = child.wait()
unchanged = all(hashlib.sha256((project / n).read_bytes()).hexdigest() == h for n, h in source.items())
result = dict(exit_code=code, frozen_inputs_unchanged=unchanged, elapsed_seconds=time.time()-started,
              scope='Exact scripts/verify.sh, normal and full sanitized phases, stops on first failure.')
(out / 'terminal.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
assert unchanged
raise SystemExit(code)
