import hashlib, json, os, runpy, shlex, shutil, subprocess, time
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
base = r / 'build/integrated-be96caf-source-v1'
project = r / 'build/integrated-cli-source-v2'
out = r / 'build/integrated-cli-results-v2'
project.mkdir()
out.mkdir()
fmt = runpy.run_path(str(r / 'scripts/format.py'))['format_text']
names = ['tests/test_examples.c', 'docs/paper/README.md', 'docs/c11-heap.md',
         'docs/c11-buffer-functions.md', 'docs/v1-plan.md']
for name in names:
    p = r / name
    p.write_text(fmt(p, p.read_text()))
source = runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']()
before = json.loads((base / 'source-hashes.json').read_text())
assert len(source) == len(before) == 237
assert [n for n in source if source[n] != before[n]] == ['tests/test_examples.c']
for name in source:
    p = project / name
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(r / name, p)
shutil.copy2(r / 'LICENSE', project / 'LICENSE')
(project / '.deps').symlink_to(r / '.deps', target_is_directory=True)
(project / 'cket').chmod(0o755)
(project / 'source-hashes.json').write_text(json.dumps(source, indent=2) + '\n')
(project / 'build').mkdir()
reused = {}
for p in (base / 'build').iterdir():
    if p.is_file() and p.name != 'test_examples' and p.suffix not in ('.log', '.csv'):
        shutil.copy2(p, project / 'build' / p.name)
        reused[p.name] = hashlib.sha256(p.read_bytes()).hexdigest()
assert all(n in reused for n in ('cket', 'cket_plugin.so', 'libcket_quantum.a', 'validate_history'))
archive = base / 'build/validation-deps/quest-3.7.0.tar.gz'
if archive.exists():
    destination = project / 'build/validation-deps'
    destination.mkdir()
    shutil.copy2(archive, destination / archive.name)
environment = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_FUZZ_SEED='20261012', CKET_FUZZ_CASES='24')
environment.pop('CKET_SIMULATOR', None)
environment.pop('CKET_SAN_ROOT', None)
command = ['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-Isrc/engine',
           'tests/test_examples.c', 'tests/validation.c', '-o', 'build/test_examples']
result = subprocess.run(command, cwd=project, env=environment, text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'test-examples-build.log').write_text(result.stdout)
assert result.returncode == 0, result.stdout
(out / 'build-reuse.json').write_text(json.dumps(dict(
    base=str(base), source_changes=['tests/test_examples.c'], reused_artifact_sha256=reused,
    rebuilt_command=command, rebuilt_exit_code=result.returncode,
    scope='Only the test_examples version assertion changed. Full production binaries and other validators retain exact bytes from the completed preceding build.'), indent=2) + '\n')
script = (project / 'scripts/verify.sh').read_text()
build = 'bash scripts/build.sh 2>&1 | tee build/verify-build.log\n'
assert script.count(build) == 1
script = script.replace(build, '').replace('cd "$(dirname "$0")/.."', 'cd ' + shlex.quote(str(project)), 1)
continuation = out / 'verify-after-build.sh'
continuation.write_text(script)
started = time.time()
with (out / 'verify.log').open('w') as log:
    child = subprocess.Popen(['bash', str(continuation)], cwd=project, env=environment,
                             stdout=log, stderr=subprocess.STDOUT)
    (out / 'process.json').write_text(json.dumps(dict(pid=child.pid, cwd=str(project), started_unix=started,
        source_files=237, base_commit='be96caf', changed_inputs=['tests/test_examples.c']), indent=2) + '\n')
    print('Started integration after recorded build reuse', child.pid, flush=True)
    code = child.wait()
unchanged = all(hashlib.sha256((project / n).read_bytes()).hexdigest() == h for n, h in source.items())
result = dict(exit_code=code, frozen_inputs_unchanged=unchanged, elapsed_seconds=time.time()-started,
              scope='All verify.sh commands after the separately recorded normal build; includes the normal suite and full sanitized phase, stops on first failure.')
(out / 'terminal.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
assert unchanged
raise SystemExit(code)
