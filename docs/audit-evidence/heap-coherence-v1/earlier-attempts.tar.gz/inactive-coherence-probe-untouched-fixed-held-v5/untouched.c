#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(void){quant uint16_t y=0;quant uint16_t *p=&y;
quant uint8_t a=superposition(0,1),b=superposition(0,1),x=superposition(0,1);
quant bool control=superposition(0,1);
if(a)phase(.73);if(b)phase(.31);if(x)phase(.19);
p[0]=((uint16_t)a<<8)|b;ownership_checkpoint("before");
if(control)memcpy((void*)p,(const void*)&x,1);
ownership_checkpoint("after");
measure(y);measure(a);measure(b);measure(x);measure(control);return 0;}
