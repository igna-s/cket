#ifndef CKET_TEST_LOCALE_FIXTURE_H
#define CKET_TEST_LOCALE_FIXTURE_H
#include "validation.h"
#include <stdlib.h>
#include <unistd.h>

static void validation_locale_fixture(validation *v, int remove) {
    char path[4096];
    if (!remove) {
        validation_path(path, sizeof path, "%s/en_US.ISO-8859-1", v->temp);
        char *command[] = {
            "localedef", "--no-archive", "-i", "en_US", "-f", "ISO-8859-1", path, NULL};
        if (validation_run(v, command, NULL, 90) || setenv("LOCPATH", v->temp, 1))
            validation_fail(
                "cannot build isolated Latin-1 fixture (requires localedef and locales sources)\n%s",
                validation_read(v->log));
        return;
    }
    const char *files[] = {"LC_CTYPE",
                           "LC_NUMERIC",
                           "LC_TIME",
                           "LC_COLLATE",
                           "LC_MONETARY",
                           "LC_MESSAGES/SYS_LC_MESSAGES",
                           "LC_PAPER",
                           "LC_NAME",
                           "LC_ADDRESS",
                           "LC_TELEPHONE",
                           "LC_MEASUREMENT",
                           "LC_IDENTIFICATION"};
    for (unsigned i = 0; i < sizeof files / sizeof *files; ++i) {
        validation_path(path, sizeof path, "%s/en_US.ISO-8859-1/%s", v->temp, files[i]);
        if (unlink(path))
            validation_fail("cannot remove generated locale fixture file");
    }
    validation_path(path, sizeof path, "%s/en_US.ISO-8859-1/LC_MESSAGES", v->temp);
    if (rmdir(path))
        validation_fail("cannot remove generated locale message directory");
    validation_path(path, sizeof path, "%s/en_US.ISO-8859-1", v->temp);
    if (rmdir(path))
        validation_fail("cannot remove generated locale fixture directory");
}

#endif
