import json
import os
from pathlib import Path
import runpy
import subprocess
import sys

root=Path('/tmp/quantum-audit-isolated-20261017')
version=sys.argv[2]
project=root/('build/coherent-store-source-'+version)
mode=sys.argv[1]
target=project if mode=='normal' else root/('build/coherent-store-sanitized-'+version)
assert json.loads((target/'build-exit.json').read_text())['exit_code']==0
output=root/('build/coherent-store-'+mode+'-results-'+version)
output.mkdir()
env=dict(os.environ,CC='gcc-11',CKET_SEED='7',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode=='sanitized':
    env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11')
records=[]
def run(label,command):
    with (output/(label+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
    records.append(dict(command=command,exit_code=result.returncode,log=label+'.log'))
    (output/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,result.returncode,(output/(label+'.log')).read_text()[-1800:],flush=True)
    assert result.returncode==0
extra=['--sanitized'] if mode=='sanitized' else []
run('coherent-overwrites',['python3','scripts/validate-coherent-overwrites.py','--compiler-root',str(target),
                           '--output',str(output/'coherent-overwrites'),'--levels',*(['O0','O2'] if mode=='normal' else ['O1']),*extra])
for name,script in [('runtime-memory','validate-runtime-memory.py'),('ownership','validate-ownership.py')]:
    run(name,['python3','scripts/'+script,'--compiler-root',str(target),'--output',str(output/name),
              '--levels','O2' if mode=='normal' else 'O1',*extra])
for name in ('validate_memcopy','validate_memset','validate_runtime_versions','validate_runtime_memory','validate_controlled_operands'):
    run(name,[str(target/'build'/name)])
run('core',[str(target/'build/cket_tests'),str(target)])
if mode=='normal':
    run('block05',['bash','scripts/run-block.sh','05'])
hashes=runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()
assert hashes==json.loads((project/'source-hashes.json').read_text())
(output/'summary.json').write_text(json.dumps(dict(status='passed',mode=mode,source_files=len(hashes),commands=len(records)),indent=2)+'\n')
print('PASS unchanged',len(hashes),'frozen inputs',flush=True)
