import json
import os
from pathlib import Path
import subprocess

root=Path('/tmp/quantum-audit-isolated-20261017')
compiler=root/'build/coherent-store-source-v4'
output=root/'build/heap-identity-probe-v4'
output.mkdir()
env=dict(os.environ,CC='gcc-11',CKET_SIMULATOR='sparse',CKET_SEED='7')
trace=root/'build/quantum-nature-probe-v4/trace.o'
records=[]
results=[]
for name,operation in {'assignment':'p[0]=p[0];','move':'memmove((void*)p,(const void*)p,1);',
                       'fill':'memset((void*)p,p[0],1);'}.items():
    source=output/(name+'.c');binary=output/name
    source.write_text('''#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t *p=calloc(1,1);if(!p)return 2;
quant uint8_t y=superposition(0,1);if(y)phase(.73);
memcpy((void*)p,(const void*)&y,1);ownership_checkpoint("before");
'''+operation+'''ownership_checkpoint("after");free((void*)p);measure(y);return 0;}
''')
    output_text=''
    for stage,command in [('compile',[str(compiler/'build/cket'),str(source),'-O2','-Wl,'+str(trace),
                                      '-Wl,--wrap=qc_create_sparse','-Wl,--wrap=__cket_apply','-o',str(binary)]),
                           ('execute',[str(binary)])]:
        r=subprocess.run(command,cwd=compiler,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
        (output/(name+'-'+stage+'.log')).write_text(r.stdout)
        records.append(dict(command=command,exit_code=r.returncode,log=name+'-'+stage+'.log'))
        assert r.returncode==0,r.stdout
        output_text=r.stdout
    points=[json.loads(line) for line in output_text.splitlines() if line.startswith('{')]
    purities=[]
    for point in points:
        heap=point['heaps'][0]['ids'][0]
        selected=[wire for reg in point['registers'] if reg['id']==heap or reg['name']=='y'
                  for wire in reg['wires']]
        mask=sum(1<<wire for wire in selected)
        blocks={}
        for basis,real,imag in point['state']:
            basis=int(basis,0)
            local=sum(((basis>>wire)&1)<<i for i,wire in enumerate(selected))
            blocks.setdefault(basis&~mask,{})[local]=complex(real,imag)
        rho={}
        for block in blocks.values():
            for a,left in block.items():
                for b,right in block.items():
                    rho[a,b]=rho.get((a,b),0j)+left*right.conjugate()
        purities.append(sum(abs(value)**2 for value in rho.values()))
    result=dict(case=name,joint_purities=purities,measurements=points[-1]['measurements'],resets=points[-1]['resets'])
    results.append(result);print(json.dumps(result),flush=True)
(output/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
(output/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
