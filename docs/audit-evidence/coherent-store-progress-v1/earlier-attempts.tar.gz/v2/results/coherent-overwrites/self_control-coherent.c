#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(int argc,char **argv){
size_t n=argc>1?strtoul(argv[1],0,10):1;
quant uint8_t x=superposition(0,1),y=superposition(0,3);
quant bool control=superposition(0,1);
if(x)phase(.31);if(y&1)phase(.73);if(y&2)phase(.29);if(control)phase(.19);

ownership_checkpoint("before");
if((y&2)){y=x^0;}
ownership_checkpoint("after");
measure(y);measure(x);measure(control);return 0;
}
