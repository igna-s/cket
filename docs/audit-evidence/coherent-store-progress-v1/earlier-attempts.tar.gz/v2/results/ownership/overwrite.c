#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant uint8_t x=superposition(0,3);
        if(x==3) phase(.31);
        quant uint8_t old=x^1;
        x=9;
        ownership_checkpoint("retained");
        if(old==2) phase(.17);
        ownership_checkpoint("inverse");
        measure(x); return 0;
    }
