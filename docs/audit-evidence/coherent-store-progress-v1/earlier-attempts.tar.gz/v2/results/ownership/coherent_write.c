#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant bool index=superposition(0,1);
        quant uint8_t values[2]={3,9};
        if(index)phase(.31);
        values[index]=7;
        if(values[0]==7)phase(.17);
        ownership_checkpoint("written");
        measure(values[1]);measure(values[0]);measure(index);return 0;
    }
