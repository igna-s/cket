#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
void f(quant uint8_t x){quant uint8_t y=x;measure(y);} int main(void){quant uint8_t x=1;f(x);measure(x);}
