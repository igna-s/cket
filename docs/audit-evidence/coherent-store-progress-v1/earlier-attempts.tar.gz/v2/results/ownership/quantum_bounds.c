#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t x[2]={1,2};quant uint8_t i=superposition(0,3);quant uint8_t y=x[i]^1;measure(y);measure(x[0]);measure(x[1]);measure(i);}
