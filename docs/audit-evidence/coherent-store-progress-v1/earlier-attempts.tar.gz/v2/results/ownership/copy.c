#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant uint8_t x=superposition(0,1), y=0, z=0;
        if(x==1) phase(.31);
        memcpy(&y,&x,1); memcpy(&z,&x,1);
        ownership_checkpoint("copied");
        if(y==1) phase(.17);
        z^=x; y^=x;
        ownership_checkpoint("inverse");
        measure(z); measure(y); measure(x); return 0;
    }
