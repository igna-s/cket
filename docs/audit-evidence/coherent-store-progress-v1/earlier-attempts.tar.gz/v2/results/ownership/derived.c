#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant uint8_t x=superposition(0,3);
        if(x==3) phase(.31);
        quant uint8_t result=x^1;
        ownership_checkpoint("computed");
        if(result==2) phase(.17);
        ownership_checkpoint("inverse");
        measure(x); return 0;
    }
