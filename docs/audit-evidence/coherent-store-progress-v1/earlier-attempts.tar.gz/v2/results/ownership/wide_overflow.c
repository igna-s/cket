#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
#include <limits.h>
int main(void){quant uint32_t x=1;quant long long y=LLONG_MAX;x+=y;measure(x);measure(y);}
