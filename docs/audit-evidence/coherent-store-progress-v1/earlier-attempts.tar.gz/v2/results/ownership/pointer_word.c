#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
quant uint16_t read_word(quant const uint16_t *p,quant const bool index) {
        return p[index]^0x100;
    }
    int main(void) {
        quant bool index=superposition(0,1);
        quant uint16_t values[2]={0x201,0x405};
        if(index)phase(.31);
        quant uint16_t result=read_word(values,index);
        ownership_checkpoint("computed");
        if(result==0x505)phase(.17);
        ownership_checkpoint("inverse");
        measure(values[1]);measure(values[0]);measure(index);return 0;
    }
