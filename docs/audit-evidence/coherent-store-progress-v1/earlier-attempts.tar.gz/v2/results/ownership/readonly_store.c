#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
void f(quant const uint8_t *x,quant const bool b){x[b]=1;} int main(void){quant uint8_t x[2]={1,2};quant bool b=superposition(0,1);f(x,b);measure(x[0]);measure(x[1]);measure(b);}
