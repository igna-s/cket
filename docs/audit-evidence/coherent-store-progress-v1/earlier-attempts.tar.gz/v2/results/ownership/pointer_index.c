#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
quant uint8_t read_buffer(quant const uint8_t *p,quant const bool index) {
        return p[index]^3;
    }
    int main(void) {
        quant bool index=superposition(0,1);
        quant uint8_t values[3]={2,5,9};
        if(index)phase(.31);
        quant uint8_t *tail=values+1;
        quant uint8_t result=read_buffer(tail,index);
        ownership_checkpoint("computed");
        if(result==10)phase(.17);
        ownership_checkpoint("inverse");
        measure(values[2]);measure(values[1]);measure(values[0]);measure(index);return 0;
    }
