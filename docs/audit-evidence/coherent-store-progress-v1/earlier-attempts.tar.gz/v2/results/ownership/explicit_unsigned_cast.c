#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
#include <limits.h>
int main(void){quant uint8_t x=1;quant int y=INT_MAX;x += (uint8_t)y;unsigned result=measure(x);measure(y);return result!=0;}
