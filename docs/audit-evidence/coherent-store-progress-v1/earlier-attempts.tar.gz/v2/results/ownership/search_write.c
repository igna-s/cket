#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant bool index=superposition(0,1);
        quant char text[3]={'a',index?'a':'b',0};
        if(index)phase(.31);
        char *last=strrchr(text,'a');
        (*last)++;
        *last='x';
        if(text[1]=='x')phase(.17);
        ownership_checkpoint("written");
        measure(text[2]);measure(text[1]);measure(text[0]);measure(index);return 0;
    }
