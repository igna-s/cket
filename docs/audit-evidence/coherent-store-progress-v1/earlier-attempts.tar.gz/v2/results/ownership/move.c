#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant uint8_t x=superposition(0,1);
        if(x==1) phase(.31);
        quant uint8_t y=x;
        ownership_checkpoint("moved");
        measure(y); return 0;
    }
