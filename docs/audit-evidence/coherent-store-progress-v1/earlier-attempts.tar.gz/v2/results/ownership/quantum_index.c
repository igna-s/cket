#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant bool index=superposition(0,1);
        quant uint8_t values[2]={3,9};
        if(index) phase(.31);
        quant uint8_t result=values[index]^1;
        ownership_checkpoint("computed");
        if(result==8) phase(.17);
        ownership_checkpoint("inverse");
        measure(values[1]); measure(values[0]); measure(index); return 0;
    }
