#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
#include <limits.h>
int main(void){quant bool b=0;quant uint8_t x=1;quant int y=INT_MAX;if(b)x+=y;unsigned result=measure(x);measure(y);measure(b);return result!=1;}
