#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
void scan(quant const uint8_t *values,size_t count,quant uint8_t total) {
        for(size_t i=0;i<count;++i) total+=values[i];
    }
    void undo(quant const uint8_t *values,size_t count,quant uint8_t total) {
        size_t i=0; while(i<count) {total-=values[i];++i;}
    }
    int main(void) {
        quant uint8_t values[2]={superposition(0,3),5}, total=0;
        if(values[0]==3) phase(.31);
        size_t count=2;
        scan(values,count,total);
        ownership_checkpoint("computed");
        if(total==8) phase(.17);
        undo(values,count,total);
        ownership_checkpoint("inverse");
        measure(total); measure(values[1]); measure(values[0]); return 0;
    }
