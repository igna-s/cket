#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant uint8_t values[2]={superposition(0,3),5};
        if(values[0]==3) phase(.31);
        size_t index=0;
        quant uint8_t result=values[index]^1;
        index=1;
        ownership_checkpoint("computed");
        if(result==2) phase(.17);
        ownership_checkpoint("inverse");
        measure(values[1]); measure(values[0]); return index!=1;
    }
