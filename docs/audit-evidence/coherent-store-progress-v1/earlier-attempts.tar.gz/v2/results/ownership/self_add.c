#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void){quant uint8_t x=1;quant uint8_t *p=&x;size_t i=0;x+=p[i];measure(x);}
