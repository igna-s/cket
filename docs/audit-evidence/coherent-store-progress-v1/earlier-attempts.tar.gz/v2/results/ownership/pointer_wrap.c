#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void){quant uint16_t x[2]={1,2};quant uint16_t *p=x;size_t i=(size_t)1<<63;quant uint16_t y=p[i]^1;measure(y);measure(x[0]);measure(x[1]);}
