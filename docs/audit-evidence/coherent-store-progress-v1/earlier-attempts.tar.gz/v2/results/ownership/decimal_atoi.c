#include <quantum.h>
#include <string.h>
#include <stdlib.h>
void ownership_checkpoint(const char*);
int main(void) {
        quant bool index=superposition(0,1);
        quant char text[3]={index?'1':'2','3',0};
        if(index)phase(.31);
        quant int result=atoi((const char*)text);
        ownership_checkpoint("computed");
        if(result==13)phase(.17);
        ownership_checkpoint("inverse");
        measure(text[2]);measure(text[1]);measure(text[0]);measure(index);return 0;
    }
