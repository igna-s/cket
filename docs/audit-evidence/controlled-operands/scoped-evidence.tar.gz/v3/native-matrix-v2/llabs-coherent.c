#include <quantum.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
int main(int argc,char **argv){int k=argc>1?atoi(argv[1]):0;int enabled=argc>2?argv[2][0]-'0':0;(void)enabled;quant bool b=superposition(0,1);quant uint8_t x=5;if(b)phase(.31);if(b){x = llabs(10LL/k);phase(.17);}unsigned a=measure(x),v=measure(b);return a!=(v?(unsigned)(uint8_t)(llabs(10LL/k)):5);}
