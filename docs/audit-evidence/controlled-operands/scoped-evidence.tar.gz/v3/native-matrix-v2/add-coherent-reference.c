#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#define phase(x) ((void)(x))
#define superposition(a,b) (b)
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
int main(int argc,char **argv){int k=argc>1?atoi(argv[1]):0;int enabled=argc>2?argv[2][0]-'0':0;(void)enabled;quant bool b=superposition(0,1);quant uint8_t x=5;if(b)phase(.31);if(b){x += 10/k;phase(.17);}unsigned a=measure(x),v=measure(b);return a!=(v?(unsigned)(uint8_t)(5 + 10/k):5);}
