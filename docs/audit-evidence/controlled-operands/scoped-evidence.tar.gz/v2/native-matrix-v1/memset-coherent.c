#include <quantum.h>
#include <string.h>
#include <stdlib.h>
int main(int argc,char **argv){int k=argc>1?argv[1][0]-'0':0;int enabled=argc>2?argv[2][0]-'0':0;(void)enabled;quant bool b=superposition(0,1);quant uint8_t x=5;if(b)phase(.31);if(b){memset((void *)&x,10/k,1);phase(.17);}unsigned a=measure(x),v=measure(b);return a!=(v?5:5);}
