"""Exercise controlled operands without mistaking C-UB diagnostics for support."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parent.parent
CANDIDATE = ROOT / 'build/coherent-body-prototype-v2'
OUT = CANDIDATE / 'build/native-matrix-v1'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


if '--worker' not in sys.argv:
    OUT.mkdir()
    shutil.copyfile(Path(__file__), OUT / 'runner.py')
    with (OUT / 'worker.log').open('x') as log:
        process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker'],
            cwd=CANDIDATE, stdin=subprocess.DEVNULL, stdout=log,
            stderr=subprocess.STDOUT, start_new_session=True)
    fields = (Path('/proc') / str(process.pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    write_json(OUT / 'job.json', {'pid': process.pid, 'linux_start_ticks': int(fields[19]),
        'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
        'runner_sha256': digest(Path(__file__))})
    print('Started controlled-body native and sanitizer matrix:', process.pid)
    raise SystemExit(0)


record = {'status': 'running', 'configurations': [], 'rows': [],
    'scope': 'Seven integer-operand profiles, basis and coherent controls, all five GCC levels '
             'and both builtin modes. Four basis inputs include an active undefined division; '
             'two coherent inputs include the analogous active undefined domain. Defined native '
             'executions and expected undefined-domain diagnostics are counted separately. '
             'Independent complex-state/inverse proof and broad regression remain pending. '
             'Phase-angle and inactive invalid-memory bugs are outside this correction. '
             'Main137 and its source-identical broad campaign are unchanged; cybersecurity unchanged.'}
write_json(OUT / 'progress.json', record)
try:
    frozen = json.loads((CANDIDATE / 'build/sources.json').read_text())
    for name, expected in frozen.items():
        assert digest(CANDIDATE / name) == expected, name
    record['source_sha256'] = frozen
    cases = {
        'xor': ('x ^= 10/k;', 0),
        'add': ('x += 10/k;', 10),
        'assignment': ('x = 10/k;', 5),
        'mixed-add': ('x = x + 10/k;', 10),
        'memset': ('memset((void *)&x,10/k,1);', 5),
        'abs': ('x = abs(10/k);', 5),
        'zero-length-memset': ('memset((void *)&x,10/k,0);', 5),
    }
    fixtures = []
    references = []
    for name, (operation, active) in cases.items():
        for kind in ('basis', 'coherent'):
            source = OUT / (name + '-' + kind + '.c')
            control = '(bool)enabled' if kind == 'basis' else 'superposition(0,1)'
            program = ('#include <quantum.h>\n#include <string.h>\n#include <stdlib.h>\n'
                'int main(int argc,char **argv){int k=argc>1?argv[1][0]-\'0\':0;'
                'int enabled=argc>2?argv[2][0]-\'0\':0;(void)enabled;quant bool b=' + control + ';'
                'quant uint8_t x=5;if(b)phase(.31);if(b){' + operation + 'phase(.17);}'
                'unsigned a=measure(x),v=measure(b);return a!=(v?' + str(active) + ':5)' +
                ('||v!=(unsigned)(enabled!=0)' if kind == 'basis' else '') + ';}\n')
            source.write_text(program)
            ordinary = OUT / (name + '-' + kind + '-reference.c')
            ordinary.write_text('#include <stdint.h>\n#include <stdbool.h>\n#define quant\n'
                '#define measure(x) (x)\n#define phase(x) ((void)(x))\n#define superposition(a,b) (b)\n' +
                program.replace('#include <quantum.h>\n', ''))
            reference = OUT / (name + '-' + kind + '-reference')
            compiled = subprocess.run(['gcc-11', '-std=c11', '-O2', str(ordinary), '-o', str(reference)],
                                      capture_output=True, text=True)
            assert compiled.returncode == 0, compiled.stderr
            inputs = [('0', '0'), ('2', '0'), ('2', '1')] if kind == 'basis' else [('2', '1')]
            for arguments in inputs:
                result = subprocess.run([str(reference), *arguments], capture_output=True, text=True)
                assert result.returncode == 0, (name, kind, arguments, result.stderr)
                references.append({'name': name, 'kind': kind, 'arguments': arguments, 'returncode': result.returncode})
            fixtures.append({'name': name, 'kind': kind, 'source': str(source), 'sha256': digest(source)})
    assert len(references) == 28
    write_json(OUT / 'ordinary-c-references.json', references)
    for configuration in ('normal', 'sanitized'):
        if configuration == 'normal':
            stage = CANDIDATE
            env = dict(os.environ, CC='gcc-11', CKET_REAL_GCC='gcc-11')
        else:
            stage = OUT / 'sanitized-stage'
            (stage / 'build').mkdir(parents=True)
            for name in ('include', 'src', 'tests', 'examples'):
                (stage / name).symlink_to(CANDIDATE / name, target_is_directory=True)
            shutil.copyfile(CANDIDATE / 'cket', stage / 'cket')
            integration = json.loads((ROOT / 'docs/audit-evidence/coherent-memory-integration/integration-summary.json').read_text())
            tools = next(item['fresh_core_sha256'] for item in integration['root_verification']['configurations']
                         if item['configuration'] == 'sanitized')
            provenance = {}
            for name in ('cket', 'cket_backend', 'cket_runtime.o', 'libcket_quantum.a', 'gcc-wrapper'):
                source = ROOT / 'build/coherent-integration-v1/project/build/sanitized/build' / name
                if name in tools:
                    assert digest(source) == tools[name], name
                provenance[name] = digest(source)
                shutil.copyfile(source, stage / 'build' / name)
                (stage / 'build' / name).chmod(0o755)
            argv = ['g++-11', '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Wno-unused-parameter',
                '-Wno-format-diag', '-fPIC', '-shared', '-fno-rtti', '-fsanitize=address,undefined',
                '-fno-omit-frame-pointer', '-I.deps/gcc/usr/lib/gcc/x86_64-linux-gnu/11/plugin/include',
                '-I.deps/gcc/usr/include', '-I.deps/gcc/usr/include/x86_64-linux-gnu',
                'src/cket_plugin.cpp', '-o', str(stage / 'build/cket_plugin.so')]
            with (OUT / 'fresh-sanitized-plugin.log').open('x') as handle:
                result = subprocess.run(argv, cwd=CANDIDATE, stdout=handle, stderr=subprocess.STDOUT)
            assert result.returncode == 0
            write_json(OUT / 'sanitized-provenance.json', {'fresh_plugin_sha256': digest(stage / 'build/cket_plugin.so'),
                       'reused_source_identical_core_sha256': provenance})
            env = dict(os.environ, CC=str(stage / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11',
                       UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        rows = []
        for fixture in fixtures:
            for level in ('-O0', '-O1', '-O2', '-O3', '-Os'):
                for builtin in ('-fbuiltin', '-fno-builtin'):
                    binary = OUT / (fixture['name'] + '-' + fixture['kind'] + '-' + configuration + '-' + level[1:] + '-' + builtin[2:])
                    result = subprocess.run([str(stage / 'build/cket'), fixture['source'], level, builtin, '-o', str(binary)],
                                            cwd=CANDIDATE, env=env, capture_output=True, text=True)
                    row = dict(fixture, configuration=configuration, optimization=level, builtins=builtin,
                               compile_returncode=result.returncode, compile_stderr=result.stderr, runs=[])
                    rows.append(row)
                    if result.returncode == 0:
                        variants = [('0', '0'), ('2', '0'), ('2', '1'), ('0', '1')] if fixture['kind'] == 'basis' else [('2', '1'), ('0', '1')]
                        for arguments in variants:
                            result = subprocess.run([str(binary), *arguments], env=env, capture_output=True, text=True)
                            undefined = arguments == ('0', '1')
                            expected = 1 if undefined else 0
                            passed = result.returncode == expected
                            if undefined:
                                passed &= 'C division/remainder by zero is undefined' in result.stderr
                            passed &= not any(marker in result.stderr for marker in ('AddressSanitizer:', 'runtime error:'))
                            row['runs'].append({'arguments': arguments, 'returncode': result.returncode,
                                                'expected_undefined_domain': undefined, 'passed': passed,
                                                'stderr': result.stderr})
                    row['passed'] = row['compile_returncode'] == 0 and all(item['passed'] for item in row['runs'])
                    write_json(OUT / (configuration + '-rows.json'), rows)
            print('Closed body operand:', configuration, fixture['name'], fixture['kind'], flush=True)
        summary = {'configuration': configuration, 'compiler_rows': len(rows),
                   'failed_compiler_rows': sum(not item['passed'] for item in rows),
                   'defined_native_executions': sum(not run['expected_undefined_domain'] and run['passed'] for item in rows for run in item['runs']),
                   'undefined_domain_diagnostics': sum(run['expected_undefined_domain'] and run['passed'] for item in rows for run in item['runs'])}
        record['configurations'].append(summary)
        write_json(OUT / 'progress.json', record)
    for name, expected in frozen.items():
        assert digest(CANDIDATE / name) == expected, name
    passed = all(row['failed_compiler_rows'] == 0 and row['compiler_rows'] == 140 and
                 row['defined_native_executions'] == 280 and row['undefined_domain_diagnostics'] == 140
                 for row in record['configurations'])
    record.update(status='passed-scoped-native-matrix' if passed else 'failed-scoped-native-matrix', exit_code=0 if passed else 1)
except BaseException as error:
    traceback.print_exc()
    (OUT / 'failure.txt').write_text(traceback.format_exc())
    record.update(status='failed-matrix-worker', exit_code=1, error=repr(error))
write_json(OUT / 'exit.json', record)
write_json(OUT / 'progress.json', record)
print(json.dumps({key: value for key, value in record.items() if key not in ('rows', 'source_sha256')}), flush=True)
raise SystemExit(record['exit_code'])
