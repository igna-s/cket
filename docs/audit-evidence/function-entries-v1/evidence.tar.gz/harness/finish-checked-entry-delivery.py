import hashlib,json,runpy
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/function-entry-source-v2'
sdk=r/'output/sdk/checked-entry'
assert json.loads((r/'build/function-entry-results-v2/terminal.json').read_text())['status']=='passed'
audit=json.loads((sdk/'sdk-audit.json').read_text())
assert audit['source_files']==240
rows=[]
for name,command,signature in [('demo','output\\sdk\\checked-entry\\run_sdk_demo.cmd',None),('example','output\\sdk\\checked-entry\\run_checked_demo.cmd','scalar=1 vector=0,1'),('heap','output\\sdk\\checked-entry\\compile_and_run.cmd output\\sdk\\checked-entry\\example_heap.c','rounds=3 output=12 sum=30')]:
    log=(r/'build'/('checked-entry-windows-'+name+'.log')).read_text()
    if signature:assert signature in log
    else:assert sum(line.startswith('build/blocks/') for line in log.splitlines())==37
    rows.append(dict(command=command,exit_code=0,stdout=log))
audit.update(windows_verified_date='2026-10-27',windows_launchers=rows,
    scope='37 rebuilt native programs, 1509 normal example checks and three verified Windows workflows. Checked-call and quantum-state scopes are separately archived. Full integration, general quantum ABI, stable release and QPU remain open.')
(sdk/'sdk-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
p=sdk/'README.es.md';text=p.read_text().replace('output\\sdk\\readonly-borrows\\example_readonly.c','output\\sdk\\checked-entry\\example_readonly.c').replace('output\\sdk\\example_heap.c','output\\sdk\\checked-entry\\example_heap.c')
text+='\nEl CI anterior se detuvo en la referencia de memoria runtime con `unmodelled retained version`;\nese gate sigue abierto y no se presenta como una calificación aprobada de esta entrega.\n';p.write_text(text)
p=r/'README.md';text=p.read_text().replace('output/sdk/readonly-borrows/README.es.md','output/sdk/checked-entry/README.es.md').replace('output\\sdk\\readonly-borrows\\','output\\sdk\\checked-entry\\')
anchor='The compiler uses GCC\'s real C frontend.'
text=text.replace(anchor,'''The [checked function-entry correction](docs/c11-function-entries.md) rejects classical
prototypes and pointers that could reach an empty quantum template stub. A remaining native entry
reports an explicit error when called through a foreign/dynamic ABI. Ordinary CPU callbacks keep
their classical behavior. The general integration gate remains open.

'''+anchor);p.write_text(text)
p=r/'docs/entrega-utilizable-2026-10-26.es.md';text=p.read_text().replace('26 de octubre de 2026. Compilador','Actualizado el 27 de octubre de 2026. Compilador').replace('sdk\\readonly-borrows\\','sdk\\checked-entry\\').replace('run_readonly_demo.cmd','run_checked_demo.cmd').replace('output\\sdk\\example_heap.c','output\\sdk\\checked-entry\\example_heap.c').replace('../output/sdk/readonly-borrows/README.es.md','../output/sdk/checked-entry/README.es.md').replace('las 239 entradas exactas','las 240 entradas exactas')
anchor='La [corrección de préstamos]'
text=text.replace(anchor,'''La [corrección de entradas de función](c11-function-entries.md) añade 90 contratos normales e
instrumentados para llamadas, prototipos y punteros. Evita que una llamada clásica no comprobada
termine en un stub vacío. El CI anterior mantiene abierto un fallo de la referencia de memoria
runtime (`unmodelled retained version`); no es una ejecución general aprobada.

'''+anchor);p.write_text(text)
p=r/'docs/estado-general-del-proyecto.es.md';text=p.read_text().replace('Estado actualizado el 26 de octubre de 2026','Estado actualizado el 27 de octubre de 2026').replace('../output/sdk/readonly-borrows/README.es.md','../output/sdk/checked-entry/README.es.md').replace('output\\sdk\\readonly-borrows\\run_readonly_demo.cmd','output\\sdk\\checked-entry\\run_checked_demo.cmd')
anchor='**Préstamos de lectura compartidos:**'
text=text.replace(anchor,'''**Entradas de funciones comprobadas:** se rechazan prototipos clásicos y punteros que podían
alcanzar un stub vacío de una función `quant`. La entrada nativa restante devuelve un error
explícito en lugar de simular éxito. La [nota](c11-function-entries.md) y su
[evidencia de 240 entradas](audit-evidence/function-entries-v1/README.es.md) registran 90 contratos
normales e instrumentados, regresiones y el SDK reconstruido. El CI de la revisión anterior se
detuvo con `unmodelled retained version` en memoria runtime; ese gate sigue abierto.

'''+anchor);p.write_text(text)
p=r/'docs/paper/README.md';text=p.read_text();anchor='Estas campañas califican perfiles finitos'
text=text.replace(anchor,'''La [nota de entradas comprobadas](../c11-function-entries.md) corrige casos que alcanzaban
un stub clásico vacío de una función cuántica. Su
[campaña de 240 entradas](../audit-evidence/function-entries-v1/README.es.md) distingue los
rechazos de ABI de una implementación cuántica. La integración general conserva un fallo abierto
en la referencia de memoria runtime; el SDK nuevo no se presenta como una 1.0 estable.

'''+anchor);p.write_text(text)
p=r/'output/sdk/README.es.md';text=p.read_text().replace('usá el [SDK con préstamos de lectura](readonly-borrows/README.es.md).','usá el [SDK con entradas comprobadas](checked-entry/README.es.md).');p.write_text(text)
docs=['README.md','docs/entrega-utilizable-2026-10-26.es.md','docs/estado-general-del-proyecto.es.md','docs/paper/README.md','docs/c11-function-entries.md','docs/audit-evidence/function-entries-v1/README.es.md','output/sdk/README.es.md','output/sdk/checked-entry/README.es.md','output/sdk/checked-entry/sdk-audit.json']
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for name in docs:
    p=r/name;p.write_text(fmt(p,p.read_text()))
print('SDK Windows workflows and source-scoped documentation finalized')
