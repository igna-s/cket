import hashlib,json,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/function-entry-source-v2'
out=r/'build/function-entry-results-v2'
target=r/'build/function-entry-sanitized-v2'
result=json.loads((out/'terminal.json').read_text())
assert result['status']=='passed' and result['source_files']==240
if 'reused_artifact_sha256' in result:
    shutil.copy2(out/'terminal.json',out/'terminal-before-artifact-clarification.json')
    result['initially_copied_artifact_sha256']=result.pop('reused_artifact_sha256')
    result['artifact_note']='The runtime object was initially copied and then rebuilt before execution. Only the final artifact hashes identify the runtime/plugin used by these tests.'
    result['final_artifact_sha256']={mode:{name:hashlib.sha256((root/'build'/name).read_bytes()).hexdigest() for name in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','validate_function_entries')} for mode,root in [('normal',project),('sanitized',target)]}
    (out/'terminal.json').write_text(json.dumps(result,indent=2)+'\n')
sdk=r/'output/sdk/checked-entry'
shutil.copy2(project/'examples/readonly_borrows.c',sdk/'example_readonly.c')
shutil.copy2(project/'examples/blocks/05/heap_iterations.c',sdk/'example_heap.c')
(sdk/'run_checked_demo.cmd').write_text('''@echo off
call "%~dp0compile_and_run.cmd" "%~dp0example_readonly.c"
exit /b %errorlevel%
''')
(r/'build/checked-entry-sdk-import.txt').write_text('\n'.join(p.relative_to(r).as_posix() for p in sorted(sdk.iterdir()) if p.is_file())+'\n')
print('SDK and final plugin/runtime identities prepared')
