from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
s=(r/'build/qualify-readonly-borrows.py').read_text()
start=s.index('changed=[');end=s.index('\nfor name in changed:',start)
s=s[:start]+"changed=['src/cket_plugin.cpp','src/quantum_frontend.inc','src/cket_runtime.c','tests/validate_function_entries.c','scripts/build.sh','scripts/sanitize-all.sh','scripts/verify.sh','scripts/archive-audit.py']"+s[end:]
s=s.replace('build/qasm-cpu-source-v2/source-hashes.json','build/readonly-borrows-source-v3/source-hashes.json')
s=s.replace("root=r/'build/readonly-borrows-source-v3'","root=r/'build/function-entry-source-v2'")
s=s.replace('build/readonly-borrows-results-v3','build/function-entry-results-v2')
s=s.replace('build/readonly-borrows-sanitized-v3','build/function-entry-sanitized-v2')
s=s.replace('build/return-reference-source-v1','build/readonly-borrows-source-v3')
s=s.replace('build/return-reference-sanitized-v1','build/readonly-borrows-sanitized-v3')
s=s.replace('len(source)==239','len(source)==240').replace('source_files=239','source_files=240').replace('checks_per_configuration=305','checks_per_configuration=90')
s=s.replace("'validate_bindings','cket_tests'","'validate_bindings','cket_tests','validate_readonly_borrows'")
s=s.replace('tests/validate_readonly_borrows.c','tests/validate_function_entries.c')
s=s.replace("target/'build/validate_readonly_borrows'","target/'build/validate_function_entries'")
s=s.replace("mode+'-readonly-borrows'","mode+'-function-entries'")
anchor="    run(mode+'-validator-build',"
where=s.index(anchor)
s=s[:where]+"    run(mode+'-runtime',flags+['-c','src/cket_runtime.c','-o',str(target/'build/cket_runtime.o')],root,env)\n"+s[where:]
anchor="    if (target/'build/validate_bindings').exists():"
where=s.index(anchor)
s=s[:where]+"    run(mode+'-readonly-regression',[str(target/'build/validate_readonly_borrows')],root,env)\n"+s[where:]
s=s.replace('PASS readonly alias implementation, full states, independent gates/inverses and mutation boundaries','PASS checked quantum entries and classical prototype/pointer boundaries')
path=r/'build/qualify-function-entries-complete.py'
path.write_text(s)
assert "root=r/'build/function-entry-source-v2'" in s
assert "source_files=240" in s
exec(compile(s,str(path),'exec'))
