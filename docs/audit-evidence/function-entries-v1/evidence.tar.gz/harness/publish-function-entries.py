import hashlib,io,json,os,runpy,subprocess,tarfile
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/function-entry-source-v2'
sanitized=r/'build/function-entry-sanitized-v2'
out=r/'build/function-entry-results-v2'
sdk=r/'output/sdk/checked-entry'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((project/'source-hashes.json').read_text())
previous=r/'build/readonly-borrows-source-v3'
old=json.loads((previous/'source-hashes.json').read_text())
changed=sorted(n for n in source if source[n]!=old.get(n))
assert len(source)==240 and len(changed)==8
assert runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()==source
result=json.loads((out/'terminal.json').read_text())
assert result['status']=='passed' and result['checks_per_configuration']==90
assert all(x['exit_code']==0 for x in json.loads((out/'commands.json').read_text()))
artifacts={}
for mode,target,prior in [('normal',project,previous),('sanitized',sanitized,r/'build/readonly-borrows-sanitized-v3')]:
    for label,text in [('function-entries','90 function entry checks passed;'),('readonly-regression','305 readonly borrow checks passed;'),('bindings','519 CPU binding checks passed;'),('core','395 passed, 0 failed')]:
        assert text in (out/(mode+'-'+label+'.log')).read_text()
    assert 'scalar=1 vector=0,1' in (out/(mode+'-example.log')).read_text()
    artifacts[mode]={}
    for name in ('cket','cket_backend','libcket_quantum.a','gcc-version.txt'):
        assert sha(target/'build'/name)==sha(prior/'build'/name)
        artifacts[mode][name]=dict(sha256=sha(target/'build'/name),scope='unchanged')
    for name in ('cket_plugin.so','cket_runtime.o','validate_function_entries'):
        actual=sha(target/'build'/name)
        assert actual==result['final_artifact_sha256'][mode][name]
        artifacts[mode][name]=dict(sha256=actual,scope='rebuilt')
    assert sha(target/'build/cket_runtime.o')!=sha(prior/'build/cket_runtime.o')
    if mode=='sanitized':
        for name in ('cket_plugin.so','cket_runtime.o','validate_function_entries'):
            symbols=subprocess.check_output(['nm','-u',str(target/'build'/name)],text=True)
            assert '__asan_init' in symbols and '__ubsan_handle' in symbols
            (out/('instrumentation-'+name+'.txt')).write_text(symbols)
for name in source:
    if name.startswith('src/engine/') or name in ('src/cket.c','src/cket_backend.c'):
        assert source[name]==old[name]
audit=json.loads((sdk/'sdk-audit.json').read_text())
assert audit['source_sha256']==source and audit['source_files']==240
assert audit['prebuilt_programs']==37 and audit['example_checks']==1509
assert sha(sdk/'cket-sdk-linux-x86_64.tar.gz')==audit['package_sha256']
assert all(row['exit_code']==0 for row in audit['commands'])
assert len(audit['windows_launchers'])==3 and all(row['exit_code']==0 for row in audit['windows_launchers'])
for name in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','gcc-version.txt'):
    assert sha(project/'build'/name)==audit['package_files_sha256']['build/'+name]
assert sha(sdk/'example_readonly.c')==source['examples/readonly_borrows.c']
assert sha(sdk/'example_heap.c')==source['examples/blocks/05/heap_iterations.c']

baseline=r/'build/function-entry-baseline-v2';baseline.mkdir()
cases=json.loads((r/'build/quantum-entry-probe-v1/results.json').read_text())
assert cases[1]['exit_code']==cases[2]['exit_code']==0
rows=[]
for number in (1,2):
    original=r/'build/quantum-entry-probe-v1'/('case-'+str(number)+'.c')
    output=baseline/('case-'+str(number)+'.json')
    command=[str(previous/'build/cket'),str(original),'--emit-ir','-o',str(output)]
    z=subprocess.run(command,cwd=previous,env=dict(os.environ,CC='gcc-11'),text=True,capture_output=True,timeout=60)
    assert z.returncode==0 and json.loads(output.read_text())['instructions']==[]
    rows.append(dict(case=number,command=command,exit_code=z.returncode,quantum_instructions=0,earlier_native_exit_code=cases[number]['exit_code'],stdout=z.stdout,stderr=z.stderr))
(baseline/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
ci=json.loads((r/'build/readonly-ci-run-v1.json').read_text())
assert ci['headSha'].startswith('0740cfa') and ci['status']=='completed' and ci['conclusion']=='failure'
assert 'unmodelled retained version' in (r/'build/readonly-ci-failed-v1.log').read_text()
for name in ('scripts/build.sh','scripts/sanitize-all.sh','scripts/verify.sh'):
    subprocess.check_call(['bash','-n',name],cwd=project)

destination=r/'docs/audit-evidence/function-entries-v1'
assert not (destination/'summary.json').exists()
def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.c','.py'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())
with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for name in source:tar.add(project/name,arcname='sources/'+name)
    raw(tar,'source-identities.json',dict(qualified=source,previous=old))
    raw(tar,'final-artifacts.json',artifacts)
    tree(tar,out,'results/final')
    tree(tar,r/'build/function-entry-results-v1','results/earlier-header-preparation')
    tree(tar,r/'build/quantum-entry-probe-v1','baseline/native')
    tree(tar,baseline,'baseline/ir')
    tree(tar,r/'build/checked-entry-sdk-results-v1','sdk-results')
    for name in ('qualify-function-entries.py','qualify-function-entries-complete.py','package-checked-entry-sdk.py','package-checked-entry-sdk-complete.py','prepare-checked-entry-delivery.py','finish-checked-entry-delivery.py','publish-function-entries.py'):
        tar.add(r/'build'/name,arcname='harness/'+name)
    for name in ('checked-entry-windows-demo.log','checked-entry-windows-example.log','checked-entry-windows-heap.log'):
        tar.add(r/'build'/name,arcname='sdk-windows/'+name)
    for name in ('readonly-ci-run-v1.json','readonly-ci-failed-v1.log'):
        tar.add(r/'build'/name,arcname='open-ci-0740cfa/'+name)
    for p in sorted(sdk.iterdir()):
        if p.is_file() and p.suffix!='.gz':tar.add(p,arcname='sdk/'+p.name)
summary=dict(status='passed-targeted-function-entry-correction-with-open-general-ci',date='2026-10-27',base_commit='c1bc6aa',version='1.0.0-rc.3',source_files=240,source_sha256=source,changed_inputs=changed,
    rebuilt_production=['src/cket_plugin.cpp','src/quantum_frontend.inc','src/cket_runtime.c'],engine_driver_backend_unchanged=True,
    checks_per_configuration=dict(function_entries=90,readonly_borrows=305,bindings=519,core=395),
    entry_scope=dict(valid_native_compositions=30,compile_time_rejections=55,explicit_runtime_rejections=5,gcc_levels=5,platform='Linux/glibc; POSIX dynamic lookup boundary'),
    sdk=dict(package_sha256=audit['package_sha256'],rebuilt_programs=37,normal_example_checks=1509,windows_workflows=3),
    open_ci=dict(run_id=40426634072,head=ci['headSha'],status='failure',signature='unmodelled retained version',validator='scripts/validate-runtime-memory.py',source_files=239,scope='Prior-source failure retained as open; not reclassified as passing.'),
    scope='Targeted ABI correction, preserved classical callbacks and prior quantum ownership-state regression. Full verify.sh, general lifetimes/alias/ABI, float values, complete everyday C and general paper review remain open. No QPU or speedup claim; cybersecurity stays classical.',
    artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
docs=['README.md','docs/entrega-utilizable-2026-10-26.es.md','docs/estado-general-del-proyecto.es.md','docs/paper/README.md','docs/c11-function-entries.md','docs/audit-evidence/function-entries-v1/README.es.md','output/sdk/README.es.md']
names=set(source)|set(docs)|{p.relative_to(r).as_posix() for p in sdk.iterdir() if p.is_file()}|{'docs/audit-evidence/function-entries-v1/summary.json','docs/audit-evidence/function-entries-v1/evidence.tar.gz'}
expected=json.loads((r/'build/format-followup-git-expected.json').read_text());expected.update({n:sha(r/n) for n in names})
(r/'build/function-entry-git-expected.json').write_text(json.dumps(expected,indent=2)+'\n')
imports=sorted((names-set(source))|set(changed)|{'build/function-entry-git-expected.json'})
(r/'build/function-entry-final-import.txt').write_text('\n'.join(imports)+'\n')
print('Ready:',len(expected),'exact files; targeted normal/sanitized checks and SDK verified; general CI remains open')
