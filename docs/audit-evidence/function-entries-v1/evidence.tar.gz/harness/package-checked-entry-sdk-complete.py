import hashlib, json, os, shutil, subprocess, tarfile
from pathlib import Path
r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/function-entry-source-v2'
stage = r / 'build/checked-entry-sdk-stage-v1'
out = r / 'build/checked-entry-sdk-results-v1'
stage.mkdir(); out.mkdir()
hashes = json.loads((project / 'source-hashes.json').read_text())
for name in hashes:
    p = stage / name
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(project / name, p)
shutil.copy2(project / 'LICENSE', stage / 'LICENSE')
(stage / 'build').mkdir()
tools = ('cket', 'cket_backend', 'cket_plugin.so', 'libcket_quantum.a', 'cket_runtime.o', 'gcc-version.txt')
for name in tools:
    shutil.copy2(project / 'build' / name, stage / 'build' / name)
(stage / 'cket').chmod(0o755)
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_SEED='7')
env.pop('CKET_SIMULATOR', None)
records = []

def run(name, command, environment=env):
    z = subprocess.run(command, cwd=stage, env=environment, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=900)
    (out / (name+'.log')).write_text(z.stdout)
    records.append(dict(name=name, command=command, exit_code=z.returncode, log=name+'.log'))
    (out / 'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(name, z.returncode, z.stdout[-2200:], flush=True)
    assert z.returncode == 0, z.stdout[-6000:]

for block in ('01','02','03','04','05','06'):
    run('block-'+block, ['bash','scripts/run-block.sh',block])
run('examples-build', ['gcc-11','-std=c11','-O2','-Wall','-Wextra','-Werror','-Isrc/engine',
    'tests/test_examples.c','tests/validation.c','-o','build/test_examples'])
run('examples', ['build/test_examples'])
programs = sorted(p for p in (stage/'build/blocks').glob('*/*') if p.is_file() and p.suffix == '')
assert len(programs) == 37, len(programs)
identity = hashlib.sha256((project/'source-hashes.json').read_bytes()).hexdigest()[:12]
sdk_dir = '/tmp/cket-sdk-'+identity
demo = stage/'run-demo.sh'
demo.write_text('''#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export CKET_SIMULATOR=sparse CKET_SEED=7
printf '%s\n' 'C Ket RC3: native C statevector simulation, 37 prebuilt programs'
for block in 01 02 03 04 05 06; do
    for program in build/blocks/"$block"/*; do
        [[ -x "$program" && "$program" != *.* ]] || continue
        printf '\n%s\n' "$program"
        "$program"
    done
done
''')
demo.chmod(0o755)
(stage/'compile-user.sh').write_text('''#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p user
cat > user/program.c
CC=gcc-11 build/cket user/program.c -O2 -o user/program
CKET_SIMULATOR=sparse CKET_SEED=7 user/program
''')
(stage/'compile-user.sh').chmod(0o755)
(stage/'README.es.md').write_text('''# Compilador C Ket listo para Linux/WSL

Candidata experimental 1.0.0-rc.3. Requiere Linux x86-64, glibc y GCC 11.4.0 (gcc-11).
El compilador, plugin GCC, runtime C y 37 programas de los seis bloques vienen construidos.

Ejecutar sin recompilar:

```sh
sha256sum -c --status SHA256SUMS
bash run-demo.sh
```

Compilar un programa propio desde la raíz del paquete:

```sh
CC=gcc-11 ./cket mi_programa.c -O2 -o mi_programa
CKET_SIMULATOR=sparse ./mi_programa
```

Incluye las fuentes de compilador, headers y ejemplos, circuitos estáticos disponibles e
informes de recursos. Las funciones, arrays, punteros, heap y biblioteca frecuente conservan
sus contratos parciales. Direcciones, I/O y ciberseguridad siguen siendo clásicas; medir es
explícito. El backend ejecuta puertas y amplitudes complejas en un simulador C.

El simulador denso admite 24 qubits; el disperso y la representación de circuito llegan a
128 cables con presupuesto de soporte y trabajo. Una operación definida en C puede exceder
recursos o no estar implementada en el perfil cuántico. Flotantes cuánticos, ABI/punteros/vidas
generales y partes de la integración siguen pendientes. No es C11 completo, una 1.0 estable,
ejecución en QPU física ni garantía de ventaja frente a CPU.

Los 37 programas ejecutados y la suite de 1509 ejemplos verifican usos finitos y salidas;
las pruebas de coherencia, estados e inversas se conservan en las cápsulas del repositorio.
La identidad exacta de las 240 entradas está en compiler-source-sha256.json.
''')
(stage/'compiler-source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
run('packaged-demo', ['bash','run-demo.sh'])
files = {p.relative_to(stage).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'SHA256SUMS').write_text(''.join(h+'  '+n+'\n' for n,h in files.items()))
run('checksums', ['sha256sum','-c','SHA256SUMS'])
destination = r/'output/sdk/checked-entry'
destination.mkdir(exist_ok=True)
archive = destination/'cket-sdk-linux-x86_64.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(stage.rglob('*')):
        if p.is_file(): tar.add(p,arcname=p.relative_to(stage).as_posix())
extract = f'''@echo off
set "CKET_SDK_ROOT={sdk_dir}"
wsl -d Ubuntu2204 --exec mkdir -p "%CKET_SDK_ROOT%"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "%CKET_SDK_ROOT%" --exec tar -xzf - < "%~dp0cket-sdk-linux-x86_64.tar.gz"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "%CKET_SDK_ROOT%" --exec sha256sum -c --status SHA256SUMS
if errorlevel 1 exit /b 1
exit /b 0
'''
(destination/'extract_sdk.cmd').write_text(extract)
(destination/'run_sdk_demo.cmd').write_text('''@echo off
setlocal
call "%~dp0extract_sdk.cmd"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "%CKET_SDK_ROOT%" --exec bash run-demo.sh
exit /b %errorlevel%
''')
(destination/'compile_and_run.cmd').write_text('''@echo off
setlocal
if "%~1"=="" (
  echo Usage: compile_and_run.cmd program.c
  exit /b 2
)
if not exist "%~1" exit /b 2
if not "%~2"=="" exit /b 2
call "%~dp0extract_sdk.cmd"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "%CKET_SDK_ROOT%" --exec bash compile-user.sh < "%~1"
exit /b %errorlevel%
''')
(destination/'sdk-audit.json').write_text(json.dumps(dict(status='passed-native-sdk-programs',
    date='2026-10-26',source_files=240,source_sha256=hashes,prebuilt_programs=37,
    example_checks=1509,package_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    package_files_sha256=files,commands=records,sdk_linux_root=sdk_dir,
    scope='Prebuilt compiler and finite native programs; Windows launcher still needs its own check. No full-C11, stable-release, general-state or QPU claim.'),indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(dict(status='passed',prebuilt_programs=37,example_checks=1509),indent=2)+'\n')
print('SDK ready',archive,flush=True)
