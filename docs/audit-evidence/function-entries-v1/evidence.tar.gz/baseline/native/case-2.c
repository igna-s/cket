#include <quantum.h>
void transform(bool value);static void (*saved)(bool)=transform;void transform(quant bool value){value=!value;}int main(void){saved(false);return 0;}
