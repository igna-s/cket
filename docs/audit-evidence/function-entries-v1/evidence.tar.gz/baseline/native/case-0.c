#include <quantum.h>
void transform(quant bool value); void early(void){quant bool x=true;transform(x);measure(x);} void transform(quant bool value){value=!value;} int main(void){early();return 0;}
