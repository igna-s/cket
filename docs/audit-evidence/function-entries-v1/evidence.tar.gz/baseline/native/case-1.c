#include <quantum.h>
void transform(bool value);void early(void){transform(false);}void transform(quant bool value){value=!value;}int main(void){early();return 0;}
