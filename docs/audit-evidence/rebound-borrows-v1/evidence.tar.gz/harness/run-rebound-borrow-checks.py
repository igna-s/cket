import json
import os
from pathlib import Path
import re
import runpy
import subprocess
import sys

root=Path('/tmp/quantum-audit-isolated-20261017')
mode,version=sys.argv[1:];project=root/('build/rebound-borrow-source-'+version)
target=project if mode=='normal' else root/('build/rebound-borrow-sanitized-'+version)
assert json.loads((target/'build-exit.json').read_text())['exit_code']==0
output=root/('build/rebound-borrow-'+mode+'-results-'+version);output.mkdir()
env=dict(os.environ,CC='gcc-11',CKET_SEED='7',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode=='sanitized':env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11')
records=[]
def run(label,command,environment=env):
    with (output/(label+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=project,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
    records.append(dict(command=command,exit_code=result.returncode,log=label+'.log'))
    (output/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    text=(output/(label+'.log')).read_text()
    print(label,result.returncode,text[-1800:],flush=True)
    assert result.returncode==0
    return text
extra=['--sanitized'] if mode=='sanitized' else []
for name,levels in [('rebound-borrows',['O0','O2'] if mode=='normal' else ['O1']),
                    ('inactive-borrows',['O2' if mode=='normal' else 'O1']),
                    ('coherent-overwrites',['O2' if mode=='normal' else 'O1'])]:
    run(name,['python3','scripts/validate-'+name+'.py','--compiler-root',str(target),
              '--output',str(output/name),'--levels',*levels,*extra])
for name in ('validate_swap_rebind','validate_inactive_borrows','validate_heap_identities',
             'validate_heap','validate_memset','validate_controlled_operands',
             'validate_runtime_memory','validate_runtime_versions',
             'validate_expressions','validate_shifts','validate_division','validate_inplace'):
    run(name,[str(target/'build'/name)])
run('core',[str(target/'build/cket_tests'),str(target)])
if mode=='normal':run('block05',['bash','scripts/run-block.sh','05'])
flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie'] if mode=='sanitized' else []
trace=output/'rebound-borrows/trace.o';binary=output/'borrow_cleanup'
run('demo-build',[str(target/'build/cket'),'examples/blocks/05/borrow_cleanup.c','-O2' if mode=='normal' else '-O1',*flags,
                  '-Wl,'+str(trace),'-Wl,--wrap=qc_create_sparse','-Wl,--wrap=__cket_apply','-o',str(binary)])
outcomes=set()
for policy in (0,1):
    for seed in range(1,17):
        text=run(f'demo-tables{policy}-seed{seed}',[str(binary)],dict(env,CKET_SIMULATOR='sparse',CKET_SEED=str(seed),OWNERSHIP_TABLES=str(policy)))
        match=re.search(r'control=(\d) source=(\d) value=(\d) expected=(\d)',text)
        assert match and match[3]==match[4]
        outcomes.add((int(match[1]),int(match[2])))
assert outcomes=={(0,0),(0,1),(1,0),(1,1)}
hashes=runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()
assert hashes==json.loads((project/'source-hashes.json').read_text())
(output/'summary.json').write_text(json.dumps(dict(status='passed',mode=mode,source_files=len(hashes),
    commands=len(records),demo_native_executions=32,demo_observed_control_source_pairs=sorted(outcomes)),indent=2)+'\n')
print('PASS unchanged',len(hashes),'frozen inputs',flush=True)
