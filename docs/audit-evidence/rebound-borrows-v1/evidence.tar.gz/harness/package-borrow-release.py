import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

root=Path('/tmp/quantum-audit-isolated-20261017');project=root/'build/rebound-borrow-source-v3'
capsule=json.loads((root/'docs/audit-evidence/rebound-borrows-v1/summary.json').read_text())
assert capsule['rebound_borrow_state_checkpoints']==1368
out=root/'output/demo';out.mkdir(exist_ok=True,parents=True)
stage=root/'build/borrow-demo-package-v1';stage.mkdir();(stage/'bin').mkdir()
binary=stage/'bin/borrow_cleanup';shutil.copy2(project/'build/blocks/05/borrow_cleanup',binary)
shutil.copy2(project/'examples/blocks/05/borrow_cleanup.c',stage/'borrow_cleanup.c')
shutil.copy2(root/'LICENSE',stage/'LICENSE')
runs=[]
for seed in (1,7,13):
    result=subprocess.run([str(binary)],env=dict(os.environ,CKET_SIMULATOR='sparse',CKET_SEED=str(seed)),
                          text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    match=re.search(r'control=(\d) source=(\d) value=(\d) expected=(\d)',result.stdout)
    assert result.returncode==0 and match and match[3]==match[4]
    runs.append(dict(seed=seed,exit_code=result.returncode,stdout=result.stdout))
manifest=hashlib.sha256(json.dumps(capsule['source_sha256'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
audit=dict(version='1.0.0-rc.1',date='2026-10-25',compiler_input_manifest_sha256=manifest,
           binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
           source_sha256=hashlib.sha256((stage/'borrow_cleanup.c').read_bytes()).hexdigest(),
           tool_sha256=capsule['tool_sha256']['normal'],runs=runs,
           evidence='docs/audit-evidence/rebound-borrows-v1',
           scope='Finite native demo of conditional scoped-borrow cleanup and interference. Not a whole compiler, C11 or QPU certification.',
           known_failure='Nonidentity coherent heap copy still dephases its inactive joint sector; this demo has no heap copy.')
(stage/'demo-borrow-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
shutil.copy2(stage/'demo-borrow-audit.json',out/'demo-borrow-audit.json')
files=sorted(p for p in stage.rglob('*') if p.is_file())
(stage/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(stage).as_posix()+'\n' for p in files))
archive_path=out/'cket-borrow-demo-linux-x86_64.tar.gz'
with tarfile.open(archive_path,'w:gz') as archive:
    for path in sorted(stage.rglob('*')):
        if path.is_file():archive.add(path,arcname=path.relative_to(stage).as_posix())
tag=hashlib.sha256(archive_path.read_bytes()).hexdigest()[:12]
destination='/tmp/cket-borrow-demo-'+tag
launcher=f'''@echo off
setlocal
wsl -d Ubuntu2204 --exec mkdir -p "{destination}"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "{destination}" --exec tar -xzf - < "%~dp0cket-borrow-demo-linux-x86_64.tar.gz"
if errorlevel 1 exit /b 1
wsl -d Ubuntu2204 --cd "{destination}" --exec sha256sum -c SHA256SUMS
if errorlevel 1 exit /b 1
for %%S in (1 7 13) do (
  wsl -d Ubuntu2204 --cd "{destination}" --exec env CKET_SIMULATOR=sparse CKET_SEED=%%S ./bin/borrow_cleanup
  if errorlevel 1 exit /b 1
)
exit /b 0
'''
(out/'run_borrow_demo.cmd').write_bytes(launcher.replace('\n','\r\n').encode())
(out/'README-borrow.es.md').write_text('''# Demo de la candidata 1.0.0-rc.1: limpieza e interferencia

Desde una consola Windows en la raíz del repositorio:

```cmd
output\\demo\\run_borrow_demo.cmd
```

Usa la distribución WSL `Ubuntu2204`, extrae el paquete en `/tmp`, verifica sus hashes y ejecuta
tres semillas sin recompilar ni montar unidades Windows. Necesita Linux x86-64/glibc compatible;
se construyó en Ubuntu 22.04 con GCC 11.4.0. El programa comprueba `value == expected` y devuelve
cero si coincide. El primer caso produce `control=0 source=0 value=1 expected=1`.

En Linux, extraer `cket-borrow-demo-linux-x86_64.tar.gz` y ejecutar:

```sh
sha256sum -c SHA256SUMS
CKET_SIMULATOR=sparse CKET_SEED=1 ./bin/borrow_cleanup
```

El paquete incluye el ejecutable, la fuente, licencia, hashes y `demo-borrow-audit.json`. El
ejemplo usa una función con puntero prestado, control en superposición, fase, limpieza de un
temporal y comprobación de interferencia. La [fuente del ejemplo](../../examples/blocks/05/borrow_cleanup.c)
y la [nota técnica](../../docs/paper/conditional_inverse_note.es.md) explican el programa.

La [evidencia de la candidata](../../docs/audit-evidence/rebound-borrows-v1/README.es.md) conserva
1368 puntos de estado completo y 456 inversas del bloque, con construcciones normales/ASan/UBSan.
La demo tiene pruebas adicionales en 32 combinaciones de semilla/política por construcción; el paquete conserva
tres ejecuciones de su binario exacto. Estos ámbitos no certifican todos los programas posibles.

Es una candidata experimental. **Persiste un fallo en copias coherentes no idénticas al heap**,
que este ejemplo no utiliza. La [guía de versión](../../docs/releases/v1.0.0-rc.1.es.md) detalla lo
implementado y lo pendiente para la 1.0 estable. Los PDF previos conservan sus revisiones originales.
La ciberseguridad permanece clásica y sin cambios.
''')
(root/'build/rebound-borrow-package-files.json').write_text(json.dumps([p.relative_to(root).as_posix() for p in
    [archive_path,out/'demo-borrow-audit.json',out/'run_borrow_demo.cmd',out/'README-borrow.es.md']],indent=2)+'\n')
print('Packaged demo',tag,'three exact-binary executions passed.',flush=True)
