from pathlib import Path

root=Path('/tmp/quantum-audit-isolated-20261017')
code=(root/'build/probe-rebound-borrow-final.py').read_text().split("folder=root/'build/rebound-borrow-prototype-findings-v1'")[0]
exec(compile(code.replace('v2','v3'),'probe-rebound-release.py','exec'))
