import json
import os
from pathlib import Path
import subprocess

root=Path('/tmp/quantum-audit-isolated-20261017')
compiler=root/'build/inactive-borrow-source-v1'
output=root/'build/inactive-borrow-final-probe-v1'
output.mkdir()
env=dict(os.environ,CC='gcc-11',CKET_SIMULATOR='sparse',CKET_SEED='7')
records=[]
def run(label,command):
    result=subprocess.run(command,cwd=compiler,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    (output/(label+'.log')).write_text(result.stdout)
    records.append(dict(command=command,exit_code=result.returncode,log=label+'.log'))
    (output/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode==0,result.stdout
    return result.stdout
trace=output/'trace.o'
run('trace',['gcc-11','-std=c11','-O1','-c',str(root/'tests/ownership_trace.c'),'-o',str(trace)])
reports=[]
for coherent in (False,True):
    label='coherent-sector' if coherent else 'zero'
    source=output/(label+'.c');binary=output/label
    source.write_text('''#include <quantum.h>
void ownership_checkpoint(const char*);
int main(void){
quant bool x=superposition(0,1),y=superposition(0,1),control='''+('superposition(0,1)' if coherent else '0')+''';
if(y)phase(.73);ownership_checkpoint("before");
{quant bool saved=y^1;if(control)y=x^0;if(saved)phase(.47);}
ownership_checkpoint("after");measure(y);measure(x);measure(control);return 0;}
''')
    run(label+'-compile',[str(compiler/'build/cket'),str(source),'-O2','-Wl,'+str(trace),
                          '-Wl,--wrap=qc_create_sparse','-Wl,--wrap=__cket_apply','-o',str(binary)])
    points=[json.loads(line) for line in run(label+'-run',[str(binary)]).splitlines() if line.startswith('{')]
    purities=[]
    for point in points:
        assert point['measurements']==point['resets']==0
        names={r['name']:r for r in point['registers'] if r['name'] and not r['history']}
        wire=names['y']['wires'][0];guard=names['control']['wires'][0]
        blocks={};weight=0
        for basis,real,imag in point['state']:
            basis=int(basis,0)
            if (basis>>guard)&1:
                continue
            amplitude=complex(real,imag);weight+=abs(amplitude)**2
            blocks.setdefault(basis&~(1<<wire),{})[(basis>>wire)&1]=amplitude
        rho={}
        for block in blocks.values():
            for a,left in block.items():
                for b,right in block.items():
                    rho[a,b]=rho.get((a,b),0j)+left*right.conjugate()/weight
        purities.append(sum(abs(value)**2 for value in rho.values()))
    assert abs(purities[0]-1)<1e-9 and abs(purities[1]-(.5 if coherent else 1))<1e-9
    reports.append(dict(case=label,inactive_sector_purities=purities,measurements=0,resets=0,
                        meaning='Projection on original control=0, normalized before computing target density. Globally inactive cleanup is corrected; possible-active coherent cleanup remains open.'))
(output/'summary.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports),flush=True)
