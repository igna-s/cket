import hashlib
import io
import json
from pathlib import Path
import runpy
import subprocess
import tarfile

root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/rebound-borrow-source-v3';san=root/'build/rebound-borrow-sanitized-v3'
sources=json.loads((project/'source-hashes.json').read_text())
assert len(sources)==231
for source_root in (root,project):
    assert runpy.run_path(str(source_root/'scripts/archive-audit.py'))['source_hashes']()==sources
campaigns={}
for mode,target,count in [('normal',project,50),('sanitized',san,49)]:
    result=root/('build/rebound-borrow-'+mode+'-results-v3')
    summary=json.loads((result/'summary.json').read_text());commands=json.loads((result/'commands.json').read_text())
    assert summary['status']=='passed' and summary['source_files']==231
    assert len(commands)==count and all(c['exit_code']==0 for c in commands)
    assert json.loads((target/'build-exit.json').read_text())['exit_code']==0
    campaigns[mode]={name:json.loads((result/name/'summary.json').read_text()) for name in ('rebound-borrows','inactive-borrows','coherent-overwrites')}
assert sum(c['rebound-borrows']['full_state_checkpoints'] for c in campaigns.values())==1368
assert sum(c['rebound-borrows']['complete_gate_inverses'] for c in campaigns.values())==456
probes=['rebound-borrow-final-probe-v3','inactive-coherence-probe-rebound-borrow-final-v3']
scope,joint=[json.loads((root/'build'/folder/'summary.json').read_text()) for folder in probes]
assert all(abs(row['inactive_sector_purities'][1]-1)<1e-9 for row in scope)
assert sum(row['inactive_density_max_error']>.49 for row in joint)==1
tools={mode:{name:hashlib.sha256((target/'build'/name).read_bytes()).hexdigest() for name in ('cket','cket_plugin.so','libcket_quantum.a','cket_runtime.o')}
       for mode,target in [('normal',project),('sanitized',san)]}
instrumentation={}
for name in ('cket_plugin.so','json.o','quantum.o','verify.o','simulator.o','cket_runtime.o','cket'):
    text=subprocess.check_output(['nm','-u',str(san/'build'/name)],text=True)
    assert '__asan_init' in text and '__ubsan_handle' in text
    instrumentation[name]=text
destination=root/'docs/audit-evidence/rebound-borrows-v1';destination.mkdir()

def tree(archive,folder,prefix,suffixes):
    for path in sorted(folder.rglob('*')):
        if path.is_file() and path.suffix in suffixes:
            archive.add(path,arcname=prefix+'/'+path.relative_to(folder).as_posix())

with tarfile.open(destination/'evidence.tar.gz','w:gz') as archive:
    for name in sources:archive.add(project/name,arcname='sources/'+name)
    archive.add(project/'docs/c11-library.json',arcname='sources/docs/c11-library.json')
    for mode,target in [('normal',project),('sanitized',san)]:
        archive.add(target/'build-exit.json',arcname='build/'+mode+'-exit.json')
        archive.add(target/('build-normal.log' if mode=='normal' else 'build.log'),arcname='build/'+mode+'.log')
        tree(archive,root/('build/rebound-borrow-'+mode+'-results-v3'),'results/'+mode,{'.log','.json','.c'})
    for name in ('borrow_cleanup.qasm','borrow_cleanup.resources.txt'):
        archive.add(project/'build/blocks/05'/name,arcname='export/'+name)
    for folder in probes:tree(archive,root/'build'/folder,'counterexamples/'+folder,{'.c','.json','.log'})
    for name in ('prepare-rebound-borrows.py','build-rebound-borrows.py','build-coherent-store.py',
                 'build-coherent-store-sanitized.py','run-rebound-borrow-checks.py','probe-rebound-release.py',
                 'probe-rebound-borrow-final.py','probe-inactive-borrow-final.py','probe-inactive-coherence.py',
                 'archive-rebound-borrows.py','update-rebound-release-docs.py','package-borrow-release.py'):
        archive.add(root/'build'/name,arcname='harness/'+name)
    for name,data in [('tool-sha256.json',tools),('instrumentation.json',instrumentation)]:
        encoded=(json.dumps(data,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(encoded)
        archive.addfile(info,io.BytesIO(encoded))
with tarfile.open(destination/'earlier-attempts.tar.gz','w:gz') as archive:
    for version in ('v1','v2'):
        prior=root/('build/rebound-borrow-source-'+version)
        manifest=json.loads((prior/'source-hashes.json').read_text())
        for name,expected in manifest.items():
            assert hashlib.sha256((prior/name).read_bytes()).hexdigest()==expected
            archive.add(prior/name,arcname=version+'/sources/'+name)
        archive.add(prior/'source-hashes.json',arcname=version+'/source-hashes.json')
    for folder in ('rebound-borrow-normal-results-v1','rebound-borrow-normal-results-v2',
                   'rebound-borrow-sanitized-results-v2','rebound-borrow-negative-normal-v2',
                   'rebound-borrow-prototype-findings-v1','rebound-borrow-native-preview-v3',
                   'rebound-negative32-diagnostic'):
        tree(archive,root/'build'/folder,folder,{'.c','.json','.log','.py'})
    for name in ('validate-rebound-negative.py','diagnose-negative32.py','preview-rebound-swaps.py'):
        archive.add(root/'build'/name,arcname='exploratory-harness/'+name)
scope_text=('Finite conditional inverse transport across possible-active controlled root-owner swaps. '
            'Bool and signed/unsigned 8/16/32-bit assignments, one-byte copy/fill, open/nested controls, '
            'chained/moved/arithmetic scoped borrows, same-unit function and signed -2/-1 preparations. '
            'Complete complex states before/during/after cleanup, explicit phases, stable public owners, '
            'only required old-root history and gate reversal. Normal O0/O2 and ASan/UBSan O1; both synthesis policies. '
            'Repeated writes, derived destinations, correlated range proofs and 64-bit scope cleanup remain unqualified. '
            'Nonidentity coherent heap copy still has an inactive-sector dephasing counterexample. '
            'No whole-compiler, C11, QPU or historical-paper qualification.')
summary=dict(status='release-candidate-with-known-quantum-correctness-finding',version='1.0.0-rc.1',date='2026-10-25',
             compiler_input_files=231,source_sha256=sources,
             source_manifest_sha256=hashlib.sha256(json.dumps(sources,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
             rebound_borrow_state_checkpoints=1368,rebound_borrow_gate_inverses=456,campaigns=campaigns,
             regression_checks_per_configuration=dict(swap_inverse=34197,inactive_borrows=139,heap_identities=1682,
                 heap=16878,native_core=395,controlled_operands=1270,memset=940,runtime_history=15,
                 runtime_memory_preflight=23,expressions=3505,shifts=203,division=990,inplace=271),
             normal_block05_native_programs=8,normal_block05_qasm_exports=1,
             native_demo_runs_per_configuration=32,tool_sha256=tools,corrected_scoped_counterexamples=scope,
             open_findings=dict(inactive_heap_joint_state=joint[-1]),scope=scope_text,
             artifact_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in destination.iterdir()})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(destination/'README.es.md').write_text('''# Inversas condicionadas de préstamos: candidata 1.0.0-rc.1

La corrección conserva y transporta la receta inversa de un temporal cuando una escritura puede
activarse bajo control cuántico. Reconstruye el valor anterior desde su ubicación condicionada,
deshace el temporal y conserva el efecto de fase. Los contraejemplos originales con control cero y
control en superposición pasan de pureza 1 → 0.5 a 1 → 1, sin mediciones ni resets.

Se eliminan también copias privadas redundantes de decisiones reconstruibles desde raíces estables,
se preservan los contratos de épocas y ciclos y se corrige un certificado que trataba patrones
negativos como rangos no negativos. La síntesis booleana evita una palabra auxiliar innecesaria.
La [nota técnica](../../paper/conditional_inverse_note.es.md) explica las precondiciones.

**1368 puntos de estado complejo completo y 456 inversas completas:** 912/304 normales O0/O2 y
456/152 ASan/UBSan O1. Son 64 programas por nivel, con ambas políticas de síntesis. Incluyen bool,
enteros con/sin signo de 8/16/32 bits, asignación y copia/relleno de un byte, controles abiertos y
anidados, préstamos encadenados/movidos/aritméticos, función del mismo archivo y negativos -2/-1.
Se compara antes, durante y después del préstamo, con fases independientes y fórmulas explícitas,
dueños/cables estables y únicamente la historia anterior necesaria. No se califican por ello las
vidas generales, escrituras repetidas del frontend, destinos derivados o préstamos de 64 bits.

Las 34197 aserciones del motor comprueban estados e inversas de intercambios repetidos, máscaras
booleanas transportadas y rechazo de épocas/ciclos antes del intercambio. Ambas construcciones
pasan además las regresiones afectadas, con recuentos y ámbitos separados en `summary.json`.
El bloque 05 normal ejecuta ocho programas y genera un QASM estático con recursos. La nueva demo
se ejecuta otras 32 veces por construcción; se observan las cuatro parejas de control/fuente.
La exportación QASM no se presenta como una nueva comprobación independiente en otro SDK.

**Sigue abierto el contraejemplo de copia coherente no idéntica al heap:** pureza conjunta sectorial
1 → 0.5 y error de densidad 0.5 sin canales explícitos. Esta candidata no es la 1.0 estable ni
cierra el C cotidiano, la auditoría general o la actualización de los papers. La ciberseguridad
permanece clásica y sin cambios.

`evidence.tar.gz` conserva las 231 entradas exactas, construcciones terminales, herramientas,
inspección ASan/UBSan de siete componentes, comandos, estados y reproducciones. `earlier-attempts.tar.gz`
separa prototipos fallidos y sus fuentes: v1 retenía un control privado redundante; v2 fallaba con
negativos; un diagnóstico posterior localizó el límite de espacio del caso de 32 bits. Esos intentos
no se suman a los resultados finales. Los papers/PDF anteriores conservan sus fuentes originales.

```sh
CC=gcc-11 CXX=g++-11 bash scripts/build.sh
build/validate_swap_rebind
python3 scripts/validate-rebound-borrows.py --output build/new-rebound-proof --levels O0 O2
bash scripts/run-block.sh 05
```
''')
print('Archived candidate: 231 inputs; 1368 states / 456 inverses; heap coherent finding remains.',flush=True)
