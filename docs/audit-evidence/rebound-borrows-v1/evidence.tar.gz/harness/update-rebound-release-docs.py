import hashlib
import json
from pathlib import Path
import runpy

root=Path('/tmp/quantum-audit-isolated-20261017')
capsule=root/'docs/audit-evidence/rebound-borrows-v1'
summary=json.loads((capsule/'summary.json').read_text())
changed=[]

def update(name,fn):
    path=root/name;old=path.read_text();new=fn(old)
    assert new!=old,name+': no update'
    path.write_text(new);changed.append(name)

def replace(name,old,new):
    def apply(text):
        assert old in text,name+': stale text'
        return text.replace(old,new,1)
    update(name,apply)

replace('README.md','[![Version](https://img.shields.io/badge/version-0.4.0--experimental-orange)](docs/releases/v0.4.0.md)',
        '[![Version](https://img.shields.io/badge/version-1.0.0--rc.1-orange)](docs/releases/v1.0.0-rc.1.es.md)')
replace('README.md','''OpenQASM 3 circuits, and resource reports. The current version is **0.4.0**, with **GCC 11.4.0** as
the reference configuration. It implements an intermediate subset, with
[version 1.0 requirements still open](docs/v1-plan.md).''','''OpenQASM 3 circuits, and resource reports. The current version is **1.0.0-rc.1**, with **GCC 11.4.0**
as the reference configuration. This is an experimental candidate; the stable 1.0 requirements
remain open. The [release guide in Spanish](docs/releases/v1.0.0-rc.1.es.md) lists what works,
what is incomplete, the known coherence failure and commands to run the delivery.''')
update('README.md',lambda text:text[:text.index('**Known quantum correctness failures remain.**')]+'''**A known quantum correctness failure remains.** The
[current coherence review](docs/re-audit-2026-10-24-coherence.md) reproduces inactive-sector
dephasing in a nonidentity coherent heap copy; avoid that combination in this candidate.
Direct fixed-buffer writes, checked heap identities and selected scoped-borrow cleanup cases
have finite corrections. The latest [conditional-inverse evidence](docs/audit-evidence/rebound-borrows-v1/README.es.md)
records 1368 complete complex states and 456 gate inverses, with phases, stable owners and
normal/ASan/UBSan builds. It includes possible-active coherent writes, signed negative values
and live/scoped borrows. General repeated writes, derived destinations, correlated range proofs
and 64-bit scope cleanup remain unqualified. Earlier tests and historical papers do not certify
the open cases. The [new runnable example](examples/blocks/05/borrow_cleanup.c) and
[technical note](docs/paper/conditional_inverse_note.es.md) demonstrate the corrected scope.

'''+text[text.index('Start with [usable delivery 01]'):])
replace('README.md','[Release notes](docs/releases/v0.4.0.md) preserve the historical release snapshot.',
        '[Current release notes](docs/releases/v1.0.0-rc.1.es.md) describe the experimental candidate;\n[0.4.0 notes](docs/releases/v0.4.0.md) preserve the historical snapshot.')
update('docs/estado-general-del-proyecto.es.md',lambda text:text[:text.index('**Auditoría cuántica:')]+'''**Candidata 1.0.0-rc.1 lista como entrega experimental; 1.0 estable pendiente.** La
[guía breve de versión](releases/v1.0.0-rc.1.es.md) reúne qué está hecho, qué falta y cómo
ejecutarlo. La [demo nueva](../output/demo/README-borrow.es.md) comprueba limpieza e interferencia
después de una escritura bajo control cuántico. La ciberseguridad sigue clásica.

**Última corrección:** los temporales pueden limpiar su inversa desde la ubicación condicionada
del valor anterior. Se corrigen los contraejemplos con control cero y con control en superposición
en los perfiles publicados, además del certificado de rangos negativos y una reserva innecesaria
de espacio. La [cápsula actual](audit-evidence/rebound-borrows-v1/README.es.md) registra **1368 puntos
de estado completo y 456 inversas**, con fases y construcciones normales/ASan/UBSan. Se observan
también los préstamos todavía vivos; conservar una copia redundante del control no cuenta como
limpieza correcta.

**Falta:** persiste el contraejemplo de copia coherente no idéntica al heap, con pureza sectorial
1 → 0.5. No usar esa combinación en esta candidata. También quedan las vidas generales con
escrituras repetidas/destinos derivados, más combinaciones de funciones y punteros, flotantes,
integración cotidiana y recalificación de papers/CI. El
[informe de coherencia](re-audit-2026-10-24-coherence.md) separa las revisiones históricas de la actual.
La auditoría general continúa abierta; el número de versión no certifica C11 completo.

'''+text[text.index('**Entrega lista para ejecutar:'):])
replace('docs/re-audit-2026-10-24-coherence.md',
        'Corregido si la escritura está probada inactiva; variante coherente todavía abierta.',
        'Corregido en los perfiles finitos de inversas condicionadas del seguimiento final.')
update('docs/re-audit-2026-10-24-coherence.md',lambda text:text+'''

## Candidata 1.0.0-rc.1: inversas desde el dueño anterior condicionado

La [cápsula de inversas condicionadas](audit-evidence/rebound-borrows-v1/README.es.md) congela 231
entradas. Los dos contraejemplos de préstamos, con control cero y con control en superposición,
conservan ahora pureza 1 → 1 y el efecto de fase. El intercambio transporta las recetas de los
préstamos mediante vistas del valor anterior; no materializa todas las dependencias como raíces.
Las decisiones privadas reconstruibles desde raíces estables se expanden en la receta para
limpiar sus copias físicas. Se verifica el estado antes, durante y después del préstamo.

Los 1368 puntos de estado y 456 inversas incluyen bool/8/16/32 bits, negativos -2/-1, controles
abiertos/anidados, copias y rellenos de un byte, préstamos encadenados/movidos/aritméticos y función
del mismo archivo. Pasan O0/O2 normales y O1 ASan/UBSan, con ambas políticas. Las 34197 aserciones
del motor tienen su alcance separado de las pruebas del frontend. Los prototipos fallidos se
archivan aparte: control privado redundante, certificado negativo incorrecto y exceso de espacio
para reconstruir un booleano. La [nota técnica](paper/conditional_inverse_note.es.md) detalla la
identidad y las precondiciones.

**Sigue abierto el contraejemplo del heap:** copia no idéntica bajo control en superposición,
sector inactivo con pureza 1 → 0.5 y error de densidad 0.5, sin mediciones ni resets. Los casos
directos fijos y el heap con control cero del contraste conservan error cero. No se afirma que
este sea el único defecto restante: las vidas generales, escrituras repetidas, destinos derivados
y rangos correlacionados requieren contratos y evidencia adicionales. La candidata no cierra el
perfil cotidiano ni recalifica los papers anteriores. La ciberseguridad permanece clásica.
''')
for name in ('docs/c11-control.md','docs/c11-history.md','docs/c11-runtime-memory.md','docs/c11-runtime-history.md'):
    update(name,lambda text:text+'''

## Conditional inverse transport in 1.0.0-rc.1

The [later scoped-borrow correction](audit-evidence/rebound-borrows-v1/README.es.md) supersedes the
earlier failing possible-active root-overwrite examples. Saved inverses refer to the conditional
location of each old input after a controlled swap. Reconstructible private decisions are expanded
from stable roots so their physical copies can clean while declared borrowers remain live. Epochs,
control masks, acyclicity and proof budgets are checked before the exchange. Complete complex states
are checked before/during/after cleanup, including negative signed values and phase kickback.
This finite correction does not qualify general repeated frontend writes, derived destinations,
correlated range proofs, 64-bit scope cleanup or nonidentity coherent heap copies. The latter still
has a reproduced inactive-sector coherence failure. See the [candidate scope](releases/v1.0.0-rc.1.es.md).
''')
replace('docs/c11-control.md','that broader scope cleanup remains incorrect in the archived case.',
        'that archived scope case is corrected in the later conditional-inverse follow-up below.')
update('docs/no-clonacion.es.md',lambda text:text+'''

## Limpieza después de una escritura que puede activarse

La [corrección de inversas condicionadas](audit-evidence/rebound-borrows-v1/README.es.md) cierra los
contraejemplos anteriores de temporales al salir del bloque, también bajo control en superposición,
en los perfiles finitos publicados. El valor anterior se reconstruye desde uno u otro dueño según
el control, y se usa en la inversa guardada; no se clonan amplitudes ni se mide para limpiar.
La [nota técnica](paper/conditional_inverse_note.es.md) explica la fase conservada y las restricciones.
Las vidas generales y el contraejemplo de copia coherente no idéntica al heap permanecen pendientes.
''')
update('docs/c11-heap.md',lambda text:text+'''

The [1.0.0-rc.1 conditional-inverse correction](audit-evidence/rebound-borrows-v1/README.es.md) closes
the published fixed root-owner scoped-borrow cases, including possible-active controls. It does
not fix the nonidentity coherent heap-copy counterexample: its inactive joint sector still dephases.
Avoid that combination in this candidate; existing finite heap evidence does not qualify it.
''')
update('docs/ir-verification.md',lambda text:text+'''

## Optional controlled-swap inverse transport

`qswap` optionally accepts Boolean `rebind`. When true, explicit matching signedness is required.
The verifier still requires prepared distinct owners and Boolean controls disjoint from exchanged
wires. On a possible-active path the exchanged owners themselves cannot have pending definitions;
other saved borrowers may be transported. Without `rebind`, the previous borrower restrictions apply.

Before emitting the exchange, the engine constructs conditional old-value recipes for saved
expressions and gate-control masks, checks dependency epochs and the resulting graph, and enforces
expansion/work budgets. Private decision definitions can expand only from available unchanged roots;
cycles or stale epochs fail. Borrower values/epochs do not change during recipe transport. The
exchanged owner epochs do change. The union of their support is conservative: `support_interval`
means nonnegative numeric support, not the unsigned bit-pattern interval of a negative signed value.

For provably valid pure branches, bit synthesis implements Boolean select as
`no XOR (condition AND (yes XOR no))`; conditional definedness that this proof cannot establish uses
the arithmetic route. C's integer-valued comparisons between one-bit operands retain zero/one
semantics without a full-word temporary. The [finite evidence](audit-evidence/rebound-borrows-v1/README.es.md)
does not establish general lifetime, heap-copy or whole-compiler correctness.
''')
replace('docs/entregas-incrementales.es.md',
        '`heap_transfer`, `heap_iterations`, `fixed_buffers` y `buffer_lengths`.',
        '`heap_transfer`, `heap_iterations`, `fixed_buffers`, `buffer_lengths` y `borrow_cleanup`.')
update('docs/entregas-incrementales.es.md',lambda text:text+'''

La candidata [1.0.0-rc.1](releases/v1.0.0-rc.1.es.md) añade el octavo ejemplo del bloque 05,
[`borrow_cleanup`](../examples/blocks/05/borrow_cleanup.c). Combina función, puntero, control en
superposición, fase, limpieza de un temporal y comprobación de interferencia. Ese ejemplo genera
además QASM e informe de recursos; los otros siete siguen siendo nativos. Hay una
[demo empaquetada](../output/demo/README-borrow.es.md) para Windows/WSL. El bloque completo y el
perfil cotidiano conservan pendientes explícitos; el heap bajo copia coherente no idéntica aún
tiene un fallo conocido.
''')
replace('docs/paper/README.md',
'''directos de buffers fijos y las identidades comprobadas del heap; siguen abiertas la limpieza de
préstamos tras escrituras que pueden activarse y las copias coherentes no idénticas al heap.''',
'''directos de buffers fijos y las identidades comprobadas del heap. La
[nota de inversas condicionadas](conditional_inverse_note.es.md) y su
[evidencia de candidata](../audit-evidence/rebound-borrows-v1/README.es.md) corrigen además los
perfiles publicados de préstamos tras escrituras que pueden activarse. Las vidas generales y
las copias coherentes no idénticas al heap conservan pendientes.''')
update('docs/v1-plan.md',lambda text:text.replace('# Version 1.0 intermediate specification and acceptance',
'''# Version 1.0 intermediate specification and acceptance

**October 25 candidate:** [1.0.0-rc.1](releases/v1.0.0-rc.1.es.md) packages the implemented scope
and records missing work. It does not close the acceptance requirements below or the everyday C
goal. In particular, a nonidentity coherent heap copy still has a reproduced coherence failure.
The historical 0.4.0 release remains separately documented.''',1))
path=root/'docs/paper/evidence/current-implementation.json';current=json.loads(path.read_text())
current.update(status=summary['status'],source_files=231,source_sha256=summary['source_sha256'],
               version='1.0.0-rc.1',directed_evidence='../../audit-evidence/rebound-borrows-v1/summary.json',
               meaning=summary['scope'])
current['known_quantum_finding'].update(summary='../../audit-evidence/rebound-borrows-v1/summary.json',scope=summary['scope'])
path.write_text(json.dumps(current,indent=2)+'\n');changed.append(path.relative_to(root).as_posix())
path=root/'docs/audit-evidence/delivery-index.json';index=json.loads(path.read_text())
index.update(active='rebound-borrows-v1',meaning=summary['scope'])
index['history'].append('rebound-borrows-v1');index['known_findings'].append('rebound-borrows-v1')
path.write_text(json.dumps(index,indent=2)+'\n');changed.append(path.relative_to(root).as_posix())
changed+=['docs/releases/v1.0.0-rc.1.es.md','docs/paper/conditional_inverse_note.es.md','docs/audit-evidence/rebound-borrows-v1/README.es.md']
format_text=runpy.run_path(str(root/'scripts/format.py'))['format_text']
for name in set(changed):
    path=root/name;path.write_text(format_text(path,path.read_text()))
(root/'build/rebound-borrow-docs-changed.json').write_text(json.dumps(sorted(set(changed)),indent=2)+'\n')
print('Updated',len(set(changed)),'current scope documents; historical papers and capsules preserved.',flush=True)
