import json
import os
from pathlib import Path
import subprocess

root=Path('/tmp/quantum-audit-isolated-20261017')
compiler=root/'build/rebound-borrow-source-v2'
code=(root/'build/probe-inactive-borrow-final.py').read_text()
code=code.replace("root/'build/inactive-borrow-source-v1'","root/'build/rebound-borrow-source-v2'")
code=code.replace("root/'build/inactive-borrow-final-probe-v1'","root/'build/rebound-borrow-final-probe-v2'")
code=code.replace('(.5 if coherent else 1)','1')
code=code.replace('Globally inactive cleanup is corrected; possible-active coherent cleanup remains open.',
                  'The finite zero and coherent-sector scoped counterexamples now preserve purity.')
exec(compile(code,'probe-rebound-borrow-final.py','exec'))
subprocess.run(['python3',str(root/'build/probe-inactive-coherence.py')],cwd=root,check=True,
               env=dict(os.environ,COHERENCE_COMPILER_ROOT=str(compiler),COHERENCE_VERSION='rebound-borrow-final-v2'))
folder=root/'build/rebound-borrow-prototype-findings-v1';folder.mkdir()
logs=root/'build/rebound-borrow-normal-results-v1/coherent-overwrites'
for path in sorted(logs.glob('*borrowed-coherent*.log')):
    points=[json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    if len(points)!=2:continue
    guards=[r for r in points[-1]['registers'] if r['history'] and len(r['wires'])==1]
    assert len(guards)==1
    wire=guards[0]['wires'][0];purities=[]
    for point in points:
        blocks={}
        for basis,real,imag in point['state']:
            basis=int(basis,0)
            blocks.setdefault((basis>>wire)&1,{})[basis&~(1<<wire)]=complex(real,imag)
        rho={}
        for block in blocks.values():
            for a,left in block.items():
                for b,right in block.items():rho[a,b]=rho.get((a,b),0j)+left*right.conjugate()
        purities.append(sum(abs(v)**2 for v in rho.values()))
    assert abs(purities[0]-1)<1e-9 and abs(purities[1]-.5)<1e-9
    report=dict(status='failed-previous-prototype',log=str(path),logical_purities=purities,
                excluded_private_guard=guards[0],
                meaning='Prototype v1 kept a redundant computed decision while a declared borrower remained live. Stable guard expansion in final v2 removes that correlation; complete live and scoped states have separate final evidence.')
    (folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
    break
else:raise AssertionError('Missing previous prototype failing trace')
