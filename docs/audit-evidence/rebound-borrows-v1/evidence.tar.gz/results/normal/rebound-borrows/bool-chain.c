#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
typedef bool word;

int main(int argc,char **argv){
size_t n=argc>1?strtoul(argv[1],0,10):1;if(n>1)return 2;
quant uint8_t x=superposition(0,1);quant word y=superposition(0,1);
quant bool c=superposition(0,1),d=superposition(0,1);
if(x)phase(.11);if(y&1)phase(.73);if(y&2)phase(.29);if(c)phase(.31);if(d)phase(.19);
ownership_checkpoint("before");{quant word saved=y^1;quant uint8_t chain=(uint8_t)(saved^1);if(c){y=(word)x;}if(chain)phase(.47);ownership_checkpoint("borrowed");if(chain&1)phase(.13);}ownership_checkpoint("after");
measure(y);measure(x);measure(c);measure(d);return 0;}
