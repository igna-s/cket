#include <quantum.h>
void ownership_checkpoint(const char*);
int main(void){
quant bool x=superposition(0,1),y=superposition(0,1),control=superposition(0,1);
if(y)phase(.73);ownership_checkpoint("before");
{quant bool saved=y^1;if(control)y=x^0;if(saved)phase(.47);}
ownership_checkpoint("after");measure(y);measure(x);measure(control);return 0;}
