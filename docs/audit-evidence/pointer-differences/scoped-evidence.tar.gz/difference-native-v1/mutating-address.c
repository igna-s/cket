#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
quant uint8_t a[2]={3,4};uint8_t *p=memset(a,0,0);ptrdiff_t n=p++-a;measure(a[0]);measure(a[1]);return n!=0;
}
