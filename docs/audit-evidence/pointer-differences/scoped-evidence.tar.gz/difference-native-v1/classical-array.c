#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
uint16_t a[3]={1,2,3};uint16_t *p=a+2;ptrdiff_t n=p-a,m=a-p;
quant bool b=1;int bit=measure(b);return n!=2||m!=-2||!bit;
}
