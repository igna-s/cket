#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
quant uint8_t a=3;uint8_t *p=memset(&a,0,0);ptrdiff_t n=p-(uint8_t*)0;measure(a);return n!=0;
}
