#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#include <string.h>
#include <stddef.h>
int main(void){
quant int16_t x=-1;int16_t *p=memmove(&x,&x,0);
ptrdiff_t n=(p+1)-p;int y=measure(x);return n!=1||y!=-1;
}
