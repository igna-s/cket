#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#include <string.h>
#include <stddef.h>
int main(void){
quant uint16_t x=0x1234;void *p=memset((char*)&x+1,0xab,1);
ptrdiff_t n=(char*)p-(char*)&x,m=(char*)&x-(char*)p;unsigned y=measure(x);return n!=1||m!=-1||y!=0xab34;
}
