#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
quant uint16_t x=0x1234;uint16_t *p=memmove(&x,&x,0);
ptrdiff_t n=(p+1)-p,m=p-(p+1);unsigned y=measure(x);return n!=1||m!=-1||y!=0x1234;
}
