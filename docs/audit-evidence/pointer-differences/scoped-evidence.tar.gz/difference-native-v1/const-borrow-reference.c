#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#include <string.h>
#include <stddef.h>
int main(void){
quant uint8_t a[2]={3,5};const uint8_t *p=memset(a,0,0);
ptrdiff_t n=(a+2)-p;unsigned x=measure(a[0]),y=measure(a[1]);return n!=2||x!=3||y!=5;
}
