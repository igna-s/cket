#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
quant uint8_t a[2]={3,5};uint8_t *p=memset(a+2,0,0);
ptrdiff_t n=p-a,m=a-p;unsigned x=measure(a[0]),y=measure(a[1]);return n!=2||m!=-2||x!=3||y!=5;
}
