#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#include <string.h>
#include <stddef.h>
int main(void){
quant uint16_t x=0x1234;uint16_t *p=memmove(&x,&x,0);
ptrdiff_t n=(unsigned char*)(p+1)-(unsigned char*)p;unsigned y=measure(x);return n!=2||y!=0x1234;
}
