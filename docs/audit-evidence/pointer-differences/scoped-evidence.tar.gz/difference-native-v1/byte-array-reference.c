#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#include <string.h>
#include <stddef.h>
int main(void){
quant uint8_t a[2]={3,5};uint8_t *p=memcpy(a+1,a,1);
ptrdiff_t n=p-a,m=a-p;unsigned x=measure(a[0]),y=measure(a[1]);return n!=1||m!=-1||x!=3||y!=3;
}
