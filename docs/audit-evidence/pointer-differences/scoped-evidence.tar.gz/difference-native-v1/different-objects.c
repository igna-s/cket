#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
quant uint8_t a=3,b=4;uint8_t *p=memset(&a,0,0);ptrdiff_t n=p-&b;measure(a);measure(b);return n!=0;
}
