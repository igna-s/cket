#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void) {
    quant bool b = superposition(0, 1);
    quant uint8_t x = 5;
    void *p = memset(&x, 0, 0);
    ptrdiff_t n = (uint8_t *)p + 1 - (uint8_t *)p;
    if (b) phase(.31);
    if (b) { if (n == 1) { memset(p, 17, 1); phase(.17); } }
    measure(x);
    measure(b);
    return n != 1;
}
