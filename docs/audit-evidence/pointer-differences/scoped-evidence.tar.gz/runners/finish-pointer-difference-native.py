"""Preserve a diagnostic-fixture expectation failure and finish its matrix."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('/tmp/quantum-audit-isolated-20261017/build/pointer-difference-prototype')
first = root / 'build/difference-native-v1'
output = root / 'build/difference-native-v2'
output.mkdir()
snapshot = json.loads((first / 'sources.json').read_text())
for name, expected in snapshot.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
previous = json.loads((first / 'progress.json').read_text())
assert len(previous) == 111 and previous[-1]['name'] == 'null-address'
assert previous[-1]['returncode'] == 1 and 'quantum reference cannot escape' in previous[-1]['stderr']
(first / 'failure-summary.json').write_text(json.dumps({
    'status': 'failed-harness-expectation-preserved', 'harness_returncode': 1,
    'completed_native_checks': 80, 'completed_specific_diagnostic_checks': 30,
    'compiler_returncode_on_disputed_fixture': 1,
    'reason': 'GCC folds subtraction of a null pointer to a pointer-to-integer conversion before the pointer-difference handler. The program is rejected by the existing CPU escape guard. C11 does not define this subtraction; only the expected diagnostic was too narrow. No accepted C result disagreed with its reference.',
    'source_sha256': snapshot,
}, indent=2) + '\n')
rows = previous[:-1]
source = first / 'null-address.c'
for level in ('-O0', '-O1', '-O2', '-O3', '-Os'):
    for builtin in ('-fbuiltin', '-fno-builtin'):
        result = subprocess.run([str(root / 'build/cket'), str(source), '--emit-ir', level, builtin,
                                 '-o', str(output / 'rejected.json')], cwd=root,
                                env=dict(os.environ, CC='gcc-11'), text=True, capture_output=True, timeout=120)
        assert result.returncode == 1 and '|c>: quantum reference cannot escape' in result.stderr
        assert not any(marker in result.stderr for marker in ('AddressSanitizer:', 'runtime error:', 'internal compiler error:'))
        rows.append({'name': 'null-address', 'optimization': level, 'builtins': builtin,
                     'returncode': result.returncode, 'stderr': result.stderr, 'kind': 'diagnostic'})
assert len(rows) == len({(r['name'], r['optimization'], r['builtins']) for r in rows}) == 120
for name, expected in snapshot.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
(output / 'results.json').write_text(json.dumps({
    'status': 'passed-scoped-in-segments', 'rows': rows, 'native_checks': 80,
    'diagnostic_checks': 40, 'ordinary_c_executions': 40,
    'source_sha256': snapshot,
    'plugin_sha256_captured_after_checks': hashlib.sha256((root / 'build/cket_plugin.so').read_bytes()).hexdigest(),
    'scope': 'Retains the original expectation failure and its exact source snapshot. Reuses 80 successful native checks and 30 successful specific diagnostics on unchanged inputs; reruns only the 10 null-address diagnostic combinations with the correct existing escape diagnostic. All five GCC levels and both builtin modes covered. Existing core/driver reused; plugin separately rebuilt. No sanitizer or full-state completion claim.',
}, indent=2) + '\n')
print('PASS: 80 native + 40 diagnostic pointer-difference checks; 40 C references separate. Original harness expectation failure preserved.')
