"""Check generated phases/inverses against an independent two-amplitude model."""
from pathlib import Path
import ast
import cmath
import hashlib
import json
import math
import os
import re
import subprocess

root = Path('/tmp/quantum-audit-isolated-20261017')
candidate = root / 'build/pointer-difference-prototype'
failed = candidate / 'build/difference-states-v1'
original_case = failed / 'difference.c'
if original_case.exists():
    result = subprocess.run([str(candidate / 'build/cket'), str(original_case), '--emit-ir', '-O0',
                             '-fbuiltin', '-o', str(failed / 'rejected.json')], cwd=candidate,
                            env=dict(os.environ, CC='gcc-11'), text=True, capture_output=True)
    assert result.returncode == 1 and 'classical branch inside quantum control is not supported yet' in result.stderr
    (failed / 'pending-context.json').write_text(json.dumps({
        'status': 'diagnosed-pending-context-preserved', 'compile_returncode': result.returncode,
        'stderr': result.stderr,
        'scope': 'Valid C address-distance stored in a CPU scalar and then used in a nested coherent branch is still rejected. This is a real pending control-flow context, not an accepted-result mismatch or a passing quantum state check. The direct checked-address expression is tested separately.',
    }, indent=2) + '\n')
output = candidate / 'build/difference-states-v2'
output.mkdir()
frozen = json.loads((candidate / 'build/difference-native-v2/results.json').read_text())['source_sha256']
for name, expected in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == expected
export_source = (root / 'build/export-memory-return.c').read_text()
assert export_source.count('if (argc != 5)') == export_source.count('qc_allow_tables(c, 0);') == 1
export_source = export_source.replace('if (argc != 5)', 'if (argc != 6)')
export_source = export_source.replace('qc_allow_tables(c, 0);', 'qc_allow_tables(c, atoi(argv[5]) != 0);')
export_c = output / 'exporter.c'
export_c.write_text(export_source)
exporter = output / 'exporter'
subprocess.run(['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                '-I' + str(candidate / 'src/engine'), str(export_c),
                str(candidate / 'build/libcket_quantum.a'), '-lm', '-o', str(exporter)], check=True)
reference_source = (root / 'build/check-byte-comparison-raw.py').read_text()
node, = [node for node in ast.parse(reference_source).body
         if isinstance(node, ast.FunctionDef) and node.name == 'simulate']
simulator = ast.get_source_segment(reference_source, node)
assert simulator.count('assert set(measurements) == set(range(bits))') == 1
simulator = simulator.replace('assert set(measurements) == set(range(bits))',
                              'assert not measurements if bits is None else set(measurements) == set(range(bits))')
(output / 'independent-simulator.py').write_text(simulator + '\n')
namespace = {'re': re, 'math': math, 'cmath': cmath}
exec(compile(simulator, '<independent H/X/phase reference>', 'exec'), namespace)
program = '''#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void) {
    quant bool b = superposition(0, 1);
    quant uint8_t x = 5;
    void *p = memset(&x, 0, 0);
    ptrdiff_t n = (uint8_t *)p + 1 - (uint8_t *)p;
    if (b) phase(.31);
    if (b) { if ((uint8_t *)p + 1 - (uint8_t *)p == 1) { memset(p, 17, 1); phase(.17); } }
    measure(x);
    measure(b);
    return n != 1;
}
'''
source, constant = output / 'difference.c', output / 'constant.c'
source.write_text(program)
constant.write_text(program.replace('(uint8_t *)p + 1 - (uint8_t *)p', '1'))
rows = []
for level in ('-O0', '-O1', '-O2', '-O3', '-Os'):
    for builtin in ('-fbuiltin', '-fno-builtin'):
        key = level[1:] + '-' + builtin[2:]
        irs = {}
        for name, path in [('difference', source), ('constant', constant)]:
            ir = output / f'{key}-{name}.json'
            result = subprocess.run([str(candidate / 'build/cket'), str(path), '--emit-ir',
                                     level, builtin, '-o', str(ir)], cwd=candidate,
                                    env=dict(os.environ, CC='gcc-11'), text=True, capture_output=True)
            assert result.returncode == 0, result.stderr
            irs[name] = ir
        for tables in (0, 1):
            artifacts = {}
            for name, ir in irs.items():
                prefix = output / f'{key}-{name}-tables{tables}'
                before, after, mapping = [Path(str(prefix) + suffix) for suffix in ('.qasm', '-inverse.qasm', '-map.json')]
                result = subprocess.run([str(exporter), str(ir), str(before), str(after), str(mapping), str(tables)],
                                        text=True, capture_output=True)
                assert result.returncode == 0, result.stderr
                artifacts[name] = (before, after, mapping)
            for stage in range(2):
                assert artifacts['difference'][stage].read_bytes() == artifacts['constant'][stage].read_bytes(), 'Pointer metadata changed the actual circuit.'
            mapping = json.loads(artifacts['difference'][2].read_text())
            assert mapping['current_id'] == 1
            for index, stage in enumerate(('before', 'after')):
                info = mapping[stage]
                assert info['measure'] == info['reset'] == 0
                registers = {row['id']: row for row in info['registers']}
                assert {0, 1} <= set(registers)
                guards = set(registers) - {0, 1}
                assert len(guards) <= 1 if stage == 'before' else not guards
                namespace['wires'] = {'qubits': info['qubits']}
                actual, observed, qubits, gates, hadamards = namespace['simulate'](artifacts['difference'][index].read_text())
                assert not observed and qubits == info['qubits'] and hadamards == 1
                expected = {}
                for bit in (0, 1):
                    values = {0: bit, 1: 5 if stage == 'after' or not bit else 17}
                    for identifier in guards:
                        assert len(registers[identifier]['wires']) == 1 and registers[identifier]['definition']
                        values[identifier] = bit
                    basis = sum(((value >> position) & 1) << wire
                                for identifier, value in values.items()
                                for position, wire in enumerate(registers[identifier]['wires']))
                    expected[basis] = cmath.exp(.48j * bit) / math.sqrt(2)
                error = max(abs(actual.get(basis, 0) - amplitude) for basis, amplitude in expected.items())
                assert set(actual) == set(expected) and error < 1e-10
                assert abs(sum(abs(value) ** 2 for value in actual.values()) - 1) < 1e-10
                rows.append({'optimization': level, 'builtins': builtin, 'tables': bool(tables),
                             'stage': stage, 'physical_wires': qubits, 'amplitudes': 2,
                             'maximum_amplitude_error': error,
                             'qasm_sha256': hashlib.sha256(artifacts['difference'][index].read_bytes()).hexdigest()})
                (output / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
        print('PASS pointer-difference phases/inverses:', key, flush=True)
for name, expected in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == expected
(output / 'results.json').write_text(json.dumps({'status': 'passed-scoped-states', 'checks': rows,
    'state_checks': 40, 'paired_constant_circuits': 40,
    'source_sha256': frozen,
    'scope': 'One coherent pointer-controlled memory profile at all five GCC levels, both builtin modes and both synthesis policies. Twenty actual prefixes and their saved definition/write inverses: 40 complete states from an independent two-amplitude reference, including phases, correlations and all private zeros. Each prefix/inverse also equals the circuit from an explicit constant address-distance program. No implicit channels, unrestricted pointer ABI, physical hardware or general completeness claim.'}, indent=2) + '\n')
print('PASS 40 complete phased prefix/inverse states and 40 circuit equalities with constant-distance references.')
