"""Execute finite pointer-difference fixtures and ordinary-C references."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
candidate = root / 'build/pointer-difference-prototype'
output = candidate / 'build/difference-native-v1'
output.mkdir()
frontend = candidate / 'src/quantum_frontend.inc'
text = frontend.read_text()
before = '''    unsigned precision = TYPE_PRECISION(type);
    if (!INTEGRAL_TYPE_P(type) || TYPE_UNSIGNED(type) || !precision || precision > 64)'''
after = '''    if (!INTEGRAL_TYPE_P(type) || TYPE_UNSIGNED(type))
        return reject("|c>: quantum pointer subtraction needs a supported signed pointer-difference type");
    unsigned precision = TYPE_PRECISION(type);
    if (!precision || precision > 64)'''
assert text.count(before) == 1
frontend.write_text(text.replace(before, after))
sys.path.insert(0, str(root / '.deps/format-venv/lib/python3.10/site-packages'))
spec = importlib.util.spec_from_file_location('difference_format', root / 'scripts/format.py')
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)
formatter.CLANG = root / '.deps/format-venv/lib/python3.10/site-packages/clang_format/data/bin/clang-format'
formatter.CLANG.chmod(0o755)
frontend.write_text(formatter.format_text(frontend, frontend.read_text()))
plugin = ['g++-11', '-std=c++17', '-O2', '-Wall', '-Wextra', '-Wno-unused-parameter',
          '-Wno-format-diag', '-fPIC', '-shared', '-fno-rtti',
          '-I.deps/gcc/usr/lib/gcc/x86_64-linux-gnu/11/plugin/include',
          '-I.deps/gcc/usr/include', '-I.deps/gcc/usr/include/x86_64-linux-gnu',
          'src/cket_plugin.cpp', '-o', 'build/cket_plugin.so']
with (output / 'plugin-build.log').open('x') as handle:
    result = subprocess.run(plugin, cwd=candidate, stdout=handle, stderr=subprocess.STDOUT)
assert result.returncode == 0
source_map = json.loads((candidate / 'build/before-sources.json').read_text())
source_map = {name: hashlib.sha256((candidate / name).read_bytes()).hexdigest() for name in source_map}
(output / 'sources.json').write_text(json.dumps(source_map, indent=2) + '\n')
header = '#include <quantum.h>\n#include <string.h>\n#include <stddef.h>\n'
cpu_header = '#include <stdint.h>\n#include <stdbool.h>\n#define quant\n#define measure(x) (x)\n'
cases = {
    'byte-array': '''quant uint8_t a[2]={3,5};uint8_t *p=memcpy(a+1,a,1);
ptrdiff_t n=p-a,m=a-p;unsigned x=measure(a[0]),y=measure(a[1]);return n!=1||m!=-1||x!=3||y!=3;''',
    'one-past-array': '''quant uint8_t a[2]={3,5};uint8_t *p=memset(a+2,0,0);
ptrdiff_t n=p-a,m=a-p;unsigned x=measure(a[0]),y=measure(a[1]);return n!=2||m!=-2||x!=3||y!=5;''',
    'word-element-units': '''quant uint16_t x=0x1234;uint16_t *p=memmove(&x,&x,0);
ptrdiff_t n=(p+1)-p,m=p-(p+1);unsigned y=measure(x);return n!=1||m!=-1||y!=0x1234;''',
    'word-byte-units': '''quant uint16_t x=0x1234;uint16_t *p=memmove(&x,&x,0);
ptrdiff_t n=(unsigned char*)(p+1)-(unsigned char*)p;unsigned y=measure(x);return n!=2||y!=0x1234;''',
    'byte-view-offset': '''quant uint16_t x=0x1234;void *p=memset((char*)&x+1,0xab,1);
ptrdiff_t n=(char*)p-(char*)&x,m=(char*)&x-(char*)p;unsigned y=measure(x);return n!=1||m!=-1||y!=0xab34;''',
    'signed-word': '''quant int16_t x=-1;int16_t *p=memmove(&x,&x,0);
ptrdiff_t n=(p+1)-p;int y=measure(x);return n!=1||y!=-1;''',
    'const-borrow': '''quant uint8_t a[2]={3,5};const uint8_t *p=memset(a,0,0);
ptrdiff_t n=(a+2)-p;unsigned x=measure(a[0]),y=measure(a[1]);return n!=2||x!=3||y!=5;''',
    'classical-array': '''uint16_t a[3]={1,2,3};uint16_t *p=a+2;ptrdiff_t n=p-a,m=a-p;
quant bool b=1;int bit=measure(b);return n!=2||m!=-2||!bit;''',
}
negatives = {
    'different-objects': 'quant uint8_t a=3,b=4;uint8_t *p=memset(&a,0,0);ptrdiff_t n=p-&b;measure(a);measure(b);return n!=0;',
    'cpu-object': 'quant uint8_t a=3;uint8_t b=4;uint8_t *p=memset(&a,0,0);ptrdiff_t n=p-&b;measure(a);return n!=0;',
    'mutating-address': 'quant uint8_t a[2]={3,4};uint8_t *p=memset(a,0,0);ptrdiff_t n=p++-a;measure(a[0]);measure(a[1]);return n!=0;',
    'null-address': 'quant uint8_t a=3;uint8_t *p=memset(&a,0,0);ptrdiff_t n=p-(uint8_t*)0;measure(a);return n!=0;',
}
rows = []
env = dict(os.environ, CC='gcc-11')
for name, body in cases.items():
    source = output / f'{name}.c'
    cpu = output / f'{name}-reference.c'
    source.write_text(header + 'int main(void){\n' + body + '\n}\n')
    cpu.write_text(cpu_header + source.read_text().replace('#include <quantum.h>\n', ''))
    for level in ('-O0', '-O1', '-O2', '-O3', '-Os'):
        reference = output / f'{name}-{level[1:]}-reference'
        subprocess.run(['gcc-11', '-std=c11', level, str(cpu), '-o', str(reference)], check=True)
        result = subprocess.run([str(reference)])
        assert result.returncode == 0, (name, level, 'ordinary C reference')
        for builtin in ('-fbuiltin', '-fno-builtin'):
            result = subprocess.run([str(candidate / 'build/cket'), str(source), '--run', level, builtin,
                                     '-o', str(output / f'{name}-{level[1:]}-{builtin[2:]}.out')],
                                    cwd=candidate, env=env, text=True, capture_output=True, timeout=120)
            row = {'name': name, 'optimization': level, 'builtins': builtin, 'returncode': result.returncode,
                   'stderr': result.stderr, 'stdout': result.stdout}
            rows.append(row)
            (output / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
            assert result.returncode == 0, row
    print('PASS native pointer difference:', name, flush=True)
for name, body in negatives.items():
    source = output / f'{name}.c'
    source.write_text(header + 'int main(void){\n' + body + '\n}\n')
    for level in ('-O0', '-O1', '-O2', '-O3', '-Os'):
        for builtin in ('-fbuiltin', '-fno-builtin'):
            result = subprocess.run([str(candidate / 'build/cket'), str(source), '--emit-ir', level, builtin,
                                     '-o', str(output / 'rejected.json')], cwd=candidate, env=env,
                                    text=True, capture_output=True, timeout=120)
            row = {'name': name, 'optimization': level, 'builtins': builtin, 'returncode': result.returncode,
                   'stderr': result.stderr, 'kind': 'diagnostic'}
            rows.append(row)
            (output / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
            assert result.returncode == 1 and '|c>: quantum pointer subtraction' in result.stderr, row
            assert not any(marker in result.stderr for marker in ('internal compiler error:', 'runtime error:', 'AddressSanitizer:'))
    print('PASS pointer difference diagnostic:', name, flush=True)
for name, expected in source_map.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == expected
(output / 'results.json').write_text(json.dumps({'status': 'passed-scoped-native', 'rows': rows,
    'native_checks': 80, 'diagnostic_checks': 40, 'ordinary_c_executions': 40,
    'source_sha256': source_map, 'scope': 'Isolated one-file frontend extension. Existing core/driver copied from the frozen pointer candidate; plugin rebuilt. Eight native fixtures and four diagnostic boundaries, five GCC levels and both builtin modes. The 40 ordinary-C executions are separate references; undefined diagnostic fixtures are not executed as references. No sanitizer/full-state/general-pointer completion claim.'}, indent=2) + '\n')
print('120 scoped native/diagnostic checks passed; 40 ordinary-C executions counted separately.', flush=True)
