"""Archive finite pointer-difference evidence without promoting compiler inputs."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
candidate = root / 'build/pointer-difference-prototype'
build = candidate / 'build'
destination = root / 'build/closed-pointer-differences-v2'
destination.mkdir()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


native = json.loads((build / 'difference-native-v2/results.json').read_text())
states = json.loads((build / 'difference-states-v2/results.json').read_text())
sanitized = json.loads((build / 'difference-sanitized-v1/results.json').read_text())
provenance = json.loads((build / 'difference-sanitized-v1/tool-provenance.json').read_text())
before = json.loads((build / 'before-sources.json').read_text())
frozen = native['source_sha256']
assert len(frozen) == 136 and states['source_sha256'] == frozen == provenance['source_sha256']
assert sorted(name for name in frozen if before.get(name) != frozen[name]) == ['src/quantum_frontend.inc']
for name, expected in frozen.items():
    assert digest(candidate / name) == expected, name
assert native['status'] == 'passed-scoped-in-segments'
assert sanitized['status'] == 'passed-scoped-sanitized' and sanitized['exit_code'] == 0
assert states['status'] == 'passed-scoped-states' and states['state_checks'] == 40
for report in (native, sanitized):
    rows = report['rows']
    assert report['native_checks'] == 80 and report['diagnostic_checks'] == 40
    assert len(rows) == len({(r['name'], r['optimization'], r['builtins']) for r in rows}) == 120
    assert sum(row.get('kind') == 'diagnostic' for row in rows) == 40
    assert all(row['returncode'] == (1 if row.get('kind') == 'diagnostic' else 0) for row in rows)
    assert all(not any(marker in row['stderr'] for marker in ('AddressSanitizer:', 'runtime error:', 'internal compiler error:')) for row in rows)
assert digest(build / 'cket_plugin.so') == native['plugin_sha256_captured_after_checks']
assert digest(build / 'difference-sanitized-v1/stage/build/cket_plugin.so') == provenance['fresh_plugin_sha256']
for row in states['checks']:
    basename = row['optimization'][1:] + '-' + row['builtins'][2:] + '-difference-tables' + str(int(row['tables']))
    suffix = '.qasm' if row['stage'] == 'before' else '-inverse.qasm'
    assert digest(build / 'difference-states-v2' / (basename + suffix)) == row['qasm_sha256']
for name in ('before-sources.tar.gz', 'before-sources.json', 'before-provenance.json',
             'difference-before.c', 'difference-before.ast', 'difference-before.log',
             'difference-after.json', 'difference-after.log', 'difference-build.log'):
    shutil.copyfile(build / name, destination / name)
with tarfile.open(destination / 'sources.tar.gz', 'x:gz') as archive:
    for name in [*frozen, 'LICENSE', 'verified-sources.json']:
        if name == 'verified-sources.json':
            data = (json.dumps(frozen, indent=2) + '\n').encode()
        elif name == 'LICENSE':
            data = (root / name).read_bytes()
        else:
            data = (candidate / name).read_bytes()
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(data), 0o644
        archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination / 'scoped-evidence.tar.gz', 'x:gz') as archive:
    for folder in ('difference-native-v1', 'difference-native-v2', 'difference-states-v1',
                   'difference-states-v2', 'difference-sanitized-v1'):
        for path in sorted((build / folder).iterdir()):
            if path.is_file() and path.suffix in ('.c', '.json', '.log', '.qasm', '.txt'):
                archive.add(path, arcname=folder + '/' + path.name)
    for name in ('prepare-pointer-difference.py', 'implement-pointer-difference.py',
                 'test-pointer-difference.py', 'finish-pointer-difference-native.py',
                 'check-pointer-difference-states.py', 'run-pointer-difference-sanitized.py',
                 'export-memory-return.c', 'check-byte-comparison-raw.py', 'archive-pointer-differences.py'):
        archive.add(root / 'build' / name, arcname='runners/' + name)
summary = {'status': 'verified-scoped-isolated', 'source_files': 136, 'source_sha256': frozen,
           'changed_inputs_from_pointer_candidate': ['src/quantum_frontend.inc'],
           'checks_per_configuration': {'native': 80, 'diagnostic': 40},
           'ordinary_c_references_separate': 40, 'independent_phased_prefix_and_inverse_states': 40,
           'constant_distance_circuit_equalities': 40,
           'pending': ['CPU scalar holding an address distance used as a nested condition inside coherent control.',
                       'Maintained regression integration and full broad normal/sanitizer campaign for this new frontend.',
                       'General C11 pointer, ABI, layout and library compatibility.'],
           'scope': 'Prototype only, no main application. Eight native and four diagnostic profiles at five GCC levels and both builtin modes. One coherent control profile at both synthesis policies, before and after saved inverses, with independent complex-amplitude checking. The original diagnostic expectation failure and the separate real pending control-flow context remain preserved. Normal and sanitizer plugins were rebuilt; source-identical engine/driver/core reuse is identified by provenance. These finite checks do not prove all C11 programs, hardware execution, speedup or absence of all bugs. Cybersecurity remains classical and unchanged.',
           'artifact_sha256': {path.name: digest(path) for path in destination.iterdir() if path.is_file()}}
(destination / 'experimental-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Archived 120 normal + 120 instrumented checks, 40 independent phased states, original failure and real pending context; 136 source hashes verified.')
