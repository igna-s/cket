"""Lower checked pointer differences as address metadata in an isolated candidate."""
from pathlib import Path
import hashlib
import io
import json
import os
import subprocess
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
candidate = root / 'build/pointer-difference-prototype'
build = candidate / 'build'
frozen = json.loads((build / 'before-sources.json').read_text())
for name, expected in frozen.items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == expected, name
with tarfile.open(build / 'before-sources.tar.gz', 'x:gz') as archive:
    for name in [*frozen, 'verified-sources.json']:
        data = ((candidate / name).read_bytes() if name in frozen else (build / 'before-sources.json').read_bytes())
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o644
        archive.addfile(member, io.BytesIO(data))
frontend = candidate / 'src/quantum_frontend.inc'
text = frontend.read_text()
marker = 'tree expand_pointer_relation(tree value) {'
assert text.count(marker) == 1
addition = '''// GCC POINTER_DIFF_EXPR is a byte difference. The C frontend supplies
// the separate EXACT_DIV_EXPR for sizeof(*pointer); dividing here as well
// would silently return the wrong element distance for 16/32/64-bit types.
tree expand_pointer_difference(tree value) {
    tree left = strip(TREE_OPERAND(value, 0)), right = strip(TREE_OPERAND(value, 1));
    if (!left || !right || TREE_CODE(TREE_TYPE(left)) != POINTER_TYPE ||
        TREE_CODE(TREE_TYPE(right)) != POINTER_TYPE)
        return NULL_TREE;
    QuantumByteRange a, b;
    bool qa = resolve_byte_range(left, a) && a.quantum;
    bool qb = resolve_byte_range(right, b) && b.quantum;
    if (!qa && !qb && !has_quantum(left) && !has_quantum(right))
        return NULL_TREE;
    auto reject = [value](const char *message) -> tree {
        error_at(at(value), "%s", message);
        return build_zero_cst(TREE_TYPE(value));
    };
    if (!qa || !qb)
        return reject("|c>: quantum pointer subtraction requires two statically checked borrows");
    if (a.elements != b.elements || a.stride != b.stride)
        return reject("|c>: quantum pointer subtraction requires the same checked storage object");
    uint64_t magnitude = a.offset >= b.offset ? a.offset - b.offset : b.offset - a.offset;
    tree type = TREE_TYPE(value);
    unsigned precision = TYPE_PRECISION(type);
    if (!INTEGRAL_TYPE_P(type) || TYPE_UNSIGNED(type) || !precision || precision > 64)
        return reject("|c>: quantum pointer subtraction needs a supported signed pointer-difference type");
    uint64_t maximum = precision == 64 ? (uint64_t)INT64_MAX
                                       : (uint64_t{1} << (precision - 1)) - 1;
    // Checked storage is small, but retain an explicit representability guard
    // before converting the unsigned address distance into a signed constant.
    if (magnitude > maximum)
        return reject("|c>: quantum pointer subtraction exceeds its signed difference representation");
    int64_t bytes = static_cast<int64_t>(magnitude);
    if (a.offset < b.offset)
        bytes = -bytes;
    // This observes addresses only. No quantum register is read or measured.
    return build_int_cst(type, bytes);
}

'''
text = text.replace(marker, addition + marker)
marker = '    if (TREE_CODE_CLASS(code) == tcc_comparison) {\n'
assert text.count(marker) == 1
text = text.replace(marker, '''    if (code == POINTER_DIFF_EXPR) {
        tree difference = expand_pointer_difference(value);
        if (difference)
            return difference;
    }
''' + marker)
frontend.write_text(text)
changed = [name for name, expected in frozen.items()
           if hashlib.sha256((candidate / name).read_bytes()).hexdigest() != expected]
assert changed == ['src/quantum_frontend.inc'], changed
command = ['g++-11', '-std=c++17', '-O2', '-Wall', '-Wextra', '-Wno-unused-parameter',
           '-Wno-format-diag', '-fPIC', '-shared', '-fno-rtti',
           '-I.deps/gcc/usr/lib/gcc/x86_64-linux-gnu/11/plugin/include',
           '-I.deps/gcc/usr/include', '-I.deps/gcc/usr/include/x86_64-linux-gnu',
           'src/cket_plugin.cpp', '-o', 'build/cket_plugin.so']
with (build / 'difference-build.log').open('x') as handle:
    result = subprocess.run(command, cwd=candidate, stdout=handle, stderr=subprocess.STDOUT)
assert result.returncode == 0, (build / 'difference-build.log').read_text()
source = build / 'difference-before.c'
result = subprocess.run([str(build / 'cket'), str(source), '--emit-ir', '-O2', '-fbuiltin',
                         '-o', str(build / 'difference-after.json')], cwd=candidate,
                        env=dict(os.environ, CC='gcc-11'), text=True, capture_output=True)
(build / 'difference-after.log').write_text(result.stdout + result.stderr)
print('New IR compilation:', result.returncode, result.stderr[-2000:], flush=True)
assert result.returncode == 0
