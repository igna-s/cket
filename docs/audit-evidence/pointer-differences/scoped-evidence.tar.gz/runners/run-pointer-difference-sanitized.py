"""Run the same finite address-difference matrix with an instrumented plugin."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parent.parent
CANDIDATE = ROOT / 'build/pointer-difference-prototype'
OUT = CANDIDATE / 'build/difference-sanitized-v1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


if '--worker' not in sys.argv:
    OUT.mkdir()
    shutil.copyfile(Path(__file__), OUT / 'runner.py')
    with (OUT / 'worker.log').open('x') as handle:
        worker = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker'],
                                  cwd=CANDIDATE, stdin=subprocess.DEVNULL, stdout=handle,
                                  stderr=subprocess.STDOUT, start_new_session=True)
    fields = (Path('/proc') / str(worker.pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    (OUT / 'job.json').write_text(json.dumps({'pid': worker.pid, 'linux_start_ticks': int(fields[19]),
        'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}, indent=2) + '\n')
    print('Started scoped sanitized pointer-difference checks:', worker.pid)
    raise SystemExit(0)

status, error, rows = 1, None, []
try:
    native = json.loads((CANDIDATE / 'build/difference-native-v2/results.json').read_text())
    for name, expected in native['source_sha256'].items():
        assert digest(CANDIDATE / name) == expected
    base = ROOT / 'build/memory-return-maintained'
    base_progress = json.loads((base / 'build/linux-isolated-resume-v2/progress.json').read_text())
    core_hashes = base_progress['fresh_instrumented_core_sha256']
    stage = OUT / 'stage'
    (stage / 'build').mkdir(parents=True)
    for name in ('src', 'tests', 'include', 'examples'):
        (stage / name).symlink_to(CANDIDATE / name, target_is_directory=True)
    shutil.copyfile(CANDIDATE / 'cket', stage / 'cket')
    for name in ('cket', 'cket_backend', 'cket_runtime.o', 'libcket_quantum.a', 'gcc-wrapper', 'gcc-version.txt'):
        source = base / 'build/sanitized/build' / name
        if name in core_hashes:
            assert digest(source) == core_hashes[name], name
        shutil.copyfile(source, stage / 'build' / name)
        (stage / 'build' / name).chmod(0o755)
    plugin = ['g++-11', '-std=c++17', '-O1', '-g', '-Wall', '-Wextra', '-Wno-unused-parameter',
              '-Wno-format-diag', '-fPIC', '-shared', '-fno-rtti', '-fsanitize=address,undefined',
              '-fno-omit-frame-pointer', '-I.deps/gcc/usr/lib/gcc/x86_64-linux-gnu/11/plugin/include',
              '-I.deps/gcc/usr/include', '-I.deps/gcc/usr/include/x86_64-linux-gnu',
              'src/cket_plugin.cpp', '-o', str(stage / 'build/cket_plugin.so')]
    with (OUT / 'plugin-build.log').open('x') as handle:
        result = subprocess.run(plugin, cwd=CANDIDATE, stdout=handle, stderr=subprocess.STDOUT)
    assert result.returncode == 0
    (OUT / 'tool-provenance.json').write_text(json.dumps({
        'source_sha256': native['source_sha256'],
        'fresh_plugin_sha256': digest(stage / 'build/cket_plugin.so'),
        'reused_instrumented_core_sha256': {name: digest(stage / 'build' / name)
            for name in ('cket', 'cket_backend', 'cket_runtime.o', 'libcket_quantum.a')},
        'scope': 'The new frontend plugin is freshly built with ASan/UBSan. Source-identical engine/runtime/driver/backend objects are copied from the successful fresh instrumented build recorded by the 136-input candidate; its plugin is not reused.',
    }, indent=2) + '\n')
    env = dict(os.environ, CC=str(stage / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for item in native['rows']:
        name = item['name']
        source = CANDIDATE / 'build/difference-native-v1' / (name + '.c')
        diagnostic = item.get('kind') == 'diagnostic'
        command = [str(stage / 'build/cket'), str(source), '--emit-ir' if diagnostic else '--run',
                   item['optimization'], item['builtins'], '-o', str(OUT / 'case.out')]
        result = subprocess.run(command, cwd=CANDIDATE, env=env, text=True, capture_output=True, timeout=180)
        row = {'name': name, 'optimization': item['optimization'], 'builtins': item['builtins'],
               'kind': 'diagnostic' if diagnostic else 'native', 'returncode': result.returncode,
               'stderr': result.stderr, 'stdout': result.stdout}
        rows.append(row)
        (OUT / 'progress.json').write_text(json.dumps(rows, indent=2) + '\n')
        assert not any(marker in result.stderr for marker in (
            'AddressSanitizer:', 'LeakSanitizer:', 'runtime error:', 'internal compiler error:'))
        if diagnostic:
            expected = 'quantum reference cannot escape' if name == 'null-address' else 'quantum pointer subtraction'
            assert result.returncode == 1 and '|c>:' in result.stderr and expected in result.stderr, row
        else:
            assert result.returncode == 0, row
    assert len(rows) == 120
    for name, expected in native['source_sha256'].items():
        assert digest(CANDIDATE / name) == expected
    status = 0
except BaseException as failure:
    error = repr(failure)
    traceback.print_exc()
(OUT / 'results.json').write_text(json.dumps({
    'status': 'passed-scoped-sanitized' if status == 0 else 'failed-scoped-sanitized',
    'exit_code': status, 'error': error, 'native_checks': sum(row['kind'] == 'native' for row in rows),
    'diagnostic_checks': sum(row['kind'] == 'diagnostic' for row in rows), 'rows': rows,
    'scope': 'Same finite pointer-difference matrix with an instrumented newly rebuilt plugin, source-identical reused instrumented core and instrumented generated executables. This is scoped verification, not a fresh full broad regression or complete C pointer/library support.',
}, indent=2) + '\n')
print('Sanitized pointer-difference matrix actual exit:', status, flush=True)
raise SystemExit(status)
