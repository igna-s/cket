"""Prepare a separate pointer-arithmetic candidate; leave running proofs unchanged."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import os

root = Path('/tmp/quantum-audit-isolated-20261017')
base = root / 'build/memory-return-maintained'
candidate = root / 'build/pointer-difference-prototype'
candidate.mkdir()
build = candidate / 'build'
build.mkdir()
frozen = json.loads((base / 'build/return-full-v3-sources-before.json').read_text())
for name, expected in frozen.items():
    source = base / name
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected, name
    target = candidate / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
shutil.copyfile(base / 'build/return-full-v3-sources-before.json', build / 'before-sources.json')
tools = {}
for source in (base / 'build').iterdir():
    if not source.is_file():
        continue
    if source.name in ('cket', 'cket_backend', 'cket_plugin.so', 'cket_runtime.o',
                        'libcket_quantum.a', 'gcc-version.txt', 'validate_memory_returns'):
        shutil.copyfile(source, build / source.name)
        tools[source.name] = hashlib.sha256(source.read_bytes()).hexdigest()
        (build / source.name).chmod(0o755)
(candidate / 'cket').chmod(0o755)
(candidate / '.deps').mkdir()
(candidate / '.deps/gcc').symlink_to(root / '.deps/gcc', target_is_directory=True)
source = build / 'difference-before.c'
source.write_text('''#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void) {
    quant uint16_t a[2] = {1, 2};
    uint16_t *p = memmove(a + 1, a, 2);
    ptrdiff_t distance = p - a;
    unsigned first = measure(a[0]), second = measure(a[1]);
    return distance != 1 || first != 1 || second != 1;
}
''')
cpu = build / 'difference-reference.c'
cpu.write_text('#include <stdint.h>\n#include <stdbool.h>\n#define quant\n#define measure(x) (x)\n' +
               source.read_text().replace('#include <quantum.h>\n', ''))
reference = build / 'difference-reference'
subprocess.run(['gcc-11', '-std=c11', '-O2', str(cpu), '-o', str(reference)], check=True)
subprocess.run([str(reference)], check=True)
result = subprocess.run([str(build / 'cket'), str(source), '--emit-ast', '-O2', '-fbuiltin',
                         '-o', str(build / 'difference-before.ast')], cwd=candidate,
                        env=dict(os.environ, CC='gcc-11'), capture_output=True, text=True)
(build / 'difference-before.log').write_text(result.stdout + result.stderr)
(build / 'before-provenance.json').write_text(json.dumps({
    'source_sha256': frozen, 'reused_tools_sha256': tools, 'reference_returncode': 0,
    'compile_returncode': result.returncode,
    'scope': 'Isolated clone of the frozen 136-input pointer candidate; existing native tools copied. Ordinary C subtraction reference executed. This records the pre-implementation gap, not a passing quantum test.'
}, indent=2) + '\n')
print('Baseline compile:', result.returncode, result.stderr[-2500:])
print('AST exists:', (build / 'difference-before.ast').exists())
