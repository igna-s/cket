#include <quantum.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
typedef uint32_t word;
int main(int argc,char **argv){
size_t n=argc>1?strtoul(argv[1],0,10):1;

quant bool a=superposition(0,1);quant uint8_t x=superposition(0,1);
quant bool c=superposition(0,1),d=superposition(0,1);
quant word y=superposition(0,1);y^=(word)(a?256:0);
if(a)phase(.11);if(y&1)phase(.23);if(x)phase(.41);if(c)phase(.17);if(d)phase(.29);
ownership_checkpoint("before");if(c){memcpy((void*)&y,(const void*)&x,n);}ownership_checkpoint("after");

measure(y);
measure(a);measure(x);measure(c);measure(d);return 0;}
