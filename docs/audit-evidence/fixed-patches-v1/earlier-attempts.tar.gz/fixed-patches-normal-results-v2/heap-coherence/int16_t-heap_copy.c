#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
typedef int16_t word;
int main(int argc,char **argv){
size_t n=argc>1?strtoul(argv[1],0,10):1;
quant word *p=calloc(1,sizeof(word));if(!p)return 2;quant word *q=calloc(1,sizeof(word));if(!q)return 2;
quant bool a=superposition(0,1),b=superposition(0,1),z=superposition(0,1);
quant uint8_t x=superposition(0,1);quant bool c=superposition(0,1),d=superposition(0,1);
if(a)phase(.11);if(b)phase(.23);if(z)phase(.31);if(x)phase(.41);if(c)phase(.17);if(d)phase(.29);
p[0]=(word)(((a?256:0)|b));q[0]=(word)z;ownership_checkpoint("before");if(c){memcpy((void*)p,(const void*)q,n);}ownership_checkpoint("after");
free((void*)p);free((void*)q);
ownership_checkpoint("freed");measure(a);measure(b);measure(z);measure(x);measure(c);measure(d);return 0;}
