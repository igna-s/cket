#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;
quant bool coin=superposition(0,1);quant uint8_t a[2]={0,5},b[2]={7,11};a[0]=coin?9:3;
unsigned got=measure(*(uint8_t*)memcpy((void*)b,(const void*)a,n));unsigned second=measure(b[1]),input=measure(a[0]);measure(a[1]);unsigned c=measure(coin);return got!=(n?input:7)||second!=(n>1?5:11)||input!=(c?9:3);}
