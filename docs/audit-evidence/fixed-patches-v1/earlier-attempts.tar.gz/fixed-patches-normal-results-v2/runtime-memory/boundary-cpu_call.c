#include <quantum.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):2;
quant bool coin=superposition(0,1);quant uint8_t a[2]={0,5},b[2]={7,11};a[0]=coin?9:3;
printf("%s",(char*)memcpy((void*)b,(const void*)a,n));measure(b[1]);measure(b[0]);measure(a[1]);measure(a[0]);measure(coin);return 0;}
