#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(int argc,char **argv){
unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;if(rounds>3)return 2;
quant bool coin=superposition(0,1);
quant uint16_t a[1]={0x5a07};quant uint8_t input=0;input=coin?9:3;
quant uint8_t saved=(uint8_t)a[0]^1;if(coin)phase(.31);ownership_checkpoint("start");
for(unsigned i=0;i<rounds;++i){
memcpy((unsigned char*)a+1,(const void*)&input,1);input++;
if(a[0]&1)phase(.07);ownership_checkpoint("step");}
if(saved==8)phase(.17);ownership_checkpoint("finish");
measure(a[0]);measure(input);measure(coin);return 0;}
