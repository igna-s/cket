from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

root = Path('/tmp/quantum-audit-isolated-20261017')
out = root / 'build/delivery-one-v1'
write = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if '--worker' not in sys.argv:
    out.mkdir()
    shutil.copy2(__file__, out / 'runner.py')
    with (out / 'worker.log').open('x') as log:
        child = subprocess.Popen([sys.executable, __file__, '--worker'], cwd=root,
                                 stdin=subprocess.DEVNULL, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'job.json', {'pid': child.pid, 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print('Delivery 01 build started:', child.pid)
    raise SystemExit(0)
r = {'status': 'running', 'commands': [], 'scope': 'Fresh Linux root build, usable block 01 execution/export and maintained example suite. Separate frozen153 division qualifications are not a fresh build of this delivery.'}
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_REAL_GCC='gcc-11')
try:
    names = json.loads((root / 'build/common-division-v3/build/sources.json').read_text())
    r['source_sha256'] = {name: digest(root / name) for name in sorted(set(names) | {'examples/quantum_buckets.c', 'scripts/run-block.sh'})}
    for name, args in [
        ('fresh-build', ['bash', 'scripts/build.sh']),
        ('block01', ['bash', 'scripts/run-block.sh', '01']),
        ('examples', ['build/test_examples']),
    ]:
        with (out / (name + '.log')).open('x') as log:
            p = subprocess.run(args, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        r['commands'].append({'name': name, 'argv': args, 'returncode': p.returncode, 'log': name + '.log', 'log_sha256': digest(out / (name + '.log'))})
        write(out / 'progress.json', r)
        assert p.returncode == 0, (name, (out / (name + '.log')).read_text()[-2500:])
    assert all(digest(root / name) == sha for name, sha in r['source_sha256'].items())
    r['resource_reports'] = {p.name: p.read_text() for p in sorted((root / 'build/blocks/01').glob('*.resources.txt'))}
    r.update(status='passed-delivery-one', exit_code=0)
except BaseException as error:
    traceback.print_exc()
    r.update(status='failed-delivery-one', exit_code=1, error=repr(error))
finally:
    write(out / 'exit.json', r)
raise SystemExit(r['exit_code'])
