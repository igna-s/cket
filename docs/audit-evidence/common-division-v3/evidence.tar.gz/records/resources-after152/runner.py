from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/common-division-v2'
out = project / 'build/division-generation-v2'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, r: p.write_text(json.dumps(r, indent=2) + '\n')
if '--worker' not in sys.argv:
    out.mkdir()
    shutil.copy2(Path(__file__), out / 'runner.py')
    with (out / 'worker.log').open('x') as log:
        p = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker'], cwd=project, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'job.json', {'pid': p.pid, 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print('Started source151 division resource baseline', p.pid)
    raise SystemExit(0)
r = {'status': 'running', 'commands': [], 'cases': [], 'scope': 'Actual frontend/typed backend resource checks before the new quotient kernel. Generation only, not state simulation.'}
env = dict(os.environ, CC='gcc-11')
def command(name, args):
    p = subprocess.run(list(map(str, args)), cwd=project, env=env, capture_output=True, text=True)
    log = out / (name + '.log')
    log.write_text(p.stdout + p.stderr)
    r['commands'].append({'name': name, 'argv': list(map(str, args)), 'returncode': p.returncode, 'log': log.name, 'log_sha256': digest(log)})
    write(out / 'progress.json', r)
    return p
try:
    frozen = json.loads((project / 'build/sources.json').read_text())
    assert len(frozen) == 152 and all(digest(project / n) == h for n, h in frozen.items())
    r['source_sha256'] = frozen
    r['core_sha256'] = {n: digest(project / 'build' / n) for n in ['cket', 'cket_backend', 'cket_plugin.so', 'cket_runtime.o', 'libcket_quantum.a']}
    profiles = [
        ('int32-full', 'int32_t', 'INT32_MIN', 'INT32_MAX', 'int32_t'),
        ('int32-byte', 'int32_t', 'INT32_MIN', 'INT32_MAX', 'uint8_t'),
        ('int32-bool', 'int32_t', 'INT32_MIN', 'INT32_MAX', 'bool'),
        ('uint32-full', 'uint32_t', 'UINT32_MAX', '(UINT32_MAX/2)', 'uint32_t'),
        ('int64-byte', 'int64_t', 'INT64_MIN', 'INT64_MAX', 'uint8_t'),
        ('uint64-byte', 'uint64_t', 'UINT64_MAX', '(UINT64_MAX/2)', 'uint8_t'),
        ('int64-bool', 'int64_t', 'INT64_MIN', 'INT64_MAX', 'bool'),
        ('uint64-bool', 'uint64_t', 'UINT64_MAX', '(UINT64_MAX/2)', 'bool'),
    ]
    for stem, c_type, first, second, result_type in profiles:
        source = out / (stem + '.c')
        source.write_text('#include <quantum.h>\n#include <stdint.h>\nint main(void){quant bool control=superposition(0,1);quant ' + c_type + ' x=control?(' + first + '):(' + second + ');quant ' + result_type + ' result=x/3;measure(result);measure(x);measure(control);return 0;}\n')
        for level in ['-O0', '-O2']:
            for builtin in ['-fbuiltin', '-fno-builtin']:
                label = stem + '-' + level[1:] + '-' + builtin[2:]
                ir = out / (label + '.json')
                p = command(label + '-compile', [project / 'build/cket', source, '--emit-ir', level, builtin, '-o', ir])
                assert p.returncode == 0, (label, p.stderr)
                for tables in [False, True]:
                    p = command(label + '-tables' + str(int(tables)), [project / 'build/cket_backend', '--resources', ir, *([] if tables else ['--no-tables'])])
                    diagnostic = p.stdout + p.stderr
                    assert p.returncode == 0, (label, p.returncode, diagnostic)
                    r['cases'].append({'profile': stem, 'optimization': level, 'builtins': builtin, 'stage': 'backend-resources', 'tables': tables, 'status': 'resource-limit' if p.returncode else 'generated', 'diagnostic': diagnostic[-1600:]})
    assert sum(row['name'].endswith('-compile') for row in r['commands']) == 32
    assert all(digest(project / n) == h for n, h in frozen.items())
    r.update(status='completed-division-generation', exit_code=0, frontend_compilations_attempted=32, resource_limits=sum(row['status']=='resource-limit' for row in r['cases']), generated=sum(row['status']=='generated' for row in r['cases']))
except BaseException as error:
    traceback.print_exc()
    r.update(status='failed-division-generation', exit_code=1, error=repr(error))
finally:
    write(out / 'exit.json', r)
raise SystemExit(r['exit_code'])
