#include <quantum.h>
#include <stdint.h>
int main(void){quant bool control=superposition(0,1);quant uint32_t x=control?(UINT32_MAX):((UINT32_MAX/2));quant uint32_t result=x/3;measure(result);measure(x);measure(control);return 0;}
