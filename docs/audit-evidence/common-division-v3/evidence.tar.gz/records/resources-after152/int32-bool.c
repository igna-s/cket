#include <quantum.h>
#include <stdint.h>
int main(void){quant bool control=superposition(0,1);quant int32_t x=control?(INT32_MIN):(INT32_MAX);quant bool result=x/3;measure(result);measure(x);measure(control);return 0;}
