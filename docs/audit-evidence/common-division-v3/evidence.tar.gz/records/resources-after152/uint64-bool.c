#include <quantum.h>
#include <stdint.h>
int main(void){quant bool control=superposition(0,1);quant uint64_t x=control?(UINT64_MAX):((UINT64_MAX/2));quant bool result=x/3;measure(result);measure(x);measure(control);return 0;}
