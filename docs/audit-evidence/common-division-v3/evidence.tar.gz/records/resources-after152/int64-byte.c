#include <quantum.h>
#include <stdint.h>
int main(void){quant bool control=superposition(0,1);quant int64_t x=control?(INT64_MIN):(INT64_MAX);quant uint8_t result=x/3;measure(result);measure(x);measure(control);return 0;}
