from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

root = Path('/tmp/quantum-audit-isolated-20261017')
parent = root / 'build/common-division-v2'
project = root / 'build/common-division-v3'
configuration = sys.argv[1]
assert configuration in ['normal', 'sanitized']
out = project / ('build/qualification-' + configuration + '-v1')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, r: p.write_text(json.dumps(r, indent=2) + '\n')
if '--worker' not in sys.argv:
    out.mkdir()
    shutil.copy2(Path(__file__), out / 'runner.py')
    with (out / 'worker.log').open('x') as log:
        p = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), configuration, '--worker'], cwd=project, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'job.json', {'pid': p.pid, 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print(configuration, 'started', p.pid)
    raise SystemExit(0)
r = {'status': 'running', 'configuration': configuration, 'commands': []}
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_REAL_GCC='gcc-11', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
def command(name, args):
    path = out / (name + '.log')
    with path.open('x') as log:
        p = subprocess.run(list(map(str, args)), cwd=project, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    r['commands'].append({'name': name, 'argv': list(map(str, args)), 'returncode': p.returncode, 'log': path.name, 'log_sha256': digest(path)})
    write(out / 'progress.json', r)
    assert p.returncode == 0, (name, p.returncode, path.read_text()[-3500:])
try:
    frozen = json.loads((project / 'build/sources.json').read_text())
    before = json.loads((parent / 'build/sources.json').read_text())
    assert all(digest(project / name) == sha for name, sha in frozen.items())
    assert all(frozen[name] == sha for name, sha in before.items() if name.startswith(('src/', 'include/')) or name == 'cket')
    r['source_sha256'] = frozen
    prior_directory = parent / ('build/qualification-' + configuration + '-v1')
    prior_record = prior_directory / ('exit.json' if (prior_directory / 'exit.json').exists() else 'progress.json')
    prior = json.loads(prior_record.read_text())
    fresh = next(row for row in prior['commands'] if row['name'] == 'fresh-build')
    assert fresh['returncode'] == 0 and digest(prior_directory / fresh['log']) == fresh['log_sha256']
    previous_stage = parent if configuration == 'normal' else parent / 'build/sanitized'
    stage = project if configuration == 'normal' else project / 'build/sanitized'
    (stage / 'build').mkdir(parents=True, exist_ok=True)
    if configuration == 'sanitized':
        shutil.copy2(project / 'cket', stage / 'cket')
        for name in ['include', 'examples', 'src', 'tests']:
            (stage / name).symlink_to(project / name, target_is_directory=True)
    core = prior['core_sha256']
    assert all(digest(previous_stage / 'build' / name) == sha for name, sha in core.items())
    copied = {}
    for path in (previous_stage / 'build').iterdir():
        if path.is_file() and (os.access(path, os.X_OK) or path.suffix in {'.o', '.so', '.a', '.txt'}):
            shutil.copy2(path, stage / 'build' / path.name)
            copied[path.name] = digest(stage / 'build' / path.name)
    r['tool_reuse'] = {'source_revision': str(parent), 'production_inputs_byte_identical': True, 'fresh_build_record_sha256': digest(prior_record), 'fresh_build_log_sha256': fresh['log_sha256'], 'copied_sha256': copied, 'scope': 'Fresh cores are from the preceding151 revision; the new division regression and archive counter changed. Rebuild the changed validator, and execute all listed suites on the corrected snapshot. No new core rebuild is claimed.'}
    r['core_sha256'] = core
    flags = ['-std=c11', '-Wall', '-Wextra', '-Werror', '-Isrc/engine']
    flags += ['-O2'] if configuration == 'normal' else ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
    command('rebuild-expression-validator', ['gcc-11', *flags, 'tests/validate_expressions.c', 'tests/validation.c', stage / 'build/libcket_quantum.a', '-lm', '-o', stage / 'build/validate_expressions'])
    if configuration == 'sanitized':
        env['CC'] = str(stage / 'build/gcc-wrapper')
    for name in ['validate_expressions', 'validate_shifts', 'validate_division', 'cket_tests', 'validate_inplace']:
        command(name, [stage / 'build' / name, *([stage] if name == 'cket_tests' else [])])
    assert all(digest(project / name) == sha for name, sha in frozen.items())
    assert all(digest(stage / 'build' / name) == sha for name, sha in core.items())
    r.update(status='passed-targeted-common-division', exit_code=0)
except BaseException as error:
    traceback.print_exc()
    r.update(status='failed-targeted-common-division', exit_code=1, error=repr(error))
finally:
    write(out / 'exit.json', r)
raise SystemExit(r['exit_code'])
