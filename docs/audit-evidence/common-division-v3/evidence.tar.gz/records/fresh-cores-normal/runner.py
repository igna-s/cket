from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

root = Path('/tmp/quantum-audit-isolated-20261017')
parent = root / 'build/common-remainder-v2'
project = root / 'build/common-division-v2'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, r: p.write_text(json.dumps(r, indent=2) + '\n')
configuration = sys.argv[1] if len(sys.argv) > 1 else 'prepare'
if configuration == 'prepare':
    project.mkdir()
    (project / 'build').mkdir()
    frozen = json.loads((parent / 'build/sources.json').read_text())
    assert len(frozen) == 148
    for name, sha in frozen.items():
        assert digest(parent / name) == sha
        target = project / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(parent / name, target)
    shutil.copy2(root / 'LICENSE', project / 'LICENSE')
    (project / '.deps').mkdir()
    (project / '.deps/gcc').symlink_to(root / '.deps/gcc', target_is_directory=True)
    shutil.copy2(root / 'build/select_views_v1.inc', project / 'src/engine/select_views.inc')
    path = project / 'src/engine/arithmetic.inc'
    text = path.read_text()
    text = text.replace('#include "small_remainder.inc"', '#include "small_remainder.inc"\n#include "select_views.inc"')
    old = '''        if (!ar_temp(p, width, out))
            return 0;
        out->sign = range.sign && range.lo < 0;
        if (select) {'''
    assert text.count(old) == 1
    text = text.replace(old, '        if (select) {')
    start = text.index('            for (unsigned j = 0; j < width; ++j) {', text.index('        if (select) {', text.index('static int ar_lower(')))
    end = text.index('        ar_value right;', start)
    text = text[:start] + '''            return ar_select_view(p, &yes, &no, condition, width, range.sign && range.lo < 0, out);
        }
        if (!ar_temp(p, width, out))
            return 0;
        out->sign = range.sign && range.lo < 0;
''' + text[end:]
    path.write_text(text)
    subprocess.run([str(root / '.deps/format-venv/bin/clang-format'), '-i', 'src/engine/arithmetic.inc', 'src/engine/select_views.inc'], cwd=project, check=True)
    frozen = {name: digest(project / name) for name in sorted([*frozen, 'src/engine/select_views.inc'])}
    assert len(frozen) == 149
    write(project / 'build/sources.json', frozen)
    print('Prepared149 frozen inputs: one production helper, unchanged frontend/runtime and tests.')
    raise SystemExit(0)
assert configuration in ['normal', 'sanitized']
out = project / ('build/qualification-' + configuration + '-v1')
if '--worker' not in sys.argv:
    out.mkdir()
    shutil.copy2(Path(__file__), out / 'runner.py')
    with (out / 'worker.log').open('x') as log:
        p = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), configuration, '--worker'], cwd=project, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'job.json', {'pid': p.pid, 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print(configuration, 'started', p.pid)
    raise SystemExit(0)
r = {'status': 'running', 'configuration': configuration, 'commands': []}
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_REAL_GCC='gcc-11', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
def command(name, args):
    path = out / (name + '.log')
    with path.open('x') as log:
        p = subprocess.run(list(map(str, args)), cwd=project, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    r['commands'].append({'name': name, 'returncode': p.returncode, 'log': path.name, 'log_sha256': digest(path)})
    write(out / 'progress.json', r)
    assert p.returncode == 0, (name, p.returncode, path.read_text()[-3000:])
try:
    frozen = json.loads((project / 'build/sources.json').read_text())
    assert all(digest(project / name) == sha for name, sha in frozen.items())
    r['source_sha256'] = frozen
    if configuration == 'normal':
        command('fresh-build', ['bash', project / 'scripts/build.sh'])
        stage = project
    else:
        text = (project / 'scripts/sanitize-all.sh').read_text().split('\nexport CKET_REAL_GCC="$real_cc"')[0] + '\n'
        path = out / 'build-only.sh'
        path.write_text(text.replace('cd "$(dirname "$0")/.."', 'cd ' + str(project)))
        command('fresh-build', ['bash', path])
        stage = project / 'build/sanitized'
        env['CC'] = str(stage / 'build/gcc-wrapper')
    r['core_sha256'] = {name: digest(stage / 'build' / name) for name in ['cket', 'cket_plugin.so', 'cket_runtime.o', 'libcket_quantum.a']}
    for name in ['validate_expressions', 'validate_shifts', 'validate_division', 'cket_tests', 'validate_inplace']:
        command(name, [stage / 'build' / name, *([stage] if name == 'cket_tests' else [])])
    assert all(digest(project / name) == sha for name, sha in frozen.items())
    r.update(status='passed-targeted-small-division', exit_code=0)
except BaseException as error:
    traceback.print_exc()
    r.update(status='failed-targeted-small-division', exit_code=1, error=repr(error))
finally:
    write(out / 'exit.json', r)
raise SystemExit(r['exit_code'])
