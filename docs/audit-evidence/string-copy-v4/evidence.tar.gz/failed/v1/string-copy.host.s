	.file	"string_copy.c"
	.text
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align 8
.LC0:
	.string	"{\"op\":\"qalloc\",\"id\":0,\"name\":\"letter\",\"width\":1,\"signed\":false,\"ancilla\":false}"
	.align 8
.LC1:
	.string	"{\"op\":\"qprepare\",\"id\":0,\"lower\":0,\"upper\":1}"
	.align 8
.LC2:
	.string	"{\"op\":\"qalloc\",\"id\":1,\"name\":\"source[0]\",\"width\":8,\"signed\":true,\"ancilla\":true}"
	.align 8
.LC3:
	.ascii	"{\"op\":\"qcompute\",\"id\":1,\"expr\":{\"op\":\"cast\",\"bi"
	.ascii	"ts\":8,\"signed\":true,\"args\":[{\"op\":\"select\",\"bits\""
	.ascii	":8,\"signed\":true,\"a"
	.string	"rgs\":[{\"op\":\"ne\",\"bits\":32,\"signed\":true,\"args\":[{\"op\":\"reg\",\"id\":0,\"bits\":1,\"signed\":false,\"active\":1},{\"op\":\"const\",\"value\":0,\"bits\":1,\"signed\":false}]},{\"op\":\"const\",\"value\":97,\"bits\":8,\"signed\":true},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]}]}}"
	.align 8
.LC4:
	.string	"{\"op\":\"qalloc\",\"id\":2,\"name\":\"source[1]\",\"width\":8,\"signed\":true,\"ancilla\":false}"
	.align 8
.LC5:
	.string	"{\"op\":\"qprepare\",\"id\":2,\"lower\":0,\"upper\":0}"
	.align 8
.LC6:
	.string	"{\"op\":\"qalloc\",\"id\":3,\"name\":\"copied[0]\",\"width\":8,\"signed\":true,\"ancilla\":false}"
	.align 8
.LC7:
	.string	"{\"op\":\"qprepare\",\"id\":3,\"lower\":88,\"upper\":88}"
	.align 8
.LC8:
	.string	"{\"op\":\"qalloc\",\"id\":4,\"name\":\"copied[1]\",\"width\":8,\"signed\":true,\"ancilla\":false}"
	.align 8
.LC9:
	.string	"{\"op\":\"qprepare\",\"id\":4,\"lower\":89,\"upper\":89}"
	.align 8
.LC10:
	.string	"{\"op\":\"qalloc\",\"id\":5,\"name\":\"copied[2]\",\"width\":8,\"signed\":true,\"ancilla\":false}"
	.align 8
.LC11:
	.string	"{\"op\":\"qprepare\",\"id\":5,\"lower\":90,\"upper\":90}"
	.align 8
.LC12:
	.string	"{\"op\":\"qalloc\",\"id\":6,\"name\":\"padded[0]\",\"width\":8,\"signed\":true,\"ancilla\":false}"
	.align 8
.LC13:
	.string	"{\"op\":\"qprepare\",\"id\":6,\"lower\":88,\"upper\":88}"
	.align 8
.LC14:
	.string	"{\"op\":\"qalloc\",\"id\":7,\"name\":\"padded[1]\",\"width\":8,\"signed\":true,\"ancilla\":false}"
	.align 8
.LC15:
	.string	"{\"op\":\"qprepare\",\"id\":7,\"lower\":89,\"upper\":89}"
	.align 8
.LC16:
	.string	"{\"op\":\"qalloc\",\"id\":8,\"name\":\"padded[2]\",\"width\":8,\"signed\":true,\"ancilla\":false}"
	.align 8
.LC17:
	.string	"{\"op\":\"qprepare\",\"id\":8,\"lower\":90,\"upper\":90}"
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC18:
	.string	"{\"op\":\"qretain\",\"id\":3}"
	.section	.rodata.str1.8
	.align 8
.LC19:
	.string	"{\"op\":\"qalloc\",\"id\":10,\"width\":8,\"signed\":true,\"ancilla\":true}"
	.align 8
.LC20:
	.ascii	"{\"op\":\"qcompute\",\"id\":10,\"expr\":{\"op\":\"cast\",\"b"
	.ascii	"its\":8,\"signed\":true,\"args\":[{\"op\":\"select\",\"bits\""
	.ascii	":8,\"signed\":true,\"args\":[{\"op\":\"lor\",\"bits\":1,\"si"
	.ascii	"gned\":false,\"args\":[{\"op\":\"eq\",\"bits\":1,\"signed\":"
	.ascii	"false,\"args\":[{\"op\":\"reg\",\"id\":1,\"bits\":8,\"signed"
	.ascii	"\":true,\"active\":8},{\"op\":\"const\",\"value\":0,\"bits\""
	.ascii	":8,\"signed\":true}]},{\"op\":\"eq\",\"bits\":1,\"signed\":f"
	.ascii	"alse,\"args\":[{\"op\":\"reg\",\"id\":2,\"bits\":8,\"signed\""
	.ascii	":true,\"active\":0,\"known\":0},{\"op\":\"const\",\"value\":"
	.ascii	"0,\"bits\":8,\"signed\":true}]}]},{\"op\":\"sequence\",\"bit"
	.ascii	"s\":8,\"signed\":true,\"args\":[{\"op\":\"reg"
	.string	"\",\"id\":3,\"bits\":8,\"signed\":true,\"active\":7,\"known\":88},{\"op\":\"reg\",\"id\":1,\"bits\":8,\"signed\":true,\"active\":8}]},{\"op\":\"div\",\"bits\":8,\"signed\":true,\"args\":[{\"op\":\"const\",\"value\":1,\"bits\":8,\"signed\":true},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]}]}]}}"
	.section	.rodata.str1.1
.LC21:
	.string	"{\"op\":\"qretain\",\"id\":4}"
	.section	.rodata.str1.8
	.align 8
.LC22:
	.string	"{\"op\":\"qalloc\",\"id\":11,\"width\":8,\"signed\":true,\"ancilla\":true}"
	.align 8
.LC23:
	.ascii	"{\"op\":\"qcompute\",\"id\":11,\"expr\":{\"op\":\"cast\",\"b"
	.ascii	"its\":8,\"signed\":true,\"args\":[{\"op\":\"sequence\",\"bit"
	.ascii	"s\":8,\"signed\":true,\"args\":[{\"op\":\"reg\",\"id\":4,\"b"
	.ascii	"its\":8,\"signed\":true,\"active\":7,\"known\":89},{\"op\":\""
	.ascii	"select\",\"bits\":8,\"signed\":true,\"args\":[{\"op\":\"ne\""
	.ascii	",\"bits\":1,\"signe"
	.string	"d\":false,\"args\":[{\"op\":\"reg\",\"id\":1,\"bits\":8,\"signed\":true,\"active\":8},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]},{\"op\":\"reg\",\"id\":2,\"bits\":8,\"signed\":true,\"active\":0,\"known\":0},{\"op\":\"reg\",\"id\":4,\"bits\":8,\"signed\":true,\"active\":7,\"known\":89}]}]}]}}"
	.section	.rodata.str1.1
.LC24:
	.string	"{\"op\":\"qretain\",\"id\":6}"
	.section	.rodata.str1.8
	.align 8
.LC25:
	.string	"{\"op\":\"qalloc\",\"id\":12,\"width\":8,\"signed\":true,\"ancilla\":true}"
	.align 8
.LC26:
	.ascii	"{\"op\":\"qcompute\",\"id\":12,\"expr\":{\"op\":\"cast\",\"b"
	.ascii	"its\":8,\"signed\":true,\"args\":[{\"op\":\"select\",\"bits\""
	.ascii	":8,\"signed\":true,\"args\":[{\"op\":\"lor\",\"bits\":1,\"si"
	.ascii	"gned\":false,\"args\":[{\"op\":\"eq\",\"bits\":1,\"signed\":"
	.ascii	"false,\"args\":[{\"op\":\"reg\",\"id\":1,\"bits\":8,\"signed"
	.ascii	"\":true,\"active\":8},{\"op\":\"const\",\"value\":0,\"bits\""
	.ascii	":8,\"signed\":true}]},{\"op\":\"eq\",\"bits\":1,\"signed\":f"
	.ascii	"alse,\"args\":[{\"op\":\"reg\",\"id\":2,\"bits\":8,\"signed\""
	.ascii	":true,\"active\":0,\"known\":0},{\"op\":\"const\",\"value\":"
	.ascii	"0,\"bits\":8,\"signed\":true}]}]},{\"op\":\"sequence\",\"bit"
	.ascii	"s\":8,\"signed\":true,\"args\":[{\"op\":\"reg"
	.string	"\",\"id\":6,\"bits\":8,\"signed\":true,\"active\":7,\"known\":88},{\"op\":\"reg\",\"id\":1,\"bits\":8,\"signed\":true,\"active\":8}]},{\"op\":\"div\",\"bits\":8,\"signed\":true,\"args\":[{\"op\":\"const\",\"value\":1,\"bits\":8,\"signed\":true},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]}]}]}}"
	.section	.rodata.str1.1
.LC27:
	.string	"{\"op\":\"qretain\",\"id\":7}"
	.section	.rodata.str1.8
	.align 8
.LC28:
	.string	"{\"op\":\"qalloc\",\"id\":13,\"width\":8,\"signed\":true,\"ancilla\":true}"
	.align 8
.LC29:
	.ascii	"{\"op\":\"qcompute\",\"id\":13,\"expr\":{\"op\":\"cast\",\"b"
	.ascii	"its\":8,\"signed\":true,\"args\":[{\"op\":\"sequence\",\"bit"
	.ascii	"s\":8,\"signed\":true,\"args\":[{\"op\":\"reg\",\"id\":7,\"b"
	.ascii	"its\":8,\"signed\":true,\"active\":7,\"known\":89},{\"op\":\""
	.ascii	"select\",\"bits\":8,\"signed\":true,\"args\":[{\"op\":\"ne"
	.string	"\",\"bits\":1,\"signed\":false,\"args\":[{\"op\":\"reg\",\"id\":1,\"bits\":8,\"signed\":true,\"active\":8},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]},{\"op\":\"reg\",\"id\":2,\"bits\":8,\"signed\":true,\"active\":0,\"known\":0},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]}]}]}}"
	.section	.rodata.str1.1
.LC30:
	.string	"{\"op\":\"qretain\",\"id\":8}"
	.section	.rodata.str1.8
	.align 8
.LC31:
	.string	"{\"op\":\"qalloc\",\"id\":14,\"width\":8,\"signed\":true,\"ancilla\":true}"
	.align 8
.LC32:
	.ascii	"{\"op\":\"qcompute\",\"id\":14,\"expr\":{\"op\":\"cast\",\"b"
	.ascii	"its\":8,\"signed\":true,\"args\":[{\"op\":\"sequence\",\"bit"
	.ascii	"s\":8,\"signed\":true,\"args\":[{\"op\":\"reg\",\"id\":8,\"b"
	.ascii	"its\":8,\"signed\":true,\"active\":7,\"known\":90},{\"op\":\""
	.ascii	"sequence\",\"bits\":8,\"signed\":true,\"args\":[{\"op\":\"la"
	.ascii	"nd\",\"bits\":1,\"signed\":false,\"args\":[{\"op\":\"ne\",\""
	.ascii	"bits\":1,\"signed\":false,\"args\":[{\"op\":\"reg\",\"id\":1"
	.ascii	",\"bits\":8,\"signed\":true,\"active\":8},{\"op\":\""
	.string	"const\",\"value\":0,\"bits\":8,\"signed\":true}]},{\"op\":\"ne\",\"bits\":1,\"signed\":false,\"args\":[{\"op\":\"reg\",\"id\":2,\"bits\":8,\"signed\":true,\"active\":0,\"known\":0},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]}]},{\"op\":\"const\",\"value\":0,\"bits\":8,\"signed\":true}]}]}]}}"
	.align 8
.LC33:
	.string	"{\"op\":\"qalloc\",\"id\":15,\"width\":1,\"signed\":false,\"ancilla\":true}"
	.align 8
.LC34:
	.string	"{\"op\":\"qcompute\",\"id\":15,\"expr\":{\"op\":\"cast\",\"bits\":1,\"signed\":false,\"args\":[{\"op\":\"eq\",\"bits\":32,\"signed\":true,\"args\":[{\"op\":\"reg\",\"id\":10,\"bits\":8,\"signed\":true,\"active\":8},{\"op\":\"const\",\"value\":97,\"bits\":8,\"signed\":true}]}]}}"
	.align 8
.LC35:
	.string	"{\"op\":\"qphase\",\"angle\":1.700000000000000122124532708767219446599483489990234375e-1,\"controls\":[{\"id\":15,\"value\":1}]}"
	.align 8
.LC36:
	.string	"{\"op\":\"quncompute\",\"id\":15,\"expr\":{\"op\":\"cast\",\"bits\":1,\"signed\":false,\"args\":[{\"op\":\"eq\",\"bits\":32,\"signed\":true,\"args\":[{\"op\":\"reg\",\"id\":10,\"bits\":8,\"signed\":true,\"active\":8},{\"op\":\"const\",\"value\":97,\"bits\":8,\"signed\":true}]}]}}"
	.section	.rodata.str1.1
.LC37:
	.string	"{\"op\":\"qrelease\",\"id\":15}"
.LC38:
	.string	"{\"op\":\"qhistory_end\",\"id\":3}"
.LC39:
	.string	"{\"op\":\"qhistory_end\",\"id\":4}"
.LC40:
	.string	"{\"op\":\"qhistory_end\",\"id\":6}"
.LC41:
	.string	"{\"op\":\"qhistory_end\",\"id\":7}"
.LC42:
	.string	"{\"op\":\"qhistory_end\",\"id\":8}"
.LC43:
	.string	"{\"op\":\"qrelease\",\"id\":2}"
	.section	.rodata.str1.8
	.align 8
.LC44:
	.string	"{\"op\":\"qalloc\",\"id\":9,\"name\":\"word\",\"width\":16,\"signed\":false,\"ancilla\":false}"
	.align 8
.LC45:
	.string	"{\"op\":\"qprepare\",\"id\":9,\"lower\":42435,\"upper\":42435}"
	.section	.text.startup,"ax",@progbits
	.p2align 4
	.globl	main
	.type	main, @function
main:
.LFB19:
	.cfi_startproc
	endbr64
	pushq	%rax
	.cfi_def_cfa_offset 16
	popq	%rax
	.cfi_def_cfa_offset 8
	leaq	.LC0(%rip), %rdi
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	call	__cket_apply@PLT
	leaq	.LC1(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC2(%rip), %rdi
	movb	$0, 5(%rsp)
	call	__cket_apply@PLT
	leaq	.LC3(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC4(%rip), %rdi
	movb	$0, 6(%rsp)
	call	__cket_apply@PLT
	leaq	.LC5(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC6(%rip), %rdi
	movb	$0, 7(%rsp)
	call	__cket_apply@PLT
	leaq	.LC7(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC8(%rip), %rdi
	movb	$0, 8(%rsp)
	call	__cket_apply@PLT
	leaq	.LC9(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC10(%rip), %rdi
	movb	$0, 9(%rsp)
	call	__cket_apply@PLT
	leaq	.LC11(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC12(%rip), %rdi
	movb	$0, 10(%rsp)
	call	__cket_apply@PLT
	leaq	.LC13(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC14(%rip), %rdi
	movb	$0, 11(%rsp)
	call	__cket_apply@PLT
	leaq	.LC15(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC16(%rip), %rdi
	movb	$0, 12(%rsp)
	call	__cket_apply@PLT
	leaq	.LC17(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC18(%rip), %rdi
	movb	$0, 13(%rsp)
	call	__cket_apply@PLT
	leaq	.LC19(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC20(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC21(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC22(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC23(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC24(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC25(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC26(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC27(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC28(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC29(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC30(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC31(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC32(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC33(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC34(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC35(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC36(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC37(%rip), %rdi
	call	__cket_apply@PLT
	movl	$10, %edi
	call	__cket_measure@PLT
	leaq	.LC38(%rip), %rdi
	call	__cket_apply@PLT
	movl	$11, %edi
	call	__cket_measure@PLT
	leaq	.LC39(%rip), %rdi
	call	__cket_apply@PLT
	movl	$5, %edi
	call	__cket_measure@PLT
	movl	$12, %edi
	call	__cket_measure@PLT
	leaq	.LC40(%rip), %rdi
	call	__cket_apply@PLT
	movl	$13, %edi
	call	__cket_measure@PLT
	leaq	.LC41(%rip), %rdi
	call	__cket_apply@PLT
	movl	$14, %edi
	call	__cket_measure@PLT
	leaq	.LC42(%rip), %rdi
	call	__cket_apply@PLT
	movl	$1, %edi
	call	__cket_measure@PLT
	movl	$2, %edi
	call	__cket_measure@PLT
	leaq	.LC43(%rip), %rdi
	call	__cket_apply@PLT
	xorl	%edi, %edi
	call	__cket_measure@PLT
	leaq	.LC44(%rip), %rdi
	call	__cket_apply@PLT
	leaq	.LC45(%rip), %rdi
	call	__cket_apply@PLT
	xorl	%eax, %eax
	movw	%ax, 14(%rsp)
	ud2
	.cfi_endproc
.LFE19:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 11.4.0-1ubuntu1~22.04.3) 11.4.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
