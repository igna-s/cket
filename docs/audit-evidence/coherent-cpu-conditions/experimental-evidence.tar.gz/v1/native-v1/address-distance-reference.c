#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#define phase(x) ((void)(x))
#define superposition(a,b) (b)
#include <string.h>
#include <stddef.h>
int main(int argc,char**argv){(void)argc;(void)argv;
quant bool b=superposition(0,1);quant uint8_t x=5;void*p=memset(&x,0,0);ptrdiff_t n=(uint8_t*)p+1-(uint8_t*)p;if(b)phase(.31);if(b){if(n==1){memset(p,17,1);phase(.17);}}unsigned a=measure(x),v=measure(b);return a!=(v?17:5)||n!=1;
}
