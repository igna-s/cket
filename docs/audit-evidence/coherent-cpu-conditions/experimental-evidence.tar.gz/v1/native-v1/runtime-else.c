#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(int argc,char**argv){(void)argc;(void)argv;
int k=argc>1?argv[1][0]-'0':0;quant bool b=superposition(0,1);quant uint8_t x=5;if(b){if(k){x=17;phase(.17);}else{x=23;phase(.09);}}unsigned a=measure(x),v=measure(b);return a!=(v?(k?17:23):5);
}
