#include "/tmp/quantum-audit-isolated-20261017/build/coherent-cpu-trace.inc"
#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(int argc,char**argv){(void)argc;(void)argv;
int k=argc>1?argv[1][0]-'0':0;quant bool b=0;quant uint8_t x=5;if(b){if(10/k>1){x^=16;phase(.17);}}unsigned a=measure(x),v=measure(b);return a!=5||v;
}
