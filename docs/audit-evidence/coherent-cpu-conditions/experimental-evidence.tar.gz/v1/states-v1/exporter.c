/* Export the real memory-return prefix and saved definitions without channels. */
#include "internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void fail(const char *message) {
    fprintf(stderr, "memory-return export: %s\n", message);
    exit(1);
}

typedef struct { unsigned id, width; char *expression; } saved_definition;
static saved_definition saved[256];
static unsigned nsaved;

static void invert_definition(qc_context *c, unsigned id) {
    qc_register *r = qc_lookup(c, id);
    if (!r || !r->alive || !r->definition)
        fail("missing saved definition during inversion");
    size_t capacity = strlen(r->definition) + 128;
    char *operation = malloc(capacity);
    if (!operation)
        fail("inverse allocation failed");
    snprintf(operation, capacity, "{\"op\":\"quncompute\",\"id\":%u,\"expr\":%s}", id, r->definition);
    if (!qc_apply(c, operation, NULL))
        fail(qc_error(c));
    snprintf(operation, capacity, "{\"op\":\"qrelease\",\"id\":%u}", id);
    if (!qc_apply(c, operation, NULL))
        fail(qc_error(c));
    free(operation);
}

static int restore_guard(qc_context *c, unsigned id) {
    qc_register *r = qc_lookup(c, id);
    if (r && r->alive)
        return 0;
    const saved_definition *definition = NULL;
    for (unsigned i = nsaved; i; )
        if (saved[--i].id == id) {
            definition = &saved[i];
            break;
        }
    if (!definition || definition->width != 1)
        fail("released control has no recorded Boolean definition");
    size_t capacity = strlen(definition->expression) + 128;
    char *operation = malloc(capacity);
    if (!operation)
        fail("control reconstruction allocation failed");
    snprintf(operation, capacity, "{\"op\":\"qalloc\",\"id\":%u,\"width\":1,\"signed\":false,\"ancilla\":true}", id);
    if (!qc_apply(c, operation, NULL))
        fail(qc_error(c));
    snprintf(operation, capacity, "{\"op\":\"qcompute\",\"id\":%u,\"expr\":%s}", id, definition->expression);
    if (!qc_apply(c, operation, NULL))
        fail(qc_error(c));
    free(operation);
    return 1;
}

static void snapshot(FILE *out, qc_context *c) {
    fprintf(out, "{\"qubits\":%u,\"registers\":[", c->physical);
    unsigned count = 0;
    for (size_t i = 0; i < c->nregisters; ++i) {
        qc_register *r = &c->registers[i];
        if (!r->alive)
            continue;
        fprintf(out, "%s{\"id\":%u,\"history\":%s,\"definition\":%s,\"wires\":[",
                count++ ? "," : "", r->id, r->history ? "true" : "false",
                r->definition ? "true" : "false");
        for (unsigned bit = 0; bit < r->width; ++bit)
            fprintf(out, "%s%u", bit ? "," : "", r->wires[bit]);
        fprintf(out, "]}");
    }
    fprintf(out, "],\"measure\":%llu,\"reset\":%llu}",
            (unsigned long long)c->measure, (unsigned long long)c->reset);
}

static void export(qc_context *c, const char *path) {
    FILE *out = fopen(path, "wx");
    if (!out || !qc_qasm(c, out) || fclose(out))
        fail("QASM creation failed");
}

int main(int argc, char **argv) {
    if (argc != 6)
        fail("usage: memory-return IR PREFIX-QASM INVERSE-QASM MAP-JSON");
    char *text = qc_read_file(argv[1]);
    cj_doc d = {0};
    qc_context *c = qc_create(0, 7);
    if (!text || !c || !cj_parse(&d, text) || !qc_verify_document(c, &d))
        fail(c ? qc_error(c) : "allocation");
    qc_allow_tables(c, atoi(argv[5]) != 0);
    int list = cj_get(&d, 0, "instructions");
    unsigned current = UINT32_MAX, naction = 0;
    struct { unsigned id; char *inverse; } actions[256];
    for (int token = list + 1; token < d.tokens[list].next; token = d.tokens[token].next) {
        int op = cj_get(&d, token, "op");
        uint64_t value;
        if (cj_equal(&d, op, "qmeasure")) {
            if (!cj_u64(&d, cj_get(&d, token, "id"), &value) || value > UINT32_MAX)
                fail("invalid observed ID");
            current = (unsigned)value;
            break;
        }
        if (cj_equal(&d, op, "qxor_inplace") || cj_equal(&d, op, "qcompute")) {
            uint64_t id;
            if (naction == sizeof actions / sizeof *actions ||
                !cj_u64(&d, cj_get(&d, token, "id"), &id) || id > UINT32_MAX)
                fail("write/definition recording budget or ID");
            actions[naction].id = (unsigned)id;
            actions[naction++].inverse = cj_equal(&d, op, "qxor_inplace") ? cj_copy(&d, token) : NULL;
        }
        if (cj_equal(&d, op, "qadd_inplace")) {
            uint64_t id, raw;
            int controls = cj_get(&d, token, "controls");
            if (naction == sizeof actions / sizeof *actions ||
                !cj_u64(&d, cj_get(&d, token, "id"), &id) || id > UINT32_MAX ||
                !cj_u64(&d, cj_get(&d, token, "value"), &raw) ||
                (raw != 1 && raw != UINT64_MAX) ||
                (controls >= 0 && d.tokens[controls].children))
                fail("unsupported argument addition in this finite exporter");
            char operation[160];
            snprintf(operation, sizeof operation, "{\"op\":\"qadd_inplace\",\"id\":%u,\"value\":%d}",
                     (unsigned)id, raw == 1 ? -1 : 1);
            actions[naction].id = (unsigned)id;
            size_t length = strlen(operation) + 1;
            actions[naction].inverse = malloc(length);
            if (!actions[naction].inverse)
                fail("addition inverse allocation failed");
            memcpy(actions[naction++].inverse, operation, length);
        }
        if (!qc_apply_token(c, &d, token, 0, 0, &value))
            fail(qc_error(c));
        if (cj_equal(&d, op, "qcompute")) {
            uint64_t id;
            if (!cj_u64(&d, cj_get(&d, token, "id"), &id) || id > UINT32_MAX ||
                nsaved == sizeof saved / sizeof *saved)
                fail("definition recording budget or ID");
            qc_register *r = qc_lookup(c, (unsigned)id);
            if (!r || !r->definition)
                fail("computed register has no saved definition");
            size_t length = strlen(r->definition) + 1;
            saved[nsaved].id = (unsigned)id;
            saved[nsaved].width = r->width;
            saved[nsaved].expression = malloc(length);
            if (!saved[nsaved].expression)
                fail("definition recording allocation failed");
            memcpy(saved[nsaved++].expression, r->definition, length);
        }
    }
    qc_register *result = qc_lookup(c, current);
    if (!result || !result->alive || c->measure || c->reset)
        fail("missing current value or implicit channel");
    FILE *out = fopen(argv[4], "wx");
    if (!out)
        fail("mapping creation failed");
    fprintf(out, "{\"current_id\":%u,\"before\":", current);
    snapshot(out, c);
    export(c, argv[2]);
    // Reverse semantic creation/write order: consumers of a known in-place
    // write must be inverted before that write's original basis is restored.
    while (naction) {
        --naction;
        qc_register *r = qc_lookup(c, actions[naction].id);
        if (!r || !r->alive) {
            free(actions[naction].inverse);
            continue;
        }
        if (actions[naction].inverse) {
            // A scope may have uncomputed a decision before this prefix ends.
            // Rebuild it from its actual saved definition while undoing its
            // writes, then clean that temporary again. No observation is used.
            cj_doc inverse = {0};
            if (!cj_parse(&inverse, actions[naction].inverse))
                fail("invalid inverse operation");
            int controls = cj_get(&inverse, 0, "controls");
            unsigned rebuilt[16], nrebuilt = 0;
            if (controls >= 0)
                for (int token = controls + 1; token < inverse.tokens[controls].next;
                     token = inverse.tokens[token].next) {
                    uint64_t id;
                    if (!cj_u64(&inverse, cj_get(&inverse, token, "id"), &id) || id > UINT32_MAX)
                        fail("invalid saved control");
                    if (restore_guard(c, (unsigned)id)) {
                        if (nrebuilt == sizeof rebuilt / sizeof *rebuilt)
                            fail("control reconstruction budget exceeded");
                        rebuilt[nrebuilt++] = (unsigned)id;
                    }
                }
            if (!qc_apply(c, actions[naction].inverse, NULL))
                fail(qc_error(c));
            while (nrebuilt)
                invert_definition(c, rebuilt[--nrebuilt]);
            cj_free(&inverse);
            free(actions[naction].inverse);
            continue;
        }
        if (!r->definition)
            continue;
        invert_definition(c, r->id);
    }
    for (size_t i = 0; i < c->nregisters; ++i)
        if (c->registers[i].alive && c->registers[i].definition)
            fail("unrecorded live saved definition remains");
    fprintf(out, ",\"after\":");
    snapshot(out, c);
    fprintf(out, "}\n");
    if (fclose(out) || c->measure || c->reset)
        fail("mapping flush or channel count");
    export(c, argv[3]);
    printf("Exported memory-return prefix/inverses: %u wires\n", c->physical);
    qc_destroy(c);
    for (unsigned i = 0; i < nsaved; ++i)
        free(saved[i].expression);
    cj_free(&d);
    free(text);
    return 0;
}
