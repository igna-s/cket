#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#define phase(x) ((void)(x))
#define superposition(a,b) (b)
#include <string.h>
#include <stddef.h>
int main(int argc,char**argv){(void)argc;(void)argv;
int k=argc>1?argv[1][0]-'0':0;quant bool b=superposition(0,1);quant bool x=0;if(b){if(k){x=1;phase(.17);}else{x=0;phase(.09);}}unsigned a=measure(x),v=measure(b);return a!=(v&&k);
}
