#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
int k=0;quant bool b=superposition(0,1);if(b){if(++k)phase(.17);}measure(b);return k;
}
