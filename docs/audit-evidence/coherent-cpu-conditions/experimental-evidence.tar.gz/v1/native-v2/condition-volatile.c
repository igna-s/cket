#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
volatile int k=1;quant bool b=superposition(0,1);if(b){if(k)phase(.17);}measure(b);return 0;
}
