#include <quantum.h>
#include <string.h>
#include <stddef.h>
int main(void){
int k=1,n=0;quant bool b=superposition(0,1);if(b){if(k)n++;}measure(b);return n;
}
