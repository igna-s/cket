#include <quantum.h>

static void mark(quant const bool a, quant const bool b) {
    if (a && b)
        phase(.31);
}

int main(void) {
    quant bool x = superposition(0, 1);
    mark(x, x);
    measure(x);
    return 0;
}
