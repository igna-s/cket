import shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
d=r/'output/sdk/readonly-borrows'
shutil.copy2(r/'build/readonly-borrows-source-v3/examples/readonly_borrows.c',d/'example_readonly.c')
(d/'run_readonly_demo.cmd').write_text('''@echo off
call "%~dp0compile_and_run.cmd" "%~dp0example_readonly.c"
exit /b %errorlevel%
''')
(r/'build/readonly-sdk-import.txt').write_text('\n'.join(p.relative_to(r).as_posix() for p in sorted(d.iterdir()) if p.is_file())+'\n')
