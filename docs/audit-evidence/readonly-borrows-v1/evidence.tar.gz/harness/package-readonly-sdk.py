from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
s=(r/'build/package-usable-sdk.py').read_text()
s=s.replace('build/return-reference-source-v1','build/readonly-borrows-source-v3')
s=s.replace('build/usable-sdk-stage-v1','build/readonly-sdk-stage-v1')
s=s.replace('build/usable-sdk-results-v1','build/readonly-sdk-results-v1')
s=s.replace("r/'output/sdk'","r/'output/sdk/readonly-borrows'")
s=s.replace('source_files=237','source_files=239').replace('237 entradas','239 entradas')
s=s.replace('sha256sum -c SHA256SUMS','sha256sum -c --status SHA256SUMS')
s=s.replace('if not exist "%~1" exit /b 2','if not exist "%~1" exit /b 2\nif not "%~2"=="" exit /b 2')
assert 'return-reference-source-v1' not in s
target=r/'build/package-readonly-sdk-complete.py'
target.write_text(s)
exec(compile(s,str(target),'exec'))
