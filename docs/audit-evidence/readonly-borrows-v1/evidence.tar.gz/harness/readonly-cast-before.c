#include <quantum.h>

static void mutate(quant const bool *values) {
    ((bool *)values)[0] = true;
}

int main(void) {
    quant bool values[2] = {false, true};
    mutate(values);
    unsigned first = measure(values[0]), last = measure(values[1]);
    return first != 1 || last != 1;
}
