import json,os,subprocess
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
o=r/'build/readonly-borrow-baseline-v1';o.mkdir()
rows=[]
for name,args in [('shared-readonly',[str(r/'build/readonly-alias-probe.c'),'--emit-ir','-o',str(o/'alias.json')]),('const-write',[str(r/'build/readonly-cast-before.c'),'--run','-O2','-o',str(o/'const-write')])]:
    command=[str(r/'build/qasm-cpu-source-v2/build/cket')]+args
    z=subprocess.run(command,env=dict(os.environ,CC='gcc-11'),capture_output=True,text=True)
    rows.append(dict(name=name,command=command,exit_code=z.returncode,stdout=z.stdout,stderr=z.stderr))
    print(name,z.returncode,z.stderr,flush=True)
(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert rows[0]['exit_code']==1 and 'mutable quantum parameters cannot alias' in rows[0]['stderr']
assert rows[1]['exit_code']==0
