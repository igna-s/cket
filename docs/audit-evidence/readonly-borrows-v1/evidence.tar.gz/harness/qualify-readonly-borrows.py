import hashlib,json,os,runpy,shutil,subprocess,time
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
changed=['src/quantum_frontend.inc','tests/validate_readonly_borrows.c','examples/readonly_borrows.c','scripts/build.sh','scripts/sanitize-all.sh','scripts/verify.sh','scripts/archive-audit.py']
for name in changed:
    p=r/name;p.write_text(fmt(p,p.read_text()))
source=runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
assert len(source)==239,len(source)
before=json.loads((r/'build/qasm-cpu-source-v2/source-hashes.json').read_text())
assert sorted(n for n in source if source[n]!=before.get(n))==sorted(changed)
root=r/'build/readonly-borrows-source-v3'
root.mkdir()
for name in source:
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/name,p)
(root/'.deps').symlink_to(r/'.deps',target_is_directory=True)
(root/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
shutil.copy2(r/'LICENSE',root/'LICENSE')
out=r/'build/readonly-borrows-results-v3';out.mkdir()
header=Path(subprocess.check_output(['gcc-11','-print-file-name=plugin'],text=True).strip())/'include'
if not (header/'gcc-plugin.h').exists():header=r/'.deps/gcc'/header.relative_to('/')
assert (header/'gcc-plugin.h').exists(),header
records=[]
def run(name,command,cwd,env):
    started=time.time()
    with (out/(name+'.log')).open('w') as log:z=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    records.append(dict(name=name,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-started,log=name+'.log'))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,z.returncode,(out/(name+'.log')).read_text()[-1800:],flush=True)
    if z.returncode:
        (out/'terminal.json').write_text(json.dumps(dict(status='failed',failed=name,exit_code=z.returncode))+'\n');raise SystemExit(z.returncode)
reuse={}
for mode,old in [('normal',r/'build/return-reference-source-v1'),('sanitized',r/'build/return-reference-sanitized-v1')]:
    target=root if mode=='normal' else r/'build/readonly-borrows-sanitized-v3'
    if mode!='normal':
        target.mkdir()
        for name in ('src','tests','include','examples'):(target/name).symlink_to(root/name,target_is_directory=True)
        shutil.copy2(root/'cket',target/'cket')
    (target/'build').mkdir()
    reuse[mode]={}
    for name in ('cket','cket_backend','libcket_quantum.a','cket_runtime.o','gcc-version.txt','validate_bindings','cket_tests'):
        if (old/'build'/name).exists():
            shutil.copy2(old/'build'/name,target/'build'/name)
            reuse[mode][name]=hashlib.sha256((target/'build'/name).read_bytes()).hexdigest()
    env=dict(os.environ,CC='gcc-11',CXX='g++-11')
    env.pop('CKET_SIMULATOR',None)
    san=[]
    if mode=='sanitized':
        shutil.copy2(old/'build/gcc-wrapper',target/'build/gcc-wrapper')
        env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        san=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
    plugin=['g++-11','-std=c++17','-O2','-Wall','-Wextra','-Wno-unused-parameter','-Wno-format-diag','-fPIC','-shared','-fno-rtti','-I'+str(header),'-I'+str(r/'.deps/gcc/usr/include'),'-I'+str(r/'.deps/gcc/usr/include/x86_64-linux-gnu')]+san+['src/cket_plugin.cpp','-o',str(target/'build/cket_plugin.so')]
    run(mode+'-plugin',plugin,root,env)
    flags=['gcc-11','-std=c11','-O2','-Wall','-Wextra','-Werror','-Isrc/engine']+san+(['-fno-pie','-no-pie'] if san else [])
    run(mode+'-validator-build',flags+['tests/validate_readonly_borrows.c','tests/validation.c',str(target/'build/libcket_quantum.a'),'-lm','-o',str(target/'build/validate_readonly_borrows')],root,env)
    run(mode+'-readonly-borrows',[str(target/'build/validate_readonly_borrows')],root,env)
    if (target/'build/validate_bindings').exists():run(mode+'-bindings',[str(target/'build/validate_bindings')],root,env)
    if (target/'build/cket_tests').exists():run(mode+'-core',[str(target/'build/cket_tests'),str(target)],root,env)
    binary=target/'build/readonly_borrows-example'
    run(mode+'-example',[str(target/'build/cket'),'examples/readonly_borrows.c','--run','-O2','-o',str(binary)],root,env)
assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in source.items())
(out/'terminal.json').write_text(json.dumps(dict(status='passed',source_files=239,checks_per_configuration=305,source_sha256=source,reused_artifact_sha256=reuse),indent=2)+'\n')
print('PASS readonly alias implementation, full states, independent gates/inverses and mutation boundaries',flush=True)
