import json,os,subprocess
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
root=r/'build/readonly-borrows-source-v3'
target=r/'build/readonly-borrows-sanitized-v3'
out=r/'build/readonly-sanitized-core-v1';out.mkdir()
env=dict(os.environ,CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
commands=[('build',['gcc-11','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie','-Isrc/engine','tests/test_native.c','tests/validation.c',str(target/'build/libcket_quantum.a'),'-lm','-o',str(target/'build/cket_tests')]),('core',[str(target/'build/cket_tests'),str(target)])]
records=[]
for name,command in commands:
    with (out/(name+'.log')).open('w') as log:z=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    records.append(dict(name=name,command=command,exit_code=z.returncode,log=name+'.log'))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,z.returncode,(out/(name+'.log')).read_text()[-1000:],flush=True)
    assert z.returncode==0
assert '395 passed, 0 failed' in (out/'core.log').read_text()
(out/'terminal.json').write_text(json.dumps(dict(status='passed',checks=395))+'\n')
