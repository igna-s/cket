import json,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
assert json.loads((r/'build/readonly-borrows-results-v3/terminal.json').read_text())['status']=='passed'
assert json.loads((r/'build/readonly-sanitized-core-v1/terminal.json').read_text())['status']=='passed'
p=r/'README.md';text=p.read_text();start=text.index('**Ready-to-run compiler package:**');end=text.index("The compiler uses GCC's real C frontend.",start)
text=text[:start]+r'''**Ready-to-run compiler package:** the [updated Windows/WSL SDK](output/sdk/readonly-borrows/README.es.md)
includes the corrected compiler and 37 rebuilt programs. Run
`output\sdk\readonly-borrows\run_sdk_demo.cmd`, or compile a C file with
`output\sdk\readonly-borrows\compile_and_run.cmd program.c`. The
[read-only borrow correction](docs/c11-readonly-borrows.md) allows shared read-only aliases and
rejects writes through casts. Its example checks phase interference. The
[delivery guide](docs/entrega-utilizable-2026-10-26.es.md) lists working examples and open limits.
This remains an experimental candidate with incomplete everyday-C integration.

'''+text[end:];p.write_text(text)
p=r/'docs/entrega-utilizable-2026-10-26.es.md';text=p.read_text()
start=text.index('```cmd');end=text.index('## Qué podés escribir',start)
text=text[:start]+r'''```cmd
output\sdk\readonly-borrows\run_sdk_demo.cmd
output\sdk\readonly-borrows\run_readonly_demo.cmd
output\sdk\readonly-borrows\compile_and_run.cmd output\sdk\example_heap.c
```

El primer comando ejecuta 37 programas reconstruidos. El segundo compila un ejemplo con alias
de lectura y comprueba interferencia: `scalar=1 vector=0,1`. El tercero compila un programa de
heap. Podés editar una copia y pasar su ruta al mismo lanzador. La
[guía del SDK actualizado](../output/sdk/readonly-borrows/README.es.md) explica los requisitos y
la CLI en Linux. Usa WSL `Ubuntu2204` sin montar unidades Windows. El SDK anterior se conserva
en el directorio padre con su propia identidad.

'''+text[end:]
start=text.index('## Qué se comprobó');end=text.index('## Qué falta',start)
text=text[:start]+'''## Qué se comprobó en esta entrega

El SDK actualizado conserva las 239 entradas exactas del compilador y pruebas, ejecutables,
headers y fuentes. Los seis runners reconstruyen los 37 programas y sus exportaciones estáticas
admitidas. La suite de ejemplos pasa 1509 comprobaciones normales en cinco niveles de GCC.
Los lanzadores Windows ejecutan el paquete y compilan el ejemplo nuevo de alias e interferencia.

La [corrección de préstamos](c11-readonly-borrows.md) permite alias de lectura y rechaza
escrituras mediante casts. Su [cápsula](audit-evidence/readonly-borrows-v1/README.es.md) registra
305 comprobaciones en normal y ASan/UBSan: compilaciones, ejecuciones, estados completos contra
fórmulas C, evolución independiente de puertas, inversas y diagnósticos. También pasan bindings
(519) y núcleo (395) en ambas configuraciones. Estos programas finitos no prueban todos los
alias, vidas o tipos.

Las campañas anteriores de 237 entradas conservan sus fuentes: la
[referencia de retornos](audit-evidence/memory-return-reference-v1/README.es.md), la
[integración C prioritaria](audit-evidence/c-priority-integration-v1/README.es.md) y la
[continuación de locale](audit-evidence/c-locale-sanitized-v1/README.es.md). Entre esas dos últimas
pasaron 17 validadores normales y doce completos instrumentados; quedaron cinco pendientes.
Sus cifras de fuzzer, QuEST y memoria no recalifican automáticamente este plugin nuevo.
La ejecución completa de `scripts/verify.sh` sigue pendiente.

'''+text[end:];p.write_text(text)
p=r/'docs/estado-general-del-proyecto.es.md';text=p.read_text();start=text.index('**Compilador listo para usar:**');end=text.index('**Bloque de desarrollo posterior',start)
text=text[:start]+r'''**Compilador actualizado listo para usar:** el
[SDK nuevo](../output/sdk/readonly-borrows/README.es.md) incluye el plugin corregido y 37
programas reconstruidos. Ejecutá `output\sdk\readonly-borrows\run_readonly_demo.cmd` para
compilar el ejemplo de fase e interferencia con alias de lectura. La
[guía de entrega](entrega-utilizable-2026-10-26.es.md) resume comandos y pendientes.

**Préstamos de lectura compartidos:** se admite pasar el mismo dueño a varios parámetros
`const`; se siguen rechazando solapamientos mutables. Se corrige además una escritura por cast
que escapaba del ámbito de lectura. La [nota](c11-readonly-borrows.md) y la
[evidencia de 239 entradas](audit-evidence/readonly-borrows-v1/README.es.md) registran 305
comprobaciones dirigidas, bindings (519) y núcleo (395) normales e instrumentados, y 1509 de
ejemplos normales. Los recuentos de las campañas anteriores que siguen abajo conservan sus
propias fuentes; no recalifican automáticamente este plugin. La integración completa sigue abierta.

'''+text[end:]
text=text.replace('**Integración C prioritaria comprobada:**','**Campaña anterior de 237 entradas:**');p.write_text(text)
p=r/'docs/perfil-c-cotidiano.es.md';text=p.read_text();anchor='## Orden de trabajo';assert text.count(anchor)==1
text=text.replace(anchor,'''La [corrección de préstamos de lectura](c11-readonly-borrows.md) admite alias `const` en
parámetros escalares y de buffers fijos. Rechaza las escrituras por casts antes de perder el
ámbito del préstamo. Su evidencia de 239 entradas distingue los casos comprobados de las
combinaciones generales de alias y vidas que siguen pendientes.

'''+anchor);p.write_text(text)
p=r/'docs/paper/README.md';text=p.read_text();anchor='Estas campañas califican perfiles finitos';assert text.count(anchor)==1
text=text.replace(anchor,'''La [nota de préstamos de lectura](../c11-readonly-borrows.md) y su
[cápsula de 239 entradas](../audit-evidence/readonly-borrows-v1/README.es.md) corrigen otro
rechazo de composición y una escritura mediante cast. El SDK nuevo incluye ese plugin;
las campañas de 237 entradas mantienen su alcance anterior. La nota distingue las referencias
al mismo dueño de una copia de estado y califica fases, auxiliares e inversas en programas finitos.

'''+anchor);p.write_text(text)
p=r/'output/sdk/README.es.md';text=p.read_text();text='''**Paquete actualizado:** usá el [SDK con préstamos de lectura](readonly-borrows/README.es.md).
Incluye el plugin corregido, 37 programas reconstruidos y el ejemplo nuevo de interferencia.
Este directorio conserva el paquete anterior de 237 entradas con sus hashes y límites originales.

'''+text;p.write_text(text)
audit_path=r/'output/sdk/readonly-borrows/sdk-audit.json';audit=json.loads(audit_path.read_text())
demo=(r/'build/readonly-sdk-windows-demo.log').read_text()
example=(r/'build/readonly-sdk-windows-example.log').read_text()
assert sum(line.startswith('build/blocks/') for line in demo.splitlines())==37
assert 'scalar=1 vector=0,1' in example
audit['windows_launchers']=[dict(command='output\\sdk\\readonly-borrows\\run_sdk_demo.cmd',exit_code=0,stdout=demo),dict(command='output\\sdk\\readonly-borrows\\run_readonly_demo.cmd',exit_code=0,stdout=example)]
audit['scope']='Rebuilt compiler, 37 native programs, 1509 normal example checks and two verified Windows launcher workflows. Targeted quantum states/inverses are separately archived; complete integration, everyday C, stable release and QPU remain unqualified.'
audit_path.write_text(json.dumps(audit,indent=2)+'\n')
print('Current delivery guide, status and SDK metadata updated')
