import ast,hashlib,io,json,runpy,subprocess,tarfile
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/readonly-borrows-source-v3'
out=r/'build/readonly-borrows-results-v3'
core=r/'build/readonly-sanitized-core-v1'
sdk=r/'output/sdk/readonly-borrows'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((project/'source-hashes.json').read_text())
assert len(source)==239
assert runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()==source
result=json.loads((out/'terminal.json').read_text())
assert result['status']=='passed' and result['checks_per_configuration']==305
assert all(x['exit_code']==0 for x in json.loads((out/'commands.json').read_text()))
for mode in ('normal','sanitized'):
    assert '305 readonly borrow checks passed;' in (out/(mode+'-readonly-borrows.log')).read_text()
    assert '519 CPU binding checks passed;' in (out/(mode+'-bindings.log')).read_text()
    assert 'scalar=1 vector=0,1' in (out/(mode+'-example.log')).read_text()
assert '395 passed, 0 failed' in (out/'normal-core.log').read_text()
assert json.loads((core/'terminal.json').read_text())==dict(status='passed',checks=395)
assert all(x['exit_code']==0 for x in json.loads((core/'commands.json').read_text()))
before=r/'build/qasm-cpu-source-v2'
old=json.loads((before/'source-hashes.json').read_text())
changed=sorted(n for n in source if source[n]!=old.get(n))
assert changed==sorted(['src/quantum_frontend.inc','tests/validate_readonly_borrows.c','examples/readonly_borrows.c','scripts/build.sh','scripts/sanitize-all.sh','scripts/verify.sh','scripts/archive-audit.py'])
assert all(source[n]==old[n] for n in source if n.startswith('src/engine/') or n in ('src/cket.c','src/cket_backend.c','src/cket_runtime.c'))
reuse={}
for mode,target,previous in [('normal',project,before),('sanitized',r/'build/readonly-borrows-sanitized-v3',r/'build/return-reference-sanitized-v1')]:
    reuse[mode]={}
    for name in ('cket','cket_backend','libcket_quantum.a','cket_runtime.o','gcc-version.txt'):
        assert sha(target/'build'/name)==sha(previous/'build'/name)
        reuse[mode][name]=sha(target/'build'/name)
    assert sha(target/'build/cket_plugin.so')!=sha(previous/'build/cket_plugin.so')
    reuse[mode]['rebuilt_plugin_sha256']=sha(target/'build/cket_plugin.so')
    reuse[mode]['validator_sha256']=sha(target/'build/validate_readonly_borrows')
    if mode=='sanitized':
        symbols=subprocess.check_output(['nm','-u',str(target/'build/cket_plugin.so')],text=True)
        assert '__asan_init' in symbols and '__ubsan_handle' in symbols
        (out/'sanitized-plugin-symbols.txt').write_text(symbols)
audit=json.loads((sdk/'sdk-audit.json').read_text())
assert audit['source_sha256']==source and audit['source_files']==239
assert audit['prebuilt_programs']==37 and audit['example_checks']==1509
assert all(x['exit_code']==0 for x in audit['commands'])
assert sha(sdk/'cket-sdk-linux-x86_64.tar.gz')==audit['package_sha256']
assert sha(project/'build/cket_plugin.so')==audit['package_files_sha256']['build/cket_plugin.so']
assert sha(sdk/'example_readonly.c')==source['examples/readonly_borrows.c']
assert len(audit['windows_launchers'])==2 and all(x['exit_code']==0 for x in audit['windows_launchers'])
heap=(r/'build/readonly-sdk-windows-heap.log').read_text()
assert 'rounds=3 output=12 sum=30' in heap
audit['windows_launchers'].append(dict(command='output\\sdk\\readonly-borrows\\compile_and_run.cmd output\\sdk\\example_heap.c',exit_code=0,stdout=heap))
audit['scope']=audit['scope'].replace('two verified Windows','three verified Windows')
(sdk/'sdk-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
baseline=json.loads((r/'build/readonly-borrow-baseline-v1/results.json').read_text())
assert [x['exit_code'] for x in baseline]==[1,0]
for name in ('scripts/build.sh','scripts/sanitize-all.sh','scripts/verify.sh'):
    subprocess.check_call(['bash','-n',name],cwd=project)
ast.parse((project/'scripts/archive-audit.py').read_text())
docs=['README.md','docs/entrega-utilizable-2026-10-26.es.md','docs/estado-general-del-proyecto.es.md','docs/perfil-c-cotidiano.es.md','docs/paper/README.md','docs/c11-readonly-borrows.md','docs/audit-evidence/readonly-borrows-v1/README.es.md','output/sdk/README.es.md','output/sdk/readonly-borrows/README.es.md','output/sdk/readonly-borrows/sdk-audit.json']
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for name in docs:
    p=r/name;p.write_text(fmt(p,p.read_text()))
dest=r/'docs/audit-evidence/readonly-borrows-v1'
assert not (dest/'summary.json').exists()
def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.c','.py'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())
with tarfile.open(dest/'evidence.tar.gz','w:gz') as tar:
    for name in source:tar.add(project/name,arcname='sources/'+name)
    raw(tar,'source-identities.json',dict(qualified=source,previous=old))
    raw(tar,'production-artifact-reuse.json',reuse)
    tree(tar,out,'results/final')
    tree(tar,core,'results/sanitized-core')
    tree(tar,r/'build/readonly-borrow-baseline-v1','baseline')
    tree(tar,r/'build/readonly-sdk-results-v1','sdk-results')
    for version in ('v1','v2'):
        previous=r/('build/readonly-borrows-source-'+version)
        identities=json.loads((previous/'source-hashes.json').read_text())
        raw(tar,'previous/'+version+'/source-hashes.json',identities)
        for name in identities:
            if identities[name]!=source.get(name):tar.add(previous/name,arcname='previous/'+version+'/'+name)
        tree(tar,r/('build/readonly-borrows-results-'+version),'results/'+version)
    for name in ('qualify-readonly-borrows.py','qualify-readonly-sanitized-core.py','reproduce-readonly-before.py','readonly-alias-probe.c','readonly-cast-before.c','package-readonly-sdk.py','package-readonly-sdk-complete.py','prepare-readonly-sdk-launchers.py','finish-readonly-docs.py','publish-readonly-borrows.py'):
        tar.add(r/'build'/name,arcname='harness/'+name)
    for name in ('readonly-sdk-windows-demo.log','readonly-sdk-windows-example.log','readonly-sdk-windows-heap.log'):
        tar.add(r/'build'/name,arcname='sdk-windows/'+name)
    for p in sdk.iterdir():
        if p.is_file() and p.suffix!='.gz':tar.add(p,arcname='sdk/'+p.name)
summary=dict(status='passed-readonly-alias-and-cast-write-correction-with-open-general-integration',date='2026-10-26',base_commit='66485f5',version='1.0.0-rc.3',source_files=239,source_sha256=source,changed_inputs=changed,
    production_changed=['src/quantum_frontend.inc'],engine_runtime_driver_reused=True,checks_per_configuration=dict(readonly_borrows=305,bindings=519,core=395),
    readonly_scopes=dict(ir_compilations=30,native_executions=30,c_states=60,independent_gate_states=60,complete_gate_inverses=60,mutation_ownership_rejections=65,profiles=6,gcc_levels=5,synthesis_policies=2,domain='two Boolean inputs; scalar/fixed-buffer procedures and nested calls'),
    sdk=dict(package_sha256=audit['package_sha256'],source_files=239,prebuilt_rebuilt_programs=37,normal_example_checks=1509,windows_workflows=3),
    scope='Finite readonly alias/cast correction, bindings/core regression and rebuilt native SDK. General alias/lifetime/ABI, full verify.sh, new full QuEST qualification and everyday-C completion remain open. Prior campaigns retain original sources. Cybersecurity remains classical.',artifact_sha256={'evidence.tar.gz':sha(dest/'evidence.tar.gz')})
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=set(source)|set(docs)|{p.relative_to(r).as_posix() for p in sdk.iterdir() if p.is_file()}|{'docs/audit-evidence/readonly-borrows-v1/summary.json','docs/audit-evidence/readonly-borrows-v1/evidence.tar.gz'}
expected=json.loads((r/'build/locale-final-git-expected.json').read_text())
expected.update({n:sha(r/n) for n in names})
(r/'build/readonly-git-expected.json').write_text(json.dumps(expected,indent=2)+'\n')
imports=sorted((names-set(source))|set(changed)|{'build/readonly-git-expected.json'})
(r/'build/readonly-final-import.txt').write_text('\n'.join(imports)+'\n')
print('Ready to publish:',len(expected),'exact files; corrected frontend, native SDK and normal/sanitized evidence')
