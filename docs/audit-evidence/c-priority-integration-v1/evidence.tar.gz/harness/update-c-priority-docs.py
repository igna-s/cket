import json
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
assert json.loads((r/'build/sanitized-priority-tail-v1/terminal.json').read_text())['status']=='time-budget-stopped'
assert json.loads((r/'build/qasm-cpu-final-results-v2/terminal.json').read_text())['status']=='passed'
p=r/'docs/estado-general-del-proyecto.es.md'
text=p.read_text()
start=text.index('**Historial y efectos seleccionados corregidos:**')
end=text.index('**Nueva demo lista para ejecutar:**',start)
text=text[:start]+'''**Historial y efectos seleccionados corregidos:** la referencia antigua suponía identificadores
separados para el valor viejo y el destino actual. Se actualizan los canales, estados completos y
fases sin depender de esa suposición. La suite completa pasa 2332 comprobaciones tanto en normal
como con ASan/UBSan en la [nueva campaña C](audit-evidence/c-priority-integration-v1/README.es.md).
La pasada histórica de 355 casos instrumentados de la
[nota técnica](paper/lazy_values_note.es.md) conserva su alcance original. Al llegar a los casos
antes ocultos se corrigieron operandos anteriores que no se transportaban y vidas de inversas en
brazos inactivos. El CI general sigue pendiente.

**Integración C prioritaria comprobada:** pasan los 17 validadores C normales listados en la
nueva cápsula y diez completos con ASan/UBSan. La pasada instrumentada de capturas de bytes se
interrumpe por tiempo; los seis validadores que venían después quedan pendientes. En normal
también pasan 145 compilaciones del fuzzer,
24 circuitos de crecimiento, cinco comparaciones clásicas y 70 exportaciones verificadas con
QuEST: 64 estados y seis canales. Se corrige una expectativa antigua del fixture QASM para ramas
CPU sin parámetros numéricos. El SDK conserva exactamente los mismos binarios del compilador.
Esta campaña no sustituye toda la composición de `scripts/verify.sh` ni cierra la 1.0 estable.

'''+text[end:]
p.write_text(text)
p=r/'docs/entrega-utilizable-2026-10-26.es.md'
text=p.read_text()
anchor='## Qué falta'
assert text.count(anchor)==1
text=text.replace(anchor,'''La [campaña C posterior](audit-evidence/c-priority-integration-v1/README.es.md) pasa sus 17
validadores normales y diez completos con ASan/UBSan, incluido el historial completo de 2332
casos. La pasada instrumentada de capturas de bytes queda interrumpida por tiempo; los seis
validadores que venían después permanecen pendientes.
Además pasan en normal 145 compilaciones del fuzzer, 24 circuitos de crecimiento y las 70
exportaciones verificadas por QuEST: 64 estados y seis canales. La corrección posterior afecta
solo al test QASM; el paquete conserva los mismos binarios del compilador y su snapshot original.
La campaña no es una ejecución completa de `scripts/verify.sh`.

'''+anchor)
p.write_text(text)
p=r/'README.md'
text=p.read_text()
old='''history references and pending old operands across conditional updates: the normal history suite
passes 2332 checks, and its changed scopes pass 355 focused ASan/UBSan checks. The full verification
gate remains open.'''
new='''history references and pending old operands across conditional updates. The subsequent
[priority C campaign](docs/audit-evidence/c-priority-integration-v1/README.es.md) passes all 2332
history checks in normal and ASan/UBSan configurations. Its 17 normal C validators pass; ten
complete their sanitized run, while seven remain incomplete or pending in that configuration.
Its normal export pass independently validates 64 states and six channels with QuEST. The full
verification gate remains open.'''
assert old in text
p.write_text(text.replace(old,new))
print('Current status, usable delivery and README updated with qualified scopes')
