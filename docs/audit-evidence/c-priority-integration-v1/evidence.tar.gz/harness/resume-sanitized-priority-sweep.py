import json, runpy
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
old=r/'build/sanitized-priority-sweep-v1'
records=json.loads((old/'commands.json').read_text())
assert len(records)==6 and all(x['exit_code']==0 for x in records)
assert records[-1]['name']=='validate_patches'
(old/'terminal.json').write_text(json.dumps(dict(status='infrastructure-path-normalization-failure',completed_commands=6,
    reason='gcc -MM spells local headers as tests/../src/engine/*.h; the manifest uses canonical relative paths. No remaining validator was executed by the interrupted harness.',
    continuation='sanitized-priority-tail-v1'),indent=2)+'\n')
script=(r/'build/run-sanitized-priority-sweep.py').read_text()
script=script.replace('import hashlib, json, os, shutil, subprocess, time','import hashlib, json, os, posixpath, shutil, subprocess, time')
script=script.replace("out = r / 'build/sanitized-priority-sweep-v1'","out = r / 'build/sanitized-priority-tail-v1'")
start=script.index("names = [")
end=script.index('\nrecords, artifacts',start)
script=script[:start]+"names = ['validate_runtime_versions','validate_runtime_memory','validate_bindings','validate_phase','validate_byte_snapshots','validate_controlled_operands','validate_division','validate_ctype','validate_profiles','validate_numeric_locale','validate_library']"+script[end:]
script=script.replace('deadline = started + 24*60','deadline = started + 12*60').replace('maximum_elapsed_seconds=24*60','maximum_elapsed_seconds=12*60')
script=script.replace("dependencies = sorted({p for p in deps if not p.endswith(':')})","dependencies = sorted({posixpath.normpath(p) for p in deps if not p.endswith(':')})")
assert 'posixpath.normpath' in script
target=r/'build/run-sanitized-priority-tail.py'
target.write_text(script)
runpy.run_path(str(target),run_name='__main__')
