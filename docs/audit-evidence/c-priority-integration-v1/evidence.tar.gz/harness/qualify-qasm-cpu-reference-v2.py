from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
script=(r/'build/qualify-qasm-cpu-reference-final.py').read_text()
script=script.replace("build/qasm-cpu-source-v1","build/qasm-cpu-source-v2")
script=script.replace("build/qasm-cpu-final-results-v1","build/qasm-cpu-final-results-v2")
script=script.replace("'gcc-version.txt','validation-deps/libQuEST.a'","'gcc-version.txt','qasm_samples','validation-deps/libQuEST.a'")
assert "'qasm_samples'" in script
target=r/'build/qualify-qasm-cpu-reference-complete.py'
target.write_text(script)
exec(compile(script,str(target),'exec'))
