import hashlib, json, os, shutil, subprocess, time
from pathlib import Path
r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/return-reference-source-v1'
base = r / 'build/single-fill-source-v2'
out = r / 'build/normal-integration-sweep-v1'
out.mkdir()
reused = {}
for p in (base / 'build').iterdir():
    if p.is_file() and p.suffix not in ('.log', '.csv') and not (project / 'build' / p.name).exists():
        shutil.copy2(p, project / 'build' / p.name)
        reused[p.name] = hashlib.sha256(p.read_bytes()).hexdigest()
archive = base / 'build/validation-deps/quest-3.7.0.tar.gz'
if archive.exists():
    (project / 'build/validation-deps').mkdir(exist_ok=True)
    shutil.copy2(archive, project / 'build/validation-deps' / archive.name)
env = dict(os.environ, CC='gcc-11', CXX='g++-11')
env.pop('CKET_SIMULATOR', None)
names = ['validate_controlled_operands', 'validate_phase', 'validate_byte_snapshots', 'validate_division',
         'validate_bindings', 'validate_history', 'validate_heap', 'validate_heap_identities',
         'validate_inactive_borrows', 'validate_swap_rebind', 'validate_patches', 'validate_runtime_versions',
         'validate_runtime_memory', 'validate_ctype', 'validate_profiles', 'validate_numeric_locale', 'validate_library']
commands = [(name, [str(project / 'build' / name)]) for name in names]
commands += [('classical', ['bash', 'scripts/test-c11-classical.sh']),
             ('validation-build', ['bash', 'scripts/build-validation.sh']),
             ('frontend', ['build/fuzz_frontend', '--seed', '20261012', '--cases', '24']),
             ('growth', ['build/benchmark_synthesis']), ('qasm', ['build/validate_qasm']),
             ('locale-sanitizer', ['bash', 'scripts/test-locale-sanitizer.sh'])]
records = []
(out / 'process.json').write_text(json.dumps(dict(pid=os.getpid(), started_unix=time.time(),
    source_snapshot=str(project), reused_artifact_sha256=reused,
    scope='Remaining maintained normal C validators, classical integration, frontend/growth/QuEST and locale guard. Separate finite Python matrices and the complete sanitized sweep are not included.'), indent=2) + '\n')
for name, command in commands:
    started = time.time()
    with (out / (name + '.log')).open('w') as log:
        z = subprocess.run(command, cwd=project, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    record = dict(name=name, command=command, exit_code=z.returncode, elapsed_seconds=time.time()-started, log=name+'.log')
    records.append(record)
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, z.returncode, (out / (name+'.log')).read_text()[-1800:], flush=True)
    if z.returncode:
        (out / 'terminal.json').write_text(json.dumps(dict(exit_code=z.returncode, failed=name, completed_commands=len(records)))+'\n')
        raise SystemExit(z.returncode)
(out / 'terminal.json').write_text(json.dumps(dict(exit_code=0, completed_commands=len(records), scope='Recorded normal sweep only, not complete verify.sh.'))+'\n')
