import hashlib, io, json, posixpath, runpy, subprocess, tarfile
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/qasm-cpu-source-v2'
previous=r/'build/return-reference-source-v1'
source=json.loads((project/'source-hashes.json').read_text())
old=json.loads((previous/'source-hashes.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(source)==237 and sorted(n for n in source if source[n]!=old[n])==['tests/validate_qasm.c']
assert runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()==source
qasm=r/'build/qasm-cpu-final-results-v2'
assert json.loads((qasm/'terminal.json').read_text())['status']=='passed'
assert all(x['exit_code']==0 for x in json.loads((qasm/'commands.json').read_text()))
assert '70 exported circuits independently validated with QuEST 3.7.0 (C): 64 states, 6 channels; table-free export' in (qasm/'qasm.log').read_text()
normal=r/'build/normal-integration-sweep-v1'
normal_commands=json.loads((normal/'commands.json').read_text())
assert len(normal_commands)==22 and all(x['exit_code']==0 for x in normal_commands[:-1])
assert normal_commands[-1]['name']=='qasm' and normal_commands[-1]['exit_code']==1
assert (normal/'qasm.log').read_text().rstrip().endswith('CPU binding QASM fixture emitted no templates')
assert '145 generated frontend compilations passed; seed=20261012' in (normal/'frontend.log').read_text()
assert '24 circuits compiled without tables;' in (normal/'growth.log').read_text()
assert '5 finite integration comparisons passed across the 29 C11 header families' in (normal/'classical.log').read_text()
head=r/'build/sanitized-priority-sweep-v1'
tail=r/'build/sanitized-priority-tail-v1'
assert json.loads((head/'terminal.json').read_text())['status']=='infrastructure-path-normalization-failure'
assert json.loads((tail/'terminal.json').read_text())['status']=='time-budget-stopped'
san_commands=json.loads((head/'commands.json').read_text())+json.loads((tail/'commands.json').read_text())
assert len(san_commands)==10 and all(x['exit_code']==0 for x in san_commands)
names=[x['name'] for x in normal_commands[:17]]
assert {x['name'] for x in san_commands} < set(names)
dependencies={}
base=r/'build/single-fill-source-v2'
base_source=json.loads((base/'source-hashes.json').read_text())
reuse=json.loads((normal/'process.json').read_text())['reused_artifact_sha256']
for name in names:
    raw=subprocess.check_output(['gcc-11','-std=c11','-Isrc/engine','-MM','tests/'+name+'.c','tests/validation.c'],cwd=project,text=True).replace('\\\n',' ').split()
    paths=sorted({posixpath.normpath(p) for p in raw if not p.endswith(':')})
    assert all(source[p]==old[p]==base_source[p] for p in paths)
    assert sha(previous/'build'/name)==sha(base/'build'/name)==reuse[name]
    dependencies[name]=dict(dependency_sha256={p:source[p] for p in paths},normal_executable_sha256=reuse[name])
for folder in (head,tail):
    for name,row in json.loads((folder/'artifacts.json').read_text()).items():
        assert all(source[n]==h for n,h in row['dependency_sha256'].items())
        assert '__asan_init' in row['instrumentation'] and '__ubsan_handle' in row['instrumentation']
sdk=json.loads((r/'output/sdk/sdk-audit.json').read_text())
for name in ('cket','cket_backend','cket_plugin.so','libcket_quantum.a','cket_runtime.o','gcc-version.txt'):
    assert sha(project/'build'/name)==sdk['package_files_sha256']['build/'+name]

destination=r/'docs/audit-evidence/c-priority-integration-v1'
assert not (destination/'summary.json').exists()
docs=['docs/audit-evidence/c-priority-integration-v1/README.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/estado-general-del-proyecto.es.md','README.md']
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for name in docs:
    p=r/name
    p.write_text(fmt(p,p.read_text()))

def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode()
    info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.c','.json','.log','.py','.sh','.txt','.csv'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())

with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for name in source:tar.add(project/name,arcname='sources/'+name)
    raw(tar,'source-identities.json',dict(qualified=source,previous_sdk=old))
    raw(tar,'normal-validator-dependencies.json',dependencies)
    for folder,prefix in [(normal,'normal-initial'),(head,'sanitized-prefix'),(tail,'sanitized-tail'),(qasm,'qasm-final'),(r/'build/qasm-cpu-final-results-v1','qasm-incomplete-preparation'),(r/'build/qasm-cpu-reference-preview-v1','qasm-preview')]:
        tree(tar,folder,prefix)
    tree(tar,project/'build/audit/locale-sanitizer','locale-guard')
    tar.add(previous/'build/synthesis-growth.csv',arcname='normal-initial/synthesis-growth.csv')
    for name in ['run-normal-integration-sweep.py','run-sanitized-priority-sweep.py','resume-sanitized-priority-sweep.py','run-sanitized-priority-tail.py','close-sanitized-priority-budget.py','qualify-qasm-cpu-reference-final.py','qualify-qasm-cpu-reference-v2.py','qualify-qasm-cpu-reference-complete.py','update-c-priority-docs.py','publish-c-priority-integration.py']:
        tar.add(r/'build'/name,arcname='harness/'+name)
counts=dict(controlled_operands=1270,phase=3380,byte_snapshots=650,division=990,bindings=519,history=2332,heap=16878,heap_identities=1682,inactive_borrows=139,swap_rebind=35871,patches=55143,runtime_versions=15,runtime_memory=23,ctype=1815,profiles=96,numeric_locale=70,library_boundary=2100)
summary=dict(status='passed-recorded-c-priority-and-normal-qasm-scopes-with-open-full-integration',date='2026-10-26',version='1.0.0-rc.3',base_commit='440e7e9',source_files=237,source_sha256=source,changed_inputs=['tests/validate_qasm.c'],production_sources_changed=False,
    normal_c_validator_counts=counts,normal_additional=dict(frontend_compilations=145,frontend_seed=20261012,random_cases=24,fixed_cases=5,gcc_levels=5,byte_inputs_per_compilation=256,growth_circuits=24,classical_header_families=29,classical_comparisons=5,qasm_states=64,qasm_channels=6,qasm_state_amplitude_tolerance=1e-10,qasm_state_scope='Export/engine consistency up to a global phase; not an independent C semantic oracle.',qasm_channel_transcripts_per_backend=8192,qasm_channel_scope='Statistical transcript-distribution comparison, not an exact arbitrary channel proof.',locale_suppression_guard='passed'),
    sanitized=dict(validators=10,completed_names=[x['name'] for x in san_commands],scope='Only the 10 completed C validators; byte snapshots interrupted for time, six following validators not run. No new sanitized QuEST/fuzz/growth or complete verify.sh claim.',prefix_commands=6,continuation_commands=4,terminal=json.loads((tail/'terminal.json').read_text())),
    sdk=dict(compiler_binaries_identical=True,source_snapshot='memory-return-reference-v1',package_sha256=sdk['package_sha256']),
    open_work=['full verify.sh composition and unlisted scopes','general lifetime/alias/ABI and everyday-C completion','quantum floating point and excluded resource profiles','general manuscript re-audit','physical QPU and speedup unclaimed'],artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=sorted(set(source)|set(docs)|{'docs/audit-evidence/c-priority-integration-v1/summary.json','docs/audit-evidence/c-priority-integration-v1/evidence.tar.gz'})
(r/'build/c-priority-git-expected.json').write_text(json.dumps({n:sha(r/n) for n in names},indent=2)+'\n')
imports=sorted((set(names)-set(source))|{'tests/validate_qasm.c','build/c-priority-git-expected.json'})
(r/'build/c-priority-import.txt').write_text('\n'.join(imports)+'\n')
print('Publication ready:',len(names),'exact files; 17 normal and 10 sanitized C validators; 70 normal QuEST exports')
