import json, os, signal, time
from pathlib import Path

r=Path('/tmp/quantum-audit-isolated-20261017/build/sanitized-priority-tail-v1')
assert not (r/'terminal.json').exists()
process=json.loads((r/'process.json').read_text())
root_pid=process['pid']
command=Path('/proc/'+str(root_pid)+'/cmdline').read_bytes().replace(b'\0',b' ')
assert b'/tmp/quantum-audit-isolated-20261017/build/resume-sanitized-priority-sweep.py' in command
os.kill(root_pid,signal.SIGSTOP)
records=json.loads((r/'commands.json').read_text())
assert all(x['exit_code']==0 for x in records)
assert [x['name'] for x in records]==['validate_runtime_versions','validate_runtime_memory','validate_bindings','validate_phase']
pending=[root_pid]
children=[]
while pending:
    parent=pending.pop()
    path=Path('/proc/'+str(parent)+'/task/'+str(parent)+'/children')
    if not path.exists():continue
    for value in path.read_text().split():
        pid=int(value)
        try:
            os.kill(pid,signal.SIGSTOP)
            children.append(pid)
            pending.append(pid)
        except ProcessLookupError:pass
for pid in reversed(children+[root_pid]):
    try:os.kill(pid,signal.SIGKILL)
    except ProcessLookupError:pass
(r/'terminal.json').write_text(json.dumps(dict(status='time-budget-stopped',completed_commands=len(records),
    elapsed_seconds=time.time()-process['started_unix'],interrupted_validator='validate_byte_snapshots',
    reason='Close the usable delivery and publish exact evidence within the user remaining session quota. Partial byte-snapshot output is not a completed pass.',
    remaining_validators=['validate_byte_snapshots','validate_controlled_operands','validate_division','validate_ctype','validate_profiles','validate_numeric_locale','validate_library']),indent=2)+'\n')
print('Closed bounded ASan campaign:',len(records),'completed tail validators; byte snapshot interrupted, not counted as passed')
