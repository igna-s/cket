import hashlib, json, os, runpy, shutil, subprocess, time
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
old = r/'build/return-reference-source-v1'
project = r/'build/qasm-cpu-source-v2'
out = r/'build/qasm-cpu-final-results-v2'
fmt = runpy.run_path(str(r/'scripts/format.py'))['format_text']
p = r/'tests/validate_qasm.c'
p.write_text(fmt(p,p.read_text()))
hashes = runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
before = json.loads((old/'source-hashes.json').read_text())
assert len(hashes)==237 and sorted(n for n in hashes if hashes[n]!=before[n])==['tests/validate_qasm.c']
project.mkdir()
out.mkdir()
for name in hashes:
    p = project/name
    p.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(r/name,p)
(project/'source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(project/'.deps').symlink_to(r/'.deps',target_is_directory=True)
(project/'build').mkdir()
(project/'build/validation-deps').mkdir()
artifacts={}
for name in ('cket','cket_backend','cket_plugin.so','libcket_quantum.a','cket_runtime.o','gcc-version.txt','qasm_samples','validation-deps/libQuEST.a'):
    shutil.copy2(old/'build'/name,project/'build'/name)
    artifacts[name]=hashlib.sha256((project/'build'/name).read_bytes()).hexdigest()
quest=old/'build/validation-deps/QuEST-d4f75f724993b4af8e43a796e3c09ce24ae11670/QuEST'
env=dict(os.environ,CC='gcc-11',CXX='g++-11')
env.pop('CKET_SIMULATOR',None)
commands=[('build',['gcc-11','-std=c11','-O2','-Wall','-Wextra','-Werror','-Isrc/engine','-Itests','-DQuEST_PREC=2','-DVALIDATION_SANITIZED=0','-I'+str(quest/'include'),'tests/validate_qasm.c','tests/qasm_reference.c','tests/validation.c','build/libcket_quantum.a','build/validation-deps/libQuEST.a','-lm','-o','build/validate_qasm']),('qasm',['build/validate_qasm']),('locale-sanitizer',['bash','scripts/test-locale-sanitizer.sh'])]
records=[]
for name,command in commands:
    started=time.time()
    with (out/(name+'.log')).open('w') as log:
        z=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    records.append(dict(name=name,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-started,log=name+'.log'))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,z.returncode,(out/(name+'.log')).read_text()[-1200:],flush=True)
    if z.returncode:
        (out/'terminal.json').write_text(json.dumps(dict(status='failed',failed=name,exit_code=z.returncode))+'\n')
        raise SystemExit(z.returncode)
assert '70 exported circuits independently validated' in (out/'qasm.log').read_text()
assert all(hashlib.sha256((project/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
(out/'terminal.json').write_text(json.dumps(dict(status='passed',states=64,channels=6,source_sha256=hashes,reused_artifacts_sha256=artifacts,source_difference=['tests/validate_qasm.c'],production_sources_changed=False),indent=2)+'\n')
print('Final frozen QASM/locale qualification passed',flush=True)
