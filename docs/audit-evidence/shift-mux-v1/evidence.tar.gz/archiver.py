from pathlib import Path
import hashlib
import json
import re
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/shift-mux-v1'
out = root / 'docs/audit-evidence/shift-mux-v1'
out.mkdir(parents=True, exist_ok=True)
assert not (out / 'summary.json').exists()
read = lambda p: json.loads(p.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = read(project / 'build/sources.json')
assert len(sources) == 161 and all(digest(project / n) == sha for n, sha in sources.items())
assert all(digest(root / n) == sha for n, sha in sources.items())
records = {}
for mode in ['normal', 'sanitized']:
    directory = project / ('build/qualification-' + mode + '-v1')
    record = read(directory / 'exit.json')
    assert record['status'] == 'passed-shift-mux-targeted' and record['exit_code'] == 0
    assert record['source_sha256'] == sources
    assert all(c['returncode'] == 0 and digest(directory / c['log']) == c['log_sha256'] for c in record['commands'])
    assert '71 shift checks passed' in (directory / 'validate_shifts.log').read_text()
    assert '393 passed, 0 failed' in (directory / 'native-regression.log').read_text()
    assert '3505 expression checks passed' in (directory / 'expression-regression.log').read_text()
    records[mode] = record
baseline = read(project / 'build/previous-shift-resource-v1/result.json')
assert baseline['status'] == 'confirmed-previous-32bit-shift-resource-limit'
assert baseline['source_sha256'] == sources['examples/blocks/02/variable_shift.c']
resource = (project / 'build/blocks/02/variable_shift.resources.txt').read_text()
assert int(re.search(r'Peak qubits:\s+(\d+)', resource)[1]) == 105
with tarfile.open(out / 'evidence.tar.gz', 'w:gz') as archive:
    for name in sources:
        archive.add(project / name, arcname='sources/' + name)
    for mode in records:
        directory = project / ('build/qualification-' + mode + '-v1')
        for path in sorted(directory.iterdir()):
            if path.is_file() and path.suffix in {'.json', '.log', '.py'}:
                archive.add(path, arcname='records/' + mode + '/' + path.name)
    for path in sorted((project / 'build/previous-shift-resource-v1').iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            archive.add(path, arcname='previous-resource/' + path.name)
    for path in sorted((project / 'build/blocks/02').iterdir()):
        if path.is_file() and path.suffix in {'.qasm', '.txt'}:
            archive.add(path, arcname='block02/' + path.name)
    archive.add(__file__, arcname='archiver.py')
summary = {
    'status': 'passed-targeted-shift-multiplexer',
    'source_files': 161, 'source_sha256': sources,
    'checks_per_configuration': {'shifts': 71, 'expressions': 3505, 'native': 393},
    'new_complete_sparse_domains_per_configuration': 16,
    'closed_commands_zero': {n: len(r['commands']) for n, r in records.items()},
    'normal_build': 'fresh-full-build',
    'sanitized_build': 'fresh-engine-runtime-driver-backend-validators; byte-verified unchanged GCC plugin reused',
    'plugin_reuse': records['sanitized']['plugin_reuse'],
    'variable_shift_peak_qubits': 105,
    'previous_failure': baseline,
    'scope': 'Complete finite complex joint states of all byte labels and eight shift amounts; selected256-label32/64-bit source domains with every32/64-bit shift amount; both synthesis policies, source/result phases, controls and clean inverse. Full32 and narrow64 outputs; not every wide input value or QPU execution.',
    'block02_status': 'usable-advance; complete integer foundation remains open',
    'broad_regression': 'pending-for-these-inputs', 'remote_ci': 'pending-for-these-inputs',
    'artifact_sha256': {'evidence.tar.gz': digest(out / 'evidence.tar.gz')},
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Archived161 shift inputs; all targeted commands zero:', summary['closed_commands_zero'])
