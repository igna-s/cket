#include "quantum.h"
#include <math.h>
#include <stdio.h>

int main(void) {
    qc_context *c = qc_create(1, 7);
    const char *operations[] = {
        "{\"op\":\"qalloc\",\"id\":0,\"width\":16,\"signed\":false}",
        "{\"op\":\"qprepare\",\"id\":0,\"lower\":0,\"upper\":65535}",
        "{\"op\":\"qalloc\",\"id\":1,\"width\":1,\"signed\":false}",
        "{\"op\":\"qcompute\",\"id\":1,\"expr\":{\"op\":\"cast\",\"bits\":1,\"signed\":false,\"args\":[{\"op\":\"not\",\"bits\":32,\"signed\":true,\"args\":[{\"op\":\"cast\",\"bits\":32,\"signed\":true,\"args\":[{\"op\":\"reg\",\"id\":0,\"bits\":16,\"signed\":false}]}]}]}}"
    };
    if (!c)
        return 2;
    for (unsigned i = 0; i < sizeof operations / sizeof *operations; ++i)
        if (!qc_apply(c, operations[i], NULL)) {
            fprintf(stderr, "%s\n", qc_error(c));
            return 2;
        }
    double correct = cabs(qc_amplitude(c, 2));
    double incorrect = cabs(qc_amplitude(c, 2 | 65536));
    printf("source=2 correct_output0_amplitude=%.17g incorrect_output1_amplitude=%.17g\n", correct, incorrect);
    qc_destroy(c);
    return fabs(correct - 1.0 / 256) > 1e-12 || incorrect > 1e-12;
}
