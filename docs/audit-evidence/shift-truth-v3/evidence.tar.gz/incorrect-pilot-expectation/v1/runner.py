from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/shift-truth-v3'
out = project / 'build/exact-regressions-v1'
out.mkdir()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
env = dict(os.environ, CC='gcc-11')
before_directory = root / 'build/shift-truth-baseline-v1'
before = json.loads((before_directory / 'result.json').read_text())
assert len(before['cases']) == 3 and all(c['returncode'] == 1 and 'qubit' in c['diagnostic'] for c in before['cases'])
record = {'previous_resource_cases': before, 'current_cases': [], 'word_not': {}}
for old in before['cases']:
    name = old['name']
    source = before_directory / (name + '.c')
    assert digest(source) == old['source_sha256']
    shutil.copy2(source, out / source.name)
    ir = out / (name + '.json')
    args = [str(project / 'build/cket'), str(source), '-O2', '--emit-ir', '-o', str(ir)]
    p = subprocess.run(args, cwd=project, env=env, capture_output=True, text=True)
    (out / (name + '-compile.log')).write_text(p.stdout + p.stderr)
    assert p.returncode == 0, (name, p.stderr)
    resources = []
    for tables in [False, True]:
        p = subprocess.run([str(project / 'build/cket_backend'), '--resources', str(ir), *([] if tables else ['--no-tables'])], cwd=project, capture_output=True, text=True)
        (out / (name + '-tables' + str(int(tables)) + '.log')).write_text(p.stdout + p.stderr)
        assert p.returncode == 0, p.stderr
        resources.append({'tables': tables, 'returncode': p.returncode, 'report': p.stdout})
    record['current_cases'].append({'name': name, 'source_sha256': digest(source), 'compile_returncode': 0, 'resources': resources})
    print('Resource regression fixed:', name)
shutil.copy2(root / 'build/logical-not-word.c', out / 'logical-not-word.c')
for label, stage, expected in [('previous161', root / 'build/shift-mux-v1', 1), ('candidate164v2', root / 'build/shift-truth-v2', 1), ('current164v3', project, 0)]:
    executable = out / label
    args = ['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-I' + str(stage / 'src/engine'), str(out / 'logical-not-word.c'), str(stage / 'build/libcket_quantum.a'), '-lm', '-o', str(executable)]
    p = subprocess.run(args, capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    p = subprocess.run([executable], capture_output=True, text=True)
    (out / (label + '.log')).write_text(p.stdout + p.stderr)
    assert p.returncode == expected, (label, p.returncode, p.stdout, p.stderr)
    record['word_not'][label] = {'library_sha256': digest(stage / 'build/libcket_quantum.a'), 'returncode': p.returncode, 'stdout': p.stdout}
    print(label, p.returncode, p.stdout.strip())
record['status'] = 'confirmed-three-resource-fixes-and-word-not-correction'
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
