from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/shift-truth-v2'
configuration = sys.argv[1]
assert configuration in ['normal', 'sanitized']
out = project / ('build/qualification-' + configuration + '-v1')
write = lambda p, r: p.write_text(json.dumps(r, indent=2) + '\n')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
if '--worker' not in sys.argv:
    out.mkdir()
    shutil.copy2(__file__, out / 'runner.py')
    with (out / 'worker.log').open('x') as log:
        child = subprocess.Popen([sys.executable, __file__, configuration, '--worker'], cwd=project, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'job.json', {'pid': child.pid, 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print(configuration, 'sparse qualification started', child.pid)
    raise SystemExit(0)
r = {'status': 'running', 'configuration': configuration, 'commands': []}
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_REAL_GCC='gcc-11', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for name in ['CKET_SIMULATOR', 'CKET_SPARSE_STATES']:
    env.pop(name, None)
def command(name, args):
    path = out / (name + '.log')
    with path.open('x') as log:
        p = subprocess.run(list(map(str, args)), cwd=project, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    r['commands'].append({'name': name, 'argv': list(map(str, args)), 'returncode': p.returncode, 'log': path.name, 'log_sha256': digest(path)})
    write(out / 'progress.json', r)
    assert p.returncode == 0, (name, path.read_text()[-3500:])
try:
    sources = json.loads((project / 'build/sources.json').read_text())
    assert all(digest(project / name) == sha for name, sha in sources.items())
    r['source_sha256'] = sources
    stage = project if configuration == 'normal' else project / 'build/sanitized'
    if configuration == 'normal':
        command('fresh-build', ['bash', 'scripts/build.sh'])
    else:
        (stage / 'build').mkdir(parents=True)
        shutil.copy2(project / 'cket', stage / 'cket')
        for name in ['src', 'include', 'tests', 'examples']:
            (stage / name).symlink_to(project / name, target_is_directory=True)
        prior = root / 'build/shift-mux-v1'
        prior_record = json.loads((prior / 'build/qualification-sanitized-v1/exit.json').read_text())
        plugin_inputs = [name for name in sources if name == 'src/cket_plugin.cpp' or name.startswith('src/quantum_') or name.startswith('include/')]
        assert all(prior_record['source_sha256'][name] == sources[name] for name in plugin_inputs)
        old_plugin = prior / 'build/sanitized/build/cket_plugin.so'
        assert digest(old_plugin) == prior_record['core_sha256']['cket_plugin.so']
        shutil.copy2(old_plugin, stage / 'build/cket_plugin.so')
        shutil.copy2(prior / 'build/sanitized/build/gcc-wrapper', stage / 'build/gcc-wrapper')
        r['plugin_reuse'] = {'source_project': str(prior), 'plugin_inputs_sha256': {n: sources[n] for n in plugin_inputs}, 'binary_sha256': digest(old_plugin), 'scope': 'Only the unchanged GCC plugin is reused with byte-verified sources. Every engine component, runtime, driver, backend and listed validator is freshly compiled with ASan/UBSan below.'}
        flags = ['-std=c11', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-Isrc/engine', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
        for component in ['json', 'quantum', 'verify', 'simulator']:
            command('build-' + component, ['gcc-11', *flags, '-c', 'src/engine/' + component + '.c', '-o', stage / ('build/' + component + '.o')])
        command('archive-engine', ['ar', 'rcs', stage / 'build/libcket_quantum.a', *[stage / ('build/' + c + '.o') for c in ['json', 'quantum', 'verify', 'simulator']]])
        command('build-runtime', ['gcc-11', *flags, '-c', 'src/cket_runtime.c', '-o', stage / 'build/cket_runtime.o'])
        for executable, source in [('cket', 'src/cket.c'), ('cket_backend', 'src/cket_backend.c'), ('cket_tests', 'tests/test_native.c'), ('validate_expressions', 'tests/validate_expressions.c'), ('validate_division', 'tests/validate_division.c'), ('validate_shifts', 'tests/validate_shifts.c')]:
            command('build-' + executable, ['gcc-11', *flags, source, *(['tests/validation.c'] if source.startswith('tests/') else []), stage / 'build/libcket_quantum.a', '-lm', '-o', stage / ('build/' + executable)])
        command('build-test_examples', ['gcc-11', *flags, 'tests/test_examples.c', 'tests/validation.c', '-o', stage / 'build/test_examples'])
        shutil.copy2(prior / 'build/sanitized/build/gcc-version.txt', stage / 'build/gcc-version.txt')
        env['CC'] = str(stage / 'build/gcc-wrapper')
    r['core_sha256'] = {name: digest(stage / 'build' / name) for name in ['cket', 'cket_backend', 'cket_plugin.so', 'cket_runtime.o', 'libcket_quantum.a']}
    command('validate_shifts', [stage / 'build/validate_shifts'])
    command('native-regression', [stage / 'build/cket_tests', stage])
    command('expression-regression', [stage / 'build/validate_expressions'])
    command('division-regression', [stage / 'build/validate_division'])
    if configuration == 'normal':
        command('usable-block02', ['bash', 'scripts/run-block.sh', '02'])
    assert all(digest(project / name) == sha for name, sha in sources.items())
    r.update(status='passed-shift-truth-targeted', exit_code=0)
except BaseException as error:
    traceback.print_exc()
    r.update(status='failed-shift-truth-targeted', exit_code=1, error=repr(error))
finally:
    write(out / 'exit.json', r)
raise SystemExit(r['exit_code'])
