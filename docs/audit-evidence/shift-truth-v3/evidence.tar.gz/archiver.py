from pathlib import Path
import hashlib
import json
import re
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/shift-truth-v3'
out = root / 'docs/audit-evidence/shift-truth-v3'
out.mkdir(parents=True, exist_ok=True)
assert not (out / 'summary.json').exists()
read = lambda p: json.loads(p.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = read(project / 'build/sources.json')
assert len(sources) == 164 and all(digest(project / n) == sha for n, sha in sources.items())
assert all(digest(root / n) == sha for n, sha in sources.items())
records = {}
for mode in ['normal', 'sanitized']:
    directory = project / ('build/qualification-' + mode + '-v1')
    record = read(directory / 'exit.json')
    assert record['status'] == 'passed-shift-truth-targeted' and record['exit_code'] == 0
    assert record['source_sha256'] == sources
    assert all(c['returncode'] == 0 and digest(directory / c['log']) == c['log_sha256'] for c in record['commands'])
    for name, pattern in [('validate_shifts', '203 shift checks passed'), ('native-regression', '393 passed, 0 failed'), ('expression-regression', '3505 expression checks passed'), ('division-regression', '990 division checks passed')]:
        assert pattern in (directory / (name + '.log')).read_text(), name
    records[mode] = record
failed = {}
for revision in ['v1', 'v2']:
    prior = root / ('build/shift-truth-' + revision)
    failed[revision] = {mode: read(prior / ('build/qualification-' + mode + '-v1/exit.json')) for mode in ['normal', 'sanitized']}
    assert all(r['status'] == 'failed-shift-truth-targeted' and r['exit_code'] == 1 for r in failed[revision].values())
proof_directory = project / 'build/exact-regressions-v3'
proof = read(proof_directory / 'result.json')
assert proof['status'] == 'confirmed-three-resource-fixes-and-word-not-correction'
assert len(proof['current_cases']) == 3 and all(r['compile_returncode'] == 0 and all(t['returncode'] == 0 for t in r['resources']) for r in proof['current_cases'])
assert [proof['word_not'][k]['returncode'] for k in ['previous161', 'candidate164v2', 'current164v3']] == [1, 1, 0]
resource = (project / 'build/blocks/02/shift_predicate.resources.txt').read_text()
assert int(re.search(r'Peak qubits:\s+(\d+)', resource)[1]) == 85
def add_records(archive, directory, prefix):
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.py', '.c'}:
            archive.add(path, arcname=prefix + '/' + path.name)
with tarfile.open(out / 'evidence.tar.gz', 'w:gz') as archive:
    for name in sources:
        archive.add(project / name, arcname='sources/' + name)
    for mode in records:
        add_records(archive, project / ('build/qualification-' + mode + '-v1'), 'records/' + mode)
    for revision, configurations in failed.items():
        prior = root / ('build/shift-truth-' + revision)
        for mode in configurations:
            add_records(archive, prior / ('build/qualification-' + mode + '-v1'), 'failed/' + revision + '/' + mode)
        for name, sha in configurations['normal']['source_sha256'].items():
            assert digest(prior / name) == sha
            if sources.get(name) != sha:
                archive.add(prior / name, arcname='failed/' + revision + '/changed-sources/' + name)
    add_records(archive, root / 'build/shift-truth-baseline-v1', 'previous-resource')
    add_records(archive, proof_directory, 'exact-regressions')
    for pilot in [1, 2]:
        add_records(archive, project / ('build/exact-regressions-v' + str(pilot)), 'incorrect-pilot-expectation/v' + str(pilot))
        archive.add(root / ('build/prove-shift-truth-regressions-v' + str(pilot) + '.py'), arcname='incorrect-pilot-expectation/v' + str(pilot) + '/runner.py')
    for path in sorted((project / 'build/blocks/02').iterdir()):
        if path.is_file() and path.suffix in {'.qasm', '.txt'}:
            archive.add(path, arcname='block02/' + path.name)
    archive.add(__file__, arcname='archiver.py')
summary = {
    'status': 'passed-targeted-truth-cast-and-logical-not-correction',
    'source_files': 164, 'source_sha256': sources,
    'checks_per_configuration': {'shifts': 203, 'expressions': 3505, 'native': 393, 'division': 990},
    'new_complete_sparse_domains_per_configuration': 132,
    'closed_commands_zero': {n: len(r['commands']) for n, r in records.items()},
    'plugin_reuse': records['sanitized']['plugin_reuse'],
    'build_scope': 'Fresh full normal build; fresh ASan/UBSan engine, runtime, driver, backend and validators, reusing only the byte-verified unchanged GCC plugin.',
    'example': {'name': 'shift_predicate', 'peak_qubits': 85, 'block02_programs': 4},
    'exact_regressions': proof,
    'failed_attempts': {v: {m: {'status': r['status'], 'exit_code': r['exit_code'], 'failed_command': r['commands'][-1]['name'], 'diagnostic': r.get('error')} for m, r in modes.items()} for v, modes in failed.items()},
    'pilot_scope': 'Two initial direct-word NOT pilots returned correct states on the previous compiler. Their driver expectation was wrong; no successful wrapper exit record is invented. The final no-table nested shift/cast case actually reaches the affected arithmetic fallback and fails on both previous161 and candidate164v2.',
    'validation_scope': 'Four stated source labels per width and every promoted32/64-bit shift count, six truth forms, byte casts, both synthesis policies, controls, full complex sparse states and clean inverse; not all C11 expressions or wide inputs.',
    'block02_status': 'usable advance; integer foundation remains open',
    'broad_regression': 'pending-for-these-inputs', 'remote_ci': 'pending-for-these-inputs',
    'artifact_sha256': {'evidence.tar.gz': digest(out / 'evidence.tar.gz')},
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('Archived164 inputs, three fixed resource cases, exact numeric regression, failed attempts and pilots:', summary['closed_commands_zero'])
