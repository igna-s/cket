#include <quantum.h>
#include <stdint.h>
int main(void){quant bool c=superposition(0,1);quant uint64_t x=c?(UINT64_C(1)<<63):3;quant uint8_t n=superposition(0,63);quant bool p=(uint8_t)(x<<n);measure(p);measure(x);measure(n);measure(c);return 0;}
