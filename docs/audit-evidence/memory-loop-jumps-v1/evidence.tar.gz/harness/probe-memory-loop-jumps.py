import json,os,runpy,subprocess,time
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
p=r/'scripts/validate-memory-loop-jumps.py'
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text'];p.write_text(fmt(p,p.read_text()))
out=r/'build/memory-loop-jump-dev-v2';out.mkdir()
records=[]
for mode,target,levels in [('normal',r/'build/loop-jump-source-v1',['O0','O2']),('sanitized',r/'build/loop-jump-sanitized-v1',['O1'])]:
    env=dict(os.environ,CC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    if mode=='sanitized':env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11')
    command=['python3',str(p),'--compiler-root',str(target),'--output',str(r/('build/memory-loop-jump-'+mode+'-v2')),'--levels']+levels+(['--sanitized'] if mode=='sanitized' else [])
    start=time.time()
    with (out/(mode+'.log')).open('w') as log:z=subprocess.run(command,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    records.append(dict(mode=mode,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-start))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(mode,z.returncode,(out/(mode+'.log')).read_text()[-6000:],flush=True)
    if z.returncode:raise SystemExit(z.returncode)
(out/'terminal.json').write_text(json.dumps(dict(status='passed'),indent=2)+'\n')
