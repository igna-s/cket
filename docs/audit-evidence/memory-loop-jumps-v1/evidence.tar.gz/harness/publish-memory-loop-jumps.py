import hashlib,io,json,re,tarfile
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');project=r/'build/memory-loop-jump-source-v2'
out=r/'build/memory-loop-jump-results-v2';destination=r/'docs/audit-evidence/memory-loop-jumps-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((project/'source-hashes.json').read_text())
before=json.loads((r/'build/loop-jump-source-v1/source-hashes.json').read_text())
terminal=json.loads((out/'terminal.json').read_text())
assert terminal['status']=='passed' and terminal['source_sha256']==source and len(source)==245
assert all(sha(project/n)==h and sha(r/n)==h for n,h in source.items())
changed=[n for n in source if source[n]!=before.get(n)]
assert changed==['scripts/archive-audit.py','scripts/sanitize-all.sh','scripts/validate-memory-loop-jumps.py','scripts/verify.sh']
assert all(source[n]==h for n,h in before.items() if n.startswith(('src/','include/','tests/')))
artifacts=terminal['producer_artifacts_sha256']
previous=json.loads((r/'docs/audit-evidence/loop-jumps-v1/summary.json').read_text())['producer_artifacts_sha256']
assert artifacts==previous
sdk=json.loads((r/'output/sdk/loop-jumps/sdk-audit.json').read_text())
for n,h in artifacts['normal'].items():assert sdk['package_files_sha256']['build/'+n]==h
assert all(row['exit_code']==0 for row in json.loads((out/'commands.json').read_text()))
matrices={}
for mode,counts in [('normal',(4740,1200,948,1)),('sanitized',(2370,600,474,1))]:
    matrix=json.loads((r/('build/memory-loop-jump-'+mode+'-final-v2/summary.json')).read_text())
    assert matrix['status']=='passed' and tuple(matrix[n] for n in ('full_state_checkpoints','complete_gate_inverses','untouched_low_byte_density_comparisons','unwanted_low_bit_copy_mutations_rejected'))==counts
    matrices[mode]=matrix
assert json.loads((out/'archive-parser.json').read_text())['contradictory_transcripts_rejected']==4
docs=(r/'build/memory-loop-jump-docs.txt').read_text().splitlines()
assert not (destination/'summary.json').exists()
def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.c','.py'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())
with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for n in source:tar.add(project/n,arcname='sources/'+n)
    raw(tar,'source-identities.json',dict(qualified=source,compiled_producer_inputs=before))
    raw(tar,'producer-artifacts.json',artifacts)
    tree(tar,out,'results/final')
    for mode in matrices:tree(tar,r/('build/memory-loop-jump-'+mode+'-final-v2'),mode+'/proof')
    for version in (1,2):tree(tar,r/('build/memory-loop-jump-dev-v'+str(version)),'preliminary/dev-'+str(version))
    tree(tar,r/'build/memory-loop-jump-results-v1','preparation/name-collision-and-resume')
    for n in ('qualify-memory-loop-jumps.py','probe-memory-loop-jumps.py','publish-memory-loop-jumps.py','update-memory-loop-jump-docs.py','memory-loop-jump-format.log'):
        tar.add(r/'build'/n,arcname='harness/'+n)
    for n in docs:tar.add(r/n,arcname='documentation/'+n)
summary=dict(status='passed-finite-memory-composition-unchanged-producers-full-integration-pending',date='2026-10-27',version='1.0.0-rc.3',compiled_producer_commit='5f120802464f7d093e1c04380aff7417243855bc',source_files=245,source_sha256=source,changed_inputs=changed,production_changes=[],rebuilt_components=[],producer_artifacts_sha256=artifacts,matrices=matrices,archive_parser_contradictory_transcripts_rejected=4,sdk=dict(package='output/sdk/loop-jumps',package_sha256=sdk['package_sha256'],scope='Unchanged original 244-input SDK. Normal producer binaries match this campaign; no archive or SDK metadata overwritten.'),scope='Finite fixed-buffer runtime byte prefixes through CPU loop jumps, C-derived masks, empty-prefix destination identity, complete correlated states, reduced coherence of one independently phased bit in an untouched low byte and complete gate inverses. No exterior coherent caller, arbitrary states, heap/general lifetimes/ABI, full C11 or physical QPU qualification. New integration full CI and general paper audit remain pending; cybersecurity stays classical.',artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=changed+docs+['docs/audit-evidence/memory-loop-jumps-v1/summary.json','docs/audit-evidence/memory-loop-jumps-v1/evidence.tar.gz']
(r/'build/memory-loop-jump-final-import.txt').write_text('\n'.join(sorted(set(names)))+'\n')
print('Memory/jump audit archived: 245 inputs, unchanged binaries, masks/densities/states/inverses.',flush=True)
