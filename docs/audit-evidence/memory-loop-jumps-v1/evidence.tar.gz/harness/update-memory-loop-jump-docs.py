import re,runpy
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
names=['README.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/paper/README.md','docs/paper/current-evidence-map-2026-10-26.es.md']
texts={n:(r/n).read_text() for n in names}
anchor='**Break y continue CPU implementados:**'
assert texts[names[1]].count(anchor)==1
texts[names[1]]=texts[names[1]].replace(anchor,'''**Memoria con saltos CPU verificada:** `memcpy`, `memmove` y `memset` conservan máscaras,
historia y fases en cinco formas de salto/bucle. La
[nota](paper/memory_loop_jumps_note.es.md) y su
[cápsula](audit-evidence/memory-loop-jumps-v1/README.es.md) registran 4740 puntos de estado
y 1200 inversas en normal; 2370 y 600 instrumentados. La densidad del bit intacto de una
palabra parcial también se conserva; se rechaza un mutante que lo copia a un auxiliar.
La campaña tiene 245 entradas y reutiliza exactamente los binarios de `5f12080`: el SDK
recomendado conserva su identidad. No se amplía su soporte de operaciones ni se afirma
que estas familias de memoria ya estén calificadas con un llamador coherente exterior.

**CI completo de llamadas coherentes aprobado:** la
[cápsula de `cba9759`](audit-evidence/full-ci-coherent-returns-v1/README.es.md) conserva
59 artefactos, logs y la comprobación de 244 blobs Git. Cierra el pendiente de aquella
revisión; los locales, bucles y saltos posteriores mantienen sus propios CI y fuentes.

'''+anchor)
old='''El compilador de llamadas coherentes `cba9759`, anterior al bloque de locales privados, tiene su
campaña dirigida aprobada; su [CI completo](https://github.com/igna-s/cket/actions/runs/40549661037)
sigue en curso al guardar este seguimiento.'''
assert old in texts[names[1]]
texts[names[1]]=texts[names[1]].replace(old,'''El compilador de llamadas coherentes `cba9759`, anterior al bloque de locales privados,
tiene ahora su [CI completo aprobado](audit-evidence/full-ci-coherent-returns-v1/README.es.md).''')
texts['README.md']+='''\nThe [memory/jump audit](docs/paper/memory_loop_jumps_note.es.md) adds C-derived byte masks,
complete states/inverses and an independent untouched-bit density check for memcpy/memmove/memset
through CPU jumps. Its [245-input campaign](docs/audit-evidence/memory-loop-jumps-v1/README.es.md)
reuses the published compiler binaries; the SDK is unchanged. The
[full CI at cba9759](docs/audit-evidence/full-ci-coherent-returns-v1/README.es.md) passed for that
earlier source identity. Later revisions and this new integration retain their own pending CI.
'''
texts['docs/entrega-utilizable-2026-10-26.es.md']+='''\nLa [auditoría de memoria con saltos](paper/memory_loop_jumps_note.es.md) pasa con los mismos
binarios del SDK, sin cambiarlo. Comprueba máscaras C, estados, historia, fases e inversas,
incluyendo la coherencia de un bit del byte intacto. Se añade al verificador normal e instrumentado;
el CI completo de esa integración queda pendiente. El
[CI de `cba9759`](audit-evidence/full-ci-coherent-returns-v1/README.es.md) terminó aprobado para
las fuentes anteriores de llamadas coherentes y no recalifica las revisiones posteriores.
'''
texts['docs/paper/README.md']+='''\nLa [nota de memoria con saltos CPU](memory_loop_jumps_note.es.md) y su
[cápsula de 245 entradas](../audit-evidence/memory-loop-jumps-v1/README.es.md) contrastan máscaras
derivadas de C, historia, estados, fases, densidad del bit intacto e inversas; los productores
son los mismos de `5f12080`. El
[CI completo de `cba9759`](../audit-evidence/full-ci-coherent-returns-v1/README.es.md) terminó
aprobado, con otra identidad de fuentes. Los manuscritos históricos mantienen sus resultados.
'''
paper='docs/paper/current-evidence-map-2026-10-26.es.md'
start=texts[paper].index('La [integración completa de `ac8f5bc`]')
end=texts[paper].index('\nSiguen pendientes',start)
texts[paper]=texts[paper][:start]+'''La [integración completa de `ac8f5bc`](../audit-evidence/full-ci-cpu-returns-v1/README.es.md),
de 242 entradas, y la de [llamadas coherentes `cba9759`](../audit-evidence/full-ci-coherent-returns-v1/README.es.md),
de 244 entradas, terminaron aprobadas. Ambas conservan logs, artefactos e identidades Git.
El CI de `183169a` también terminó aprobado. No recalifican las revisiones posteriores de
locales, bucles o saltos; una misma cantidad de archivos no identifica las mismas fuentes.
'''+texts[paper][end:]
texts[paper]+='''\nLa [auditoría de memoria con saltos](memory_loop_jumps_note.es.md) añade 245 entradas de
campaña, con fuentes de producción y binarios iguales a `5f12080`. Su
[cápsula](../audit-evidence/memory-loop-jumps-v1/README.es.md) registra estados/inversas y
densidades 2×2 del bit preparado en el byte intacto; no es una prueba de estados arbitrarios
de un byte ni de estas familias con un llamador coherente exterior. La integración nueva
permanece pendiente de su CI completo.
'''
for n,s in texts.items():(r/n).write_text(fmt(r/n,s))
extras=['docs/paper/memory_loop_jumps_note.es.md','docs/audit-evidence/memory-loop-jumps-v1/README.es.md','docs/audit-evidence/full-ci-coherent-returns-v1/README.es.md']
for n in extras:
    p=r/n;p.write_text(fmt(p,p.read_text()))
(r/'build/memory-loop-jump-docs.txt').write_text('\n'.join(names+extras)+'\n')
print('Updated current evidence map and',len(names),'current documents')
