import hashlib,json,os,runpy,shutil,subprocess,time
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for n in ('scripts/validate-memory-loop-jumps.py','scripts/verify.sh','scripts/sanitize-all.sh','scripts/archive-audit.py'):
    p=r/n;p.write_text(fmt(p,p.read_text()))
source=runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()
before=json.loads((r/'build/loop-jump-source-v1/source-hashes.json').read_text())
assert len(source)==245
assert [n for n in source if source[n]!=before.get(n)]==['scripts/archive-audit.py','scripts/sanitize-all.sh','scripts/validate-memory-loop-jumps.py','scripts/verify.sh']
root=r/'build/memory-loop-jump-source-v2'
if root.exists():
    assert json.loads((root/'source-hashes.json').read_text())==source
    assert all(sha(root/n)==h for n,h in source.items())
else:
    root.mkdir()
    for n in source:
        p=root/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/n,p)
    (root/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
out=r/'build/memory-loop-jump-results-v2';out.mkdir(exist_ok=True)
records=json.loads((out/'commands.json').read_text()) if (out/'commands.json').exists() else []
artifacts={}
for mode,previous,levels in [('normal',r/'build/loop-jump-source-v1',['O0','O2']),('sanitized',r/'build/loop-jump-sanitized-v1',['O1'])]:
    target=root if mode=='normal' else r/'build/memory-loop-jump-sanitized-tools-v2'
    if any(row['mode']==mode and row['exit_code']==0 for row in records):
        assert json.loads((r/('build/memory-loop-jump-'+mode+'-final-v2/summary.json')).read_text())['status']=='passed'
        artifacts[mode]={n:sha(target/'build'/n) for n in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','gcc-version.txt')}
        assert all(h==sha(previous/'build'/n) for n,h in artifacts[mode].items())
        continue
    if mode=='sanitized':
        target.mkdir()
        for n in ('src','include','tests','examples'):(target/n).symlink_to(root/n,target_is_directory=True)
    (target/'build').mkdir()
    artifacts[mode]={}
    for n in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','gcc-version.txt'):
        shutil.copy2(previous/'build'/n,target/'build'/n);artifacts[mode][n]=sha(target/'build'/n)
    env=dict(os.environ,CC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    if mode=='sanitized':
        shutil.copy2(previous/'build/gcc-wrapper',target/'build/gcc-wrapper')
        env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11')
    command=['python3',str(root/'scripts/validate-memory-loop-jumps.py'),'--compiler-root',str(target),'--output',str(r/('build/memory-loop-jump-'+mode+'-final-v2')),'--levels']+levels+(['--sanitized'] if mode=='sanitized' else [])
    start=time.time()
    with (out/(mode+'.log')).open('w') as log:z=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    records.append(dict(mode=mode,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-start))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(mode,z.returncode,(out/(mode+'.log')).read_text()[-2200:],flush=True)
    if z.returncode:raise SystemExit(z.returncode)
assert all(sha(root/n)==h and sha(r/n)==h for n,h in source.items())
parser=runpy.run_path(str(root/'scripts/archive-audit.py'))['memory_loop_jump_results']
transcript='\n'.join((out/(mode+'.log')).read_text() for mode in ('normal','sanitized'))
matrices=parser(transcript)
faults=[(out/'normal.log').read_text(),transcript+'\n'+(out/'normal.log').read_text()]
bad=json.loads(json.dumps(matrices['normal']));bad['full_state_checkpoints']+=1
faults.append(json.dumps(bad)+'\n'+(out/'sanitized.log').read_text())
bad=json.loads(json.dumps(matrices['ASan/UBSan']));bad['unwanted_low_bit_copy_mutations_rejected']=0
faults.append((out/'normal.log').read_text()+'\n'+json.dumps(bad))
for text in faults:
    try:parser(text)
    except SystemExit:pass
    else:raise AssertionError('archive accepted incomplete or contradictory evidence')
(out/'archive-parser.json').write_text(json.dumps(dict(status='passed',actual_configurations=2,contradictory_transcripts_rejected=len(faults)),indent=2)+'\n')
for n in ('verify.sh','sanitize-all.sh'):
    z=subprocess.run(['bash','-n',str(root/'scripts'/n)],capture_output=True,text=True)
    assert z.returncode==0,z.stderr
(out/'terminal.json').write_text(json.dumps(dict(status='passed',source_files=245,source_sha256=source,producer_artifacts_sha256=artifacts,production_changes=[],rebuilt_components=[],archive_parser_rejections=4),indent=2)+'\n')
print('Memory/jump composition passed with unchanged compiler/runtime producers.',flush=True)
