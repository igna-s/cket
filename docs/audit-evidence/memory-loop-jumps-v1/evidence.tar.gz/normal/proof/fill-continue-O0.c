#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(int argc,char **argv){
unsigned length=argc>1?(unsigned)strtoul(argv[1],0,10):2;
unsigned selector=argc>2?(unsigned)strtoul(argv[2],0,10):2;if(length>2||selector>3)return 2;
quant bool coin=superposition(0,1);
quant uint8_t a[4]={0,5,7,11};a[0]=coin?9:3;
quant uint8_t saved=a[0]^1;if(coin)phase(.31);ownership_checkpoint("start");
for(unsigned i=0;i<4;++i){if(i==selector)continue;size_t n=(length+i)%3;
memset((void*)a,a[0]+1,n);
if(a[0]&1)phase(.07*(i+1));ownership_checkpoint("step");}
if(saved==8)phase(.17);ownership_checkpoint("finish");
measure(a[3]);measure(a[2]);measure(a[1]);measure(a[0]);measure(coin);return 0;}
