from pathlib import Path
import json
import runpy
import shutil

root = Path('/tmp/quantum-audit-isolated-20261017')
format_text = runpy.run_path(str(root / 'scripts/format.py'))['format_text']
files = ['src/quantum_semantics.inc', 'scripts/validate-fixed-memory-loops.py',
         'tests/validate_memcopy.c', 'scripts/run-block.sh', 'scripts/verify.sh',
         'scripts/sanitize-all.sh', 'scripts/inventory_c11.py',
         'examples/blocks/05/fixed_buffers.c']
for name in files:
    path = root / name
    path.write_text(format_text(path, path.read_text()))
inventory_path = root / 'docs/c11-library.json'
inventory = json.loads(inventory_path.read_text())
semantics = runpy.run_path(str(root / 'scripts/inventory_c11.py'))['semantics']
for row in inventory['interfaces']:
    if row['header'] == 'string.h' and row['name'] in ('memcpy', 'memmove', 'memset'):
        values = semantics(row['header'], row['name'], row['kind'], False)
        for field, value in zip(('quantum', 'restriction_classes', 'milestone', 'tests', 'contract'), values):
            row[field] = value
inventory_path.write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
sources = runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
project = root / 'build/fixed-memory-source-v1'
project.mkdir()
for name in sources:
    path = project / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / name, path)
(project / '.deps').symlink_to(root / '.deps', target_is_directory=True)
(project / 'cket').chmod(0o755)
(project / 'docs').mkdir()
shutil.copy2(inventory_path, project / 'docs/c11-library.json')
(project / 'source-hashes.json').write_text(json.dumps(sources, indent=2) + '\n')
(root / 'build/fixed-memory-changed.txt').write_text('\n'.join(files + ['docs/c11-library.json']) + '\n')
print('Formatted', len(files), 'files; frozen', len(sources), 'inputs.', flush=True)
