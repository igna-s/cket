from pathlib import Path
import json
import os
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/fixed-memory-source-v1'
san = root / 'build/fixed-memory-sanitized-v1'
mode = sys.argv[1]
target = project if mode == 'normal' else san
assert json.loads((target / 'build-exit.json').read_text())['exit_code'] == 0
tag = sys.argv[2] if len(sys.argv) > 2 else 'v1'
output = root / ('build/fixed-memory-contexts-' + mode + '-' + tag)
output.mkdir()
env = dict(os.environ, CKET_SIMULATOR='sparse', CKET_SEED='7',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
if mode == 'sanitized':
    env.update(CC=str(san / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11')
flags = ['-O2'] if mode == 'normal' else ['-O1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
cases = {
    'cpu_fill_once': 'unsigned calls=0;quant uint8_t a[2]={7,9};for(unsigned i=0;i<rounds;++i)memset((void*)a,++calls,2);unsigned x=measure(a[0]),y=measure(a[1]);return calls!=rounds||x!=(rounds?rounds:7)||y!=(rounds?rounds:9);',
    'cpu_byte_snapshots': 'unsigned char data[2]={3,5};quant uint8_t a[2]={7,9};for(unsigned i=0;i<rounds;++i){data[0]++;memcpy((void*)a,data,2);}unsigned x=measure(a[0]),y=measure(a[1]);return x!=(rounds?3+rounds:7)||y!=(rounds?5:9);',
    'cpu_branches': 'quant bool coin=superposition(0,1);quant uint8_t a=0,b=7;a=coin?9:3;for(unsigned i=0;i<rounds;++i){if(i&1)memcpy((void*)&b,(const void*)&a,1);else memset((void*)&b,5,1);}unsigned y=measure(b),x=measure(a),c=measure(coin);return x!=(c?9:3)||y!=(rounds?(rounds&1?5:x):7);',
    'identity': 'quant uint8_t a=superposition(0,255);quant uint8_t saved=a^1;for(unsigned i=0;i<rounds;++i)memmove((void*)&a,(const void*)&a,1);unsigned s=measure(saved),x=measure(a);return s!=(x^1);',
}
records = []


def run(label, command, expected=0, diagnostic=None):
    result = subprocess.run(command, cwd=project, env=env, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    (output / (label + '.log')).write_text(result.stdout)
    records.append(dict(command=command, exit_code=result.returncode, expected_exit_code=expected, log=label + '.log'))
    (output / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == expected and (not diagnostic or diagnostic in result.stdout), result.stdout


executions = 0
for name, body in cases.items():
    source = output / (name + '.c')
    source.write_text('#include <quantum.h>\n#include <stdlib.h>\n#include <string.h>\nint main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;' + body + '}\n')
    binary = output / name
    run(name + '-compile', [str(target / 'build/cket'), str(source), *flags, '-o', str(binary)])
    for rounds in (0, 1, 3):
        run(name + '-n' + str(rounds), [str(binary), str(rounds)])
        executions += 1
binary = output / 'fixed_buffers'
run('example-compile', [str(target / 'build/cket'), 'examples/blocks/05/fixed_buffers.c', *flags, '-o', str(binary)])
for rounds in (0, 1, 2, 3):
    run('example-n' + str(rounds), [str(binary), str(rounds)])
    executions += 1
if mode == 'normal':
    run('static-export', [str(target / 'build/cket'), 'examples/blocks/05/fixed_buffers.c',
                          '--emit-qasm', '-o', str(output / 'unsupported.qasm')],
        expected=1, diagnostic='dynamic CPU control requires native C execution')
(output / 'summary.json').write_text(json.dumps(dict(status='passed', mode=mode,
    native_program_executions=executions, contexts=list(cases),
    scope='Finite native observations and example execution only; full-state evidence is recorded separately.'), indent=2) + '\n')
print(mode, executions, 'native fixed-memory executions passed', flush=True)
