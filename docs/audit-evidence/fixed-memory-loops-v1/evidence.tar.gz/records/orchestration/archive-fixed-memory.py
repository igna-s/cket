from collections import Counter
from pathlib import Path
import hashlib
import json
import runpy
import tarfile

root = Path('/tmp/quantum-audit-isolated-20261017')
project = root / 'build/fixed-memory-source-v1'
sanbuild = root / 'build/fixed-memory-sanitized-v1'
folder = root / 'docs/audit-evidence/fixed-memory-loops-v1'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
locations = {mode: root / ('build/fixed-memory-' + mode + '-results-v1') for mode in ('normal', 'sanitized')}
contexts = {mode: root / ('build/fixed-memory-contexts-' + mode + '-' + ('v2' if mode == 'normal' else 'v1')) for mode in locations}
sources = read(project / 'source-hashes.json')
assert len(sources) == 216
assert sources == runpy.run_path(str(root / 'scripts/archive-audit.py'))['source_hashes']()
assert all(sha(project / name) == digest for name, digest in sources.items())
for build in (project, sanbuild):
    assert read(build / 'build-exit.json')['exit_code'] == 0
matrices = {mode: read(path / 'matrix/summary.json') for mode, path in locations.items()}
for mode, counts in [('normal', (200, 60)), ('sanitized', (100, 30))]:
    path = locations[mode]
    assert matrices[mode]['status'] == 'passed'
    assert (matrices[mode]['full_state_checkpoints'], matrices[mode]['complete_gate_inverses']) == counts
    assert all(row['exit_code'] == 0 for row in read(path / 'exit.json'))
    assert '414 memory-copy checks passed' in (path / 'memcopy.log').read_text()
    assert '940 memset checks passed' in (path / 'memset.log').read_text()
    assert read(path / 'heap-loops/summary.json')['status'] == 'passed'
    assert read(contexts[mode] / 'summary.json')['native_program_executions'] == 16
    assert all(row['exit_code'] == row['expected_exit_code'] for row in read(contexts[mode] / 'commands.json'))
assert '395 passed, 0 failed' in (locations['normal'] / 'native-core.log').read_text()
assert '6 executables, 0 QASM' in (locations['normal'] / 'block05.log').read_text()
components = ['cket_plugin.so', 'json.o', 'quantum.o', 'verify.o', 'simulator.o', 'cket_runtime.o', 'cket', 'validate_memcopy', 'validate_memset']
for component in components[:7]:
    text = (locations['sanitized'] / ('instrumentation-' + component + '.log')).read_text()
    assert '__asan_init' in text and '__ubsan_handle' in text
folder.mkdir(parents=True, exist_ok=True)
assert not any((folder / name).exists() for name in ('summary.json', 'evidence.tar.gz', 'earlier-attempts.tar.gz', 'tool-sha256.json'))
tools = {mode: {name: sha(path / 'build' / name) for name in components} for mode, path in [('normal', project), ('sanitized', sanbuild)]}
(folder / 'tool-sha256.json').write_text(json.dumps(tools, indent=2) + '\n')


def records(archive, location, prefix):
    for path in sorted(location.rglob('*')):
        if path.is_file() and path.suffix in ('.json', '.log', '.c'):
            archive.add(path, arcname=prefix + '/' + path.relative_to(location).as_posix())


with tarfile.open(folder / 'evidence.tar.gz', 'x:gz') as archive:
    for name in sources:
        archive.add(project / name, arcname='sources/' + name)
    archive.add(root / 'LICENSE', arcname='sources/LICENSE')
    for name, path in [('source-hashes.json', project / 'source-hashes.json'), ('inventory-fixture.json', project / 'docs/c11-library.json'), ('tool-sha256.json', folder / 'tool-sha256.json')]:
        archive.add(path, arcname='records/' + name)
    for mode in locations:
        records(archive, locations[mode], 'records/' + mode)
        records(archive, contexts[mode], 'records/contexts-' + mode)
    for name in ('build.log', 'build-exit.json', 'build-sanitized.sh'):
        archive.add(sanbuild / name, arcname='records/sanitized-build/' + name)
    for name in ('build-normal.log', 'build-exit.json'):
        archive.add(project / name, arcname='records/normal-build/' + name)
    for name in ('prepare-fixed-memory.py', 'fixed-memory-changed.txt', 'run-fixed-memory.py', 'check-fixed-memory-contexts.py', 'archive-fixed-memory.py'):
        archive.add(root / 'build' / name, arcname='records/orchestration/' + name)
with tarfile.open(folder / 'earlier-attempts.tar.gz', 'x:gz') as archive:
    baseline = root / 'build/runtime-history-source-v4'
    baseline_sources = read(baseline / 'source-hashes.json')
    for name, digest in baseline_sources.items():
        assert sha(baseline / name) == digest
        archive.add(baseline / name, arcname='baseline/sources/' + name)
    archive.add(baseline / 'source-hashes.json', arcname='baseline/source-hashes.json')
    for name in ('fixed-memory-before', 'fixed-memory-after', 'fixed-memory-dev-proof-v1', 'fixed-memory-dev-proof-v2', 'fixed-memory-contexts-normal-v1'):
        records(archive, root / 'build' / name, name)
    for name in ('fixed-memory-dev-build.log', 'fixed-memory-dev-build-2.log', 'fixed-memory-dev-build-3.log', 'build-fixed-plugin.py', 'check-fixed-memory-dev.py'):
        archive.add(root / 'build' / name, arcname='development/' + name)
summary = dict(date='2026-10-24', status='finite-fixed-memory-loops-qualified', source_files=216,
    source_sha256=sources, artifact_sha256={name: sha(folder / name) for name in ('evidence.tar.gz', 'earlier-attempts.tar.gz', 'tool-sha256.json')},
    normal=matrices['normal'], sanitized=matrices['sanitized'], full_state_checkpoints=300, complete_gate_inverses=90,
    normal_native_core_checks=395, memcopy_checks_per_configuration=414, memset_checks_per_configuration=940,
    extra_native_context_executions=32, delivery=dict(block05_native_executables=6, static_exports=0, example_iteration_counts=[0, 1, 2, 3]),
    contexts={mode: read(path / 'summary.json') for mode, path in contexts.items()},
    heap_loop_regression={mode: read(path / 'heap-loops/summary.json') for mode, path in locations.items()},
    inventory=dict(Counter(row['quantum'] for row in read(root / 'docs/c11-library.json')['interfaces'])),
    base_commit='8890c059b3a312369b1f018145b49119d2faf30e', compiler=(project / 'build/gcc-version.txt').read_text().strip(),
    source_scope='Both builds and all final checks use the same 216 frozen compiler/test inputs. Source hashes identify the implementation; documentation is outside that manifest.',
    earlier_attempts='The baseline has 214 frozen inputs. Development probes first reproduced the loop rejections, then exposed incorrect source-before-consumer observation order in two fixtures. They were rejected by the ownership contract; final fixtures observe consumers first. Development build invocations twice used the wrong directory, and the first trace link omitted a required wrapper. A preliminary context run expected the heap-specific export message instead of the actual CPU-control rejection. Final campaigns are closed separately; repeated counts are not added.',
    limitations=['Finite integer fixed-buffer CPU loops with constant checked counts/addresses; no complete everyday-C/C11 claim.',
        'Five two-amplitude profiles, 0/1/3 iterations, normal O0/O2 and sanitized O1, both synthesis policies; not arbitrary quantum-state proof.',
        'Retained history consumes the 128-wire representation budget, with separate 24-wire dense and bounded sparse simulator limits.',
        'Runtime counts on fixed-only buffers, general addresses/ABI, arbitrary CFG lifetimes, heap strings and quantum floating point remain pending.',
        'GCC host is uninstrumented and keeps the existing host leak-attribution exclusion; generated sanitized programs retain leak detection.',
        'Previous deliveries and paper reports retain their own sources; new-compiler paper qualification is still pending. Cybersecurity stays classical. No QPU or speedup claim.'])
(folder / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
p = root / 'docs/audit-evidence/delivery-index.json'
index = read(p)
index['active'] = 'fixed-memory-loops-v1'
index['history'].append('fixed-memory-loops-v1')
index['meaning'] = 'Current source identity selects finite fixed-buffer runtime-memory validation. Historical deliveries retain their inputs; full everyday C integration and new-compiler paper qualification remain open.'
p.write_text(json.dumps(index, indent=2) + '\n')
(root / 'docs/paper/evidence/current-implementation.json').write_text(json.dumps(dict(date='2026-10-24', status=summary['status'], source_files=216, source_sha256=sources,
    directed_evidence='../../audit-evidence/fixed-memory-loops-v1/summary.json', paper_audit='pending-for-new-compiler',
    previous_paper_review='../../audit-evidence/paper-truth-oct24-v1/summary.json', meaning='Fixed-buffer loop validation advances the compiler. The published paper review retains its own 210-input predecessor; historical reports remain unchanged.'), indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('status', 'source_files', 'full_state_checkpoints', 'complete_gate_inverses')}), flush=True)
