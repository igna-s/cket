#include <quantum.h>
#include <string.h>
#include <stdlib.h>
int main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;quant bool coin=superposition(0,1);quant uint8_t a[2]={0,5};a[0]=coin?9:3;memset((void*)a,a[0]+1,2);unsigned x=measure(a[0]),y=measure(a[1]),c=measure(coin);return x!=(c?10:4)||y!=x;}
