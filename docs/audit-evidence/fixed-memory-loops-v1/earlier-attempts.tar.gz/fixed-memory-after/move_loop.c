#include <quantum.h>
#include <string.h>
#include <stdlib.h>
int main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;quant bool coin=superposition(0,1);quant uint8_t a[3]={0,5,7};a[0]=coin?9:3;for(unsigned i=0;i<rounds;++i)memmove((void*)(a+1),(const void*)a,2);unsigned x=measure(a[0]),y=measure(a[1]),z=measure(a[2]),c=measure(coin);return x!=(c?9:3)||y!=(rounds?x:5)||z!=(rounds>1?x:rounds?5:7);}
