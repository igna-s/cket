#include <quantum.h>
#include <string.h>
#include <stdlib.h>
int main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;quant bool coin=superposition(0,1);quant uint8_t a=0,b=7;a=coin?9:3;for(unsigned i=0;i<rounds;++i){memcpy((void*)&b,(const void*)&a,1);a++;}unsigned x=measure(a),y=measure(b),c=measure(coin);return x!=(c?9:3)+rounds||y!=(rounds?(c?9:3)+rounds-1:7);}
