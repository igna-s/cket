#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;quant uint8_t a=superposition(0,255);quant uint8_t saved=a^1;for(unsigned i=0;i<rounds;++i)memmove((void*)&a,(const void*)&a,1);unsigned s=measure(saved),x=measure(a);return s!=(x^1);}
