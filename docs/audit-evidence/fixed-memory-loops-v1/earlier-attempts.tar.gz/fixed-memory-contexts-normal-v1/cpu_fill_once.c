#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;unsigned calls=0;quant uint8_t a[2]={7,9};for(unsigned i=0;i<rounds;++i)memset((void*)a,++calls,2);unsigned x=measure(a[0]),y=measure(a[1]);return calls!=rounds||x!=(rounds?rounds:7)||y!=(rounds?rounds:9);}
