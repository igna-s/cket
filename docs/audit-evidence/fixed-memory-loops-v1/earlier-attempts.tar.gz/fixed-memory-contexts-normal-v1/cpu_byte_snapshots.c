#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;unsigned char data[2]={3,5};quant uint8_t a[2]={7,9};for(unsigned i=0;i<rounds;++i){data[0]++;memcpy((void*)a,data,2);}unsigned x=measure(a[0]),y=measure(a[1]);return x!=(rounds?3+rounds:7)||y!=(rounds?5:9);}
