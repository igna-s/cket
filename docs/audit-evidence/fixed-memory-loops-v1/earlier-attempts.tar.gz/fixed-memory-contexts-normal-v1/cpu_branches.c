#include <quantum.h>
#include <stdlib.h>
#include <string.h>
int main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;quant bool coin=superposition(0,1);quant uint8_t a=0,b=7;a=coin?9:3;for(unsigned i=0;i<rounds;++i){if(i&1)memcpy((void*)&b,(const void*)&a,1);else memset((void*)&b,5,1);}unsigned y=measure(b),x=measure(a),c=measure(coin);return x!=(c?9:3)||y!=(rounds?(rounds&1?5:x):7);}
