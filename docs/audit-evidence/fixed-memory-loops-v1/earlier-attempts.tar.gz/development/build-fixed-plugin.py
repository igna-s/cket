from pathlib import Path
import os
import subprocess

root = Path('/tmp/quantum-audit-isolated-20261017')
script = (root / 'scripts/build.sh').read_text().split('flags=(-std=c11')[0]
line = next(line for line in script.splitlines() if line.startswith('cd '))
script = script.replace(line, 'cd ' + str(root))
output = root / 'build/fixed-memory-dev-build-3.log'
with output.open('x') as log:
    result = subprocess.run(['bash', '-c', script], cwd=root,
                            env=dict(os.environ, CC='gcc-11', CXX='g++-11'),
                            stdout=log, stderr=subprocess.STDOUT)
print('plugin-build', result.returncode, flush=True)
print(output.read_text()[-2000:])
raise SystemExit(result.returncode)
