from pathlib import Path
import json
import os
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
compiler = root / (sys.argv[1] if len(sys.argv) > 1 else 'build/runtime-history-source-v4') / 'build/cket'
output = root / ('build/fixed-memory-' + (sys.argv[2] if len(sys.argv) > 2 else 'before'))
output.mkdir()
cases = {
    'copy_loop': 'quant uint8_t a=0,b=7;a=coin?9:3;for(unsigned i=0;i<rounds;++i){memcpy((void*)&b,(const void*)&a,1);a++;}unsigned x=measure(a),y=measure(b),c=measure(coin);return x!=(c?9:3)+rounds||y!=(rounds?(c?9:3)+rounds-1:7);',
    'move_loop': 'quant uint8_t a[3]={0,5,7};a[0]=coin?9:3;for(unsigned i=0;i<rounds;++i)memmove((void*)(a+1),(const void*)a,2);unsigned x=measure(a[0]),y=measure(a[1]),z=measure(a[2]),c=measure(coin);return x!=(c?9:3)||y!=(rounds?x:5)||z!=(rounds>1?x:rounds?5:7);',
    'fill_loop': 'quant uint8_t a[2]={0,5};a[0]=coin?9:3;for(unsigned i=0;i<rounds;++i)memset((void*)a,a[0]+1,2);unsigned x=measure(a[0]),y=measure(a[1]),c=measure(coin);return x!=(c?9:3)+rounds||y!=(rounds?x:5);',
    'fill_once': 'quant uint8_t a[2]={0,5};a[0]=coin?9:3;memset((void*)a,a[0]+1,2);unsigned x=measure(a[0]),y=measure(a[1]),c=measure(coin);return x!=(c?10:4)||y!=x;',
}
records = []
env = dict(os.environ, CKET_SIMULATOR='sparse', CKET_SEED='7')
for name, body in cases.items():
    source = output / (name + '.c')
    source.write_text('#include <quantum.h>\n#include <string.h>\n#include <stdlib.h>\nint main(int argc,char **argv){unsigned rounds=argc>1?(unsigned)strtoul(argv[1],0,10):3;quant bool coin=superposition(0,1);' + body + '}\n')
    binary = output / name
    commands = [[str(compiler), str(source), '-O2', '-o', str(binary)]]
    for index, command in enumerate(commands):
        result = subprocess.run(command, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (output / (name + '-compile.log')).write_text(result.stdout)
        records.append(dict(case=name, command=command, exit_code=result.returncode))
    if result.returncode == 0:
        for count in (0, 1, 3):
            result = subprocess.run([str(binary), str(count)], cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            (output / (name + '-n' + str(count) + '.log')).write_text(result.stdout)
            records.append(dict(case=name, rounds=count, exit_code=result.returncode))
(output / 'outcomes.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
