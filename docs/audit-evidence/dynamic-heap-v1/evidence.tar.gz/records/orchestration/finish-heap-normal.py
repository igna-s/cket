from pathlib import Path
import json,runpy,shutil,subprocess
root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/dynamic-heap-source-v1'
output=root/'build/dynamic-heap-normal-v1'
(project/'docs').mkdir()
shutil.copy2(root/'docs/c11-library.json',project/'docs/c11-library.json')
command=['python3','scripts/inventory_c11.py']
with (output/'inventory-retry.log').open('x') as out:
    result=subprocess.run(command,cwd=project,stdout=out,stderr=subprocess.STDOUT)
records=json.loads((output/'exit.json').read_text())
records.append({'label':'inventory-retry','command':command,'exit_code':result.returncode,'log':'inventory-retry.log'})
(output/'exit.json').write_text(json.dumps(records,indent=2)+'\n')
assert result.returncode==0
assert runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()==json.loads((project/'source-hashes.json').read_text())
(output/'completion.json').write_text(json.dumps({'status':'passed-after-inventory-fixture-retry','setup_issue':'The initial frozen build omitted the noncompiled docs/c11-library.json needed by inventory audit. The original failed command is preserved; copying that fixture and retrying succeeded. Compiler sources and prior test results are unchanged.'},indent=2)+'\n')
print((output/'inventory-retry.log').read_text(),flush=True)
print('PASS unchanged frozen source hashes',flush=True)
