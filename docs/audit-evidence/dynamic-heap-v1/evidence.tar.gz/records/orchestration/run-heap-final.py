from pathlib import Path
import hashlib,json,os,runpy,shutil,subprocess,sys
root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/dynamic-heap-source-v1'
san=root/'build/dynamic-heap-sanitized-v1'
mode=sys.argv[1]
if mode=='freeze':
    fmt=runpy.run_path(str(root/'scripts/format.py'))['format_text']
    for name in ('README.md','docs/estado-general-del-proyecto.es.md','scripts/validate-heap.py'):
        p=root/name
        p.write_text(fmt(p,p.read_text()))
    source=runpy.run_path(str(root/'scripts/archive-audit.py'))['source_hashes']()
    project.mkdir()
    for name in source:
        p=project/name
        p.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(root/name,p)
    (project/'.deps').symlink_to(root/'.deps',target_is_directory=True)
    (project/'cket').chmod(0o755)
    (project/'source-hashes.json').write_text(json.dumps(source,indent=2)+'\n')
    print('Frozen',len(source),'source files',flush=True)
    sys.exit(0)
if mode=='sanitize-build':
    san.mkdir()
    prefix=(project/'scripts/sanitize-all.sh').read_text().split('\nexport CKET_REAL_GCC="$real_cc"')[0]
    prefix=prefix.replace('cd "$(dirname "$0")/.."','cd "'+str(project)+'"')
    script=san/'build-sanitized.sh'
    script.write_text(prefix+'\n')
    with (san/'build.log').open('x') as out:
        result=subprocess.run(['bash',str(script)],cwd=project,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SAN_ROOT=str(san)))
    (san/'build-exit.json').write_text(json.dumps({'exit_code':result.returncode,'command':['bash',str(script)]},indent=2)+'\n')
    print('Sanitized build',result.returncode,flush=True)
    if result.returncode: print((san/'build.log').read_text()[-4000:],flush=True)
    sys.exit(result.returncode)
assert mode in ('normal','sanitized')
target=project if mode=='normal' else san
output=root/('build/dynamic-heap-normal-v1' if mode=='normal' else 'build/dynamic-heap-sanitized-v1-results')
output.mkdir()
env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SEED='7',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
flags=[]
levels=['O0','O1','O2','O3','Os']
if mode=='sanitized':
    env.update(CC=str(san/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11')
    flags=['--sanitized']
    levels=['O1']
records=[]
def run(label,command,selected_env=None,diagnostic=None):
    with (output/(label+'.log')).open('x') as out:
        result=subprocess.run(command,cwd=project,env=selected_env or env,stdout=out,stderr=subprocess.STDOUT,timeout=480)
    records.append({'label':label,'command':command,'exit_code':result.returncode,'log':label+'.log'})
    (output/'exit.json').write_text(json.dumps(records,indent=2)+'\n')
    text=(output/(label+'.log')).read_text()
    ok=result.returncode>0 and diagnostic in text if diagnostic else result.returncode==0
    print(label,result.returncode,text[-1000:],flush=True)
    if not ok: sys.exit(1)
if mode=='normal': run('build',['bash','scripts/build.sh'])
run('heap-matrix',['python3','scripts/validate-heap.py','--compiler-root',str(target),'--output',str(output/'matrix'),'--levels',*levels,*flags])
run('heap-engine',[str(target/'build/validate_heap')])
run('ownership-regression',['python3','scripts/validate-ownership.py','--compiler-root',str(target),'--output',str(output/'ownership'),'--levels',levels[0] if mode=='sanitized' else 'O2',*flags])
for name in ('cket_tests','validate_bindings','validate_history'):
    run(name,[str(target/'build'/name),str(target)] if name=='cket_tests' else [str(target/'build'/name)])
for level in levels:
    binary=output/('dynamic_heap-'+level)
    run('example-'+level+'-compile',[str(target/'build/cket'),str(project/'examples/blocks/05/dynamic_heap.c'),'-'+level,'-o',str(binary)])
    for count in (2,3,4):
        run('example-'+level+'-'+str(count),[str(binary),str(count)],dict(env,CKET_SIMULATOR='sparse'))
if mode=='normal':
    run('block05',['bash','scripts/run-block.sh','05'])
    run('heap-static-export',[str(target/'build/cket'),'examples/blocks/05/dynamic_heap.c','-O2','--emit-qasm','-o',str(output/'unsupported.qasm')],diagnostic='static export is unsupported')
    run('inventory',['python3','scripts/inventory_c11.py'])
assert runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()==json.loads((project/'source-hashes.json').read_text())
print('PASS frozen sources unchanged',flush=True)
