from pathlib import Path
import json,os,runpy,subprocess
root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/dynamic-heap-source-v1'
target=root/'build/dynamic-heap-sanitized-v1'
output=root/'build/dynamic-heap-sanitized-v1-results'
env=dict(os.environ,CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',CKET_SEED='7')
records=json.loads((output/'exit.json').read_text())
records.append({'label':'validate_history','command':[str(target/'build/validate_history')],'exit_code':None,'status':'orchestrator-timeout','timeout_seconds':480,'log':'validate_history.log','completed_prefix_end':'observation_diagnostics'})
(output/'exit.json').write_text(json.dumps(records,indent=2)+'\n')
assert 'PASS 30 observation diagnostics:' in (output/'validate_history.log').read_text()
source=output/'history_remaining.c'
source.write_text('#define main original_history_main\n#include "'+str(project/'tests/validate_history.c')+'"\n#undef main\nint main(int argc,char **argv){if(argc!=1)validation_fail("usage: remaining history");validation v;validation_init(&v,argv[0]);lazy_value_programs(&v);lazy_value_combinations(&v);lazy_value_states(&v);lazy_value_rejections(&v);rejections(&v);validation_cleanup(&v);printf("%u remaining history checks passed\\n",checks);return checks!=585;}\n')
def run(label,command,selected_env=None):
    with (output/(label+'.log')).open('x') as out:
        result=subprocess.run(command,cwd=project,env=selected_env or env,stdout=out,stderr=subprocess.STDOUT,timeout=1200)
    records.append({'label':label,'command':command,'exit_code':result.returncode,'log':label+'.log'})
    (output/'exit.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,result.returncode,(output/(label+'.log')).read_text()[-1300:],flush=True)
    assert result.returncode==0
binary=target/'build/validate_history_remaining'
run('history-continuation-compile',['gcc-11','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-I'+str(project/'src/engine'),'-I'+str(project/'tests'),'-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie',str(source),str(project/'tests/validation.c'),str(target/'build/libcket_quantum.a'),'-lm','-o',str(binary)])
run('history-continuation',[str(binary)])
example=output/'dynamic_heap-O1'
run('example-O1-compile',[str(target/'build/cket'),str(project/'examples/blocks/05/dynamic_heap.c'),'-O1','-o',str(example)])
for count in (2,3,4):run('example-O1-'+str(count),[str(example),str(count)],dict(env,CKET_SIMULATOR='sparse'))
assert runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()==json.loads((project/'source-hashes.json').read_text())
(output/'completion.json').write_text(json.dumps({'status':'passed-in-two-history-segments','history_total_checks':2332,'history_completed_prefix_checks':1747,'history_continuation_checks':585,'history_continuation_source':'history_remaining.c','history_continuation_scope':'Uses the exact original test functions from the frozen unit. Completed prefix ends at observation_diagnostics. Restarted the interrupted lazy_value_programs function and ran the remaining five function groups; partial interrupted work is not counted. The aggregate is a continuation, not an uninterrupted original validator invocation.','source_hashes':'unchanged'},indent=2)+'\n')
print('PASS unchanged 201 source inputs; sanitized history finished in two segments',flush=True)
