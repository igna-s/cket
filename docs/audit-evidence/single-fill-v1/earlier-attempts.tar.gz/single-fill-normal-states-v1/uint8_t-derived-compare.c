#include <quantum.h>
#include <string.h>
void ownership_checkpoint(const char*);
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error This finite fixture requires the declared little-endian target.
#endif
typedef uint8_t word;
int main(void){
quant bool b=superposition(0,1);if(b)phase(.19);quant word x=(word)(b+1);if(x==2)phase(.31);ownership_checkpoint("before");
memset((void*)&x,strncmp((const char*)&x,"\x01",1),sizeof x);if(x&1)phase(.37);ownership_checkpoint("after");
measure(x);measure(b);return 0;}
