#include <quantum.h>
#include <string.h>
void ownership_checkpoint(const char*);
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error This finite fixture requires the declared little-endian target.
#endif
typedef uint16_t word;
int main(void){
quant word x=superposition(0,1);++x;if(x==2)phase(.31);ownership_checkpoint("before");
memset((void*)&x,strncmp((const char*)&x,"\x01",1),sizeof x);if(x&1)phase(.37);ownership_checkpoint("after");
measure(x);return 0;}
