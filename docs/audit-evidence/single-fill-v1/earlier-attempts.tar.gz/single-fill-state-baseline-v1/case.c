#include <quantum.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(void){
quant bool b=superposition(0,1);if(b)phase(.19);
quant uint8_t x=b+1;if(x==2)phase(.31);
ownership_checkpoint("before");
memset((void*)&x,strncmp((const char*)&x,"\x01",1),1);
if(x)phase(.37);
ownership_checkpoint("after");
measure(x);measure(b);return 0;}
