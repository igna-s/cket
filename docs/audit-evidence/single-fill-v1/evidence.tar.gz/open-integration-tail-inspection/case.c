#include <quantum.h>
#include <string.h>
int main(void){quant uint16_t x=0x1234;void *p=memset((char*)&x+1,0xab,1);memset(p,0xcd,1);unsigned got=measure(x);return got!=0xcd34||p!=(char*)&x+1;}
