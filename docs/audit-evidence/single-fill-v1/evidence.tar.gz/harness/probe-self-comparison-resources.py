import json, os, shutil, subprocess
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
out = r / 'build/self-comparison-resource-baseline-v1'
out.mkdir()
source = out / 'case.c'
shutil.copy2(r / 'build/integrated-cli-source-v2/build/validation-A6s261/sequence.c', source)
records = []
for label, project in [('rc3', r / 'build/fixed-patches-source-v4'),
                       ('strings', r / 'build/string-writes-examples-source-v2'),
                       ('current', r / 'build/integrated-cli-source-v2')]:
    compiler = project / 'build/cket'
    for action in ('--emit-ir', '--resources'):
        target = out / (label + ('.json' if action == '--emit-ir' else '-resources.json'))
        command = [str(compiler), str(source), action, '-O0', '-fno-builtin', '-o', str(target)]
        z = subprocess.run(command, env=dict(os.environ, CC='gcc-11'), text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        records.append(dict(label=label, command=command, exit_code=z.returncode, stdout=z.stdout))
    command = [str(compiler), str(source), '--run', '-O0', '-fno-builtin', '-o', str(out / label)]
    for simulator in ('dense', 'sparse'):
        env = dict(os.environ, CC='gcc-11', CKET_SEED='7')
        if simulator == 'sparse':
            env['CKET_SIMULATOR'] = 'sparse'
        else:
            env.pop('CKET_SIMULATOR', None)
        z = subprocess.run(command, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        records.append(dict(label=label, simulator=simulator, command=command,
                            exit_code=z.returncode, stdout=z.stdout))
        print(label, simulator, z.returncode, z.stdout[-150:], flush=True)
    print(label, (out / (label + '-resources.json')).read_text()[:2500], flush=True)
(out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
