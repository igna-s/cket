#include "internal.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    char *text = qc_read_file(argv[1]);
    cj_doc document = {0};
    qc_context *context = qc_create_sparse(7, 1024);
    if (!text || !context || !cj_parse(&document, text) || !qc_verify_document(context, &document)) return 1;
    context->recording = 1;
    int list = cj_get(&document, 0, "instructions");
    for (int token = list + 1; token < document.tokens[list].next; token = document.tokens[token].next) {
        if (cj_equal(&document, cj_get(&document, token, "op"), "qmeasure")) break;
        uint64_t result;
        if (!qc_apply_token(context, &document, token, 0, 0, &result)) {
            fprintf(stderr, "%s\n", qc_error(context)); return 1;
        }
    }
    for (size_t i = 0; i < context->nregisters; ++i) {
        qc_register *reg = &context->registers[i];
        if (!reg->alive) continue;
        printf("id=%u width=%u history=%d known=%d value=%" PRIu64 " wires=", reg->id, reg->width, reg->history, reg->basis_known, reg->basis_value);
        for (unsigned bit = 0; bit < reg->width; ++bit) printf("%s%u", bit ? "," : "", reg->wires[bit]);
        printf(" definition=%s\n", reg->definition ? reg->definition : "none");
    }
    for (size_t row = 0; row < qc_sparse_size(context); ++row) {
        uint64_t low, high; double complex amplitude;
        qc_sparse_entry(context, row, &low, &high, &amplitude);
        printf("state=%016" PRIx64 "%016" PRIx64 " amplitude=%.17g %.17g\n", high, low, creal(amplitude), cimag(amplitude));
    }
    qc_resources(context, stdout);
    qc_destroy(context); cj_free(&document); free(text);
    return 0;
}
