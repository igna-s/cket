import hashlib, io, json, runpy, subprocess, tarfile
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/single-fill-source-v2'
san = r / 'build/single-fill-sanitized-v2'
source = json.loads((project / 'source-hashes.json').read_text())
base = json.loads((r / 'build/integrated-cli-source-v2/source-hashes.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert len(source) == len(base) == 237
assert [n for n in source if source[n] != base[n]] == ['src/quantum_semantics.inc']
assert runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']() == source
campaigns, tools = {}, {}
for mode, target, previous in [('normal', project, r / 'build/integrated-cli-source-v2'),
                              ('sanitized', san, r / 'build/lazy-pending-sanitized-v1')]:
    out = r / ('build/single-fill-' + mode + '-results-v2')
    summary = json.loads((out / 'summary.json').read_text())
    assert summary['status'] == 'passed' and summary['source_files'] == 237
    assert all(x['exit_code'] == 0 for x in json.loads((out / 'commands.json').read_text()))
    for name, text in [('memory-sequences', '360 memory sequence checks passed'),
                       ('memset', '940 memset checks passed'),
                       ('history-focused', '355 focused history-reference checks passed'),
                       ('core', '395 passed, 0 failed')]:
        assert text in (out / (name + '.log')).read_text()
    resources = (out / 'resources.txt').read_text()
    assert 'Peak qubits:    18' in resources
    reuse = json.loads((out / 'build-reuse.json').read_text())
    assert all(sha(target / 'build' / n) == sha(previous / 'build' / n) == h
               for n, h in reuse['reused_artifact_sha256'].items())
    state_out = r / ('build/single-fill-' + mode + '-states-v3')
    states = json.loads((state_out / 'summary.json').read_text())
    assert states['status'] == 'passed' and states['compiled_programs'] == 34
    assert states['public_density_comparisons'] == states['independent_joint_gate_states'] == 136
    assert states['complete_independent_inverses'] == 68 and len(states['exclusions']) == 2
    records = json.loads((state_out / 'commands.json').read_text())
    nonzero = [row for row in records if row['exit_code']]
    assert len(nonzero) == 4 and all(row['exit_code'] == 1 and 'at most 12 input bits' in
                                    (state_out / row['log']).read_text() for row in nonzero)
    campaigns[mode] = dict(regression=summary, states=states, build_reuse=reuse)
    tools[mode] = {name: sha(target / 'build' / name) for name in
                   ('cket_plugin.so', 'cket', 'cket_backend', 'libcket_quantum.a', 'cket_runtime.o',
                    'validate_memory_sequences', 'validate_memset', 'validate_history', 'cket_tests')}
instrumentation = {}
for name in tools['sanitized']:
    text = subprocess.check_output(['nm', '-u', str(san / 'build' / name)], text=True)
    assert '__asan_init' in text and '__ubsan_handle' in text, name
    instrumentation[name] = text
baseline = r / 'build/self-comparison-resource-baseline-v1'
records = json.loads((baseline / 'commands.json').read_text())
for label in ('rc3', 'strings', 'current'):
    rows = [row for row in records if row['label'] == label and 'simulator' in row]
    assert len(rows) == 2
    assert next(x for x in rows if x['simulator'] == 'dense')['exit_code'] == 1
    assert 'limited to 24 qubits' in next(x for x in rows if x['simulator'] == 'dense')['stdout']
    assert next(x for x in rows if x['simulator'] == 'sparse')['exit_code'] == 0
    assert 'Peak qubits:    26' in (baseline / (label + '-resources.json')).read_text()
tail = r / 'build/integration-single-fill-tail-v1'
assert json.loads((tail / 'terminal.json').read_text())['exit_code'] == 1
assert 'unexpected memory return word history' in (tail / 'verify.log').read_text()
old_tail = r / 'build/memory-return-history-baseline-v1'
assert json.loads((old_tail / 'result.json').read_text())['exit_code'] == 1
assert 'unexpected memory return word history' in (old_tail / 'baseline.log').read_text()
destination = r / 'docs/audit-evidence/single-fill-v1'
assert not (destination / 'summary.json').exists()
docs = ['docs/c11-memset.md', 'docs/no-clonacion.es.md', 'docs/paper/README.md',
        'docs/estado-general-del-proyecto.es.md', 'docs/paper/single_fill_note.es.md',
        'docs/audit-evidence/single-fill-v1/README.es.md']
fmt = runpy.run_path(str(r / 'scripts/format.py'))['format_text']
for name in docs:
    p = r / name
    p.write_text(fmt(p, p.read_text()))

def tree(tar, folder, prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.c', '.json', '.log', '.py', '.sh', '.txt'):
            tar.add(p, arcname=prefix + '/' + p.relative_to(folder).as_posix())

def raw(tar, name, value):
    data = (json.dumps(value, indent=2) + '\n').encode()
    entry = tarfile.TarInfo(name)
    entry.size = len(data)
    tar.addfile(entry, io.BytesIO(data))

with tarfile.open(destination / 'evidence.tar.gz', 'w:gz') as tar:
    for name in source:
        tar.add(project / name, arcname='sources/' + name)
    raw(tar, 'source-identities.json', dict(qualified=source, previous=base))
    raw(tar, 'instrumentation.json', instrumentation)
    raw(tar, 'tool-sha256.json', tools)
    for mode in ('normal', 'sanitized'):
        tree(tar, r / ('build/single-fill-' + mode + '-results-v2'), 'results/' + mode)
        tree(tar, r / ('build/single-fill-' + mode + '-states-v3'), 'states/' + mode)
    tree(tar, baseline, 'resource-baselines')
    tree(tar, tail, 'open-integration-tail')
    tree(tar, old_tail, 'open-integration-tail-baseline')
    tree(tar, r / 'build/memory-return-history-inspect-v1', 'open-integration-tail-inspection')
    previous_failure = r / 'build/integrated-cli-results-v2'
    for name in ('verify.log', 'terminal.json'):
        tar.add(previous_failure / name, arcname='preceding-integration/' + name)
    for name in ('prepare-single-fill-v2.py', 'qualify-single-fill-v2.py', 'probe-single-fill-final.py',
                 'probe-self-comparison-resources.py', 'run-integration-single-fill-tail.py',
                 'memory-return-history-inspect.c', 'inspect-memory-return-history.py', 'finalize-single-fill.py'):
        tar.add(r / 'build' / name, arcname='harness/' + name)
with tarfile.open(destination / 'earlier-attempts.tar.gz', 'w:gz') as tar:
    for name in ('single-fill-state-dev-v1', 'single-fill-state-dev-v2', 'single-fill-state-baseline-v1',
                 'single-fill-normal-states-v1', 'single-fill-normal-states-v2',
                 'single-fill-wide-baseline-v1', 'single-fill-normal-results-v1', 'single-fill-sanitized-results-v1'):
        tree(tar, r / 'build' / name, name)
    intermediate = r / 'build/single-fill-source-v1'
    tar.add(intermediate / 'src/quantum_semantics.inc', arcname='intermediate-frozen/src/quantum_semantics.inc')
    tar.add(intermediate / 'source-hashes.json', arcname='intermediate-frozen/source-hashes.json')
    for path, arc in [('build/lazy-pending-preview-memset-full-v1/build/cket_plugin.so', 'first-unfrozen-plugin.so'),
                      ('build/single-fill-state-dev-v1/case', 'first-unfrozen-case')]:
        tar.add(r / path, arcname='unfrozen-development-binaries/' + arc)
summary = dict(status='finite-whole-word-fill-resource-correction-with-open-integration', date='2026-10-26',
    base_commit='0cfbcd5', version='1.0.0-rc.3', compiler_input_files=237, source_sha256=source,
    changed_inputs=['src/quantum_semantics.inc'], campaigns=campaigns, tool_sha256=tools,
    resource_case=dict(previous_physical_wires=26, corrected_physical_wires=18,
                       previous_dense_exit_code=1, previous_sparse_exit_code=0, corrected_dense_exit_code=0),
    total_public_densities=272, total_independent_joint_states=272, total_complete_inverses=136,
    open_integration=dict(validator='validate_memory_returns', diagnostic='unexpected memory return word history',
                          previous_compiler_exit_code=1, corrected_compiler_exit_code=1,
                          reference_not_yet_audited=True, full_ci_qualified=False),
    scope='Finite 8/16-bit optimization; shared capture retained for 32/64-bit words. State fixtures cover supported 8/16/32-bit profiles and record two preexisting 32-bit synthesis limits. No new 64-bit states, general lifetime/alias/ABI, full C11/everyday-C, broad CI, general paper or physical-QPU qualification. Cybersecurity remains classical.',
    discarded_attempts='Fresh-owner variant had 0.5 public density error; its sources were not frozen. Broad inline variant regressed 32-bit comparison resources despite passing targeted legacy suites. Both discarded, final source frozen separately.',
    artifact_sha256={name: sha(destination / name) for name in ('evidence.tar.gz', 'earlier-attempts.tar.gz')})
(destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
names = sorted(set(source) | set(docs) | {'docs/audit-evidence/single-fill-v1/summary.json',
    'docs/audit-evidence/single-fill-v1/evidence.tar.gz', 'docs/audit-evidence/single-fill-v1/earlier-attempts.tar.gz'})
(r / 'build/single-fill-git-expected.json').write_text(json.dumps({n: sha(r / n) for n in names}, indent=2) + '\n')
imports = sorted((set(names) - set(source)) | {'src/quantum_semantics.inc', 'build/single-fill-git-expected.json'})
(r / 'build/single-fill-import.txt').write_text('\n'.join(imports) + '\n')
print('Archived final whole-word fill block;', len(names), 'publication files')
