import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
mode = sys.argv[1]
source = r / 'build/single-fill-source-v2'
target = source if mode == 'normal' else r / 'build/single-fill-sanitized-v2'
base = r / ('build/integrated-cli-source-v2' if mode == 'normal' else 'build/lazy-pending-sanitized-v1')
out = r / ('build/single-fill-' + mode + '-results-v2')
out.mkdir()
if mode == 'sanitized':
    target.mkdir()
    for name in ('include', 'src', 'tests', 'examples', '.deps'):
        (target / name).symlink_to(source / name, target_is_directory=True)
    shutil.copy2(source / 'cket', target / 'cket')
(target / 'build').mkdir()
reused = {}
for name in ('cket', 'cket_backend', 'libcket_quantum.a', 'cket_runtime.o', 'gcc-version.txt',
             *(['gcc-wrapper'] if mode == 'sanitized' else [])):
    shutil.copy2(base / 'build' / name, target / 'build' / name)
    reused[name] = hashlib.sha256((target / 'build' / name).read_bytes()).hexdigest()
environment = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_SEED='7')
environment.pop('CKET_SIMULATOR', None)
if mode == 'sanitized':
    environment.update(CC=str(target / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11',
                       UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
records = []

def run(name, command):
    z = subprocess.run(command, cwd=source, env=environment, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1200)
    (out / (name + '.log')).write_text(z.stdout)
    records.append(dict(command=command, exit_code=z.returncode, log=name + '.log'))
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, z.returncode, z.stdout[-1800:], flush=True)
    assert z.returncode == 0, z.stdout[-6000:]
    assert not any(s in z.stdout for s in ('ERROR: AddressSanitizer', 'runtime error:', 'internal compiler error:'))

headers = Path(subprocess.check_output(['gcc-11', '-print-file-name=plugin'], text=True).strip()) / 'include'
if not (headers / 'gcc-plugin.h').is_file():
    headers = r / '.deps/gcc' / str(headers).lstrip('/')
flags = ['-O2'] if mode == 'normal' else ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer']
run('plugin-build', ['g++-11', '-std=c++17', *flags, '-Wall', '-Wextra', '-Wno-unused-parameter', '-Wno-format-diag',
    '-fPIC', '-shared', '-fno-rtti', '-I' + str(headers), '-I' + str(r / '.deps/gcc/usr/include'),
    '-I' + str(r / '.deps/gcc/usr/include/x86_64-linux-gnu'), str(source / 'src/cket_plugin.cpp'),
    '-o', str(target / 'build/cket_plugin.so')])
link = [] if mode == 'normal' else ['-fno-pie', '-no-pie']
for name, files in [('validate_memory_sequences', ['tests/validate_memory_sequences.c', 'tests/validation.c']),
                    ('validate_memset', ['tests/validate_memset.c', 'tests/validation.c']),
                    ('validate_history', ['tests/validate_history.c', 'tests/validation.c']),
                    ('cket_tests', ['tests/test_native.c', 'tests/validation.c'])]:
    run(name + '-build', ['gcc-11', '-std=c11', *flags, *link, '-Wall', '-Wextra', '-Werror',
        '-I' + str(source / 'src/engine'), *[str(source / f) for f in files],
        str(target / 'build/libcket_quantum.a'), '-lm', '-o', str(target / 'build' / name)])
(out / 'build-reuse.json').write_text(json.dumps(dict(reused_artifact_sha256=reused,
    scope='Unchanged engine/runtime/drivers reused byte for byte; new plugin and validators built from the frozen sources.'), indent=2) + '\n')
case = r / 'build/self-comparison-resource-baseline-v1/case.c'
extra = [] if mode == 'normal' else ['-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
run('minimal-native', [str(target / 'build/cket'), str(case), '-O0', '-fno-builtin', *extra,
                       '--run', '-o', str(out / 'minimal')])
run('minimal-resources', [str(target / 'build/cket'), str(case), '-O0', '-fno-builtin',
                          '--resources', '-o', str(out / 'resources.txt')])
run('memory-sequences', [str(target / 'build/validate_memory_sequences')])
run('memset', [str(target / 'build/validate_memset')])
run('history-focused', [str(target / 'build/validate_history'), '--coherent-reference'])
run('core', [str(target / 'build/cket_tests'), str(target)])
hashes = json.loads((source / 'source-hashes.json').read_text())
assert all(hashlib.sha256((source / name).read_bytes()).hexdigest() == h for name, h in hashes.items())
(out / 'summary.json').write_text(json.dumps(dict(status='passed', mode=mode, source_files=237,
    commands=len(records), memory_sequences=360, memset=940, history_focused=355, native_core=395), indent=2) + '\n')
print('PASS frozen whole-word fill qualification', mode, flush=True)
