import cmath, itertools, json, math, os, runpy, subprocess, sys
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
mode = sys.argv[1]
target = r / ('build/single-fill-source-v2' if mode == 'normal' else 'build/single-fill-sanitized-v2')
out = r / ('build/single-fill-' + mode + '-states-v3')
out.mkdir()
reference = runpy.run_path(str(r / 'scripts/validate-ownership.py'))
density = runpy.run_path(str(r / 'scripts/validate-heap-coherence.py'))
env = dict(os.environ, CC='gcc-11', CKET_SIMULATOR='sparse', CKET_SEED='7')
flags = []
if mode == 'sanitized':
    env.update(CC=str(target / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    flags = ['-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
records = []

def run(name, command, environment=env, allow_resource=False):
    z = subprocess.run(command, env=environment, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=180)
    (out / (name + '.log')).write_text(z.stdout)
    records.append(dict(command=command, exit_code=z.returncode, log=name + '.log'))
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert not any(x in z.stdout for x in ('ERROR: AddressSanitizer', 'runtime error:', 'internal compiler error:'))
    if allow_resource and z.returncode == 1 and any(message in z.stdout for message in (
            '|c> backend: gate IR is limited to 128 physical qubits',
            '|c> backend: exact reversible synthesis supports at most 12 input bits')):
        return None
    assert z.returncode == 0, z.stdout[-6000:]
    return z.stdout

trace = out / 'trace.o'
run('trace-build', ['gcc-11', '-std=c11', '-O1', *flags, '-c', str(r / 'tests/ownership_trace.c'), '-o', str(trace)])
programs = comparisons = inverses = 0
errors, exclusions = [], []
for type_name, producer, profile in itertools.product(
        ('uint8_t', 'int8_t', 'uint16_t', 'int16_t', 'uint32_t', 'int32_t'),
        ('root', 'derived'), ('compare', 'transform', 'identity')):
    bits = int(''.join(c for c in type_name if c.isdigit()))
    fill = {'compare': 'strncmp((const char*)&x,"\\x01",1)', 'transform': '(int)x+2', 'identity': 'x'}[profile]
    initial = ('quant bool b=superposition(0,1);if(b)phase(.19);quant word x=(word)(b+1);'
               if producer == 'derived' else 'quant word x=superposition(0,1);++x;')
    name = '-'.join((type_name, producer, profile))
    path = out / (name + '.c')
    path.write_text(f'''#include <quantum.h>
#include <string.h>
void ownership_checkpoint(const char*);
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
#error This finite fixture requires the declared little-endian target.
#endif
typedef {type_name} word;
int main(void){{
{initial}if(x==2)phase(.31);ownership_checkpoint("before");
memset((void*)&x,{fill},sizeof x);if(x&1)phase(.37);ownership_checkpoint("after");
measure(x);{'measure(b);' if producer == 'derived' else ''}return 0;}}
''')
    binary = out / name
    built = run(name + '-build', [str(target / 'build/cket'), str(path), '-O2' if mode == 'normal' else '-O1',
        *flags, '-Wl,' + str(trace), '-Wl,--wrap=qc_create_sparse', '-Wl,--wrap=__cket_apply', '-o', str(binary)], allow_resource=True)
    if built is None:
        previous = run('baseline-' + name + '-build', [str(r / 'build/integrated-cli-source-v2/build/cket'),
            str(path), '-O2' if mode == 'normal' else '-O1', *flags, '-Wl,' + str(trace),
            '-Wl,--wrap=qc_create_sparse', '-Wl,--wrap=__cket_apply', '-o', str(out / ('baseline-' + name))], allow_resource=True)
        assert previous is None, ('new resource regression', name)
        diagnostic = (out / (name + '-build.log')).read_text()
        old_diagnostic = (out / ('baseline-' + name + '-build.log')).read_text()
        signature = ('128 physical qubits' if '128 physical qubits' in diagnostic else 'at most 12 input bits')
        assert signature in old_diagnostic, ('changed resource failure', name)
        exclusions.append(dict(type=type_name, producer=producer, profile=profile,
            reason=signature + '; same exact diagnostic in previous compiler; no positive state qualification.'))
        print('EXCLUDED resource', mode, name, flush=True)
        continue
    programs += 1
    for policy in (0, 1):
        points = [json.loads(line) for line in run(name + '-' + str(policy), [str(binary)],
                  dict(env, OWNERSHIP_TABLES=str(policy))).splitlines()]
        assert [p['tag'] for p in points] == ['before', 'after']
        evolved, gates = {0: 1 + 0j}, []
        for point in points:
            assert point['measurements'] == point['resets'] == 0
            names = {p['name']: p for p in point['registers'] if not p['history']}
            registers = ([names['b']] if producer == 'derived' else []) + [names['x']]
            blocks, phases = {}, {}
            for b in (0, 1):
                old = b + 1
                byte = b if profile == 'compare' else b + 3 if profile == 'transform' else old
                value = old if point['tag'] == 'before' else sum(byte << s for s in range(0, bits, 8))
                angle = b * (.5 if producer == 'derived' else .31)
                if point['tag'] == 'after':
                    angle += .37 * (value & 1)
                public = b | (value << 1) if producer == 'derived' else value
                history = (b,) if producer == 'root' and point['tag'] == 'after' and not (profile == 'identity' and bits == 8) else ()
                blocks.setdefault(history, {})[public] = cmath.exp(1j * angle) / math.sqrt(2)
                phases[public] = cmath.exp(1j * angle) / math.sqrt(2)
            wanted = density['density'](blocks)
            actual = density['actual_density'](point, registers)
            error = max(abs(actual.get(k, 0j) - wanted.get(k, 0j)) for k in actual.keys() | wanted.keys())
            assert error < 1e-10, (name, policy, point['tag'], error)
            native = {int(b, 0): complex(re, im) for b, re, im in point['state']}
            assert len(native) == 2
            public_wires = [w for register in registers for w in register['wires']]
            common = None
            for basis, amplitude in native.items():
                public = sum(((basis >> w) & 1) << i for i, w in enumerate(public_wires))
                ratio = amplitude / phases[public]
                if common is None:
                    common = ratio
                assert abs(abs(ratio) - 1) < 1e-10 and abs(ratio - common) < 1e-10
                if producer == 'derived' or point['tag'] == 'before':
                    assert not (basis & ~sum(1 << w for w in public_wires))
            evolved = reference['evolve'](evolved, point['gates'])
            reference['equal_states'](native, evolved)
            gates.extend(point['gates'])
            comparisons += 1
            errors.append(error)
        inverse = [[k, w, m, p, -a if k == 2 else a] for k, w, m, p, a in reversed(gates)]
        reference['equal_states'](reference['evolve'](evolved, inverse), {0: 1 + 0j})
        inverses += 1
    print('PASS', mode, name, flush=True)
(out / 'summary.json').write_text(json.dumps(dict(status='passed', mode=mode, compiled_programs=programs,
    public_density_comparisons=comparisons, independent_joint_gate_states=comparisons,
    complete_independent_inverses=inverses, maximum_density_error=max(errors), exclusions=exclusions,
    scope='Finite little-endian 8/16/32-bit whole-word fills, signed/unsigned, root/derived, compare/transform/identity, both synthesis policies. Before/after phases and full states. No 64-bit or general memory qualification.'), indent=2) + '\n')
print('PASS whole-word fill states', mode, comparisons, inverses, flush=True)
