import hashlib, json, os, shutil, subprocess, time
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/single-fill-source-v2'
base = r / 'build/integrated-cli-source-v2'
out = r / 'build/integration-single-fill-tail-v1'
out.mkdir()
reused = {}
for p in (base / 'build').iterdir():
    if p.is_file() and p.suffix not in ('.log', '.csv') and not (project / 'build' / p.name).exists():
        shutil.copy2(p, project / 'build' / p.name)
        reused[p.name] = hashlib.sha256(p.read_bytes()).hexdigest()
assert (project / 'build/validate_memory_returns').is_file()
archive = base / 'build/validation-deps/quest-3.7.0.tar.gz'
assert archive.is_file()
destination = project / 'build/validation-deps'
destination.mkdir(exist_ok=True)
shutil.copy2(archive, destination / archive.name)
script = (project / 'scripts/verify.sh').read_text()
marker = 'build/validate_memory_returns 2>&1 | tee build/verify-memory-returns.log\n'
assert script.count(marker) == 1
tail = 'set -euo pipefail\ncd ' + str(project) + '\n' + marker + script.split(marker, 1)[1]
(out / 'verify-tail.sh').write_text(tail)
env = dict(os.environ, CC='gcc-11', CXX='g++-11', CKET_FUZZ_SEED='20261012', CKET_FUZZ_CASES='24')
env.pop('CKET_SIMULATOR', None)
env.pop('CKET_SAN_ROOT', None)
started = time.time()
with (out / 'verify.log').open('w') as log:
    child = subprocess.Popen(['bash', str(out / 'verify-tail.sh')], cwd=project, env=env,
                             stdout=log, stderr=subprocess.STDOUT)
    (out / 'process.json').write_text(json.dumps(dict(pid=child.pid, started_unix=started,
        source_snapshot=str(project), reused_validator_sha256=reused,
        scope='Starts at normal memory returns after the first whole-word fill fix; then the remaining normal and full sanitized verify.sh tail. Does not rerun the earlier normal prefix on these new sources.'), indent=2) + '\n')
    print('Started integration tail', child.pid, flush=True)
    code = child.wait()
source = json.loads((project / 'source-hashes.json').read_text())
assert all(hashlib.sha256((project / n).read_bytes()).hexdigest() == h for n, h in source.items())
(out / 'terminal.json').write_text(json.dumps(dict(exit_code=code, frozen_inputs_unchanged=True,
    elapsed_seconds=time.time()-started, scope='Only the recorded verification tail, not a fresh entire integration.'), indent=2) + '\n')
print('Verification tail terminal', code, flush=True)
raise SystemExit(code)
