import json, runpy, shutil
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
p = r / 'src/quantum_semantics.inc'
fmt = runpy.run_path(str(r / 'scripts/format.py'))['format_text']
p.write_text(fmt(p, p.read_text()))
h = runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']()
base = json.loads((r / 'build/integrated-cli-source-v2/source-hashes.json').read_text())
assert len(h) == len(base) == 237
assert [n for n in h if h[n] != base[n]] == ['src/quantum_semantics.inc']
project = r / 'build/single-fill-source-v2'
project.mkdir()
for name in h:
    target = project / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(r / name, target)
(project / '.deps').symlink_to(r / '.deps', target_is_directory=True)
(project / 'cket').chmod(0o755)
(project / 'source-hashes.json').write_text(json.dumps(h, indent=2) + '\n')
print('Frozen 237 inputs; only whole-word fill capture selection changed')
