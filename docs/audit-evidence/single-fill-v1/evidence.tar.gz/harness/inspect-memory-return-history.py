import json, os, subprocess
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/single-fill-source-v2'
out = r / 'build/memory-return-history-inspect-v1'
out.mkdir()
source = out / 'case.c'
source.write_text('''#include <quantum.h>
#include <string.h>
int main(void){quant uint16_t x=0x1234;void *p=memset((char*)&x+1,0xab,1);memset(p,0xcd,1);unsigned got=measure(x);return got!=0xcd34||p!=(char*)&x+1;}
''')
commands = [
    ['gcc-11', '-std=c11', '-O2', '-I' + str(project / 'src/engine'), str(r / 'build/memory-return-history-inspect.c'),
     str(project / 'build/libcket_quantum.a'), '-lm', '-o', str(out / 'inspect')],
    [str(project / 'build/cket'), str(source), '--emit-ir', '-O0', '-fno-builtin', '-o', str(out / 'case.json')],
    [str(out / 'inspect'), str(out / 'case.json')],
]
rows = []
for i, command in enumerate(commands):
    z = subprocess.run(command, env=dict(os.environ, CC='gcc-11'), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out / (str(i) + '.log')).write_text(z.stdout)
    rows.append(dict(command=command, exit_code=z.returncode))
    print(z.returncode, z.stdout, flush=True)
    assert z.returncode == 0
(out / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
