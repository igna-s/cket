#include <quantum.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
int main(void){quant bool b=superposition(0,1);quant uint8_t x=b+1;memset(&x,strncmp((char*)&x,"\x01",1),1);unsigned a=measure(x),v=measure(b);return a!=v;}
