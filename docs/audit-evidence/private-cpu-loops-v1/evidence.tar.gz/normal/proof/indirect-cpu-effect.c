#include <quantum.h>
static void cpu(void){}static void(*callback)(void)=cpu;void update(quant bool x,int n){callback();if(n)return;x^=true;}
int main(int argc,char**argv){quant bool c=superposition(0,1),x=false;if(c)update(x,argc);measure(x);measure(c);return 0;}
