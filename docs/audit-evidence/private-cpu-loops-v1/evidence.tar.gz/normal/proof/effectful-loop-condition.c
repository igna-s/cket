#include <quantum.h>
void update(quant bool x,int n){int local=0;while(local++<n)x^=true;}
int main(int argc,char**argv){quant bool c=superposition(0,1),x=false;if(c)update(x,argc);measure(x);measure(c);return 0;}
