from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
s=(r/'build/probe-immutable-cpu-locals.py').read_text()
for old,new in [('build/immutable-cpu-local-source-v3','build/private-cpu-loop-source-v3'),('build/immutable-cpu-local-results-v3','build/private-cpu-loop-results-v3'),('build/immutable-cpu-local-sanitized-v3','build/private-cpu-loop-sanitized-v3'),('immutable-cpu-local-','private-cpu-loop-'),('-proof-v3','-proof-v3')]:
    s=s.replace(old,new)
s=s.replace("r/'build/coherent-return-source-v1'","r/'build/immutable-cpu-local-source-v3'").replace("r/'build/coherent-return-sanitized-v1'","r/'build/immutable-cpu-local-sanitized-v3'")
s=s.replace("'src/quantum_semantics.inc',","'src/quantum_semantics.inc','src/quantum_frontend.inc',")
s=s.replace('Immutable CPU locals:','Private CPU loops:')
p=r/'build/probe-private-cpu-loops-complete.py';p.write_text(s)
exec(compile(s,str(p),'exec'))
