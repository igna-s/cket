import runpy
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
names=['README.md','output/sdk/README.es.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/c11-procedure-returns.md','docs/perfil-c-cotidiano.es.md','docs/paper/README.md','docs/paper/current-evidence-map-2026-10-26.es.md']
texts={n:(r/n).read_text() for n in names}
for n in ['README.md','output/sdk/README.es.md','docs/estado-general-del-proyecto.es.md','docs/entrega-utilizable-2026-10-26.es.md','docs/paper/current-evidence-map-2026-10-26.es.md']:
    texts[n]=texts[n].replace('sdk/immutable-locals/','sdk/cpu-loops/').replace('sdk\\immutable-locals\\','sdk\\cpu-loops\\').replace('(immutable-locals/README.es.md)','(cpu-loops/README.es.md)')
def replace(n,old,new):
    assert texts[n].count(old)==1,(n,old);texts[n]=texts[n].replace(old,new)
replace('README.md','Private, initialized CPU integer locals now compose with those calls when they are never written\nagain and their addresses do not escape. The [note](docs/paper/private_cpu_locals_note.es.md) and\n[evidence](docs/audit-evidence/immutable-cpu-locals-v1/README.es.md) identify the new compiler,\nnormal/sanitized state and inverse checks, and checked Windows SDK workflows. Mutable locals,\ncoherent loops and general lifetimes remain pending.', '''Private CPU integer locals now support updates and CPU for/while/do loops in coherent calls.
Writes remain in the quantum branch where the local was declared; their addresses may not escape.
The [note](docs/paper/private_cpu_loops_note.es.md) and
[evidence](docs/audit-evidence/private-cpu-loops-v1/README.es.md) identify the compiler, finite
normal/sanitized states and inverses, and checked Windows SDK workflows. Quantum-dependent
iteration, coherent break/continue, nested CPU effects and general lifetimes remain pending.''')
replace('output/sdk/README.es.md','SDK con locales CPU privados y llamadas coherentes','SDK con locales privados y bucles CPU coherentes')
replace('docs/estado-general-del-proyecto.es.md','**Locales CPU privados implementados:**','''**Locales mutables privados y bucles CPU implementados:** las llamadas coherentes admiten
`for`, `while` y `do while` con condiciones CPU puras, contadores privados y retornos CPU.
Las escrituras quedan dentro de la misma rama cuántica donde se declaró cada local. La
[nota](paper/private_cpu_loops_note.es.md) y la
[evidencia](audit-evidence/private-cpu-loops-v1/README.es.md) registran 1400 puntos de estado
y 700 inversas en normal; 280 y 140 con ASan/UBSan. El SDK recomendado comprueba también un
parámetro CPU modificado por valor. Quedan condiciones/salidas cuánticas, saltos coherentes,
efectos CPU anidados, vidas/alias/ABI generales e integración completa de estas fuentes.

**Bloque anterior de locales CPU inmutables:**''')
replace('docs/estado-general-del-proyecto.es.md','ejemplo. Siguen pendientes locales mutables, bucles coherentes y vidas generales.','ejemplo de aquel bloque. La ampliación de bucles de arriba supera los límites de mutabilidad\ny bucles CPU; sus propias fuentes y resultados se identifican por separado.')
replace('docs/c11-procedure-returns.md','locales enteros CPU privados, inicializados una vez y sin escrituras posteriores ni dirección\ntomada; su [nota técnica](paper/private_cpu_locals_note.es.md) detalla el análisis.', '''locales enteros CPU privados con inicializador puro y sin dirección tomada. Pueden recibir
escrituras puras y contar bucles CPU dentro de la misma rama cuántica donde se declararon;
su [nota técnica](paper/private_cpu_loops_note.es.md) detalla el análisis.''')
replace('docs/c11-procedure-returns.md','CPU del usuario, los retornos dependientes de datos cuánticos sin medir, los bucles coherentes y las\nvidas generales conservan sus restricciones.','CPU observables, los retornos y condiciones de bucle dependientes de datos cuánticos sin medir,\nlos saltos coherentes y las vidas generales conservan sus restricciones.')
texts['docs/perfil-c-cotidiano.es.md']+='''\nLa [ampliación de bucles CPU](paper/private_cpu_loops_note.es.md) supera el límite anterior:
permite escrituras a esos enteros privados y bucles CPU puros dentro de la misma rama cuántica
de declaración. Incluye retornos y bucles anidados. No permite que el local registre otra
decisión cuántica, ni habilita direcciones escapadas, efectos CPU anidados o saltos coherentes.
'''
texts['docs/paper/README.md']+='''\nLa [nota de locales mutables y bucles CPU](private_cpu_loops_note.es.md) y su
[cápsula](../audit-evidence/private-cpu-loops-v1/README.es.md) amplían el bloque inmutable con
análisis de ramas, condiciones CPU puras y retornos dentro de bucles desde llamadores coherentes.
Conservan identidades propias, el rechazo previo y estados/fases/inversas normales e instrumentados;
la integración completa de estas fuentes sigue pendiente.
'''
texts['docs/paper/current-evidence-map-2026-10-26.es.md']+='''\nEl SDK recomendado ahora usa la [ampliación de bucles CPU](private_cpu_loops_note.es.md), con
244 entradas y otros hashes. Su [evidencia](../audit-evidence/private-cpu-loops-v1/README.es.md)
comprueba locales mutables privados, condiciones CPU y bucles/retornos anidados con estados e
inversas. La condición no puede ser cuántica; quedan saltos y vidas generales. Los CI anteriores
corresponden a sus revisiones originales; el CI completo de esta ampliación sigue pendiente.
'''
replace('docs/entrega-utilizable-2026-10-26.es.md','count=3 control=1 target=0','count=1 control=1 target=0')
texts['docs/entrega-utilizable-2026-10-26.es.md']+='''\nEl paquete recomendado amplía aquel bloque con [locales mutables privados y bucles CPU](paper/private_cpu_loops_note.es.md).
La [cápsula](audit-evidence/private-cpu-loops-v1/README.es.md) identifica otros hashes de fuente,
estados/inversas y el ejemplo de parámetro por valor. Sus condiciones son CPU puras; no incluye
bucles con decisión cuántica, saltos coherentes ni vidas generales. Su CI completo queda pendiente.
'''
for n,s in texts.items():(r/n).write_text(fmt(r/n,s))
for n in ['docs/paper/private_cpu_loops_note.es.md','docs/audit-evidence/private-cpu-loops-v1/README.es.md','output/sdk/cpu-loops/README.es.md']:
    p=r/n;p.write_text(fmt(p,p.read_text()))
(r/'build/private-cpu-loop-docs.txt').write_text('\n'.join(names)+'\n')
print('Updated',len(names),'current documents')
