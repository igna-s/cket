import hashlib,io,json,os,re,runpy,shutil,subprocess,tarfile
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/private-cpu-loop-source-v3';sanitized=r/'build/private-cpu-loop-sanitized-v3'
out=r/'build/private-cpu-loop-results-v3';sdk=r/'output/sdk/cpu-loops'
destination=r/'docs/audit-evidence/private-cpu-loops-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((project/'source-hashes.json').read_text())
before=json.loads((r/'build/immutable-cpu-local-source-v3/source-hashes.json').read_text())
assert len(source)==244 and all(sha(project/n)==h and sha(r/n)==h for n,h in source.items())
terminal=json.loads((out/'terminal.json').read_text());assert terminal['status']=='passed' and terminal['source_sha256']==source
assert all(row['exit_code']==0 for row in json.loads((out/'commands.json').read_text()))
changed=[n for n in source if source[n]!=before.get(n)]
assert changed==['scripts/validate-coherent-procedure-returns.py','src/cket_plugin.cpp','src/quantum_frontend.inc','src/quantum_semantics.inc']
matrices={};artifacts={}
for mode,target,counts in [('normal',project,(1400,700,50,45)),('sanitized',sanitized,(280,140,10,9))]:
    matrix=json.loads((r/('build/private-cpu-loop-'+mode+'-proof-v3/summary.json')).read_text())
    assert matrix['status']=='passed' and tuple(matrix[n] for n in ('full_state_checkpoints','complete_gate_inverses','native_boundary_executions','compile_rejections'))==counts
    matrices[mode]=matrix
    for name,phrase in [('validate_bindings','519 CPU binding checks passed;'),('validate_readonly_borrows','305 readonly borrow checks passed;'),('validate_function_entries','90 function entry checks passed;'),('validate_controlled_operands','1270 controlled operand checks passed;'),('core','395 passed, 0 failed')]:
        assert phrase in (out/(mode+'-'+name+'.log')).read_text()
    previous=r/('build/immutable-cpu-local-source-v3' if mode=='normal' else 'build/immutable-cpu-local-sanitized-v3')
    artifacts[mode]={n:sha(target/'build'/n) for n in ('cket','cket_backend','cket_plugin.so','cket_runtime.o','libcket_quantum.a','gcc-version.txt')}
    for n,h in artifacts[mode].items():
        assert (h!=sha(previous/'build'/n)) if n=='cket_plugin.so' else (h==sha(previous/'build'/n))
symbols=subprocess.check_output(['nm','-u',str(sanitized/'build/cket_plugin.so')],text=True)
assert '__asan_init' in symbols and '__ubsan_handle' in symbols
(out/'plugin-instrumentation.txt').write_text(symbols)
audit=json.loads((sdk/'sdk-audit.json').read_text())
assert audit['source_sha256']==source and audit['source_files']==244 and audit['example_checks']==1509 and audit['prebuilt_programs']==37
assert audit['package_sha256']==sha(sdk/'cket-sdk-linux-x86_64.tar.gz')
assert all(row['exit_code']==0 for row in audit['commands'])
for n,h in artifacts['normal'].items():assert audit['package_files_sha256']['build/'+n]==h
windows=json.loads((r/'build/private-cpu-loop-windows-results.json').read_text())
assert len(windows)==3 and all(row['exit_code']==0 for row in windows)
assert len(re.findall(r'^build/blocks/',(r/'build/private-cpu-loop-windows-demo.log').read_text(),re.M))==37
assert 'count=1 control=1 target=0' in (r/'build/private-cpu-loop-windows-coherent.log').read_text()
assert 'rounds=3 output=12 sum=30' in (r/'build/private-cpu-loop-windows-heap.log').read_text()
audit['windows_launchers']=windows
audit['standalone_example_sha256']={n:sha(sdk/n) for n in ('example_coherent.c','example_heap.c')}
audit['scope']='Finite native SDK programs and three actual Windows/WSL workflows. Private CPU integer statement updates and pure CPU for/while/do loops compose with coherent callers in directed complex-state, phase and inverse families. Writes remain within their declaration quantum branch. Quantum-dependent iteration/exits/writes, escaping addresses, coherent break/continue, nested CPU effects, general lifetimes/ABI, quantum floats, full C11/current integration/paper audit and physical QPU remain pending. Cybersecurity stays classical.'
(sdk/'sdk-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
example=json.loads((r/'build/private-cpu-loop-example-v2/summary.json').read_text());assert example['status']=='passed' and example['native_executions']==10
baseline=r/'build/private-cpu-loop-baseline-v1';baseline.mkdir()
p=baseline/'call.c';shutil.copy2(sdk/'example_coherent.c',p)
rows=[]
for label,target in [('previous',r/'build/immutable-cpu-local-source-v3'),('corrected',project)]:
    command=[str(target/'build/cket'),str(p),'--emit-ir','-O0','-o',str(baseline/(label+'.json'))]
    z=subprocess.run(command,cwd=target,env=dict(os.environ,CC='gcc-11'),text=True,capture_output=True)
    assert z.returncode==(1 if label=='previous' else 0),z.stdout+z.stderr
    if label=='previous':assert 'classical storage cannot be created coherently' in z.stdout+z.stderr
    rows.append(dict(label=label,command=command,exit_code=z.returncode,stdout=z.stdout,stderr=z.stderr))
(baseline/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
assert not (destination/'summary.json').exists()
def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.c','.py','.ps1'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())
docs=(r/'build/private-cpu-loop-docs.txt').read_text().splitlines()+['docs/paper/private_cpu_loops_note.es.md','docs/audit-evidence/private-cpu-loops-v1/README.es.md','output/sdk/cpu-loops/README.es.md']
with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for n in source:tar.add(project/n,arcname='sources/'+n)
    raw(tar,'source-identities.json',dict(qualified=source,previous=before))
    raw(tar,'producer-artifacts.json',artifacts)
    tree(tar,out,'results/final')
    for mode in matrices:tree(tar,r/('build/private-cpu-loop-'+mode+'-proof-v3'),mode+'/proof')
    tree(tar,baseline,'baseline')
    tree(tar,r/'build/private-cpu-loop-example-v2','sdk/example-normal-and-sanitized')
    first=r/'build/private-cpu-loop-source-v1'
    raw(tar,'earlier/first/source-sha256.json',json.loads((first/'source-hashes.json').read_text()))
    for n in source:
        if sha(first/n)!=source[n]:tar.add(first/n,arcname='earlier/first/sources/'+n)
    for n in ('check-private-cpu-loop-example.py','package-private-cpu-loop-sdk-v3.py','rebuild-private-cpu-loop-sdk.py','probe-private-cpu-loops-complete.py','publish-private-cpu-loops-complete.py','private-cpu-loop-format.log'):
        tar.add(r/'build'/n,arcname='harness/'+n)
    tree(tar,r/'build/private-cpu-loop-sdk-results-v2','sdk/results')
    # Earlier preparation and an overstrong zero-history oracle remain separate.
    tree(tar,r/'build/private-cpu-loop-results-v1','earlier/first')
    tree(tar,r/'build/private-cpu-loop-normal-proof-v1','earlier/first-proof')
    for n in ('private-cpu-loop-windows-results.json','private-cpu-loop-windows-demo.log','private-cpu-loop-windows-coherent.log','private-cpu-loop-windows-heap.log','probe-private-cpu-loops.py','package-private-cpu-loop-sdk.py','package-private-cpu-loop-sdk-complete.py','check-private-cpu-loop-sdk-windows.ps1','update-private-cpu-loop-docs.py','publish-private-cpu-loops.py'):
        tar.add(r/'build'/n,arcname='harness/'+n)
    for p in sorted(sdk.iterdir()):
        if p.is_file() and p.suffix!='.gz':tar.add(p,arcname='sdk/files/'+p.name)
    for n in docs:tar.add(r/n,arcname='documentation/'+n)
summary=dict(status='passed-private-cpu-locals-and-loops-current-full-integration-pending',date='2026-10-27',version='1.0.0-rc.3',previous_compiler_commit='750bf284e8d7793d858b22e379177b8dbabe9a80',source_files=244,source_sha256=source,changed_inputs=changed,producer_artifacts_sha256=artifacts,matrices=matrices,regressions_per_configuration=dict(bindings=519,readonly_borrows=305,function_entries=90,controlled_operands=1270,core=395),baseline=rows,sdk=dict(package_sha256=audit['package_sha256'],prebuilt_programs=37,normal_example_checks=1509,windows_workflows=3),earlier_rejection='The first compiler rejected its own controls-possible query while revisiting a shared CPU choice in a versioned Boolean assignment. Generated pure guarded captures now retain their identity. A final indirect-call diagnostic regression also prevents dereferencing a missing direct callee. Earlier attempts are not the final qualification.',scope=audit['scope'],artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
imports=changed+docs+['docs/audit-evidence/private-cpu-loops-v1/summary.json','docs/audit-evidence/private-cpu-loops-v1/evidence.tar.gz']+[p.relative_to(r).as_posix() for p in sdk.iterdir() if p.is_file()]
(r/'build/private-cpu-loop-final-import.txt').write_text('\n'.join(sorted(set(imports)))+'\n')
print('Private CPU loops: exact sources, normal/ASan qualification and usable SDK archived.',flush=True)
