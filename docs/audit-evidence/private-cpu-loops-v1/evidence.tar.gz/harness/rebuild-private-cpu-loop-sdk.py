import shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');sdk=r/'output/sdk/cpu-loops'
backup=r/'build/private-cpu-loop-sdk-before-v3';backup.mkdir()
for p in sdk.iterdir():
    if p.is_file():shutil.copy2(p,backup/p.name)
(sdk/'cket-sdk-linux-x86_64.tar.gz').rename(r/'build/private-cpu-loop-sdk-before-v3.tar.gz')
s=(r/'build/package-private-cpu-loop-sdk.py').read_text().replace('private-cpu-loop-source-v2','private-cpu-loop-source-v3').replace('private-cpu-loop-normal-proof-v2','private-cpu-loop-normal-proof-v3').replace('private-cpu-loop-sdk-stage-v1','private-cpu-loop-sdk-stage-v2').replace('private-cpu-loop-sdk-results-v1','private-cpu-loop-sdk-results-v2')
# The generator adapts an older package script by replacing its original names.
s=s.replace("s=s.replace('Los procedimientos", "s=s.replace('Los procedimientos")
p=r/'build/package-private-cpu-loop-sdk-v3.py';p.write_text(s);exec(compile(s,str(p),'exec'))
