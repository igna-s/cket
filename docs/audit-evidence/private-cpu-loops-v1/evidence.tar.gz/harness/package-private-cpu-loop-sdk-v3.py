import json,shutil
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017');project=r/'build/private-cpu-loop-source-v3'
assert json.loads((r/'build/private-cpu-loop-normal-proof-v3/summary.json').read_text())['status']=='passed'
shutil.copy2(r/'build/immutable-cpu-local-source-v3/LICENSE',project/'LICENSE')
s=(r/'build/package-immutable-cpu-local-sdk-complete.py').read_text()
for old,new in [('build/immutable-cpu-local-source-v3','build/private-cpu-loop-source-v3'),('build/immutable-cpu-local-sdk-stage-v1','build/private-cpu-loop-sdk-stage-v2'),('build/immutable-cpu-local-sdk-results-v1','build/private-cpu-loop-sdk-results-v2'),('output/sdk/immutable-locals','output/sdk/cpu-loops')]:
    assert old in s;s=s.replace(old,new)
s=s.replace('Los procedimientos void admiten retornos CPU anticipados y locales enteros privados, puros e inmutables desde llamadores coherentes.','Los procedimientos void admiten retornos CPU anticipados, locales enteros privados y bucles CPU desde llamadores coherentes.')
s=s.replace('los bucles coherentes y la ABI general siguen pendientes.','los bucles con condición cuántica y la ABI general siguen pendientes.')
p=r/'build/package-private-cpu-loop-sdk-complete.py';p.write_text(s);exec(compile(s,str(p),'exec'))
destination=r/'output/sdk/cpu-loops'
(destination/'example_coherent.c').write_text('''#include <quantum.h>
#include <stdio.h>
#include <stdlib.h>

static void transform(quant bool target, unsigned count) {
    unsigned visited = 0;
    int sign = 1;
    while (count) {
        if (visited == 2)
            return;
        --count;
        ++visited;
        sign = -sign;
        target ^= true;
        phase(sign * 3.141592653589793);
    }
}

int main(int argc, char **argv) {
    unsigned count = argc > 1 ? (unsigned)strtoul(argv[1], NULL, 10) : 1;
    if (count > 4)
        return 2;
    quant bool control = superposition(0, 1), target = false;
    if (control)
        transform(target, count);
    if (count == 1)
        if (control)
            target ^= true;
    fourier(control);
    unsigned c = measure(control), t = measure(target);
    printf("count=%u control=%u target=%u\\n", count, c, t);
    return t || c != (count == 1);
}
''')
shutil.copy2(project/'examples/blocks/05/heap_iterations.c',destination/'example_heap.c')
(destination/'run_coherent_demo.cmd').write_text('@echo off\ncall "%~dp0compile_and_run.cmd" "%~dp0example_coherent.c"\nexit /b %errorlevel%\n')
print('Private CPU loop SDK ready for Windows workflow checks',flush=True)
