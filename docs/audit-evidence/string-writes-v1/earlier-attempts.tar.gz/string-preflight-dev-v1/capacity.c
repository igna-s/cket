#include <quantum.h>
#include <stdint.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(int argc,char **argv){quant uint16_t y=1;char src[2]={argc>1?argv[1][0]:0,0};ownership_checkpoint("before");strcat((char*)&y,src);ownership_checkpoint("after");measure(y);return 0;}
