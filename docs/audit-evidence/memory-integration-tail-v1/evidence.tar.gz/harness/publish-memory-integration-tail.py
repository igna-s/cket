import hashlib,io,json,runpy,tarfile
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
project=r/'build/runtime-memory-reference-source-v1'
out=r/'build/memory-integration-tail-results-v1'
destination=r/'docs/audit-evidence/memory-integration-tail-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((project/'source-hashes.json').read_text())
terminal=json.loads((out/'terminal.json').read_text())
assert terminal['status']=='passed' and terminal['source_sha256']==source
assert runpy.run_path(str(r/'scripts/archive-audit.py'))['source_hashes']()==source
assert len(source)==240 and all(sha(project/n)==h for n,h in source.items())
commands=json.loads((out/'commands.json').read_text())
assert len(commands)==4 and all(row['exit_code']==0 for row in commands)
previous=json.loads((r/'docs/audit-evidence/runtime-memory-reference-v1/summary.json').read_text())
artifacts=previous['producer_artifacts_sha256']
for mode,target in [('normal',project),('sanitized',r/'build/function-entry-sanitized-v2')]:
    assert all(sha(target/'build'/n)==h for n,h in artifacts[mode].items())
matrices={}
for mode,expected in [('normal',[(160,80),(200,60)]),('sanitized',[(80,40),(100,30)])]:
    matrices[mode]={}
    for name,counts in zip(('coherent-overwrites','fixed-memory-loops'),expected):
        folder=r/('build/memory-integration-tail-'+mode+'-'+name+'-v1')
        result=json.loads((folder/'summary.json').read_text())
        assert result['status']=='passed'
        assert (result['full_state_checkpoints'],result['complete_gate_inverses'])==counts
        matrices[mode][name]=result
docs=['docs/paper/current-evidence-map-2026-10-26.es.md','docs/paper/README.md',
      'docs/estado-general-del-proyecto.es.md','docs/audit-evidence/memory-integration-tail-v1/README.es.md']
fmt=runpy.run_path(str(r/'scripts/format.py'))['format_text']
for name in docs:
    p=r/name;p.write_text(fmt(p,p.read_text()))
assert not (destination/'summary.json').exists()
def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
def tree(tar,folder,prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.txt','.c','.py'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())
with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for name in source:tar.add(project/name,arcname='sources/'+name)
    raw(tar,'source-identities.json',source)
    raw(tar,'unchanged-producer-artifacts.json',artifacts)
    tree(tar,out,'qualification')
    for mode in matrices:
        for name in matrices[mode]:tree(tar,r/('build/memory-integration-tail-'+mode+'-'+name+'-v1'),mode+'/'+name)
    for name in ('qualify-memory-integration-tail.py','publish-memory-integration-tail.py'):
        tar.add(r/'build'/name,arcname='harness/'+name)
    for name in docs:tar.add(r/name,arcname='documentation/'+name)
summary=dict(status='passed-finite-memory-tail-full-integration-pending',date='2026-10-27',base_commit='183169a',version='1.0.0-rc.3',source_files=240,
    source_sha256=source,producer_artifacts_sha256=artifacts,production_sources_unchanged=True,matrices=matrices,
    full_state_checkpoints=540,complete_gate_inverses=210,
    scope='Finite two-label C formulas, independent gate states and complete inverses. Counts overlap earlier campaigns. No full verify.sh, arbitrary state/C11, QPU or speedup claim. Cybersecurity stays classical.',
    artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=docs+['docs/audit-evidence/memory-integration-tail-v1/summary.json','docs/audit-evidence/memory-integration-tail-v1/evidence.tar.gz']
expected=json.loads((r/'build/runtime-memory-reference-git-expected.json').read_text());expected.update({n:sha(r/n) for n in names})
(r/'build/memory-integration-tail-git-expected.json').write_text(json.dumps(expected,indent=2)+'\n')
(r/'build/memory-integration-tail-import.txt').write_text('\n'.join(names+['build/memory-integration-tail-git-expected.json'])+'\n')
print('Memory tail evidence ready:',len(expected),'exact files; 540 complex states and 210 full inverses.')
