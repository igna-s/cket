import hashlib,json,os,subprocess,time
from pathlib import Path
r=Path('/tmp/quantum-audit-isolated-20261017')
source=r/'build/runtime-memory-reference-source-v1'
out=r/'build/memory-integration-tail-results-v1';out.mkdir()
records=[]
for mode,target,levels in [('normal',source,['O0','O2']),('sanitized',r/'build/function-entry-sanitized-v2',['O1'])]:
    for name in ('coherent-overwrites','fixed-memory-loops'):
        result=r/('build/memory-integration-tail-'+mode+'-'+name+'-v1')
        env=dict(os.environ,CC='gcc-11',CXX='g++-11')
        if mode=='sanitized':env.update(CC=str(target/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        command=['python3',str(source/'scripts'/('validate-'+name+'.py')),'--compiler-root',str(target),'--output',str(result),'--levels']+levels+(['--sanitized'] if mode=='sanitized' else [])
        start=time.time()
        with (out/(mode+'-'+name+'.log')).open('w') as log:z=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
        records.append(dict(name=name,mode=mode,command=command,exit_code=z.returncode,elapsed_seconds=time.time()-start))
        (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
        print(mode,name,z.returncode,(out/(mode+'-'+name+'.log')).read_text()[-1800:],flush=True)
        if z.returncode:
            (out/'terminal.json').write_text(json.dumps(dict(status='failed',mode=mode,name=name,exit_code=z.returncode))+'\n');raise SystemExit(z.returncode)
hashes=json.loads((source/'source-hashes.json').read_text())
assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
(out/'terminal.json').write_text(json.dumps(dict(status='passed',source_files=len(hashes),source_sha256=hashes),indent=2)+'\n')
print('Memory integration tail normal/sanitized passed',flush=True)
