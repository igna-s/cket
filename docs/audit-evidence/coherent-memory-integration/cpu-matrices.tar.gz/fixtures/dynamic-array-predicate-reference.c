#include <stdint.h>
#include <stdbool.h>
#define quant
#define measure(x) (x)
#define phase(x) ((void)(x))
#define superposition(a,b) (b)
#include <string.h>
#include <stddef.h>
int main(int argc,char**argv){(void)argc;(void)argv;
int k=argc>1?argv[1][0]-'0':0;unsigned a[2]={0,1};quant bool b=superposition(0,1);quant uint8_t x=5;if(b){if(a[k]){x^=16;phase(.17);}}unsigned r=measure(x),v=measure(b);return r!=(v&&k?21:5);
}
