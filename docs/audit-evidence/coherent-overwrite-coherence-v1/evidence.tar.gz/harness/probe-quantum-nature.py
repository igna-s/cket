import cmath
import itertools
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017')
compiler = root / 'build/runtime-memory-source-v3'
reference = runpy.run_path(str(root / 'scripts/validate-ownership.py'))
out = root / ('build/quantum-nature-probe-' + (sys.argv[1] if len(sys.argv) > 1 else 'v1'))
out.mkdir()
env = dict(os.environ, CC='gcc-11', CKET_SIMULATOR='sparse', CKET_SEED='7', OWNERSHIP_TABLES='0')
commands = []

def run(label, command):
    result = subprocess.run(command, cwd=compiler, env=env, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    (out / (label + '.log')).write_text(result.stdout)
    commands.append(dict(command=command, exit_code=result.returncode, log=label + '.log'))
    (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == 0, result.stdout[-5000:]
    return result.stdout

trace = out / 'trace.o'
run('trace', ['gcc-11', '-std=c11', '-O1', '-c', str(compiler / 'tests/ownership_trace.c'), '-o', str(trace)])
links = ['-Wl,' + str(trace), '-Wl,--wrap=qc_create_sparse', '-Wl,--wrap=__cket_apply']
header = '#include <quantum.h>\n#include <stdlib.h>\n#include <string.h>\nvoid ownership_checkpoint(const char*);\n'
prepare = '''quant uint8_t x=0,y=0;quant bool control=superposition(0,1);
fourier(x);if(x&1)phase(.83);inverse_fourier(x);
fourier(y);if(y&1)phase(1.17);inverse_fourier(y);
if(control)phase(.31);
'''
cases = {
    'copy': ('', 'memcpy((void*)&y,(const void*)&x,n);', 'if(y&128)phase(.47);',
             'memset((void*)&y,0,n);', 'measure(y);measure(x);measure(control);'),
    'coherent': ('', 'if(control)memcpy((void*)&y,(const void*)&x,n);', 'if(y&128)phase(.47);',
                 'memset((void*)&y,0,n);', 'measure(y);measure(x);measure(control);'),
    'heap_free': ('quant uint8_t *p=calloc(1,1);if(!p)return 2;memcpy((void*)p,(const void*)&y,1);',
                 'memcpy((void*)p,(const void*)&x,n);', 'if(p[0]&128)phase(.47);',
                 'free((void*)p);', 'measure(y);measure(x);measure(control);'),
    'heap_shrink': ('quant uint8_t *p=calloc(2,1);if(!p)return 2;memcpy((void*)(p+1),(const void*)&y,1);',
                   'memcpy((void*)(p+1),(const void*)&x,n);', 'if(p[1]&128)phase(.47);',
                   'quant uint8_t *q=realloc((void*)p,1);if(!q)exit(2);p=q;',
                   'free((void*)p);measure(y);measure(x);measure(control);'),
    'move': ('', '', 'if(y&128)phase(.47);', 'quant uint8_t moved=x;',
             'measure(moved);measure(y);measure(control);'),
}
ax = [(1 + cmath.exp(.83j)) / 2, (1 - cmath.exp(.83j)) / 2]
ay = [(1 + cmath.exp(1.17j)) / 2, (1 - cmath.exp(1.17j)) / 2]
branches = list(itertools.product((0, 1), repeat=3))
weights = [ax[a] * ay[b] * cmath.exp(.31j*c) / math.sqrt(2) for a,b,c in branches]

def reduced_purity(state, wires):
    mask = sum(1 << wire for wire in wires)
    blocks = {}
    for basis, amplitude in state.items():
        local = sum(((basis >> wire) & 1) << bit for bit, wire in enumerate(wires))
        blocks.setdefault(basis & ~mask, {})[local] = amplitude
    rho = {}
    for block in blocks.values():
        for a, left in block.items():
            for b, right in block.items():
                rho[a,b] = rho.get((a,b), 0j) + left * right.conjugate()
    return sum(abs(value) ** 2 for value in rho.values())

totals = 0
for case, (initial, effect, phase, final, finish) in cases.items():
    path, binary = out / (case + '.c'), out / case
    allocation = ''
    if case.startswith('heap_'):
        allocation, initial = initial.split('memcpy',1)
        initial = 'memcpy' + initial
    path.write_text(header + 'int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):1;' + allocation + prepare + initial +
                    'ownership_checkpoint("before");' + effect + phase + 'ownership_checkpoint("after");' +
                    final + 'ownership_checkpoint("final");' + finish + 'return 0;}\n')
    run(case + '-compile', [str(compiler / 'build/cket'), str(path), '-O2', *links, '-o', str(binary)])
    for n in (0,1):
        log = run(case + '-n' + str(n), [str(binary), str(n)])
        points = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
        assert [p['tag'] for p in points] == ['before','after','final']
        wire_values, state, gates = {}, {0: 1+0j}, []
        purities = []
        for point in points:
            assert point['measurements'] == point['resets'] == 0
            names = {r['name']:r for r in point['registers'] if r['name'] and not r['history']}
            current = {r['id']:r for r in point['registers']}
            def assign(register, values):
                for bit, wire in enumerate(register['wires']):
                    wire_values[wire] = [(value >> bit) & 1 for value in values]
            assign(names['control'], [c for a,b,c in branches])
            assign(names.get('x', names.get('moved')), [128*a for a,b,c in branches])
            y = [128*b for a,b,c in branches]
            if case in ('copy','coherent') and point['tag'] != 'before':
                y = [128*(a if n and (case == 'copy' or c) else b) for a,b,c in branches]
                if point['tag'] == 'final' and n:
                    y = [0]*len(branches)
            assign(names['y'], y)
            for name, register in names.items():
                if name.startswith('__cket_dynamic_fill_'):
                    assign(register, [0]*len(branches))
            if point['heaps']:
                heap = point['heaps'][0]
                for slot, identity in enumerate(heap['ids']):
                    values = [0]*len(branches)
                    selected = 0 if case == 'heap_free' else 1
                    if slot == selected:
                        values = [128*(a if n and point['tag'] != 'before' else b) for a,b,c in branches]
                    assign(current[identity], values)
            alive = {wire for r in point['registers'] for wire in r['wires']}
            if case == 'coherent' and point['tag'] != 'before' and n:
                captures = [r for r in point['registers'] if r['history'] and len(r['wires']) == 1
                            and r['wires'][0] not in wire_values]
                for register in captures:
                    assign(register, [c for a,b,c in branches])
            assert alive <= wire_values.keys(), ('unmodelled live wires', case, point['tag'], alive-wire_values.keys())
            expected = {}
            for row, (a,b,c) in enumerate(branches):
                phase_bit = b
                if case != 'move' and n:
                    phase_bit = a if case != 'coherent' or c else b
                angle = 0 if point['tag'] == 'before' else .47*phase_bit
                basis = sum(wire_values[wire][row] << wire for wire in alive)
                expected[basis] = expected.get(basis, 0j) + weights[row]*cmath.exp(1j*angle)
            actual = {int(basis,0):complex(real,imag) for basis,real,imag in point['state']}
            state = reference['evolve'](state, point['gates'])
            reference['equal_states'](actual, state)
            reference['equal_states'](actual, expected)
            gates.extend(point['gates'])
            purities.append(reduced_purity(actual, names.get('x',names.get('moved'))['wires']))
            totals += 1
        inverse = [[kind,wire,mask,pattern,-angle if kind==2 else angle] for kind,wire,mask,pattern,angle in reversed(gates)]
        reference['equal_states'](reference['evolve'](state,inverse), {0:1+0j})
        print(case, n, 'PASS', 'source purities', purities, flush=True)
(out/'summary.json').write_text(json.dumps(dict(status='passed', complete_states=totals),indent=2)+'\n')
