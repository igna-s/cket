#include <quantum.h>
#include <stdlib.h>
#include <string.h>
void ownership_checkpoint(const char*);
int main(int argc,char **argv){size_t n=argc>1?strtoul(argv[1],0,10):1;quant uint8_t *p=calloc(2,1);if(!p)return 2;quant uint8_t x=0,y=0;quant bool control=superposition(0,1);
fourier(x);if(x&1)phase(.83);inverse_fourier(x);
fourier(y);if(y&1)phase(1.17);inverse_fourier(y);
if(control)phase(.31);
memcpy((void*)(p+1),(const void*)&y,1);ownership_checkpoint("before");memcpy((void*)(p+1),(const void*)&x,n);if(p[1]&128)phase(.47);ownership_checkpoint("after");quant uint8_t *q=realloc((void*)p,1);if(!q)exit(2);p=q;ownership_checkpoint("final");free((void*)p);measure(y);measure(x);measure(control);return 0;}
