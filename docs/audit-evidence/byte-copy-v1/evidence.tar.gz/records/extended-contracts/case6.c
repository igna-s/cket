#include <quantum.h>
#include <string.h>
int main(void){quant uint8_t a=7,b=0;quant uint8_t child=a-a;memcpy((void*)&child,(const void*)&b,1);unsigned result=measure(child),source=measure(a),other=measure(b);return result||source!=7||other;}
