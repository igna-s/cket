#include <quantum.h>
#include <string.h>
int main(void){quant uint8_t a=7,b=0;quant uint8_t child=b+1;memcpy((void*)&b,(const void*)&a,1);unsigned old=measure(child),result=measure(b),source=measure(a);return old!=1||result!=7||source!=7;}
