#include <quantum.h>
#include <string.h>
int main(void){uint8_t a=7;quant uint8_t b=0;memcpy((void*)&b,&a,1);return measure(b)!=7||a!=7;}
