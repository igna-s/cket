#include <quantum.h>
#include <string.h>
int main(void){quant uint8_t a=7;quant uint16_t b=0;memcpy((void*)&b,(const void*)&a,1);uint16_t r=0;uint8_t s=7;memcpy(&r,&s,1);unsigned result=measure(b),source=measure(a);return result!=r||source!=7;}
