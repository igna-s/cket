#include <quantum.h>
#include <string.h>
int main(void){quant uint8_t a=7,b=superposition(0,1);memmove((void*)&b,(const void*)&a,1);unsigned r=measure(b),s=measure(a);return r!=7||s!=7;}
