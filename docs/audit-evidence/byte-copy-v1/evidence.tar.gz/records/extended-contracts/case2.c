#include <quantum.h>
#include <string.h>
int main(void){quant uint16_t a=7,b=0;memcpy((void*)&b,(const void*)&a,1);uint16_t r=0,s=7;memcpy(&r,&s,1);unsigned result=measure(b),source=measure(a);return result!=r||source!=7;}
