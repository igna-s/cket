from pathlib import Path
import json
import os
import re
import subprocess
import sys

root = Path('/tmp/quantum-audit-isolated-20261017/build/byte-copy-delivery-v1')
text = (root / 'tests/validate_memcopy.c').read_text()
valid = text.split('const char *valid[] = {', 1)[1].split('const char *invalid[]', 1)[0].rsplit('};', 1)[0]
groups = re.findall(r'((?:"(?:[^"\\]|\\.)*"\s*)+)(?:,|$)', valid)
programs = [''.join(json.loads(token) for token in re.findall(r'"(?:[^"\\]|\\.)*"', group))
            for group in groups]
assert len(programs) == 18
directory = root / 'build/extended-contracts'
directory.mkdir()
records = []
for index, body in enumerate(programs[-7:]):
    source = directory / f'case{index}.c'
    executable = directory / f'case{index}'
    source.write_text('#include <quantum.h>\n#include <string.h>\nint main(void){' + body + '}\n')
    for label, command in (('compile', [str(root / 'build/cket'), str(source), '-O2', '-o', str(executable)]),
                            ('native', [str(executable)])):
        result = subprocess.run(command, cwd=root, env=dict(os.environ, CC='gcc-11',
                                CKET_SIMULATOR='sparse', CKET_SEED='7'), capture_output=True, text=True)
        records.append({'case': index, 'stage': label, 'exit_code': result.returncode,
                         'command': command, 'stdout': result.stdout, 'stderr': result.stderr})
        (root / 'build/extended-contracts.json').write_text(json.dumps(records, indent=2) + '\n')
        if result.returncode:
            print(json.dumps(records[-1]), flush=True)
            sys.exit(result.returncode)
print('Seven changed contracts compile and execute at O2; full GCC/state matrix deferred.')
