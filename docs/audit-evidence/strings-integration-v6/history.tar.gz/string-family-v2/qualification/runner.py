"""Fresh grouped normal/SAN qualification after development actually passes."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback

root = Path('/tmp/quantum-audit-isolated-20261017')
candidate = root / 'build/string-family-v2'
out = candidate / 'build/family-qualification-v1'
write = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
if '--worker' not in sys.argv:
    out.mkdir()
    shutil.copyfile(Path(__file__), out / 'runner.py')
    with (out / 'worker.log').open('x') as log:
        worker = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker'],
                                  cwd=candidate, stdin=subprocess.DEVNULL, stdout=log,
                                  stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'job.json', {'pid': worker.pid,
                            'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()})
    print('Started grouped string-family qualification:', worker.pid)
    raise SystemExit(0)
record = {'status': 'waiting-for-development-result', 'commands': []}
write(out / 'progress.json', record)
frozen = None

def run(name, argv, env, cwd=candidate):
    assert all(digest(candidate / path) == expected for path, expected in frozen.items())
    row = {'name': name, 'argv': list(map(str, argv)), 'log': name + '.log',
           'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    record['commands'].append(row)
    write(out / 'progress.json', record)
    with (out / row['log']).open('x') as log:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    row.update(returncode=result.returncode, log_sha256=digest(out / row['log']),
               finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(out / 'progress.json', record)
    assert result.returncode == 0, (name, result.returncode)
    print(name, 'closed zero', flush=True)

try:
    result = {'source_sha256': json.loads((candidate / 'build/sources.json').read_text())}
    assert all(digest(candidate / path) == expected for path, expected in result['source_sha256'].items())
    frozen = {path: digest(candidate / path) for path in result['source_sha256']}
    write(candidate / 'build/sources.json', frozen)
    record.update(status='running-grouped-qualification', source_sha256=frozen)
    write(out / 'progress.json', record)
    env = dict(os.environ, CC='gcc-11', CXX='g++-11')
    for configuration in ['normal', 'sanitized']:
        stage = candidate if configuration == 'normal' else candidate / 'build/sanitized-strings-v1'
        if configuration == 'normal':
            run('fresh-normal-build', ['bash', 'scripts/build.sh'], env)
            test_env = env
        else:
            source = (candidate / 'scripts/sanitize-all.sh').read_text()
            marker = '"$san_root/build/cket_tests" "$san_root"\n'
            assert source.count(marker) == 1
            source = source[:source.index(marker)].replace('cd "$(dirname "$0")/.."', 'cd ' + str(candidate))
            script = out / 'fresh-sanitized.sh'
            script.write_text(source)
            run('fresh-sanitized-build', ['bash', str(script)], dict(env, CKET_SAN_ROOT=str(stage)))
            test_env = dict(env, CC=str(stage / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11',
                            UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        for name in ['bindings', 'strings', 'native', 'controlled_operands', 'memcmp', 'strncmp', 'library', 'phase']:
            executable = stage / 'build' / ('cket_tests' if name == 'native' else 'validate_' + name)
            run(configuration + '-' + name, [str(executable)] + ([str(stage)] if name == 'native' else []), test_env, stage)
    assert all(digest(candidate / path) == expected for path, expected in frozen.items())
    record.update(status='passed-string-family-targeted', exit_code=0)
except BaseException as error:
    traceback.print_exc()
    record.update(status='failed-string-family-targeted', exit_code=1, error=repr(error))
finally:
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(out / 'exit.json', record)
raise SystemExit(record['exit_code'])
