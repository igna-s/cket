#include <quantum.h>
#include <stdlib.h>
int main(void){quant uint8_t *p=NULL;quant bool b=0;quant uint8_t x=b?p[0]++:5;unsigned got=measure(x);measure(b);return got!=5;}
