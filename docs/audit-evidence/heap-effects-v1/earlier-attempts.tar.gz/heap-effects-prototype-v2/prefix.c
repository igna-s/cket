#include <quantum.h>
#include <stdlib.h>
int main(void){quant uint8_t *p=calloc(2,sizeof *p);p[0]=3;p[1]=9;quant bool i=superposition(0,1);quant uint8_t next=++p[i];unsigned x=measure(next),j=measure(i),a=measure(p[0]),b=measure(p[1]);free((void*)p);return x!=(j?10u:4u)||a!=(j?3u:4u)||b!=(j?10u:9u);}
