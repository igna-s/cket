#include <quantum.h>
#include <stdlib.h>
int main(void){quant uint8_t *p=calloc(2,sizeof *p);size_t i=1;p[0]=3;p[1]=9;quant uint8_t next=p[i]++;unsigned x=measure(next),a=measure(p[0]),b=measure(p[1]);free((void*)p);return x!=9||a!=3||b!=10;}
