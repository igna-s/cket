#include <quantum.h>
#include <stdlib.h>
int main(void){quant uint8_t *p=calloc(2,sizeof *p);p[0]=3;p[1]=9;quant bool i=superposition(0,1);quant uint8_t old=p[i]++;free((void*)p);if(old==9)phase(.17);unsigned got=measure(old),j=measure(i);return got!=(j?9u:3u);}
