#include <quantum.h>
#include <stdlib.h>
int main(void){quant uint8_t *p=calloc(1,sizeof *p);p[0]=3;quant uint8_t x=(p[0]++,p[0]);unsigned a=measure(x),b=measure(p[0]);free((void*)p);return a!=4||b!=4;}
