from pathlib import Path
import json,os,runpy,subprocess,sys
root=Path('/tmp/quantum-audit-isolated-20261017')
project=root/'build/heap-effects-source-v1'
san=root/'build/heap-effects-sanitized-v1'
mode=sys.argv[1]
if mode=='sanitize-build':
    san.mkdir()
    prefix=(project/'scripts/sanitize-all.sh').read_text().split('\nexport CKET_REAL_GCC="$real_cc"')[0]
    prefix=prefix.replace('cd "$(dirname "$0")/.."','cd "'+str(project)+'"')
    script=san/'build-sanitized.sh'
    script.write_text(prefix+'\n')
    with (san/'build.log').open('x') as out:
        result=subprocess.run(['bash',str(script)],cwd=project,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SAN_ROOT=str(san)))
    (san/'build-exit.json').write_text(json.dumps({'exit_code':result.returncode,'command':['bash',str(script)]},indent=2)+'\n')
    print('Sanitized build',result.returncode,flush=True)
    if result.returncode:print((san/'build.log').read_text()[-3500:],flush=True)
    sys.exit(result.returncode)
assert mode in ('normal','sanitized')
target=project if mode=='normal' else san
output=root/('build/heap-effects-'+mode+'-results-v1')
output.mkdir()
env=dict(os.environ,CC='gcc-11',CXX='g++-11',CKET_SEED='7',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
levels=['O0','O2','Os'] if mode=='normal' else ['O1']
extra=[] if mode=='normal' else ['--sanitized']
if mode=='sanitized':env.update(CC=str(san/'build/gcc-wrapper'),CKET_REAL_GCC='gcc-11')
records=[]
def run(label,command,selected_env=None,diagnostic=None):
    with (output/(label+'.log')).open('x') as out:
        result=subprocess.run(command,cwd=project,env=selected_env or env,stdout=out,stderr=subprocess.STDOUT,timeout=1200)
    records.append({'label':label,'command':command,'exit_code':result.returncode,'log':label+'.log'})
    (output/'exit.json').write_text(json.dumps(records,indent=2)+'\n')
    text=(output/(label+'.log')).read_text()
    print(label,result.returncode,text[-1150:],flush=True)
    assert (result.returncode>0 and diagnostic in text) if diagnostic else result.returncode==0
if mode=='normal':run('build',['bash','scripts/build.sh'])
run('heap-matrix',['python3','scripts/validate-heap.py','--compiler-root',str(target),'--output',str(output/'matrix'),'--levels',*levels,*extra])
run('heap-engine',[str(target/'build/validate_heap')])
run('ownership-regression',['python3','scripts/validate-ownership.py','--compiler-root',str(target),'--output',str(output/'ownership'),'--levels',levels[0] if mode=='sanitized' else 'O2',*extra])
if mode=='normal':run('native-core',[str(target/'build/cket_tests'),str(target)])
for name in ('dynamic_heap','coherent_heap'):
    binary=output/name
    run(name+'-compile',[str(target/'build/cket'),str(project/'examples/blocks/05'/ (name+'.c')),'-O2' if mode=='normal' else '-O1','-o',str(binary)])
    run(name+'-run',[str(binary)],dict(env,CKET_SIMULATOR='sparse'))
if mode=='normal':
    run('block05',['bash','scripts/run-block.sh','05'])
    run('heap-static-export',[str(target/'build/cket'),'examples/blocks/05/coherent_heap.c','-O2','--emit-qasm','-o',str(output/'unsupported.qasm')],diagnostic='static export is unsupported')
    run('inventory',['python3','scripts/inventory_c11.py'])
assert runpy.run_path(str(project/'scripts/archive-audit.py'))['source_hashes']()==json.loads((project/'source-hashes.json').read_text())
print('PASS unchanged 202 frozen source inputs',flush=True)
