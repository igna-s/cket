from pathlib import Path
import hashlib,json,runpy,shutil
root=Path('/tmp/quantum-audit-isolated-20261017')
inventory=runpy.run_path(str(root/'scripts/inventory_c11.py'))
p=root/'docs/c11-library.json'
data=json.loads(p.read_text())
for row in data['interfaces']:
    if row['header']=='stdlib.h' and row['name'] in inventory['HEAP']:
        status,classes,milestone,tests,contract=inventory['semantics'](row['header'],row['name'],row['kind'],False)
        row.update(quantum=status,restriction_classes=classes,milestone=milestone,tests=tests,contract=contract)
p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
fmt=runpy.run_path(str(root/'scripts/format.py'))['format_text']
files='''src/cket_plugin.cpp src/engine/heap.inc src/engine/quantum.c src/engine/verify.c src/quantum_heap.inc src/quantum_semantics.inc tests/validate_heap.c scripts/archive-audit.py scripts/inventory_c11.py scripts/run-block.sh scripts/validate-heap.py examples/blocks/05/coherent_heap.c README.md docs/c11-library.json docs/c11-heap.md docs/c-coverage.md docs/perfil-c-cotidiano.es.md docs/estado-general-del-proyecto.es.md docs/entregas-incrementales.es.md'''.split()
for name in files:
    path=root/name
    path.write_text(fmt(path,path.read_text()))
(root/'build/heap-effects-changed-files.txt').write_text('\n'.join(files)+'\n')
sources=runpy.run_path(str(root/'scripts/archive-audit.py'))['source_hashes']()
assert len(sources)==202,len(sources)
target=root/'build/heap-effects-source-v1'
target.mkdir()
for name in sources:
    path=target/name
    path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/name,path)
(target/'.deps').symlink_to(root/'.deps',target_is_directory=True)
(target/'cket').chmod(0o755)
(target/'docs').mkdir()
shutil.copy2(root/'docs/c11-library.json',target/'docs/c11-library.json')
(target/'source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
(root/'build/heap-effects-source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
print('Formatted',len(files),'files; frozen',len(sources),'source inputs.',flush=True)
