import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
r = Path('/tmp/quantum-audit-isolated-20261017')
mode = sys.argv[1]
source = r / 'build/return-reference-source-v1'
target = source if mode == 'normal' else r / 'build/return-reference-sanitized-v1'
base = r / ('build/single-fill-source-v2' if mode == 'normal' else 'build/single-fill-sanitized-v2')
out = r / ('build/return-reference-' + mode + '-results-v1')
out.mkdir()
if mode == 'sanitized':
    target.mkdir()
    for name in ('src', 'include', 'tests', 'examples', '.deps'):
        (target / name).symlink_to(source / name, target_is_directory=True)
    shutil.copy2(source / 'cket', target / 'cket')
(target / 'build').mkdir()
reused = {}
for name in ('cket', 'cket_backend', 'cket_plugin.so', 'libcket_quantum.a', 'cket_runtime.o', 'gcc-version.txt',
             *(['gcc-wrapper'] if mode == 'sanitized' else [])):
    shutil.copy2(base / 'build' / name, target / 'build' / name)
    reused[name] = hashlib.sha256((target / 'build' / name).read_bytes()).hexdigest()
flags = ['-O2'] if mode == 'normal' else ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-fno-pie', '-no-pie']
env = dict(os.environ, CC='gcc-11')
if mode == 'sanitized':
    env.update(CC=str(target / 'build/gcc-wrapper'), CKET_REAL_GCC='gcc-11', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
records = []
for name in ('validate_memory_returns', 'validate_pointer_differences'):
    commands = [('build', ['gcc-11', '-std=c11', *flags, '-Wall', '-Wextra', '-Werror',
        '-I' + str(source / 'src/engine'), str(source / 'tests' / (name + '.c')), str(source / 'tests/validation.c'),
        str(target / 'build/libcket_quantum.a'), '-lm', '-o', str(target / 'build' / name)]),
        ('run', [str(target / 'build' / name)])]
    for action, command in commands:
        z = subprocess.run(command, cwd=source, env=env, text=True, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=900)
        label = name + '-' + action
        (out / (label + '.log')).write_text(z.stdout)
        records.append(dict(command=command, exit_code=z.returncode, log=label + '.log'))
        (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
        print(mode, label, z.returncode, z.stdout[-2200:], flush=True)
        assert z.returncode == 0, z.stdout
        assert not any(x in z.stdout for x in ('ERROR: AddressSanitizer', 'runtime error:', 'internal compiler error:'))
(out / 'build-reuse.json').write_text(json.dumps(dict(artifact_sha256=reused,
    scope='Production compiler, engine and runtime unchanged from 8e65d2a; exact binaries reused, only the two validators rebuilt.'), indent=2) + '\n')
hashes = json.loads((source / 'source-hashes.json').read_text())
assert all(hashlib.sha256((source / n).read_bytes()).hexdigest() == h for n, h in hashes.items())
(out / 'summary.json').write_text(json.dumps(dict(status='passed', mode=mode, source_files=237,
    memory_returns=290, pointer_differences=170, word_channel_gate_inverse_contexts=40,
    boolean_saved_inverse_contexts=60, pointer_saved_inverse_contexts=40), indent=2) + '\n')
