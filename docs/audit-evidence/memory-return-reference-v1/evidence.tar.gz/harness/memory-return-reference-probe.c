#define main maintained_memory_return_main
#include "../tests/validate_memory_returns.c"
#undef main

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    char *text = qc_read_file(argv[1]);
    if (!text) return 1;
    unsigned maximum = 0;
    unsigned count = memory_return_state_probe(text, 2, &maximum);
    free(text);
    printf("%u word reference contexts passed\n", count);
    return 0;
}
