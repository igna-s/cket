import copy, json, os, re, subprocess
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/memory-return-reference-preview-v2'
out = r / 'build/memory-return-reference-contracts-v1'
out.mkdir()
env = dict(os.environ, CC='gcc-11')
source = (r / 'tests/validate_memory_returns.c').read_text()
start = source.index('{"word-coherent",')
end = source.index('NULL}', start)
parts = re.findall(r'"(?:\\.|[^"\\])*"', source[start:end])
program = ''.join(json.loads(p) for p in parts[1:])
assert 'superposition(0, 65535)' in program
(out / 'word.c').write_text(program)
records = []

def run(name, command, status=0, diagnostic=None):
    z = subprocess.run(command, env=env, text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=180)
    (out / (name + '.log')).write_text(z.stdout)
    records.append(dict(command=command, exit_code=z.returncode, log=name + '.log', expected_diagnostic=diagnostic))
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    assert z.returncode == status, z.stdout
    if diagnostic:
        assert diagnostic in z.stdout, z.stdout
    assert not any(s in z.stdout for s in ('AddressSanitizer', 'runtime error:', 'internal compiler error:'))
    print(name, z.returncode, z.stdout[-500:], flush=True)

driver = out / 'probe'
run('probe-build', ['gcc-11', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
    '-I' + str(r / 'src/engine'), str(r / 'build/memory-return-reference-probe.c'),
    str(r / 'tests/validation.c'), str(project / 'build/libcket_quantum.a'), '-lm', '-o', str(driver)])
run('compile-word', [str(project / 'build/cket'), str(out / 'word.c'), '--emit-ir',
                     '-O2', '-o', str(out / 'valid.json')])
run('valid', [str(driver), str(out / 'valid.json')])
valid = json.loads((out / 'valid.json').read_text())
instructions = valid['instructions']
stop = next(i for i, op in enumerate(instructions) if op['op'] == 'qmeasure')
owner = instructions[stop]['id']
mutations = {}
wrong_value = copy.deepcopy(valid)
wrong_value['instructions'].insert(stop, dict(op='qxor_inplace', id=owner, value=1))
mutations['wrong-value'] = (wrong_value, 'word C value/phase/private-zero mismatch')
wrong_phase = copy.deepcopy(valid)
last_phase = next(op for op in reversed(wrong_phase['instructions'][:stop]) if op['op'] == 'qphase')
last_phase['angle'] += .1
mutations['wrong-phase'] = (wrong_phase, 'word C value/phase/private-zero mismatch')
cloned_low = copy.deepcopy(valid)
new_id = max(op.get('id', 0) for op in instructions) + 1
cloned_low['instructions'][stop:stop] = [
    dict(op='qalloc', id=new_id, width=8, signed=False, ancilla=True),
    dict(op='qcompute', id=new_id, expr=dict(op='cast', bits=8, signed=False,
         args=[dict(op='reg', id=owner, bits=16, signed=False)])),
    dict(op='qmaterialize', id=new_id, optional=False), dict(op='qretain', id=new_id),
]
mutations['redundant-low-history'] = (cloned_low, 'history copied an untouched byte')
for name, (document, diagnostic) in mutations.items():
    path = out / (name + '.json')
    path.write_text(json.dumps(document, indent=2) + '\n')
    run(name, [str(driver), str(path)], 1, diagnostic)
(out / 'summary.json').write_text(json.dumps(dict(status='passed', positive_contexts=2,
    semantic_mutations_rejected=3, scope='Reference effectiveness: unchanged valid word case passes both synthesis policies; valid unitary mutations of public value, phase and redundant untouched-byte history fail the C contract. Normal harness only; no general compiler proof.'), indent=2) + '\n')
