import json, runpy, shutil
from pathlib import Path
r = Path('/tmp/quantum-audit-isolated-20261017')
fmt = runpy.run_path(str(r / 'scripts/format.py'))['format_text']
for name in ('tests/memory_return_state.inc', 'tests/validate_memory_returns.c'):
    p = r / name
    p.write_text(fmt(p, p.read_text()))
hashes = runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']()
base = json.loads((r / 'build/single-fill-source-v2/source-hashes.json').read_text())
assert len(hashes) == 237 and sorted(n for n in hashes if hashes[n] != base[n]) == [
    'tests/memory_return_state.inc', 'tests/validate_memory_returns.c']
project = r / 'build/return-reference-source-v1'
project.mkdir()
for name in hashes:
    p = project / name
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(r / name, p)
(project / '.deps').symlink_to(r / '.deps', target_is_directory=True)
(project / 'cket').chmod(0o755)
shutil.copy2(r / 'LICENSE', project / 'LICENSE')
(project / 'source-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
print('Frozen 237 inputs; only two reference/validator files changed')
