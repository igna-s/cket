import hashlib, io, json, runpy, tarfile
from pathlib import Path

r = Path('/tmp/quantum-audit-isolated-20261017')
project = r / 'build/return-reference-source-v1'
source = json.loads((project / 'source-hashes.json').read_text())
base = json.loads((r / 'build/single-fill-source-v2/source-hashes.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert len(source) == 237
assert sorted(n for n in source if source[n] != base[n]) == ['tests/memory_return_state.inc', 'tests/validate_memory_returns.c']
assert runpy.run_path(str(r / 'scripts/archive-audit.py'))['source_hashes']() == source
campaigns = {}
for mode, target, original in [('normal', project, r / 'build/single-fill-source-v2'),
    ('sanitized', r / 'build/return-reference-sanitized-v1', r / 'build/single-fill-sanitized-v2')]:
    out = r / ('build/return-reference-' + mode + '-results-v1')
    result = json.loads((out / 'summary.json').read_text())
    assert result['status'] == 'passed' and result['memory_returns'] == 290 and result['pointer_differences'] == 170
    assert all(x['exit_code'] == 0 for x in json.loads((out / 'commands.json').read_text()))
    assert '40 word C channels/phases and independent complete gate inverses' in (out / 'validate_memory_returns-run.log').read_text()
    assert '170 pointer difference checks passed' in (out / 'validate_pointer_differences-run.log').read_text()
    reuse = json.loads((out / 'build-reuse.json').read_text())
    assert all(sha(target / 'build' / n) == sha(original / 'build' / n) == h for n,h in reuse['artifact_sha256'].items())
    campaigns[mode] = dict(result=result, build_reuse=reuse)
contracts = r / 'build/memory-return-reference-contracts-v1'
assert json.loads((contracts / 'summary.json').read_text())['semantic_mutations_rejected'] == 3
sdk = r / 'output/sdk'
audit = json.loads((sdk / 'sdk-audit.json').read_text())
assert audit['source_sha256'] == source and audit['prebuilt_programs'] == 37 and audit['example_checks'] == 1509
assert sha(sdk / 'cket-sdk-linux-x86_64.tar.gz') == audit['package_sha256']
assert all(row['exit_code'] == 0 for row in audit['commands'])
assert len(audit['windows_launchers']) == 3 and all(row['exit_code'] == 0 for row in audit['windows_launchers'])
assert 'restored=0 values=3,5 word=1366 words=291,1110' in audit['windows_launchers'][1]['stdout']
assert 'rounds=3 output=12 sum=30' in audit['windows_launchers'][2]['stdout']
for name in ('cket','cket_backend','cket_plugin.so','libcket_quantum.a','cket_runtime.o','gcc-version.txt'):
    assert sha(project/'build'/name) == audit['package_files_sha256']['build/'+name]
assert sha(sdk/'example_functions.c') == source['examples/blocks/03/cpu_vector_return.c']
assert sha(sdk/'example_heap.c') == source['examples/blocks/05/heap_iterations.c']
destination = r / 'docs/audit-evidence/memory-return-reference-v1'
assert not (destination / 'summary.json').exists()
docs = ['README.md', 'docs/estado-general-del-proyecto.es.md', 'docs/c11-memory-returns.md',
        'docs/entrega-utilizable-2026-10-26.es.md', 'docs/audit-evidence/memory-return-reference-v1/README.es.md']
fmt = runpy.run_path(str(r / 'scripts/format.py'))['format_text']
for name in docs + ['output/sdk/README.es.md','output/sdk/sdk-audit.json']:
    p = r / name
    p.write_text(fmt(p, p.read_text()))

def tree(tar, folder, prefix):
    for p in sorted(folder.rglob('*')):
        if p.is_file() and p.suffix in ('.c','.json','.log','.py','.sh','.txt'):
            tar.add(p,arcname=prefix+'/'+p.relative_to(folder).as_posix())

def raw(tar,name,value):
    data=(json.dumps(value,indent=2)+'\n').encode()
    entry=tarfile.TarInfo(name);entry.size=len(data);tar.addfile(entry,io.BytesIO(data))

with tarfile.open(destination/'evidence.tar.gz','w:gz') as tar:
    for name in source: tar.add(project/name,arcname='sources/'+name)
    raw(tar,'source-identities.json',dict(qualified=source,previous=base))
    for mode in ('normal','sanitized'):
        tree(tar,r/('build/return-reference-'+mode+'-results-v1'),'results/'+mode)
    tree(tar,contracts,'reference-contracts')
    tree(tar,r/'build/memory-return-history-baseline-v1','previous-failure')
    tree(tar,r/'build/memory-return-history-inspect-v1','previous-state-inspection')
    tree(tar,r/'build/usable-sdk-results-v1','sdk-results')
    for name in ('sdk-audit.json','README.es.md','extract_sdk.cmd','run_sdk_demo.cmd','compile_and_run.cmd','example_functions.c','example_heap.c'):
        tar.add(sdk/name,arcname='sdk/'+name)
    for name in ('sdk-windows-demo-final.log','sdk-windows-functions.log','sdk-windows-heap.log'):
        tar.add(r/'build'/name,arcname='sdk-windows/'+name)
    for name in ('prepare-return-reference-final.py','qualify-return-reference.py','check-memory-return-reference.py',
                 'memory-return-reference-probe.c','package-usable-sdk.py','finalize-return-reference-sdk.py'):
        tar.add(r/'build'/name,arcname='harness/'+name)
    tar.add(r/'build/single-fill-source-v2/tests/memory_return_state.inc',arcname='previous/memory_return_state.inc')
summary = dict(status='passed-memory-return-references-and-native-sdk-with-open-general-integration',date='2026-10-26',
    base_commit='8e65d2a',version='1.0.0-rc.3',compiler_input_files=237,source_sha256=source,
    changed_inputs=['tests/memory_return_state.inc','tests/validate_memory_returns.c'],production_sources_changed=False,
    campaigns=campaigns,reference_effectiveness=dict(positive_contexts=2,semantic_mutations_rejected=3,configuration='normal harness'),
    sdk=dict(package_sha256=audit['package_sha256'],prebuilt_programs=37,example_checks=1509,windows_workflows_verified=3,
             source_files=237,source_metadata='../../../output/sdk/sdk-audit.json'),
    scope='Finite word C values/phases/history classes and independent complete gate inversion; Boolean saved-inverse checks unchanged. Labeled action through 49 physical wires, not dense 49-qubit simulation. Native SDK demos and compilation workflow. Remaining normal sweep, complete sanitized integration, everyday-C, general papers and QPU qualification remain open. Cybersecurity remains classical.',
    artifact_sha256={'evidence.tar.gz':sha(destination/'evidence.tar.gz')})
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
names=sorted(set(source)|set(docs)|{p.relative_to(r).as_posix() for p in sdk.iterdir() if p.is_file()}|
    {'docs/audit-evidence/memory-return-reference-v1/summary.json','docs/audit-evidence/memory-return-reference-v1/evidence.tar.gz'})
(r/'build/return-reference-sdk-git-expected.json').write_text(json.dumps({n:sha(r/n) for n in names},indent=2)+'\n')
imports=sorted((set(names)-set(source))|{'tests/memory_return_state.inc','tests/validate_memory_returns.c','build/return-reference-sdk-git-expected.json'})
(r/'build/return-reference-sdk-import.txt').write_text('\n'.join(imports)+'\n')
print('Publication ready:',len(names),'exact files; SDK and reference evidence closed')
