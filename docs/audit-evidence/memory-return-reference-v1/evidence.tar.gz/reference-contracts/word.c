#include <quantum.h>
#include <string.h>

int main(void) {
    quant uint16_t x = superposition(0, 65535);
    if (x & 1)
        phase(1.0000000000000001e-05);
    if (x & 2)
        phase(2.0000000000000002e-05);
    if (x & 4)
        phase(4.0000000000000003e-05);
    if (x & 8)
        phase(8.0000000000000007e-05);
    if (x & 16)
        phase(0.00016000000000000001);
    if (x & 32)
        phase(0.00032000000000000003);
    if (x & 64)
        phase(0.00064000000000000005);
    if (x & 128)
        phase(0.0012800000000000001);
    if (x & 256)
        phase(0.0025600000000000002);
    if (x & 512)
        phase(0.0051200000000000004);
    if (x & 1024)
        phase(0.010240000000000001);
    if (x & 2048)
        phase(0.020480000000000002);
    if (x & 4096)
        phase(0.040960000000000003);
    if (x & 8192)
        phase(0.081920000000000007);
    if (x & 16384)
        phase(0.16384000000000001);
    if (x & 32768)
        phase(0.32768000000000003);
    void *p = memset((char *)&x + 1, 0xab, 1);
    memset(p, 0xcd, 1);
    if (x == 0xcd34)
        phase(.17);
    measure(x);
    return p != (char *)&x + 1;
}
