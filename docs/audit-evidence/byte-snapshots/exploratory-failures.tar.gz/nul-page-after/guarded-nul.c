#define _POSIX_C_SOURCE 200809L
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#ifdef __CKET__
#include <quantum.h>
#else
#define quant
#define measure(value) (value)
#endif
_Alignas(4096) static unsigned char reference[8192];
int main(void) {
    if (sysconf(_SC_PAGESIZE)!=4096) abort();
    reference[4095]=0;
    if (mprotect(reference+4096,4096,PROT_NONE)) abort();
    quant uint16_t input=0;
    quant bool result=strncmp((const char*)&input,(const char*)reference+4095,2)<=0;
    if (mprotect(reference+4096,4096,PROT_READ|PROT_WRITE)) abort();
    unsigned actual=measure(result);measure(input);
    return actual!=1;
}
